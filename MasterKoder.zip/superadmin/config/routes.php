<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['superadmin'] 			= 'home';
$route['superadmin/dashboard'] 	= 'home';
$route['superadmin/dashboard/posts'] 	= 'home/posts';
$route['superadmin/dashboard/quiz'] 	= 'home/quiz';
$route['superadmin/dashboard/reports'] 	= 'home/reports';
$route['superadmin/dashboard/feedback'] 	= 'home/feedback';

$route['superadmin/subcategory/topics/(:num)']  		= 'topics/index/$1';
$route['superadmin/subcategory/topics'] 				= 'topics';

$route['superadmin/subcategory/topics/subtopics/(:num)']  		= 'subtopics/index/$1';
$route['superadmin/subcategory/topics/subtopics/add/(:num)']  	= 'subtopics/add/$1';

$route['superadmin/subcategory/topics/add/(:num)']  = 'topics/add/$1';
$route['superadmin/subcategory/topics/add'] 		= 'topics/add';
$route['superadmin/subcategory/exam/(:num)']  		= 'exam/index/$1';
$route['superadmin/subcategory/exam/add/(:num)']  	= 'exam/add/$1';

$route['superadmin/subcategory/(:num)']  			= 'subcategory/details/$1';

$route['superadmin/vehicle_subcategory/(:num)']     = 'vehicle_subcategory/index/$1';
$route['superadmin/current-affairs']                = 'currentaffairs/index';
$route['superadmin/current-affairs/add']            = 'currentaffairs/add';


$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
