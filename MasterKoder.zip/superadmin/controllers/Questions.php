<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Questions extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('form_validation'));
			$this->load->model(array('db_model', 'question_model'));
			$this->user = $this->session->userdata($this->session_name);
		}	
	}

	public function index($course_id = 0){
		redirect(admin_url('courses'), 'refresh');
	}





	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('tbl_exams_questions', $data, 'id_question', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Question status updated successfully', 'function'=> 'refreshQuestionsTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('exam'), 'refresh');
		}		
	}



	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('tbl_exams_questions', $data, 'id_question', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Question status updated successfully', 'function'=> 'refreshQuestionsTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('exam'), 'refresh');
		}		
	}



	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_exams_questions', 'id_question', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Question status updated successfully', 'function'=> 'refreshQuestionsTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('exam'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Question Details', 'fun' => 3),
								array('tag' => '#infoModal .modal-body',  'data' => $this->get_data($this->input->post('id')), 'fun' => 0)
			);
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('courses'), 'refresh');
		}		
	}

	private function get_data($id = 0){
    	if(!empty($id)){
    		$question_data  	= $this->question_model->get_single($id);
	    	if(count($question_data) > 0){
			    $data   =  '<div style="background-color : #ecf0f5; padding: 30px 5px 1px 5px; margin: 0; display: block;">
			    				<ul class="timeline">
							   
							    <li>
							        <i class="fa fa-question bg-blue"></i>
							        <div class="timeline-item">
							            <h3 class="timeline-header"><a href="#">'.$question_data->question_name.'</a></h3>';
							            if(!empty($question_data->question_image)):
							            	$data   .=  '<div class="timeline-body">
						                  			<img src="'.base_url($question_data->question_upload_path.$question_data->question_image).'" alt="'.$question_data->question_image.'" class="margin img-responsive">
						                	</div>';
						            	endif;

							$data   .=  '</div>

							    </li>
							   
							    <li>
							        <i class="fa '.(($question_data->question_answer == 1)? "fa-check bg-green" : "fa-info bg-gray").'"></i>
							        <div class="timeline-item">
							            <h4 class="timeline-header">'.$question_data->question_option_1.'</h4>';
							            if(!empty($question_data->question_option_1_image)):
							            	$data   .=  '<div class="timeline-body">
						                  			<img src="'.base_url($question_data->question_upload_path.$question_data->question_option_1_image).'" alt="'.$question_data->question_option_1_image.'" class="margin img-responsive">
						                	</div>';
						            	endif;
							        $data   .=  '</div>
							    </li>



							    <li>
							        <i class="fa '.(($question_data->question_answer == 2)? "fa-check bg-green" : "fa-info bg-gray").'"></i>
							        <div class="timeline-item">
							            <h4 class="timeline-header">'.$question_data->question_option_2.'</h4>';
							            if(!empty($question_data->question_option_2_image)):
							            	$data   .=  '<div class="timeline-body">
						                  			<img src="'.base_url($question_data->question_upload_path.$question_data->question_option_2_image).'" alt="'.$question_data->question_option_2_image.'" class="margin img-responsive">
						                	</div>';
						            	endif;
							        $data   .=  '
							        </div>
							    </li>



							    <li>
							        <i class="fa '.(($question_data->question_answer == 3)? "fa-check bg-green" : "fa-info bg-gray").'"></i>
							        <div class="timeline-item">
							            <h4 class="timeline-header">'.$question_data->question_option_3.'</h4>';
							            if(!empty($question_data->question_option_3_image)):
							            	$data   .=  '<div class="timeline-body">
						                  			<img src="'.base_url($question_data->question_upload_path.$question_data->question_option_3_image).'" alt="'.$question_data->question_option_3_image.'" class="margin img-responsive">
						                	</div>';
						            	endif;
							        $data   .=  '
							        </div>
							    </li>



							    <li>
							        <i class="fa '.(($question_data->question_answer == 4)? "fa-check bg-green" : "fa-info bg-gray").'"></i>
							        <div class="timeline-item">
							            <h4 class="timeline-header">'.$question_data->question_option_4.'</h4>';
							            if(!empty($question_data->question_option_4_image)):
							            	$data   .=  '<div class="timeline-body">
						                  			<img src="'.base_url($question_data->question_upload_path.$question_data->question_option_4_image).'" alt="'.$question_data->question_option_4_image.'" class="margin img-responsive">
						                	</div>';
						            	endif;
							        $data   .=  '
							        </div>
							    </li>
							 <li>
							    <i class="fa '.(($question_data->question_answer == 5)? "fa-check bg-green" : "fa-info bg-gray").'"></i>
							        <div class="timeline-item">
							            <h4 class="timeline-header">'.$question_data->question_option_5.'</h4>';
							            if(!empty($question_data->question_option_5_image)):
							            	$data   .=  '<div class="timeline-body">
						                  			<img src="'.base_url($question_data->question_upload_path.$question_data->question_option_5_image).'" alt="'.$question_data->question_option_4_image.'" class="margin img-responsive">
						                	</div>';
						            	endif;
							        $data   .=  '
							        </div>
							    </li>
							</ul></div>';
				return $data;
		    }
    	}
	}

}