<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Defaultimages extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('advertizement_model', 'db_model'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'category_slug',
							'title' => 'category_name',
							'table' => 'tbl_categories',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}

	public function index(){
	if (!has_permission('defaultimages', 'dashboard_view')) {
         redirect(admin_url('login'), 'refresh');
    }
		$data['page']  		= 'defaultimages';
		$data['script']  	= 1;
		$this->myadmin->view('defaultimages/home', $data);
	}
    function updateimages()
	{
		if (!has_permission('defaultimages', 'update')) {
         redirect(admin_url('login'), 'refresh');
		}	
			      if(!empty($_FILES['postimage']['name'])){
				 
				    $fileTmpLoc = $_FILES['postimage']['name'];
				 		if(file_exists("assets/images/default_article.png"))
						
						unlink("assets/images/default_article.png");
                     
                        move_uploaded_file($_FILES['postimage']['tmp_name'], "assets/images/default_article.png");
						$return  	= array('has_error'=>0, 'page'=> admin_url('defaultimages'), 'message' => 'Post Default Image Updated successfully'
						,'function'=> 'refreshtable');
				 }	
			    if(!empty($_FILES['quizimage']['name'])){
				 
				    $fileTmpLoc = $_FILES['quizimage']['name'];
				 		if(file_exists("assets/images/default_quiz.png"))
						
						unlink("assets/images/default_quiz.png");
                     
                        move_uploaded_file($_FILES['quizimage']['tmp_name'], "assets/images/default_quiz.png");
						$return  	= array('has_error'=>0, 'page'=> admin_url('defaultimages'), 'message' => 'Quiz Default Image Updated successfully',
						'function'=> 'refreshtable');
				 }	
				  if(!empty($_FILES['syllabusimage']['name'])){
				 
				    $fileTmpLoc = $_FILES['syllabusimage']['name'];
				 		if(file_exists("assets/images/default_syllabus.png"))
						
						unlink("assets/images/default_syllabus.png");
                     
                        move_uploaded_file($_FILES['syllabusimage']['tmp_name'], "assets/images/default_syllabus.png");
						$return  	= array('has_error'=>0,'page'=> admin_url('defaultimages'), 'message' => 'Syllbus Default Image Updated successfully',
						'function'=> 'refreshtable');
				 }	
				   if(!empty($_FILES['notesimage']['name'])){
				 
				    $fileTmpLoc = $_FILES['notesimage']['name'];
				 		if(file_exists("assets/images/default_notes.png"))
						
						unlink("assets/images/default_notes.png");
                     
                        move_uploaded_file($_FILES['notesimage']['tmp_name'], "assets/images/default_notes.png");
						$return  	= array('has_error'=>0,'page'=> admin_url('defaultimages'), 'message' => 'Notes Default Image Updated successfully',
						'function'=> 'refreshtable');
				 }	
				 if(!empty($_FILES['studyplanimage']['name'])){
				 
				    $fileTmpLoc = $_FILES['studyplanimage']['name'];
				 		if(file_exists("assets/images/default_studyplan.png"))
						
						unlink("assets/images/default_studyplan.png");
                     
                        move_uploaded_file($_FILES['studyplanimage']['tmp_name'], "assets/images/default_studyplan.png");
						$return  	= array('has_error'=>0,'page'=> admin_url('defaultimages'), 'message' => 'Study Plan Default Image Updated successfully',
						'function'=> 'refreshtable');
				 }	
			     if(!empty($_FILES['examdetailsimage']['name'])){
				 
				    $fileTmpLoc = $_FILES['examdetailsimage']['name'];
				 		if(file_exists("assets/images/default_examdetails.png"))
						
						unlink("assets/images/default_examdetails.png");
                     
                        move_uploaded_file($_FILES['examdetailsimage']['tmp_name'], "assets/images/default_examdetails.png");
						$return  	= array('has_error'=>0,'page'=> admin_url('defaultimages'), 'message' => 'Study Plan Default Image Updated successfully',
						'function'=> 'refreshtable');
				 }	
			echo json_encode($return);
	}
	
}