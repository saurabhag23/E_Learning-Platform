<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Membership_plans extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('membershipmodel', 'db_model'));
			$this->user = $this->session->userdata($this->session_name);
		}	
	}

	public function index(){
		$data['page']  		= 'membership';
		$data['script']  	= 1;
		$this->myadmin->view('membership/home', $data);
	}

	public function get_all_datas(){
		echo $this->membershipmodel->all_datas();
	}

	public function add(){
	    $data['script']  	= 1;
		$data['page']  		= 'membership';
	    $this->myadmin->view('membership/add', $data);
	}

	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
		
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_message('is_unique', 'The {field} already exsist, try another one');	
			$this->form_validation->set_rules('title', 'Membership title', 'trim|required');
			$this->form_validation->set_rules('duration', 'Membership Duration', 'trim|required');
			$this->form_validation->set_rules('duration_slug', 'Duration Slug ', 'trim|required');
			$this->form_validation->set_rules('features[0]', 'Membership Features', 'trim|required');
			$this->form_validation->set_rules('amount', 'Membership Amount', 'trim|required');
			$this->form_validation->set_rules('courselimit', 'Course Limit', 'trim|required');
			

			if ($this->form_validation->run() == FALSE) {
		        $error['title'] 	    = form_error('title');
				$error['features'] 	    = form_error('features[0]');
				$error['amount'] 		= form_error('amount');
				$error['duration'] 		= form_error('duration');
				$error['duration_slug'] = form_error('duration_slug');
				$error['courselimit'] 	= form_error('courselimit');
			    $return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['membership_title']	 = addslashes($this->input->post('title'));
				$data['duration']	 = addslashes($this->input->post('duration'));
				$data['duration_slug']	 = $this->input->post('duration_slug');
				$data['course_limit']	 = $this->input->post('courselimit');
				$data['membership_amount']	 = addslashes($this->input->post('amount'));
				$data['added_user']		    = $this->user->id;
				$data['added_date']		    = date("Y-m-d H:i:s");
				$invoice_id = $this->db_model->insert('tbl_membership', $data);
				 
				foreach($_POST['features'] as $features)
				{
					$data2['membership_id'] = $invoice_id;
					$data2['feature'] = $features ;
					
					if(!empty($features))
					{
						$this->db_model->insert('tbl_membership_features', $data2);
					}
				}
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('membership_plans'), 'message' => 'Membership Plan added successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('membership_plans'), 'refresh');
		}
	}

	public function edit($id = 0){
		if(!empty($id)){
			$data['page']  		= 'membership';
			$data['script']  	= 1;
			$data['row']  		= $this->membershipmodel->get_single($id);
			$data['features'] 	= $this->membershipmodel->get_membershipfeatures($id);
			$this->myadmin->view('membership/edit', $data);
		}
		else{
			redirect(admin_url('membership_plans'), 'refresh');
		}
	}

	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_message('is_unique', 'The {field} already exsist, try another one');	
			$this->form_validation->set_rules('title', 'Membership title', 'trim|required');
			$this->form_validation->set_rules('duration', 'Membership Duration', 'trim|required');
			$this->form_validation->set_rules('duration_slug', 'Duration Slug ', 'trim|required');
			//$this->form_validation->set_rules('features[]', 'Membership Features', 'trim|required');
			$this->form_validation->set_rules('amount', 'Membership Amount', 'trim|required');
			$this->form_validation->set_rules('courselimit', 'Course Limit', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
		       $error['amount'] 		= form_error('amount');
				$error['duration'] 		= form_error('duration');
				$error['duration_slug'] = form_error('duration_slug');
				$error['courselimit'] 	= form_error('courselimit');
				//$error['features'] 	    = form_error('features');
			    $return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['membership_title']	 = addslashes($this->input->post('title'));
				$data['duration']	 = addslashes($this->input->post('duration'));
				$data['duration_slug']	 = $this->input->post('duration_slug');
				$data['course_limit']	 = $this->input->post('courselimit');
				$data['membership_amount']	 = addslashes($this->input->post('amount'));
				
				$invoice_id = $this->db_model->update('tbl_membership', $data, 'id', $this->input->post('id')); 
				$this->membershipmodel->deletefeature($this->input->post('id'));
				foreach($_POST['features'] as $features)
				{
					$data2['membership_id'] = $this->input->post('id');
					$data2['feature'] = $features ;
					
					if(!empty($features))
					{
						$this->db_model->insert('tbl_membership_features', $data2);
					}
				}
				$return  	= array('has_error'=>0, 'page'=> admin_url('membership_plans'), 'message' => 'Membership Plan updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('membership_plans'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('tbl_membership', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'User status updated successfully', 'function'=> 'refreshMembershipTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('membership_plans'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('tbl_membership', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'User status updated successfully', 'function'=> 'refreshMembershipTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('membership_plans'), 'refresh');
		}		
	}

	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_membership', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'User deleted successfully', 'function'=> 'membershipTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('membership_plans'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');
			$row 		= $this->membershipmodel->get_single($this->input->post('id'));
			$features 		= $this->membershipmodel->get_membershipfeatures($this->input->post('id'));
			
			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
			    $html = '';
			    $html.='<table class="table table-bordered">
						  <thead>
							
						  </thead>
						  <tbody>';
						 
						  
						  $html.='<tr>
								 <td>Membership Title</td>
								  <td>'.$row->membership_title.'</td>
								</tr>
								<tr>
								 <td>Membership Duration</td>
								  <td>'.$row->duration.'</td>
								</tr>
								<tr>
								 <td>Membership Amount</td>
								  <td>'.$row->membership_amount.' '.$row->duration_slug.'</td>
								</tr>
								  <td>Course Limit</td>
								  <td>'.$row->course_limit.'</td>
								</tr>';
								if(!empty($features))
								{
								$i = 1;
								foreach($features as $row2)
								{
								$html.='</tr>
								        <td>feature '.$i.'</td>
								        <td>'.$row2->feature.'</td>
								     </tr>';
								$i++;
								}
								}
						 
				  $html.='</tbody>
						</table>';
				
				
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Membership plans', 'fun' => 3),
				                array('tag' => '#infoModal .modal-body',  'data' => $html, 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('users'), 'refresh');
		}		
	}
}