<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Feedback extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->helper('form');
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('user_model', 'db_model','GeneralModel','feedback_model'));
			$this->user = $this->session->userdata($this->session_name);
		}

	}

	public function add(){
		$data['page']  = 'mentor';
		$data['page1']  = 'feedback';
		$data['script']  	= 1;		
			
		$data['tbl_categories']=$this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');

		
	    $this->myadmin->view('feedback/add', $data);
	}
	
	public function addsub(){
		
/* $post = $this->input->post();

echo "<hr><pre>post: ";
var_dump( $post );
exit; */
		
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('title', 'Feedback Title', 'trim|required');
			$this->form_validation->set_rules('type', 'Feedback Type', 'trim|required');
			$this->form_validation->set_rules('parent', 'Super Category', 'trim|required');


			if ($this->form_validation->run() == FALSE) {
			 
				$error['title'] 			= form_error('title');
				$error['type'] 	= form_error('type');
				$error['parent'] 	= form_error('parent');

				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
			   
				$save_pub = $this->input->post('save_pub');
				
								
				$idata['title'] = $this->input->post('title');
				$idata['type'] = $this->input->post('type');
				$idata['parent'] = $this->input->post('parent');
				$idata['created_on'] = date('Y-m-d');
				$idata['status'] = ( $save_pub == '1' ) ? 'A' : 'D' ;			
								
				$fid = $this->GeneralModel->AddNewRow( "feedback", $idata );
				
				$opt = $this->input->post('opt');
				$optlet = $this->input->post('optlet');
				$star_rat = $this->input->post('star_rat');
				$txt_input = $this->input->post('txt_input');
				
				if( !empty( $opt ) )
				{	
					for( $i = 0 ; $i < count( $opt ) ; $i++ )
					{	
						$srat = ( !empty( $star_rat[ $i ] ) && $star_rat[ $i ] != 'null' && $star_rat[ $i ] != null ) ? $star_rat[ $i ] : 'N' ;
						$tinp = ( !empty( $txt_input[ $i ] ) && $txt_input[ $i ] != 'null' && $txt_input[ $i ] != null ) ? $txt_input[ $i ] : 'N' ;
						
						$idata = array();
						$idata['fid'] = $fid;
						$idata['opt_name'] = $opt[ $i ];
						$idata['feed_optlet'] = $optlet[ $i ];
						$idata['star_rat'] = $srat;
						$idata['txt_input'] = $tinp;
						
						$this->GeneralModel->AddNewRow( "feedback_opt", $idata );
					}
				}
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('feedback'), 'message' => 'Feedback inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('feedback/add'), 'refresh');
		}
	}
		
	public function index(){
		$data['page']  		= 'mentor';
		$data['page1']  		= 'feedback';
		$data['script']  	= 1;
	    $this->myadmin->view('feedback/list', $data);
	}
	
	public function viewopt( $id, $optlet ){

		$data['page']  		= 'level1';
		$data['page1']  	= 'feedback';
		$data['script']  	= 1;				
		$data['roles']  	= $this->user_model->get_all_roles();
		$data['texts']  	= $this->feedback_model->get_texts( $id, $optlet );
		// print "<hr><pre>".$this->db->last_query();exit;		
		$data['foptname']  		= $this->feedback_model->get_feed_optname( $id, $optlet );
				
		$this->myadmin->view('feedback/viewopt', $data);
	
	}	
		
	public function view( $id ){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
		$row	= $this->feedback_model->get_single_feed($this->input->post('id'));
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{

				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'View Feedback', 'fun' => 3),
								array('tag' => '#infoModal .modal-body',  'data' => $this->get_data($this->input->post('id')), 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			// redirect(admin_url('users'), 'refresh');
			$data['page']  		= 'level1';
			$data['page1']  	= 'feedback';
			$data['script']  	= 1;				
			$data['roles']  	= $this->user_model->get_all_roles();
			$data['row']  		= $this->feedback_model->get_single_feed( $id );
			// print "<hr><pre>".$this->db->last_query();exit;
			
			$data['fopt']  		= $this->feedback_model->get_feed_opt( $id );
			$data['ftscore']  	= $this->feedback_model->feedtotscore( $id );
			
/* echo "<hr><pre>ftscore: ";
var_dump( $data['ftscore'] );
exit; */			
			
			$data['tbl_categories'] = $this->GeneralModel->GetSelectedRows( $table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '' );
			
			$this->myadmin->view('feedback/view', $data);
		}		
	}
	
	private function get_data($id = 0){
    	if(!empty($id)){
    		$row  	= $this->feedback_model->get_single_feed($id);
			
			$data = "";
		
			$type = ( $row->type == 'S' ) ? 'Single Choice' : 'Multiple Choice' ;
			$status = ( $row->status == 'A' ) ? 'Active' : 'Deactive' ;
			
			$data .= '<div class="card">
						<table class="table">
						<tr><td><b>Title</b></td><td>'.$row->title.'</td></tr>
						<tr><td><b>Type</b></td><td>'.$type.'</td></tr>
						<tr><td><b>Created On</b></td><td>'. date('d M Y', strtotime( $row->created_on ) ).'</td></tr>
						<tr><td><b>Category</b></td><td>'.$row->category_name.'</td></tr>
						<tr><td><b>Status</b></td><td>'.$status.'</td></tr>
						</table>
					</div>';
						
			return $data;
		    
    	}
		
	}
	
	public function edit($id = 0){
	if (!has_permission('feedback', 'edit')) {
         redirect(admin_url('login'), 'refresh');
    }
		if($id>0){
			
			$data['page']  		= 'level1';
			$data['page1']  = 'feedback';
			$data['script']  	= 1;				
			$data['roles']  	= $this->user_model->get_all_roles();
			$data['row']  		= $this->feedback_model->get_single_feed($id);
			$data['fopt']  		= $this->feedback_model->get_feed_opt( $id );
			
			$data['tbl_categories'] = $this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');
			
			$this->myadmin->view('feedback/edit', $data);
		}
		else{
			redirect(admin_url('feedback'), 'refresh');
		}
	}
	
	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row  	= $this->feedback_model->get_single_feed( $this->input->post('id') );
			
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');

			$this->form_validation->set_rules('title', 'Feedback Title', 'trim|required');
			$this->form_validation->set_rules('type', 'Feedback Type', 'trim|required');
			$this->form_validation->set_rules('parent', 'Super Category', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				
				$error['title'] 	= form_error('title');
				$error['type'] 		= form_error('type');
				$error['parent'] 	= form_error('parent');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{

				$id = $this->input->post('id');
				$save_pub = $this->input->post('save_pub');
												
				$idata['title'] = $this->input->post('title');
				$idata['type'] = $this->input->post('type');
				$idata['parent'] = $this->input->post('parent');
				$idata['status'] = ( $save_pub == '1' ) ? 'A' : 'D' ;			
								
				$this->GeneralModel->UpdateRow( "feedback", $idata, array( 'id' => $id ) );
				
				$this->GeneralModel->DeleteRow( "feedback_opt", array( 'fid' => $id ) );
				
				$opt = $this->input->post('opt');
				$optlet = $this->input->post('optlet');
				$star_rat = $this->input->post('star_rat');
				$txt_input = $this->input->post('txt_input');
				
				if( !empty( $opt ) )
				{	
					for( $i = 0 ; $i < count( $opt ) ; $i++ )
					{	
						$idata = array();
						$idata['fid'] = $id;
						$idata['opt_name'] = $opt[ $i ];
						$idata['feed_optlet'] = $optlet[ $i ];
						$idata['star_rat'] = $star_rat[ $i ];
						$idata['txt_input'] = $txt_input[ $i ];
						
						$this->GeneralModel->AddNewRow( "feedback_opt", $idata );
					}
				}
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('feedback'), 'message' => 'Feedback updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url( 'feedback/update/' . $this->input->post('id') ), 'refresh');
		}
	}	
	
	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 'D';
				$this->db_model->update('feedback', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Feedback status updated successfully', 'function'=> 'refreshfeedTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('feedback'), 'refresh');
		}		
	}
	
	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 'A';
				$this->db_model->update('feedback', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Feedback status updated successfully', 'function'=> 'refreshfeedTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('feedback'), 'refresh');
		}		
	}
	
	public function delete(){
			
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('feedback_opt', 'fid', $this->input->post('id'));				
				$this->db_model->delete('feedback', 'id', $this->input->post('id'));
				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Feedback deleted successfully', 'function'=> 'refreshfeedTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('feedback'), 'refresh');
		}		
	}
	
	public function get_feedback(){
		echo $this->feedback_model->all_feedback();
	}

	
}	
	
?>