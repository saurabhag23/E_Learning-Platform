<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('user_model', 'db_model','mentor_model','admin_model','course_model'));
			$this->user = $this->session->userdata($this->session_name);
		}	
	}

	public function index(){
	if (!has_permission('admin', 'dashboard_view')) {
         redirect(admin_url('login'), 'refresh');
    }
		$data['page']  		= 'admin';
		$data['script']  	= 1;
		$data['subsubcats']  	= $this->course_model->getsubsubcat();
		$this->myadmin->view('admin/home', $data);
	}
	 
	public function get_all_users(){
		echo $this->admin_model->all_users();
	}

	public function add(){
	    
	    error_reporting(E_ALL);
ini_set('display_errors', 1);
	    
	if (!has_permission('admin', 'add')) {
         redirect(admin_url('login'), 'refresh');
    }
		$data['page']  		= 'admin';
		$data['script']  	= 1;
		$data['roles']  	= $this->user_model->get_all_roles();
		$data['subsubcats']  	= $this->course_model->getsubsubcat();
		$this->myadmin->view('admin/add', $data);
	}

	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_message('is_unique', 'The {field} already exsist, try another one');	
			$this->form_validation->set_rules('role', 'role', 'trim|required');
			$this->form_validation->set_rules('first_name', 'first name', 'trim|required|max_length[75]');
			$this->form_validation->set_rules('last_name', 'last name', 'trim|max_length[50]');
			$this->form_validation->set_rules('email', 'email', 'trim|required|is_unique[tbl_users.user_email]');
			$this->form_validation->set_rules('password', 'password', 'trim|required');
			
			$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			$this->form_validation->set_rules('birthdate', 'Birthdate', 'trim|required');
			$this->form_validation->set_rules('subjects[]', 'Subjects', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
			 
				$error['role'] 			= form_error('role');
				$error['first_name'] 	= form_error('first_name');
				$error['last_name'] 	= form_error('last_name');
				$error['email'] 		= form_error('email');
				$error['password'] 		= form_error('password');
				
				$error['confirm_password'] 		= form_error('confirm_password');
				$error['address'] 		= form_error('address');
				$error['birthdate'] 		= form_error('birthdate');
				$error['subjects'] 		= form_error('subjects[]');
				
				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
			   
				$data['user_fname']			= $this->input->post('first_name');
				$data['user_lname']			= $this->input->post('last_name');
				$data['user_email']			= $this->input->post('email');
				$data['user_pass']			= md5($this->input->post('password'));
				$data['id_role']  			= 1;
				$data['ContactNo']  			= $this->input->post('contactnum');
				$data['user_added_by']		= $this->user->id;
				$data['user_reg_date']		= date("Y-m-d H:i:s");
				
				$data['subjects']  			= implode(",",  $this->input->post('subjects'));
				$data['birthdate']			= $this->input->post('birthdate');
                $data['address']			= $this->input->post('address');
				
				$examcat = $this->user_model->getallexamcats();
				foreach($examcat as $examcat)
				{
					$examarray[] = $examcat->id;
				}
				$allexams = implode(',',$examarray);
				$data['exam_category']	= $allexams;
				$invoice_id = $this->db_model->insert('tbl_users', $data); 
				$this->senddashboardurl($data);
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('admin'), 'message' => 'Admin inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('admin'), 'refresh');
		}
	}
    function senddashboardurl($data=array())
	{
		
		//////////  ****MAIL****  /////////
				 $to = $data['user_email'];
				 $this->load->library('email');
				 $message = '<p></p><table align="center"><tbody><tr><td style="font-family: Helvetica Neue, Helvetica, 	Arial, sans-serif; font-size: 14px; color: #666;"><div style="text-align: left; background-color: #fff; max-width: 500px;"><div style="text-align: center;"><div style="padding: 30px 20px; color: #000; font-size: 28px; background-color: #efefef; border-bottom: 1px solid #ddd; text-align: center;">Educational Portal </div></div><div style="padding: 10px 20px 20px 20px; background-color: #fff; line-height: 18px;"><p style="text-align: left; font-size: small; font-weight:bold;">hi,</p><p style="text-align: center; font-size: small;">Mentor Dashboard Details.	</p>
				    <p>Dashboard Url : '.base_url('mentor/login').'</p>
					<p>Name : '.$data['user_fname'].'</p>
					<p>Email : '.$data['user_email'].'</p>		 
					<p>Password : '.$this->input->post('password').'</p>	
					<p><br></p><div style="text-align: center; margin: 10px 0 20px;"> </div><div style="text-align: center; color: #888; margin-top: 20px;"> </div><div style="text-align: center; color: #888;"> Have a nice day..! </div></div></div></td></tr></tbody></table>';
				 
				 
			     
				 $this->email->set_mailtype('html');
				 $this->email->set_newline("\r\n");
				 $this->email->from('teamadsdev1@gmail.com');
				 $this->email->to($to); 
				 $this->email->subject('Dashboard Details');
				 $this->email->message($message);    
		        // $this->email->send();
			//////////  ****MAIL****  /////////
	}
	public function edit($id = 0){
	if (!has_permission('admin', 'edit')) {
         redirect(admin_url('login'), 'refresh');
    }
		if($id>0){
			$data['page']  		= 'admin';
			$data['script']  		= '1';
			$data['roles']  	= $this->user_model->get_all_roles();
			$data['row']  		= $this->user_model->get_single_user($id);
			$data['subsubcats']  	= $this->course_model->getsubsubcat();
			$this->myadmin->view('admin/edit', $data);
		}
		else{
			redirect(admin_url('admin'), 'refresh');
		}
	}

	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row	= $this->user_model->get_single_user($this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_message('is_unique', 'The {field} already exsist, try another one');	
			
			$this->form_validation->set_rules('first_name', 'first name', 'trim|required|max_length[75]');
			$this->form_validation->set_rules('last_name', 'last name', 'trim|max_length[50]');
			$this->form_validation->set_rules('password', 'password', 'trim');
			if($row->user_email != $this->input->post('email')){
				$this->form_validation->set_rules('email', 'email', 'trim|required|is_unique[tbl_users.user_email]');
			}
			else{
				$this->form_validation->set_rules('email', 'email','trim|required');
			}
			
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			$this->form_validation->set_rules('birthdate', 'Birthdate', 'trim|required');
			$this->form_validation->set_rules('subjects[]', 'Subjects', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				
				$error['first_name'] 	= form_error('first_name');
				$error['last_name'] 	= form_error('last_name');
				$error['email'] 		= form_error('email');
				$error['password'] 		= form_error('password');
				
				$error['address'] 		= form_error('address');
				$error['birthdate'] 		= form_error('birthdate');
				$error['subjects'] 		= form_error('subjects[]');
				
				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['user_fname']			= $this->input->post('first_name');
				$data['user_lname']			= $this->input->post('last_name');
				$data['user_email']			= $this->input->post('email');
				if($this->input->post('password')!=""){
					$data['user_pass']			= md5($this->input->post('password'));
				}
				$data['id_role']  			= 1;
				
				$data['ContactNo']  			= $this->input->post('contactnum');
				$data['subjects']  			= implode(",",  $this->input->post('subjects'));
				$data['birthdate']			= $this->input->post('birthdate');
                $data['address']			= $this->input->post('address');
				
				$invoice_id = $this->db_model->update('tbl_users', $data, 'id', $this->input->post('id')); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('admin'), 'message' => 'Admin updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('admin'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['user_status'] 	= 0;
				$this->db_model->update('tbl_users', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Admin status updated successfully', 'function'=> 'refreshUserTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('admin'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['user_status'] 	= 1;
				$this->db_model->update('tbl_users', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Admin status updated successfully', 'function'=> 'refreshUserTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('admin'), 'refresh');
		}		
	}

	public function delete(){if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['user_status'] 	= 1;
				$this->db_model->update('tbl_users', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Admin status updated successfully', 'function'=> 'refreshUserTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('admin'), 'refresh');
		}		
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_users', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Admin deleted successfully', 'function'=> 'refreshUserTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('admin'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
		$row	= $this->user_model->get_single_user($this->input->post('id'));
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
					if($row->id_role==1)
					{
						$role = 'Admin Details';
					}
					if($row->id_role==2)
					{
						$role = 'Mentor Details';
					}
					if($row->id_role==3)
				    {
					   $role = 'User Details';
				    }
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => $role, 'fun' => 3),
								array('tag' => '#infoModal .modal-body',  'data' => $this->get_data($this->input->post('id')), 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('users'), 'refresh');
		}		
	}
	private function get_data($id = 0){
    	if(!empty($id)){
    		$row  	= $this->user_model->get_single_user($id);
			if($row->logintype == 2)
                  		{
                  			$userimage = $row->user_img;
                  		}
                  		elseif($row->logintype == 3)
                  		{
                  			$userimage = $row->user_img;
                  		}
                  		else
                  		{
                  			$userimage = base_url().$row->user_img;
                  		}
	    	$data="";
			    $data.= '<div class="card">
							  <img src="'.$userimage.'" alt="John" style="width:100%">
							  <h1>'.$row->user_fname.' '.$row->user_lname.'</h1>
							  <p class="title">'.$row->user_email.'</p>
							  <p>'.$row->ContactNo.'</p>
							    <p>Joined Date:'.date("M d, Y", strtotime($row->user_reg_date)).'</p>
							  <div style="margin: 24px 0;">
							  <form  class = "process-form" method = "post" action ="'.admin_url('users/block').'">';
							  if($row->user_status == 1)
							  {
							   $data.=  '<input type="submit" class="btn btn-danger"  onclick="return confirm(\'Are you sure you want to block '.$row->user_fname.' ?\');" value="Block">';
							  }
							  else
							  {
							  	 $data.=  '<input type="submit" class="btn btn-danger"  onclick="return confirm(\'Are you sure you want to Unblock '.$row->user_fname.' ?\');" value="UnBlock">';
							  }
						$data.= '<input type = "hidden" name="blockid" id = "blockid" value = "'.$row->id.'"> 
							<input type="hidden" name="action" value="block">
							</form>
							  </div>
							 </div>';
				return $data;
		    
    	}
		
	}
	function block()
		{
			if(isset($_POST['action']) && $_POST['action'] == "block"){
			$error = array();
			$this->form_validation->set_rules('blockid', 'blockid', 'trim|required');
			$row	= $this->user_model->get_single_user($this->input->post('blockid'));
			if($row->user_status == '1')
			{
				$status = 0;
				$statusmsg = 'Blocked';
			}
			else
			{
				$status = 1;
				$statusmsg = 'UnBlocked';
			}
			if ($this->form_validation->run() == FALSE) {
				$error['blockid'] 	= (form_error('blockid'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['user_status'] 	= $status;
				$this->db_model->update('tbl_users', $data, 'id', $this->input->post('blockid'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => ''.$statusmsg.' successfully', 'function'=> 'refreshUserTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('users'), 'refresh');
		}		
		}
}