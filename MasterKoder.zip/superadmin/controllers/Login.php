<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		$this->load->model('login_model', 'login');
		$this->load->library(array('form_validation'));
		$this->csrf = array('name' => $this->security->get_csrf_token_name(),
					        'hash' => $this->security->get_csrf_hash());
	}

	public function index(){
		if($this->session->userdata($this->session_name)){
			redirect(admin_url('dashboard'), 'refresh');
		}else{
			$data['page']  = 'login';
			$data['csrf']  = $this->csrf;
			$this->load->view('login/home', $data);
		}	
	}

	public function signin(){
		
		if(isset($_POST['action']) && $_POST['action'] == "login"){
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('username', 'email', 'trim|required|valid_email');
			$this->form_validation->set_rules('password', 'password', 'trim|required');
			$error = array("email_error"=>"", "password_error"=>"");
			if ($this->form_validation->run() == FALSE) {
				$error['username'] 		= form_error('username');
				$error['password'] 		= form_error('password');
				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
				$username	= $this->input->post('username');
				$password	= $this->input->post('password');
				$result 	= $this->login->get($username, md5($password));
				
				// print "<hr><pre>".$this->db->last_query();exit;
				
				if(count($result) <= 0){
					$error['username'] 		= form_error('username');
					$error['password'] 		= '<label class="control-label error">Invalid username or password</label>';
					$return  				= array('has_error'=>1, 'error' => $error);
				}
				elseif($result->id_role != 1 && $result->id_role != 2){
					$error['username'] 		= form_error('username');
					$error['password'] 		= '<label class="control-label error">You have no access here</label>';
					$return  				= array('has_error'=>1, 'error' => $error);
				}
				else{
				    
				    setcookie ("admin_login",$username,time()+ (10 * 365 * 24 * 60 * 60), "/");  
					setcookie ("admin_password",$password,time()+ (10 * 365 * 24 * 60 * 60), "/");
				    
					$this->session->set_userdata($this->session_name, $result);
					$return  = array('has_error'=>0, 'page' => admin_url('dashboard'), 'message' => 'Login successfully');
				}			
			}	
			echo json_encode($return);
		}
		else{
			redirect(site_url('login'), 'refresh');
		}
	}

	public function signout(){
	    setcookie ("admin_login",$username,time() - 3600, "/");  
		setcookie ("admin_password",$password,time() - 3600, "/");
		$this->session->sess_destroy();
		redirect(admin_url('login'), 'refresh');
	}
}