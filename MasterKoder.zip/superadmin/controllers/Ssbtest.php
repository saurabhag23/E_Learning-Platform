<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Ssbtest extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('currentaffair_model', 'db_model', 'course_model','ssbtest_model'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'topic_slug',
							'title' => 'topic_title',
							'table' => 'tbl_current_affairs',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}



	public function index(){
		    $data['page']  		= 'ssbtest';
		    $data['script']  	= 1;
			$data['row']  		= $this->ssbtest_model->get_single();
			$this->myadmin->view('ssbtest/home', $data);
	
	}



	public function get_all_datas(){
		echo $this->ssbtest_model->all_datas();
	}



	public function add(){
		    $data['page']  		= 'ssbtest';
		    $data['script']  	= 1;
			$data['examcats']  	= $this->course_model->get_all_categories();
            $data['exams'] =  $this->course_model->getallmainexams();
			$data['curtypes']  = $this->course_model->getcurrent_affairtypes();
			$data['exams'] =  $this->course_model->getallmainexams();
			$this->myadmin->view('ssbtest/add', $data);
	}
    public function getsubcategory()
	{
		 $subcats =  $this->course_model->get_all_subcatscategoriesbyid($this->input->post('catid'));
		 $html = "";
		 $html.='<option value="0">Select Sub category</option>'; 
		 foreach( $subcats as  $subcats)
		 {
		 	 $html.= '<option value="'.$subcats->id_course.'">'.$subcats->course_title.'</option>';
		 }
		 echo  $html;
	}
	 public function getexamsbyid()
	{
		 $exams =  $this->course_model->get_all_examsid($this->input->post('examid'));
		 $html = "";
		 $html.='<option value="0">Select Exam </option>'; 
		 foreach($exams as  $exams)
		 {
		 	 $html.= '<option value="'.$exams->id.'">'.$exams->exam_title.'</option>';
			         
		 }
		 echo  $html;
	}


	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			
			
			$this->form_validation->set_rules('title', 'topic title', 'trim|required');
			$this->form_validation->set_rules('content', 'topic content', 'trim|required');
			if (empty($_FILES['image']['name']))
            {
                $this->form_validation->set_rules('image', 'Image', 'required');
				
            }

			if ($this->form_validation->run() == FALSE) {
				$error['title'] 	= form_error('title');
				$error['editor'] 	= form_error('content');
				$error['image'] 	= form_error('image');
				
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
			
			     if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/SSB')) {
                            mkdir('uploads/SSB');
							chmod('uploads/SSB', 0755);
                        }
						$config['upload_path'] = 'uploads/SSB/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = "";
						}
				 }	
				
				$data['featured_image']	    = $image;
			    $data['id_parent']          = $this->input->post('examcat');
				$data['id_subcategory']     = $this->input->post('examsubcat');
				$data['id_mainexam']        = $this->input->post('exam');
				$data['topic_title']		= $this->input->post('title');
				$data['topic_description']	= base64_encode($this->input->post('content'));
				$data['topic_slug']			= $this->slug->create_uri($this->input->post('title'));
				$data['feautured_post']		= $this->input->post('featured');
				$data['added_by']			= $this->user->id;
				$data['added_date']			= date("Y-m-d");
				$invoice_id = $this->db_model->insert('tbl_ssb', $data); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('ssbtest'), 'message' => 'SSB Test Preperation inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('ssbtest'), 'refresh');
		}
	}



	public function edit($id = 0){
	

		if(!empty($id)){
			$data['page']  		= 'ssbtest';
			$data['script']  	= 1;
			$data['row']  		= $this->ssbtest_model->ssbdetails($id);
			$data['curtypes']  = $this->course_model->getcurrent_affairtypes($id);
			$data['subcats'] =  $this->course_model->getsubcatscategoriesbyid($id);
			$data['exams'] =  $this->course_model->getallmainexams();
				$data['examcats']  	= $this->course_model->get_all_categories();
			if(count($data['row']) > 0){
				$this->myadmin->view('ssbtest/edit', $data);
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			$this->myadmin->view('404', $data);
		}
	}



	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row 		= $this->ssbtest_model->ssbdetails( $this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			//$this->form_validation->set_rules('examcat', 'Exam Category', 'trim|required');
			
			
			$this->form_validation->set_rules('title', 'topic title', 'trim|required');
			$this->form_validation->set_rules('content', 'topic content', 'trim|required');
			
			if ($this->form_validation->run() == FALSE) {
			  //  $error['examcats'] = form_error('examcat');
				//$error['examsubcat'] = form_error('examsubcat');
			   
				$error['title'] 	= form_error('title');
				$error['editor'] 	= form_error('content');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
				  if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/SSB')) {
                            mkdir('uploads/SSB');
							chmod('uploads/SSB', 0755);
                        }
						$config['upload_path'] = 'uploads/SSB/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = $row->featured_image;
						}
				 }
				 else
				 {
				 	$image = $row->featured_image;
				 }	
				$data['featured_image']	    = $image;
			    $data['id_parent']          = $this->input->post('examcat');
				
				$data['feautured_post']		= $this->input->post('featured');
				$data['topic_title']		= $this->input->post('title');
				$data['topic_description']	= base64_encode($this->input->post('content'));
				$data['topic_slug']			= $this->slug->create_uri($this->input->post('title'), $this->input->post('id'));
				$invoice_id 				= $this->db_model->update('tbl_ssb', $data, 'id', $this->input->post('id')); 
				$return  					= array('has_error'=>0, 'page'=> admin_url('ssbtest'), 'message' => 'SSB Test Preperation updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('ssbtest'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['topic_status'] 	= 0;
				$this->db_model->update('tbl_ssb', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Current affairs status updated successfully', 
				                'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('ssbtest'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['topic_status'] 	= 1;
				$this->db_model->update('tbl_ssb', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'SSB Peperation status updated successfully', 
				               'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('ssbtest'), 'refresh');
		}		
	}

	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_ssb', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'SSB  Peperation deleted successfully', 'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');
            $row = $this->ssbtest_model->ssbdetails($this->input->post('id'));
			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
			     $html = '';
			     $html.='<table class="table table-bordered">
						  <thead>
							
						  </thead>
						  <tbody>';
						 
						  
						  $html.='
								<tr>
								 <td>Title</td>
								  <td>'.$row->topic_title.'</td>
								</tr>
								<tr>
								  <td>Description</td>
								  <td>'.base64_decode($row->topic_description).'</td>
								</tr>';
								
								
								
						 
				  $html.='</tbody>
						</table>';
				
				
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'SSB Preperation Details', 'fun' => 3),
				                array('tag' => '#infoModal .modal-body',  'data' => $html, 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
				
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('ssbtest'), 'refresh');
		}		
	}
}