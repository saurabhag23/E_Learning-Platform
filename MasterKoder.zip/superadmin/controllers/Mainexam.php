<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Mainexam extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation', 'image_lib', 'upload'));
			$this->load->model(array('course_model', 'db_model','mainexam_model'));
			$this->user 	= $this->session->userdata($this->session_name);
			$this->path    	= 'uploads/';
			$this->tmp_path = 'tmp/';
			if(!file_exists($this->path)) {
				mkdir($this->path);
				chmod($this->path, 0755);
			}	
			$config = array('field' => 'exam_slug',
							'title' => 'exam_title	',
							'table' => 'tbl_mainexam',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}

	public function index(){
		$data['page']  		= 'mainexam';
		$data['script']  	= 1;
		$this->myadmin->view('mainexam/home', $data);
	}

	public function get_all_datas(){
		echo $this->mainexam_model->all_datas();
	}

	public function add(){
		$data['page']  		= 'mainexam';
		$data['script']  	= 1;
		$data['categories'] = $this->mainexam_model->get_all_categories();
		$this->myadmin->view('mainexam/add', $data);
	}

	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('category', 'category', 'trim|required');
			$this->form_validation->set_rules('examsubcat',  'Exam SubCategory', 'trim|required');
			$this->form_validation->set_rules('exam',  'Exam ', 'trim|required');
			$this->form_validation->set_rules('content',  'content ', 'trim|required');
			
		 if ($this->form_validation->run() == FALSE || !empty($error)) {
				$error['category'] 			= form_error('category');
				$error['examsubcat'] 		= form_error('examsubcat');
				$error['exam'] 		        = form_error('exam');
				$error['editor'] 		    = form_error('content');
				
				$return  					= array('has_error'=>1, 'error' => $error);
			}

			if(empty($error)){
			      $image = "";
			      if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/Mainexam')) {
                            mkdir('uploads/Mainexam');
							chmod('uploads/Mainexam', 0755);
                        }
						$config['upload_path'] = 'uploads/Mainexam/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = "";
						}
				 }	
				 
				$data['id_category']			= $this->input->post('category');
				$data['id_subcategory']			= $this->input->post('examsubcat');
				$data['exam_title']			    = $this->input->post('exam');
				$data['examdescription']	    =  base64_encode($this->input->post('content'));
				$data['image']			        = $image;
				$data['exam_slug']			    = $this->slug->create_uri($this->input->post('exam'));
				$data['added_by']				= $this->user->id;
				$data['added_date']				= date("Y-m-d H:i:s");
				$course_id 	= $this->db_model->insert('tbl_mainexam', $data); 

				$return  	= array('has_error'=>0, 'page'=> admin_url('mainexam'), 'message' => 'Exam inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('mainexam'), 'refresh');
		}
	}

	public function edit($id = 0){
		$data['page']  			= 'mainexam';
		if(!empty($id)){
			$data['script']  	= 1;
			$data['categories'] = $this->course_model->get_all_categories();
			$data['subcats'] =  $this->course_model->getsubcatscategoriesbyid($id);
			$data['row']  		= $this->mainexam_model->get_single($id);
			if(count($data['row']) > 0){
				$this->myadmin->view('mainexam/edit', $data);
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			$this->myadmin->view('404', $data);
		}
	}

	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row	= $this->mainexam_model->get_single($this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('category', 'category', 'trim|required');
			$this->form_validation->set_rules('examsubcat',  'Exam SubCategory', 'trim|required');
			$this->form_validation->set_rules('exam',  'Exam ', 'trim|required');
			$this->form_validation->set_rules('content',  'content ', 'trim|required');
			

			if($this->form_validation->run() == FALSE || !empty($error)) {
				$error['category'] 			= form_error('category');
				$error['title'] 			= form_error('title');
				$error['editor'] 		    = form_error('content');
				$return  					= array('has_error'=>1, 'error' => $error);
			}

			if(empty($error)){
			  
			   if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/Mainexam')) {
                            mkdir('uploads/Mainexam');
							chmod('uploads/Mainexam', 0755);
                        }
						$config['upload_path'] = 'uploads/Mainexam/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = $row->image;
						}
				 }
				 else
				 {
				 	$image = $row->image;
				 }	
				$data['image']			        = $image;
				$data['id_category']			= $this->input->post('category');
				$data['id_subcategory']			= $this->input->post('examsubcat');
				$data['exam_title']			    = $this->input->post('exam');
				$data['examdescription'] 		 = base64_encode($this->input->post('content'));
				$data['exam_slug']			    = $this->slug->create_uri($this->input->post('exam'));
				$this->db_model->update('tbl_mainexam', $data, 'id', $this->input->post('id')); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('mainexam'), 'message' => 'Exam updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('mainexam'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['exam_status'] 	= 0;
				$this->db_model->update('tbl_mainexam', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Exam updated successfully', 'function'=> 'refreshCourseTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('mainexam'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['exam_status'] 	= 1;
				$this->db_model->update('tbl_mainexam', $data, 'id_course', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Exam status updated successfully', 'function'=> 'refreshCourseTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('mainexam'), 'refresh');
		}		
	}

	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$course_data	= $this->course_model->get_single($this->input->post('id'));
				
				$this->db_model->delete('tbl_courses', 'id_course', $this->input->post('id'));							
				$this->db_model->delete('tbl_exams', 'id_course', $this->input->post('id'));				
				$this->db_model->delete('tbl_mainexam', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Exam deleted successfully', 'function'=> 'refreshCourseTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('mainexam'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Exam Details', 'fun' => 3),
								array('tag' => '#infoModal .modal-body',  'data' => $this->get_data($this->input->post('id')), 'fun' => 0)
			);
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('mainexam'), 'refresh');
		}		
	}

	private function get_data($id = 0){
    	if(!empty($id)){
    		$course_data  	= $this->course_model->get_single($id);
	    	if(count($course_data) > 0){
			    $data   =  '<table class="table table-responsive">
                              <tbody>
                              	<tr>
                                  <th>Course Category</th>
                                  <td>'.$course_data->category_name.'</td>
                                </tr>
                                <tr>
                                  <th width="25%">Course Title</th>
                                  <td>'.$course_data->course_title.'</td>
                                </tr>
                                
                                  <th>Added on</th>
                                  <td>'.date("M d, Y", strtotime($course_data->added_date)).'</td>
                                </tr>
                                <tr>
                                  <th>Added by</th>
                                  <td>'.$course_data->user_fname.'</td>
                                </tr>
                              </tbody>
                            </table>';
				return $data;
		    }
    	}
	}

	public function details($course_id = 0){
		$data['page']  	= 'subcategory';
		if(!empty($course_id)){
			$data['course_id']  	= $course_id;
    		$data['row']  			= $this->course_model->get_single($course_id);
			$data['examcount']  			= $this->course_model->quizcount($course_id);
    		if(count($data['row']) > 0){
				$this->myadmin->view('subcategory/details', $data);
    		}
    		else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			$this->myadmin->view('404', $data);
		}
	}
}