<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation','permissions'));
			$this->load->model(array('posts_model', 'db_model', 'course_model','dailyquiz_model','GeneralModel'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'topic_slug',
							'title' => 'topic_title',
							'table' => 'tbl_articelepost',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}
	public function index(){
	if (!has_permission('posts', 'dashboard_view')) {
         redirect(admin_url('login'), 'refresh');
    }
		    $data['page']  		= 'posts';
		    $data['script']  	= 1;
			//$data['row']  		= $this->posts_model->get_single();
			$this->myadmin->view('posts/home', $data);
	
	}



	public function get_all_datas(){
	
		echo $this->posts_model->all_datas();
	}


	public function add(){

		if (!has_permission('posts', 'add')) {
			redirect(admin_url('login'), 'refresh');
		}

		$data['page']  		= 'posts';
		$data['script']  	= 1;
		$data['examcats']  	= $this->course_model->get_all_categories();
		$data['exams']      = $this->course_model->getallmainexams();		
		$data['curtypes']  = $this->course_model->getcurrent_affairtypes();
		$data['exams']     = $this->course_model->getallmainexams();		
		$data['articles'] = $this->dailyquiz_model->get_all_articles();
		
		$this->myadmin->view('posts/addnew1', $data);

	}
	
    public function getsubcategory()
	{
	
		 $subcats =  $this->course_model->get_all_subcatscategoriesbyid($_POST['catid']);
		 $html = "";
		 $html.='<option value="0">Select Category</option>'; 
		 if(!empty($subcats))
		 {
			 foreach($subcats as  $subcats)
			 {
				 $html.= '<option value="'.$subcats->id.'">'.$subcats->title.'</option>';
			 }
		 }
		 echo  $html;
	}
	 public function getsubsub()
	{
		 $subsub =  $this->posts_model->get_all_subsubbcats($_POST['subid']);
		 $html = "";
		 $html.='<option value="0">Select Sub Category </option>'; 
		 if(!empty($subsub))
		 {
			 foreach($subsub as  $subsub)
			 {
				 $html.= '<option value="'.$subsub->id.'">'.$subsub->title.'</option>';
						 
			 }
		 }
		 echo  $html;
	}


	public function insert_createp(){
		
		if(isset($_POST['action']) && $_POST['action'] == "post-step1"){
			
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('examcat[]', 'Exam Category', 'trim|required');
			//$this->form_validation->set_rules('examsubcat', 'Exam SubCategory', 'trim|required');
			//$this->form_validation->set_rules('subsub', 'Exam SubsubCategory', 'trim|required');
			$this->form_validation->set_rules('title', 'topic title', 'trim|required');
			// $this->form_validation->set_rules('content', 'topic content', 'trim|required');
			/*if (empty($_FILES['image']['name']))
            {
                $this->form_validation->set_rules('image', 'Image', 'required');
				
            }*/

			if ($this->form_validation->run() == FALSE) {
			    $error['examcat'] = form_error('examcat[]');
			   // $error['examsubcat'] =form_error('examsubcat');
				//$error['subsub']     =form_error('subsub');
				$error['title'] 	= form_error('title');
				$error['editor'] 	= form_error('content');
				$error['image'] 	= form_error('image');
				
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
			
	
				 /*
				  if(!empty($_FILES['document']['name'])){
				 		if (!is_dir('uploads/Postdocument')) {
                            mkdir('uploads/Postdocument');
							chmod('uploads/Postdocument', 0755);
                        }
						$config['upload_path']   = 'uploads/Postdocument/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name']     = $_FILES['document']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('document')){
							$uploadData = $this->upload->data();
							$image1 = $uploadData['file_name'];
							
						}else{
							$image1 = "";
						}
				 }
				 else
				 {
				 	$image1 = "";
				 }	
				 */
			   // $data['id_parent']          = $this->input->post('examcat');
				//$data['id_subsub']        = $this->input->post('subsub');
				$data['topic_title']		= $this->input->post('title');
				
				/*
                echo "<hr><pre>content: ";
                var_dump( $this->input->post('content') );
                exit;
                */
				
				$data['topic_description']	= base64_encode($this->input->post('content'));
				$data['topic_slug']			= $this->slug->create_uri($this->input->post('title'));
				// $data['document']		    = $image1;
				// $data['image_url']		    = $this->input->post('imageurl');
				$data['added_by']			= $this->user->id;
				$data['added_date']			= date("Y-m-d H:i:s");
				

				
				if(isset($_POST['save']))
				{
					$data['topic_status'] = 0;
					$data['draft'] = 1;
				}
				$invoice_id = $this->db_model->insert('tbl_articelepost', $data);
				
				$ndata = array();
				$ndata['title'] = $this->input->post('title');
				$ndata['description'] = $data['added_date'];
				$ndata['created_date'] = date("Y-m-d H:i:s");
				$ndata['created_by'] = $this->user->id;
				$ndata['artid'] = $invoice_id;
				
                $this->session->set_userdata('ses_pnot',$ndata);
				
				
				
				$examcat  = $this->input->post('examcat');
				$examsubcat  = $this->input->post('examsubcat');
				$examsubsubcat  = $this->input->post('subsub');
				
				$parentcat_ids = implode(",", $examcat) ;
				$parentinnercat_ids = implode(",", $examsubcat) ;
				$parentsubcat_ids = implode(",", $examsubsubcat) ;

				$id_parent = $id_subcategory = $id_subsub = 0;	
				$catcnt = $coursecnt = $subsubcatcnt = -1;	

				foreach($examcat as $examcat) 
				{
					 $data2['article_id']   = $invoice_id;
					 $data2['parentcat_id'] = $examcat;
					 $this->db_model->insert('article_parentcats', $data2); 

					if( empty( $id_parent ) )
						$id_parent = $examcat ;

					$catcnt++;

					$this->db->query( 'update `tbl_categories` set postcount = postcount + 1 where id = "' . $examcat . '"' );

				}
				
				foreach($_POST['examsubcat'] as $examsubcat) 
				{
					$data4['article_id']= $invoice_id;
					$data4['sub_catid']=  $examsubcat;
					$this->db_model->insert('article_parentcats', $data4); 

					if( empty( $id_subcategory ) )
						$id_subcategory = $examsubcat ;
					$coursecnt++;

					$this->db->query( 'update `tbl_subcategories` set postcount = postcount + 1 where id = "' . $examsubcat . '"' );

				}

				foreach($_POST['subsub'] as $examsubsubcat) 
				{
					$data5['article_id']    = $invoice_id;
					$data5['sub_sub_catid'] =  $examsubsubcat;
					$this->db_model->insert('article_parentcats', $data5);

					if( empty( $id_subsub ) )
						$id_subsub = $examsubsubcat ;

					$subsubcatcnt++;

					$this->db->query( 'update `tbl_subsubcategory` set postcount = postcount + 1 where id = "' . $examsubsubcat . '"' );
 
				}

				$data3['userid'] =  $this->user->id;
				$data3['created'] =  date("Y-m-d H:i:s");
				$data3['exam_category'] = $id_parent;
				$data3['status'] =  6;
				$data3['article_id'] = $invoice_id;
				$data3['posttype'] = $this->input->post('typepost');
			    $this->db_model->insert('tbl_posts', $data3);
			    
                //print "<hr><pre>".$this->db->last_query();exit;
				
				$parentcat_ids = "," . $parentcat_ids . ",";
				$parentinnercat_ids = "," . $parentinnercat_ids . ",";
				$parentsubcat_ids = "," . $parentsubcat_ids . ",";
				$this->GeneralModel->UpdateRow( "tbl_posts", array( 'parentcat_ids' => $parentcat_ids,'parentinnercat_ids' => $parentinnercat_ids,'parentsubcat_ids' => $parentsubcat_ids ), array( 'article_id' => $invoice_id ) );
				
				//$apid = $this->GeneralModel->AddNewRow( "tbl_posts", $data3 );

				$this->GeneralModel->UpdateRow( "tbl_articelepost", array( 'id_parent' => $id_parent, 'id_subcategory' => $id_subcategory, 'id_subsub' => $id_subsub, 'catcnt' => $catcnt, 'coursecnt' => $coursecnt, 'subsubcatcnt' => $subsubcatcnt ), array( 'id' => $invoice_id ) );
				


				//$return  	= array('has_error'=>0, 'page'=> admin_url('Posts'), 'message' => 'Posts inserted successfully');
				
				$set = array( array('tag' => '.artclid', 'data' => $invoice_id, 'fun' => 1) );

				$return = array('has_error' => 0, 'set' => $set, 'step' => '1', 'nextStep' => 2, 'message' => 'Step 1 completed');
				
/* 				$set = array(array('tag' => '.exam_id', 'data' => $exam_id, 'fun' => 1));

				$return = array('has_error' => 0, 'set' => $set, 'step' => '1', 'nextStep' => 2, 'message' => 'Step 1 completed'); */
				
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}
	}

	public function insert_publish(){
		
		if(isset($_POST['action']) && $_POST['action'] == "post-step2"){
		
			 if(!empty($_FILES['image']['name'])){
					if (!is_dir('uploads/posts')) {
						mkdir('uploads/posts');
						chmod('uploads/posts', 0755);
					}
					$config['upload_path'] = 'uploads/posts/';
					$config['allowed_types'] = 'jpg|jpeg|png|gif';
					$config['file_name'] = $_FILES['image']['name'];
						
					//Load upload library and initialize configuration
					$this->load->library('upload',$config);
					$this->upload->initialize($config);
					
					if($this->upload->do_upload('image')){
						$uploadData = $this->upload->data();
						$image = $uploadData['file_name'];
						
					}else{
						$image = "";
					}
			 }
			 else
			 {
				$image = "";
			 }
		 
			$data['featured_image']	    = $image;
			$data['featured_video']	    = $this->input->post('featured_video');
			$data['feautured_post']		= $this->input->post('featured');
			$data['feautured_order']	= $this->input->post('feautured_order');
			$data['notification']		= $this->input->post('notification');
			$data['recommended_1'] = $this->input->post('fpost1');
			$data['recommended_2'] = $this->input->post('fpost2');
			$data['recommended_3'] = $this->input->post('fpost3');
			$data['recommended_4'] = $this->input->post('fpost4');			
			$data['scheduleddate'] = date('Y-m-d', strtotime( $this->input->post('scheduleddate') ) );
			$data['scheduledtime'] = $this->input->post('scheduledtime');
			if( !empty( $data['scheduledtime'] ) )
			{
				$data['scheduled'] = 'Y';
			}
			else
			{
			    $ses_pnot = $this->session->userdata('ses_pnot');
			    $ses_pnot['created_date'] = date("Y-m-d H:i:s");
			    $this->GeneralModel->AddNewRow( "tbl_notifications", $ses_pnot );
			}
			
			$this->db_model->update('tbl_articelepost', $data, 'id', $this->input->post('artclid'));
			
			$return = array('has_error' => 0, 'page' => admin_url('posts'), 'message' => 'Post added successfully');
			
			/*			
			echo "<hr><pre>return: ";
			var_dump( $return );
			exit;
			*/

			echo json_encode($return);
		
		}
	
	}
	
	public function update_publish(){
		
		if(isset($_POST['action']) && $_POST['action'] == "update"){
		
			 if(!empty($_FILES['image']['name'])){
					if (!is_dir('uploads/posts')) {
						mkdir('uploads/posts');
						chmod('uploads/posts', 0755);
					}
					$config['upload_path'] = 'uploads/posts/';
					$config['allowed_types'] = 'jpg|jpeg|png|gif';
					$config['file_name'] = $_FILES['image']['name'];
						
					//Load upload library and initialize configuration
					$this->load->library('upload',$config);
					$this->upload->initialize($config);
					
					if($this->upload->do_upload('image')){
						$uploadData = $this->upload->data();
						$image = $uploadData['file_name'];
						
					}else{
						$image = "";
					}
			 }
			 else
			 {
				$image = "";
			 }
		 
			$data['featured_image']	    = $image;
			$data['feautured_post']		= $this->input->post('featured');
			$data['feautured_order']	= $this->input->post('feautured_order');
			$data['notification']		= $this->input->post('notification');
			$data['recommended_1'] = $this->input->post('fpost1');
			$data['recommended_2'] = $this->input->post('fpost2');
			$data['recommended_3'] = $this->input->post('fpost3');
			$data['recommended_4'] = $this->input->post('fpost4');			
			$data['scheduleddate'] = date('Y-m-d', strtotime( $this->input->post('scheduleddate') ) );
			$data['scheduledtime'] = $this->input->post('scheduledtime');
			if( !empty( $data['scheduledtime'] ) )
			{
				$data['scheduled'] = 'Y';
			}
			
			$this->db_model->update('tbl_articelepost', $data, 'id', $this->input->post('artclid'));
			

			
			$return = array('has_error' => 0, 'page' => admin_url('posts'), 'message' => 'Post added successfully');
			
			/*			
			echo "<hr><pre>return: ";
			var_dump( $return );
			exit;
			*/

			echo json_encode($return);
		
		}
	
	}
	
	public function edit($id = 0){
	if (!has_permission('posts', 'edit')) {
           redirect(admin_url('login'), 'refresh');
    }

		if(!empty($id)){
			$data['page']  		= 'posts';
			$data['script']  	= 1;
			$data['row']  		= $this->posts_model->articledetails($id);
			

			
			// $data['row']->catid = str_replace( "\\","", $data['row']->catid );
			//$data['curtypes']  = $this->course_model->getcurrent_affairtypes($id);
			$data['subcats']    =  $this->posts_model->get_all_subcategoriesbypost($data['row']->catid);



			
			
			$subcatid = str_replace(",", "','", $data['row']->subcatid);
			$subcatid = str_replace(" ", "", $subcatid);
			
			$data['subsubcats']    =  $this->posts_model->get_all_subsubcategories( $subcatid );
			
			// print "<hr><pre>".$this->db->last_query();exit;			
			
			$data['examcats']  	= $this->course_model->get_all_categories();
			$data['articles'] = $this->dailyquiz_model->get_all_articles();
			$data['tbl_posts'] = $this->GeneralModel->GetInfoRow('tbl_posts', array( 'article_id' => $data['row']->id ));
			

/* echo "<hr><pre>tbl_posts: ";
var_dump( $data['tbl_posts'] );
exit; */

			
			// print "<hr><pre>".$this->db->last_query();exit;
			
			if(count($data['row']) > 0){
				$this->myadmin->view('posts/edit1', $data);
				// $this->myadmin->view('posts/edit', $data);
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			$this->myadmin->view('404', $data);
		}
	}


	/*
	// old running code
	
	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row 		= $this->posts_model->articledetails( $this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('examcat[]', 'Exam Category', 'trim|required');
		
			
			$this->form_validation->set_rules('title', 'topic title', 'trim|required');
			$this->form_validation->set_rules('content', 'topic content', 'trim|required');
			
			if ($this->form_validation->run() == FALSE) {
			    $error['examcat'] = form_error('examcat[]');
				
			   
				$error['title'] 	= form_error('title');
				$error['editor'] 	= form_error('content');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
				  if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/posts')) {
                            mkdir('uploads/posts');
							chmod('uploads/posts', 0755);
                        }
						$config['upload_path'] = 'uploads/posts/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = $row->featured_image;
						}
				 }
				 else
				 {
				 	$image = $row->featured_image;
				 }	
				if(!empty($_FILES['document']['name'])){
				 		if (!is_dir('uploads/Postdocument')) {
                            mkdir('uploads/Postdocument');
							chmod('uploads/Postdocument', 0755);
                        }
						$config['upload_path']   = 'uploads/Postdocument/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name']     = $_FILES['document']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('document')){
							$uploadData = $this->upload->data();
							$image1 = $uploadData['file_name'];
							
						}else{
							$image1 = "";
						}
				 }
				 else
				 {
				 	$image1 = "";
				 }	
				$data['featured_image']	    = $image;
			   // $data['id_parent']          = $this->input->post('examcat');
				//$data['id_subsub']          = $this->input->post('subsub');
				$data['feautured_post']		= $this->input->post('featured');
				$data['topic_title']		= $this->input->post('title');
				$data['topic_description']	= base64_encode($this->input->post('content'));
				$data['notification']		= $this->input->post('notification');
				$data['topic_slug']			= $this->slug->create_uri($this->input->post('title'), $this->input->post('id'));
				$data['document']		    = $image1;
				$data['image_url']		    = $this->input->post('imageurl');
				if(isset($_POST['top_post']))
				{
					$data['added_date']			= date("Y-m-d H:i:s");
				}
				$invoice_id 				= $this->db_model->update('tbl_articelepost', $data, 'id', $this->input->post('id'));
				$this->db_model->delete('article_parentcats', 'article_id', $this->input->post('id'));
				$examcat  = $this->input->post('examcat');	
				$parentcat_ids = implode(",", $examcat) ;
				
				$parentcat_ids = "," . $parentcat_ids . ",";
				$this->GeneralModel->UpdateRow( "tbl_posts", array( 'parentcat_ids' => $parentcat_ids ), array( 'id' => $this->input->post('id') ) );
				
				foreach($examcat as $examcat) 
				{
					$data2['article_id']=$this->input->post('id');
					$data2['parentcat_id']=$examcat;
					$this->db_model->insert('article_parentcats', $data2);
				}
			
				foreach($_POST['examsubcat'] as $examsubcat) 
				{
					$data4['article_id']= $this->input->post('id');
					$data4['sub_catid']=  $examsubcat;
					$this->db_model->insert('article_parentcats', $data4); 
				}
				foreach($_POST['subsub'] as $examsubsubcat) 
				{
					$data5['article_id']= $this->input->post('id');
					$data5['sub_sub_catid']=  $examsubsubcat;
					$this->db_model->insert('article_parentcats', $data5); 
				}
				
				//$return  					= array('has_error'=>0, 'page'=> admin_url('Posts'), 'message' => 'Posts updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('topics'), 'refresh');
		}
	}
	*/
	
	
	
	public function repost(){	

		$artclid = $this->input->post('artclid');
		$tbl_posts = $this->GeneralModel->GetInfoRow( 'tbl_posts', array( 'article_id' => $artclid ) );
				// UNCOMMENT THIS
		//$this->GeneralModel->UpdateRow( "tbl_posts", array( 'repostedon' => @$tbl_posts[0]->created, 'created' => date('Y-m-d H:i:s') ), array( 'article_id' => $artclid ) );
		
		echo '1';exit;
	
	}
	
	public function update(){		
		
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			
			$error 	= array();
			$row 		= $this->posts_model->articledetails( $this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('examcat[]', 'Exam Category', 'trim|required');		
			$this->form_validation->set_rules('title', 'topic title', 'trim|required');
			// $this->form_validation->set_rules('content', 'topic content', 'trim|required');
			
			if ($this->form_validation->run() == FALSE) {
							
			    $error['examcat'] = form_error('examcat[]');			   
				$error['title'] 	= form_error('title');
				$error['editor'] 	= form_error('content');
				$return  			= array('has_error'=>1, 'error' => $error);
				
			}
			else{


			
				$data['topic_title']		= $this->input->post('title');
				$data['topic_description']	= base64_encode($this->input->post('content'));
				$data['topic_slug']			= $this->slug->create_uri($this->input->post('title'), $this->input->post('id'));

				if(isset($_POST['top_post']))
				{
					$data['added_date']			= date("Y-m-d H:i:s");
				}
				
				$invoice_id = $this->db_model->update('tbl_articelepost', $data, 'id', $this->input->post('id'));
				
				
				$this->db_model->delete('article_parentcats', 'article_id', $this->input->post('id'));
				
				$examcat  = $this->input->post('examcat');	
				$examsubcat  = $this->input->post('examsubcat');	
				$examsubsubcat  = $this->input->post('subsub');	
				
				$parentcat_ids = implode(",", $examcat) ;
				$parentinnercat_ids = implode(",", $examsubcat) ;
				$parentsubcat_ids = implode(",", $examsubsubcat) ;
				
				$parentcat_ids = "," . $parentcat_ids . ",";
				$parentinnercat_ids = "," . $parentinnercat_ids . ",";
				$parentsubcat_ids = "," . $parentsubcat_ids . ",";
				
				$this->GeneralModel->UpdateRow( "tbl_posts", array( 'parentcat_ids' => $parentcat_ids, 'parentinnercat_ids' => $parentinnercat_ids, 'parentsubcat_ids' => $parentsubcat_ids ), array( 'article_id' => $this->input->post('id') ) );
				
				foreach($examcat as $examcat) 
				{
					$data2['article_id']=$this->input->post('id');
					$data2['parentcat_id']=$examcat;
					$this->db_model->insert('article_parentcats', $data2);
				}
			
				foreach($_POST['examsubcat'] as $examsubcat) 
				{
					$data4['article_id']= $this->input->post('id');
					$data4['sub_catid']=  $examsubcat;
					$this->db_model->insert('article_parentcats', $data4); 
				}
				foreach($_POST['subsub'] as $examsubsubcat) 
				{
					$data5['article_id']= $this->input->post('id');
					$data5['sub_sub_catid']=  $examsubsubcat;
					$this->db_model->insert('article_parentcats', $data5); 
				}
				
				/*
				$return  					= array('has_error'=>0, 'page'=> admin_url('Posts'), 'message' => 'Posts updated successfully');
				*/
				
				$set = array( array('tag' => '.artclid', 'data' => $this->input->post('id'), 'fun' => 1) );
				
				$return = array('has_error' => 0, 'set' => $set, 'step' => '1', 'nextStep' => 2, 'message' => 'Post updated');
				
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('topics'), 'refresh');
		}
	}
	
	
    function getexamcategories()
	{
		 $cats = $this->posts_model->getallexamcategories();
		 if(count($cats) > 0){
           foreach($cats as $cats) {
   	       $data[]   = (object) array("id" => $cats->id, "text" => $cats->category_name);
         }
		 }
   	   echo json_encode($data); 
	}
	public function hide(){
	if (!has_permission('posts', 'status')) {
           redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['topic_status'] 	= 0;
				$this->db_model->update('tbl_articelepost', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Posts status updated successfully', 
				                'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function unhide(){
	if (!has_permission('posts', 'status')) {
           redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
			    $draft  		= $this->posts_model->checkdraftstatus($this->input->post('id'));
				if($draft == 1)
				{
					$this->posts_model->reinsertpost($this->input->post('id'));
				}
				$data['topic_status'] 	= 1;
				$this->db_model->update('tbl_articelepost', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Posts status updated successfully', 
				               'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function delete(){
	if (!has_permission('posts', 'delete')) {
           redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_articelepost', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Posts deleted successfully', 'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function view(){
	if (!has_permission('posts', 'view')) {
           redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');
            $row = $this->posts_model->articledetails($this->input->post('id'));
			$cats = $this->posts_model->articlecategorydeatils($this->input->post('id'));
			$subcats = $this->posts_model->articlesubcategorydeatils($this->input->post('id'));
			$subsubcats = $this->posts_model->articlesubsubcategorydeatils($this->input->post('id'));
			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
			     $html = '';
			     $html.='<table class="table table-bordered">
						  <thead>
							
						  </thead>
						  <tbody>';
						 
						  
						  $html.='<tr>
								 <td width ="30%">Super Category</td>
								 <td>';
								 if(!empty($cats))
								 {
									 foreach($cats  as $cats)
									 {
									    $html.=$cats->category_name;
										$html.='</br>';
										   
									 }
								}
							$html.='</td>
						         </tr>
								<tr>
								 <td width ="30%">Category</td>
								  <td>';
								 if(!empty($subcats))
								 {
									 foreach($subcats  as $subcats)
									 {
									    $html.=$subcats->title;
										$html.='</br>';
										   
									 }
								}
						  $html.='</td>
								</tr>
								<tr>
								<tr>
								 <td> Sub Category
								  <td>';
								 if(!empty($subsubcats))
								 {
									 foreach($subsubcats  as $subsubcats)
									 {
									    $html.=$subsubcats->title;
										$html.='</br>';
										   
									 }
								}
						  $html.='</td>
								</tr>
								<tr>
								 <td>Title</td>
								  <td>'.$row->topic_title.'</td>
								</tr>
								<tr>
								  <td>Description</td>
								  <td>'.base64_decode($row->topic_description).'</td>
								</tr>';
								
								
								
						 
				  $html.='</tbody>
						</table>';
				
				
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Posts Details', 'fun' => 3),
				                array('tag' => '#infoModal .modal-body',  'data' => $html, 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
				
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('topics'), 'refresh');
		}		
	}
}