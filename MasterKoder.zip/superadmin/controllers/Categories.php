<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Categories extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('category_model', 'db_model'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'category_slug',
							'title' => 'category_name',
							'table' => 'tbl_categories',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}

	public function index(){

		if (!has_permission('categories', 'dashboard_view')) {
			redirect( admin_url('login'), 'refresh' );
		}

		$data['page']  		= 'category';
		$data['script']  	= 1;
		$data['catcount']    = $this->category_model->category_count();
		$data['subcatcount']    = $this->category_model->subcategory_count();
		$data['subsubcatcount']    = $this->category_model->subsubcategory_count();

		$this->myadmin->view('category/details', $data);

	}
    public function details(){
		$data['page']  		= 'category';
		$data['script']  	= 1;
		$this->myadmin->view('category/home', $data);
	}
	public function get_all_datas(){
		echo $this->category_model->all_datas();
	}

	public function add(){
	if (!has_permission('categories', 'add')) {
         redirect(admin_url('login'), 'refresh');
    }
		$data['page']  		= 'category';
		$data['script']  	= 1;
		$this->myadmin->view('category/add', $data);
	}

	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_message('is_unique', 'The {field} already exsist, try another one');	
			$this->form_validation->set_rules('category_name', 'category_name', 'trim|required|is_unique[tbl_users.user_email]');
			$this->form_validation->set_rules('content',  'content ', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['category_name'] = form_error('category_name');
				$error['editor'] 		    = form_error('content');
				
				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
			
			      if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/ExamCategory')) {
                            mkdir('uploads/ExamCategory');
							chmod('uploads/ExamCategory', 0755);
                        }
						$config['upload_path'] = 'uploads/ExamCategory/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = "";
						}
				 }	
				$data['category_name']	= $this->input->post('category_name');
				$data['category_slug']	= $this->slug->create_uri($this->input->post('category_name'));
				$data['cat_description'] =  base64_encode($this->input->post('content'));
				$data['cat_image']			     = $image;
				$data['added_by']		= $this->user->id;
				$data['added_date']		= date("Y-m-d");
				$invoice_id = $this->db_model->insert('tbl_categories', $data); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('categories'), 'message' => 'Super Category inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('categories'), 'refresh');
		}
	}

	public function edit($id = 0){
	if (!has_permission('categories', 'edit')) {
         redirect(admin_url('login'), 'refresh');
    }
		if(!empty($id)){
			$data['page']  		= 'category';
			$data['script']  	= 1;
			$data['row']  		= $this->category_model->get_single($id);
			$this->myadmin->view('category/edit', $data);
		}
		else{
			redirect(admin_url('categories'), 'refresh');
		}
	}

	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row	= $this->category_model->get_single($this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_message('is_unique', 'The {field} already exsist, try another one');	

			if($row->category_name != $this->input->post('category_name')){
				$this->form_validation->set_rules('category_name', 'category_name', 'trim|required|is_unique[tbl_categories.category_name]');
			}
			else{
				$this->form_validation->set_rules('category_name', 'category_name', 'trim|required');
			}

			if ($this->form_validation->run() == FALSE) {
				$error['category_name'] = form_error('category_name');
				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
				 if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/ExamCategory')) {
                            mkdir('uploads/ExamCategory');
							chmod('uploads/ExamCategory', 0755);
                        }
						$config['upload_path'] = 'uploads/ExamCategory/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							//unlink('uploads/ExamCategory/'.$row->cat_image);
							
						}else{
							$image = $row->cat_image;
						}
				 }
				 else
				 {
				 	$image = $row->cat_image;
				 }	
				$data['category_name']		= $this->input->post('category_name');
				$data['category_slug']		= $this->slug->create_uri($this->input->post('category_name'), $this->input->post('id'));
				$data['cat_description']	=  base64_encode($this->input->post('content'));
				$data['cat_image']		    = $image;
				$invoice_id = $this->db_model->update('tbl_categories', $data, 'id', $this->input->post('id')); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('categories'), 'message' => 'Super Category updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('users'), 'refresh');
		}
	}

	public function hide(){
	if (!has_permission('categories', 'status')) {
         redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['category_status'] 	= 0;
				$this->db_model->update('tbl_categories', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Super Category status updated successfully', 'function'=> 'refreshCategoryTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('categories'), 'refresh');
		}		
	}

	public function unhide(){
	if (!has_permission('categories', 'status')) {
         redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['category_status'] 	= 1;
				$this->db_model->update('tbl_categories', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Super Category status updated successfully', 'function'=> 'refreshCategoryTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('categories'), 'refresh');
		}		
	}

	public function delete(){
	if (!has_permission('categories', 'status')) {
         redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_categories', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Category deleted successfully', 'function'=> 'refreshCategoryTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('categories'), 'refresh');
		}		
	}

	public function view(){
	if (!has_permission('categories', 'view')) {
         redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$row	= $this->category_model->get_single($this->input->post('id'));
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Super Category Details', 'fun' => 3),
				array('tag' => '#infoModal .modal-body',  'data' =>  $row->category_name, 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('categories'), 'refresh');
		}		
	}
}