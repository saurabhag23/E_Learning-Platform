<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Roles extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}
		else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('db_model','rolemodel'));
			$this->user = $this->session->userdata($this->session_name);
			$config['table_name']   = 'tbl_permissions';
			$config['ajax_url']   	= admin_url('roles/set_permissions');
			$this->load->library('permissions');
			$this->permissions->init($config);
		}	
	}

	public function index(){
		$data['page']  		= 'roles';
		$data['script']  	= 1;
		$this->myadmin->view('roles/home', $data);
	}

	public function get_all_datas(){
		echo $this->rolemodel->all_datas();
	}

	public function add(){
		$data['page']  		= 'roles';
	    $this->myadmin->view('roles/add', $data);
	}

	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
		
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_message('is_unique', 'The {field} already exsist, try another one');
			$this->form_validation->set_rules('role', 'User Role', 'trim|required|is_unique[ tbl_roles.role_name]');
			
			

			if ($this->form_validation->run() == FALSE) {
		        $error['role'] 	= form_error('role');
				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['role_name']	 = $this->input->post('role');
				$data['role_added_by']		    = $this->user->id;
				$data['role_added_date	']		    = date("Y-m-d H:i:s");
				$invoice_id = $this->db_model->insert('tbl_roles', $data); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('roles'), 'message' => 'User Role added successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('roles'), 'refresh');
		}
	}

	public function edit($id = 0){
		if(!empty($id)){
			$data['page']  		= 'roles';
			
			$data['row']  		= $this->rolemodel->get_single($id);
			$this->myadmin->view('roles/edit', $data);
		}
		else{
			redirect(admin_url('roles'), 'refresh');
		}
	}

	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
		
			$error 	= array();
			
			$this->form_validation->set_rules('role', 'role', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
		       $error['role'] 	= form_error('role');
				$return  				= array('has_error'=>1, 'error' => $error);
			
			}
			else{
				$data['role_name']	 = $this->input->post('role');
				
				$invoice_id = $this->db_model->update('tbl_roles', $data, 'id', $this->input->post('id')); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('roles'), 'message' => 'User Role added successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('roles'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['role_status'] 	= 0;
				$this->db_model->update('tbl_roles', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'User Role status updated successfully', 'function'=> 'refreshUserroleTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('roles'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['role_status'] 	= 1;
				$this->db_model->update('tbl_roles', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'User Role status updated successfully', 'function'=> 
				         'refreshUserroleTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('roles'), 'refresh');
		}		
	}

	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_roles', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'User deleted successfully', 'function'=> 'refreshUserroleTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('roles'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');
			$row 		= $this->rolemodel->get_single($this->input->post('id'));
			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
			   
				
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'User Role', 'fun' => 3),
				                array('tag' => '#infoModal .modal-body',  'data' => $row->role_name, 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('roles'), 'refresh');
		}		
	}
	public function permissions($roleid = 0){
		$data['page']  			= 'roles';
		$data['script_page']  	= 'roles';
		
		$row 					= $this->rolemodel->get_single($roleid);
		if(count($row) > 0){
			$data['row']        	= $row;
			$data['permissions'] 	= $this->permissions->generate($roleid);
			$this->myadmin->view('roles/permission', $data);
		}
		else{
			$this->myadmin->view('404', $data);
		}
	}
	public function set_permissions(){
		$this->permissions->set_permission();
	}
}