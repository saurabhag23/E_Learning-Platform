<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Notes extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('syllabus_model', 'db_model', 'course_model','notes_model','posts_model'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'slug',
							'title' => 'title',
							'table' => 'tbl_notes',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}



	public function index(){
	if (!has_permission('notes', 'dashboard_view')) {
         redirect(admin_url('login'), 'refresh');
    }
		    $data['page']  		= 'notes';
		    $data['script']  	= 1;
			//$data['row']  		= $this->syllabus_model->get_single();
			$this->myadmin->view('notes/home', $data);
	
	}
    public function get_all_datas(){
		echo $this->notes_model->all_datas();
	}



	public function add(){
	if (!has_permission('notes', 'add')) {
         redirect(admin_url('login'), 'refresh');
    }
		    $data['page']  		= 'notes';
		    $data['script']  	= 1;
			$data['examcats']  	= $this->course_model->get_all_categories();
			//$data['subcats']    =  $this->posts_model->get_all_subcategoriesbypost();
			$data['curtypes']  = $this->course_model->getcurrent_affairtypes();
			
			$this->myadmin->view('notes/add', $data);
	}
 


	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('examcat', 'Exam Category', 'trim|required');
			$this->form_validation->set_rules('examsubcat', 'Exam Sub Category', 'trim|required');
			//$this->form_validation->set_rules('exam', 'Exam', 'trim|required');
			$this->form_validation->set_rules('title', 'Notes title', 'trim|required');
			$this->form_validation->set_rules('content', 'Notes content', 'trim|required');
			

			if ($this->form_validation->run() == FALSE) {
			    $error['examcat'] = form_error('examcat');
				$error['examsubcat'] = form_error('examsubcat');
				//$error['exam']      = form_error('exam');
			   
				$error['title'] 	= form_error('title');
				$error['editor'] 	= form_error('content');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
				 if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/Notes')) {
                            mkdir('uploads/Notes');
							chmod('uploads/Notes', 0755);
                        }
						$config['upload_path'] = 'uploads/Notes/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
						}else{
							$image = '';
						}
				 }	
				 else
				 {
				 	$image = '';
				 }
				  if(!empty($_FILES['document']['name'])){
				 		if (!is_dir('uploads/NotesDocument')) {
                            mkdir('uploads/NotesDocument');
							chmod('uploads/NotesDocument', 0755);
                        }
						$config['upload_path'] = 'uploads/NotesDocument/';
						$config['allowed_types'] = '*';
						$config['file_name'] = $_FILES['document']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('document')){
							$uploadData = $this->upload->data();
							$document = $uploadData['file_name'];
						}else{
							$document = '';
						}
				 }	
				 else
				 {
				 	$document = '';
				 }
			    $data['featured_image']	= $image; 
				$data['document']		= $document;
			    $data['id_parent']          = $this->input->post('examcat');
				$data['id_subcategory']     = $this->input->post('examsubcat');
		     	
				$data['title']		= $this->input->post('title');
				$data['description']	= base64_encode($this->input->post('content'));
				$data['slug']			= $this->slug->create_uri($this->input->post('title'));
				$data['feautured_post']		= $this->input->post('featured');
				$data['image_url']		= $this->input->post('imgurl');
				$data['added_by']			= $this->user->id;
				$data['added_date']			= date("Y-m-d");
				$invoice_id = $this->db_model->insert('tbl_notes', $data); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('notes'), 'message' => 'Notes inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notes'), 'refresh');
		}
	}



	public function edit($id = 0){
	if (!has_permission('notes', 'edit')) {
         redirect(admin_url('login'), 'refresh');
    }

		if(!empty($id)){
			$data['page']  		= 'notes';
			$data['script']  	= 1;
			$data['row']  		= $this->notes_model->notesdetails($id);
		    $data['examcats']  	= $this->course_model->get_all_categories();
			$data['subcats']    =  $this->notes_model->get_all_subcategoriesbycat($data['row']->id_subcategory);
		//	$data['notescat']  	= $this->notes_model->get_all_notescategories();
			$data['exams'] =  $this->course_model->getallmainexams();
			$this->myadmin->view('notes/edit', $data);
		}
	}



	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row  	= $this->notes_model->notesdetails($this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('examcat', 'Exam Category', 'trim|required');
			$this->form_validation->set_rules('examsubcat', 'Exam Sub Category', 'trim|required');
			
			$this->form_validation->set_rules('title', 'topic title', 'trim|required');
			$this->form_validation->set_rules('content', 'Notes content', 'trim|required');
			
			if ($this->form_validation->run() == FALSE) {
			     $error['examcat'] = form_error('examcat');
				 $error['examsubcat'] = form_error('examsubcat');
			   
				$error['title'] 	= form_error('title');
				$error['editor'] 	= form_error('content');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
			  	
				 if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/Notes')) {
                            mkdir('uploads/Notes');
							chmod('uploads/Notes', 0755);
                        }
						$config['upload_path'] = 'uploads/Notes/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							if(!empty($row->featured_image))
							{
								if (file_exists('uploads/Notes'.$row->featured_image)) {
								 unlink('uploads/Notes/'.$row->featured_image);
								 }
							}
							
						}else{
							$image = $row->featured_image;
						}
				 }	
				 else
				 {
				 	$image = $row->featured_image;
				 }
				 if(!empty($_FILES['document']['name'])){
				 		if (!is_dir('uploads/NotesDocument')) {
                            mkdir('uploads/NotesDocument');
							chmod('uploads/NotesDocument', 0755);
                        }
						$config['upload_path'] = 'uploads/NotesDocument/';
						$config['allowed_types'] = '*';
						$config['file_name'] = $_FILES['document']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('document')){
							$uploadData = $this->upload->data();
							$document = $uploadData['file_name'];
						}else{
							$document = $row->document;
						}
				 }	
				 else
				 {
				 	$document = $row->document;
				 }
			    $data['featured_image']	    = $image;
			    $data['id_parent']          = $this->input->post('examcat');
				$data['id_subcategory']     = $this->input->post('examsubcat');
			 	$data['document']		= $document;
				$data['title']		= $this->input->post('title');
				$data['description']= base64_encode($this->input->post('content'));
				$data['slug']		= $this->slug->create_uri($this->input->post('title'));
				$data['feautured_post']		= $this->input->post('featured');
				$data['image_url']		= $this->input->post('imgurl');
				$invoice_id 				= $this->db_model->update('tbl_notes', $data, 'id', $this->input->post('id')); 
				$return  					= array('has_error'=>0, 'page'=> admin_url('notes'), 'message' => 'Notes updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notes'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('tbl_notes', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Notes status updated successfully', 
				                'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notes'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('tbl_notes', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Notes status updated successfully', 
				               'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notes'), 'refresh');
		}		
	}

	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_notes', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Notes deleted successfully', 'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notes'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');
            $row = $this->notes_model->notesdetails($this->input->post('id'));
			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
			     $html = '';
			     $html.='<table class="table table-bordered">
						  <thead>
							
						  </thead>
						  <tbody>';
						 
						  
						  $html.='<tr>
								 <td>Exam Category</td>
								  <td>'.$row->category_name.'</td>
								</tr>
								<tr>
								 <td>Exam Sub Category</td>
								  <td>'.$row->subtitle.'</td>
								</tr>
								<tr>
								 <td>Title</td>
								  <td>'.$row->title.'</td>
								</tr>
								<tr>
								  <td>Description</td>
								  <td>'.base64_decode($row->description).'</td>
								</tr>';
								
								
						 
				  $html.='</tbody>
						</table>';
				
				
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Notes Details', 'fun' => 3),
				                array('tag' => '#infoModal .modal-body',  'data' => $html, 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
				
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notes'), 'refresh');
		}		
	}
	function getsubcategory()
	{
		
	
	
		 $subcats =  $this->notes_model->get_all_subcatscategoriesbyid($_POST['catid']);
		 $html = "";
		 $html.='<option value="0">Select Sub category</option>'; 
		 if(!empty($subcats))
		 {
			 foreach($subcats as  $subcats)
			 {
				 $html.= '<option value="'.$subcats->id.'">'.$subcats->title.'</option>';
			 }
		 }
		 echo  $html;
	
	}
}