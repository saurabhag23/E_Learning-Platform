<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Tools extends MX_Controller{
	
	function __construct(){
		
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->user = $this->session->userdata($this->session_name);
		}	
		
	}

	public function index(){
		$data['page']  = 'dashboard';
		
		$l1count = $this->db->query( "SELECT count(*) as l1count FROM `tbl_mlevel1`" )->row();
		$l2count = $this->db->query( "SELECT count(*) as l2count FROM `tbl_mlevel2`" )->row();
		$l3count = $this->db->query( "SELECT count(*) as l3count FROM `tbl_mlevel3`" )->row();
		
		$data['menucnt'] = $l1count->l1count + $l2count->l2count + $l3count->l3count ;
		
		$data['feedcount'] = $this->db->query( "SELECT count(*) as feedcount FROM `feedback`" )->row()->feedcount;
		$data['advcount'] = $this->db->query( "SELECT count(*) as advcount FROM `tble_advertizement`" )->row()->advcount;
		$data['quickcount'] = $this->db->query( "SELECT count(*) as quickcount FROM `quicklinks`" )->row()->quickcount;
		$data['leadcount'] = $this->db->query( "SELECT count(*) as leadcount FROM `leaderboard`" )->row()->leadcount;
		$data['countcount'] = $this->db->query( "SELECT count(*) as countcount FROM `countdown`" )->row()->countcount;
		
	    $this->myadmin->view('tools', $data);
	}
	
	public function get_all_datas(){
		echo 'asdf fdsa';
	}

	public function mlevels(){
		$data['page']  = 'dashboard';
	    $this->myadmin->view('mlevels', $data);
	}
	
	
}

?>