<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Exam extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation', 'upload'));
			$this->load->model(array('exam_model', 'db_model','course_model'));
			$this->user = $this->session->userdata($this->session_name);
			$this->tmp_path = 'tmp/';
			$config = array('field' => 'exam_slug',
							'title' => 'exam_title',
							'table' => 'tbl_exams',
							'id'    => 'id_exam');
			$this->load->library('slug', $config);
		}	
	}



	public function index($course_id = 0){
		$data['page']  			= 'exam';
		if(!empty($course_id)){
			$data['script']  	= 1;
			$data['course_id']  = $course_id;
			$data['row']  		= $this->course_model->get_single($course_id);
			if(count($data['row']) > 0){
				$this->myadmin->view('exam/home', $data);
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			redirect(admin_url('404'), 'refresh');
		}
	}

	public function get_all_datas($course_id){
		echo $this->exam_model->all_datas($course_id);
	}

	public function add($course_id = 0){
		$data['page']  			= 'exam';
		if(!empty($course_id)){
			$data['script']  	= 1;
			$data['course_id']  = $course_id;
			$data['row']  		= $this->course_model->get_single($course_id);
			$this->session->unset_userdata('exam_id');
			if(count($data['row']) > 0){
				$this->myadmin->view('exam/add', $data);
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			redirect(admin_url('404'), 'refresh');
		}
	}



	public function insert_step_1(){
		if(isset($_POST['action']) && $_POST['action'] == "exam-step1"){
		    $path  = "";
			$new_path  = "";
			$error = array();
			$course_id   = $this->input->post('course_id');
			$exam_id     = $this->input->post('exam_id');
			if(!empty($exam_id)){
				$row  = $this->exam_model->get_single($exam_id);
			}
			$course_data = $this->course_model->get_single($course_id);
			if(count($course_data) > 0){

				$path  = 'uploads/'.$this->tmp_path;
				
				if(!is_dir($path)) {
					mkdir($path);
					chmod($path, 0755);
					
				}

				$config['upload_path']  			= $path;
				$config['allowed_types']   			= 'gif|jpg|png|jpeg|bmp';
				$config['file_name'] 				= strtolower($this->input->post('exam_name')); 
				$config['file_ext_tolower']			= TRUE;
				$config['remove_spaces'] 			= TRUE;		
				$this->upload->initialize($config);
                $this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
				$this->form_validation->set_rules('exam_name', 'exam name', 'trim|required');
				$this->form_validation->set_rules('total_questions',  'total questions', 'trim|required|numeric');
				$this->form_validation->set_rules('total_time', 'exam duration', 'trim|required|numeric');
				$this->form_validation->set_rules('duration_slug', 'exam duration', 'trim|required');
				$this->form_validation->set_rules('exam_description', 'exam description', 'trim|required');
				$this->form_validation->set_rules('meta_tags[]', 'exam meta tags', 'trim|required');
				
				//if(!empty($_FILES['featured_image']['name'])) {
				
					if (!$this->upload->do_upload('featured_image')){
						$error['featured_image'] 	= set_error($this->upload->display_errors());
						
					}
				//}

				if ($this->form_validation->run() == FALSE) {
					$error['exam_name'] 		= form_error('exam_name');
					$error['total_questions'] 	= form_error('total_questions');
					$error['total_time'] 		= form_error('total_time');
					$error['editor'] 			= form_error('exam_description');
					//$error['featured_image'] 	= form_error('featured_image');
					$error['meta_tags'] 		= form_error('meta_tags[]');
					if(form_error('duration')!=""){
						$error['total_time'] 	= form_error('total_time');
					}
					else{
						$error['total_time'] 	= form_error('duration_slug');
					}
					$return  					= array('has_error'=>1, 'error' => $error);
				}
				else{
					$exam_no 					= $this->exam_model->get_next_exam_no($course_id);
					if(!empty($_FILES['featured_image']['name']) && !empty($exam_id)) {
						if(file_exists($row->exam_upload_path.$row->exam_featured_image)) {
							unlink($row->exam_upload_path.$row->exam_featured_image);
						}	
						$image 						= $this->upload->data();
						$data['exam_featured_image']= $image['file_name'];
					}
					elseif(!empty($_FILES['featured_image']['name'])) {
						$image 						= $this->upload->data();
						$data['exam_featured_image']= $image['file_name'];
					}
					$data['id_course']				= $course_id;
					$data['exam_name']				= $this->input->post('exam_name');
					$data['exam_description']		= base64_encode($this->input->post('exam_description'));
					$data['exam_duration']			= $this->input->post('total_time');
					$data['exam_duration_slug']		= $this->input->post('duration_slug');
					$data['total_questions']		= $this->input->post('total_questions');
					$data['exam_meta_tags']			= json_encode($this->input->post('meta_tags'));
					$data['exam_slug']				= $this->slug->create_uri($this->input->post('exam_name'));
					if(empty($exam_id)){
					
						$data['exam_no']			= $exam_no;
						$data['added_by']			= $this->user->id;
						$data['added_date']			= date("Y-m-d H:i:s");
						$exam_id 					= $this->db_model->insert('tbl_exams', $data); 
						$this->session->set_userdata('exam_id',$exam_id);
						$new_path 					= 'uploads/exam_'.$exam_no.'/';
						if(!is_dir($new_path)) {
							mkdir($new_path);
							chmod($new_path, 0755);
						}
						rename('uploads/'.$this->tmp_path.$image['file_name'], $new_path.$image['file_name']);
						$data2['exam_upload_path']	= $new_path;
						$this->db_model->update('tbl_exams', $data2, 'id_exam', $exam_id);
					}
					else{
						if(!empty($_FILES['featured_image']['name'])) {
							$new_path 	= $row->exam_upload_path;
							if(!is_dir($new_path)) {
								mkdir($new_path);
								chmod($new_path, 0755);
							}
							rename('uploads/'.$this->tmp_path.$image['file_name'], $new_path.$image['file_name']);
							$data['exam_upload_path']	= $new_path;
						}
						$this->db_model->update('tbl_exams', $data, 'id_exam', $exam_id); 
					}
					$set 		= array(array('tag' => '.exam_id',  'data' => $exam_id, 'fun' => 1));
					$return  	= array('has_error'=>0, 'step'=>'1', 'nextStep' => 2, 'set'=> $set, 'message' => 'Step 1 completed');
				}	
				echo json_encode($return);
			}
		}
		else{
			redirect(admin_url('exams'), 'refresh');
		}
	}



	public function insert_step_2(){
		if(isset($_POST['action']) && $_POST['action'] == "exam-step2"){
			$error = array();
			$exam_id     	= $this->input->post('exam_id');
			$exam_data 		= $this->exam_model->get_single($exam_id);
			if(count($exam_data) > 0){
				$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
				$this->form_validation->set_rules('question_name', 'question name', 'trim|required');
				$this->form_validation->set_rules('answer_option', 'answer', 'trim|required');
				

				$temp_path  = $exam_data->exam_upload_path.$this->tmp_path;
				if(!is_dir($temp_path)) {
					mkdir($temp_path);
					chmod($temp_path, 0755);
				}

				$question_image 	= do_image_upload($temp_path, 'question_image', array("file_name" => "question_image", "overwrite" => TRUE), 0);
				if(!empty($question_image['error'])){
					$error['question_image']		= $question_image['error'];
				}

				$option_1_image 	= do_image_upload($temp_path, 'option_1_image', array("file_name" => "option_1_image", "overwrite" => TRUE), 0);
				if(!empty($option_1_image['error'])){
					$error['option_1_image']		= $option_1_image['error'];
				}
				elseif(!empty($option_1_image['name'])){
					$this->form_validation->set_rules('option_1',  'first option',  'trim');
				}
				else{
					$this->form_validation->set_rules('option_1',  'first option',  'trim|required');
				}



				$option_2_image 	= do_image_upload($temp_path, 'option_2_image', array("file_name" => "option_2_image", "overwrite" => TRUE), 0);
				if(!empty($option_2_image['error'])){
					$error['option_2_image']		= $option_2_image['error'];
				}
				elseif(!empty($option_2_image['name'])){
					$this->form_validation->set_rules('option_2',  'first option',  'trim');
				}
				else{
					$this->form_validation->set_rules('option_2',  'first option',  'trim|required');
				}


				$option_3_image 	= do_image_upload($temp_path, 'option_3_image', array("file_name" => "option_3_image", "overwrite" => TRUE), 0);
				if(!empty($option_3_image['error'])){
					$error['option_3_image']		= $option_3_image['error'];
				}
				elseif(!empty($option_3_image['name'])){
					$this->form_validation->set_rules('option_3',  'first option',  'trim');
				}
				else{
					$this->form_validation->set_rules('option_3',  'first option',  'trim|required');
				}


				$option_4_image 	= do_image_upload($temp_path, 'option_4_image', array("file_name" => "option_4_image", "overwrite" => TRUE), 0);
				if(!empty($option_4_image['error'])){
					$error['option_4_image']		= $option_4_image['error'];
				}
				elseif(!empty($option_4_image['name'])){
					$this->form_validation->set_rules('option_4',  'first option',  'trim');
				}
				else{
					$this->form_validation->set_rules('option_4',  'first option',  'trim|required');
				}


				if ($this->form_validation->run() == FALSE || !empty($error)) {
					$error['question_name'] 		= form_error('question_name');
					$error['option_1'] 				= form_error('option_1');
					$error['option_2'] 				= form_error('option_2');
					$error['option_3'] 				= form_error('option_3');
					$error['option_4'] 				= form_error('option_4');
					$error['answer_option '] 		= form_error('answer_option');
					$return  						= array('has_error'=>1, 'error' => $error);
				}

				if(empty($error)){
					$question_no 					= $this->exam_model->get_next_qstn_no($exam_id);
					$data['id_exam']				= $exam_id;
					$data['id_course']				= $this->input->post('course_id');
					$data['question_no']			= $question_no;
					$data['question_name']			= $this->input->post('question_name');
					$data['question_option_1']		= $this->input->post('option_1');
					$data['question_option_2']		= $this->input->post('option_2');
					$data['question_option_3']		= $this->input->post('option_3');
					$data['question_option_4']		= $this->input->post('option_4');
					$data['question_answer']		= $this->input->post('answer_option');
					$data['explanation']		    = $this->input->post('explanation');
					$data['added_by']				= $this->user->id;
					$data['added_date']				= date("Y-m-d H:i:s");
					$question_id = $this->db_model->insert('tbl_exams_questions', $data);
					$path 		 = $exam_data->exam_upload_path.'question_'.$question_no.'/';
 					if(!is_dir($path)) {
						mkdir($path);
						chmod($path, 0755);
					}

					if(!empty($question_image['name'])){
						rename($temp_path.$question_image['name'], $path.$question_image['name']);
						$data2['question_image']			= $question_image['name'];
					}

					if(!empty($option_1_image['name'])){
						rename($temp_path.$option_1_image['name'], $path.$option_1_image['name']);
						$data2['question_option_1_image	']	= $option_1_image['name'];
					}

					if(!empty($option_2_image['name'])){
						rename($temp_path.$option_2_image['name'], $path.$option_2_image['name']);
						$data2['question_option_2_image	']	= $option_2_image['name'];
					}

					if(!empty($option_3_image['name'])){
						rename($temp_path.$option_3_image['name'], $path.$option_3_image['name']);
						$data2['question_option_3_image	']	= $option_3_image['name'];
					}

					if(!empty($option_4_image['name'])){
						rename($temp_path.$option_4_image['name'], $path.$option_4_image['name']);
						$data2['question_option_4_image	']	= $option_4_image['name'];
					}

					$data2['question_upload_path']		= $path;
					$this->db_model->update('tbl_exams_questions', $data2, 'id_question', $question_id); 
					$return  	 = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Question added successfully', 'function'=> 'refreshQuestionsTable', 'reset' => '1');
				}	
				echo json_encode($return);
			}
		}
		else{
			redirect(admin_url('exams'), 'refresh');
		}
	}



	public function insert_step_3(){
		if(isset($_POST['action']) && $_POST['action'] == "exam-step3"){
			$course_id   = $this->input->post('course_id');
			$data['quiz_id']			= $this->session->userdata('exam_id');
			$data['status']				= 4;
			$data['userid']				= $this->user->id;
			$data['created']				= date("Y-m-d ");
			$question_id = $this->db_model->insert('tbl_posts', $data);
			$return  	 = array('has_error'=>0, 'page'=> admin_url('subcategory/exam/'.$course_id, 1), 'message' => 'Exam details added successfully');
			echo json_encode($return);
		}
	}



	public function get_all_questions(){
		$exam_id = 0;
		if($this->session->userdata('exam_id')!=""){
			$exam_id = $this->session->userdata('exam_id');
		}
		echo $this->exam_model->all_questions($exam_id);
	}



	public function edit($exam_id = 0){
		$data['page']  			= 'exam';
		if(!empty($exam_id)){
			$data['script']  	= 1;
			$data['row']  		= $this->exam_model->get_single($exam_id);
			$data['course_id']  = $data['row']->id_course;
			$this->session->set_userdata('exam_id', $exam_id);
			if(count($data['row']) > 0){
				$this->myadmin->view('exam/edit', $data);
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('tbl_exams', $data, 'id_exam', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Exam status updated successfully', 'function'=> 'refreshExamTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('exam'), 'refresh');
		}		
	}



	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('tbl_exams', $data, 'id_exam', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Exam status updated successfully', 'function'=> 'refreshExamTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('exam'), 'refresh');
		}		
	}



	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$row	= $this->exam_model->get_single($this->input->post('id'));
				if(!empty($row)){
					if(is_dir($row->exam_upload_path)) {
					    deleteDirectory($row->exam_upload_path);
					}
				}
				$this->db_model->delete('tbl_exams', 'id_exam', $this->input->post('id'));				
				$this->db_model->delete('tbl_exams_questions', 'id_exam', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Exam deleted successfully', 'function'=> 'refreshExamTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('exam'), 'refresh');
		}		
	}



	public function details($exam_id = 0){
		$data['page']  			= 'exam';
		if(!empty($exam_id)){
			$data['script']  	= 1;
			$data['row']  		= $this->exam_model->get_single($exam_id);
			$this->session->set_userdata('exam_id', $exam_id);
			if(count($data['row']) > 0){
				$data['course_id']  = $data['row']->id_course;
				$this->myadmin->view('exam/details', $data);
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			redirect(admin_url('courses'), 'refresh');
		}
	}

}