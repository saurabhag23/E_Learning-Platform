<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->user = $this->session->userdata($this->session_name);
		}	
			$this->load->library(array('datatables', 'form_validation'));

		$this->load->helper('form');
	}

	public function index(){
	    
	    
		$data['page']  = 'upload';
		$data['script']  	= 1;
	    $this->load->model('db_model');
	    $data['upload_files'] =  $this->db_model->all_datas();

	    $this->myadmin->view('upload/details', $data);
	}
	
		public function upload(){
		$data['page']  = 'upload';
		$data['script']  	= 1;
	    $this->myadmin->view('upload/upload', $data);
	}
	
	public function up(){
		// if(isset($_POST['action']) && $_POST['action'] == "insert"){
			
		$config['upload_path']   = './uploads/attatchments'; 
        $config['allowed_types'] = 'pdf|doc|docx|jpg|png|gif|ico'; 
        $config['max_size']      = 2000; 
		$config['file_name'] = strtolower($_FILES['ufile']['name']);
		
        $this->load->library('upload', $config);
			
         if ( ! $this->upload->do_upload('ufile')) {
            // $error = array('error' => $this->upload->display_errors()); 
            // $this->load->view('upload_form', $error); 
			
			$error['ufile'] = $this->upload->display_errors();
			$return  		= array('has_error'=>1, 'error' => $error);
			
         }
			
         else {  
            $data = array('upload_data' => $this->upload->data()); 
            // $this->load->view('upload_success', $data); 
			
/* 			echo "<hr><pre>data: ";
			var_dump( $data["upload_data"]["file_name"] );
			exit; */
						$now = new DateTime();
            $now->setTimezone(new DateTimezone('Asia/Kolkata'));


            $data1['file_name'] = $this->input->post('file_name');
			$data1['file_link'] = base_url() . 'uploads/attatchments/' . $data["upload_data"]["file_name"];
			$data1['created_at'] = $now->format('Y-m-d H:i:s');
	
			$this->load->model('db_model');
			$this->db_model->insert_upload('tbl_upload', $data1);

			$return  	= array('has_error'=>0, 'page'=> admin_url('upload'), 'uurl' => base_url() . 'uploads/attatchments/' . $data["upload_data"]["file_name"] );
			

         } 
			

			echo json_encode($return);
/* 		}
		else{
			redirect(admin_url('upload'), 'refresh');
		} */
	}
	
	
	public function upasdf(){		



	}
	
	public function get_all_datas(){
	    $this->load->model('upload_model');
	echo $this->upload_model->all_datas();
	}

	public function mlevels(){
		$data['page']  = 'dashboard';
	    $this->myadmin->view('mlevels', $data);
	}
}

?>