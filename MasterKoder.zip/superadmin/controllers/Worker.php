<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Worker extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation','permissions'));
			$this->load->model(array('posts_model', 'db_model', 'course_model','dailyquiz_model','GeneralModel'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'topic_slug',
							'title' => 'topic_title',
							'table' => 'tbl_articelepost',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}
	
	public function index(){
	    echo 'ready to work';
	    
	    $res = $this->db->query( "SELECT distinct( quiz_id ) as quiz_id FROM `tbl_quizparentcats`" )->result();
	    
	    if( !empty( $res1 ) )
        {	
            foreach( $res as $key => $value )
        	{	
        	    
				$resinnercat = $this->db->query( "select * from tbl_quizparentcats where quiz_id = " . $value->quiz_id . " and sub_catid is not null" )->result();
				
				$parentinnercat_ids = '';
				
				if( !empty( $resinnercat ) )
				{	
					foreach( $resinnercat as $key => $valueicat )
					{	
						$parentinnercat_ids .= $valueicat->sub_catid . ',';
					}
					
					$parentinnercat_ids = ',' . $parentinnercat_ids;
					
				    $this->db->query( "update tbl_posts set parentinnercat_ids = '$parentinnercat_ids' where quiz_id = " . $value->quiz_id );
				}
        	    
        	    
        	}
        }
	    
	    echo 'damlo';
	}
	
	public function vcf(){
	 
    	 //Call the function
    
        $contactData = '{
        
        "data": [
        
        {
        
        "name": "Viral Jadhav",
        
        "desi": "Digital Marketer",
        
        "company": "SIB Infotech",
        
        "website": "http://www.sibinfotech.co.uk/projects/card/login.php",
        
        "mobile_number": "9898098980",
        
        "email_address": "user1@domain.com"
        
        }
        
        ]
        
        }';
        
        //NOTE : You can add multiple contacts or get them from database to generate all contacts VCF file.
        
        //echo exportContactVCF($contactData);
        
        $userContacts = json_decode($contactData);

        $dataArray = "";
        
        foreach($userContacts as $contact){
        
            for($i=0; $i<sizeof($contact);$i++){
            
            $company = $contact[$i]->company;
            
            $desi = $contact[$i]->desi;
            
            $fullname = $contact[$i]->name;
            
            $website = $contact[$i]->website;
            
            $fullnameArray = explode(" ",$fullname);
            
            $first_name = $fullnameArray[0];
            
            $last_name = $fullnameArray[1];
            
            $mobile_number = $contact[$i]->mobile_number;
            
            $email_address= $contact[$i]->email_address;
            
            /*
            $dataArray .="BEGIN:VCARD\nN:$first_name;$last_name\nFN:$first_name\nTEL;TYPE=WORK,MSG:$mobile_number\nEMAIL;TYPE=INTERNET:$email_address\nEND:VCARD\n";
            */
            
            $dataArray .="BEGIN:VCARD\nVERSION:3.0\nREV:2019-03-08T16:49:56Z\n
N;CHARSET=utf-8:$last_name;$first_name;;;\nFN;CHARSET=utf-8:$first_name $last_name\nORG;CHARSET=utf-8:$company\nTITLE;CHARSET=utf-8:$desi\nEMAIL;INTERNET:$email_address\nTEL;PREF;WORK:$mobile_number\nTEL;WORK:+$mobile_number\nURL:$website\nEND:VCARD\n";
            
            }
        
        }
        
        $data = $dataArray;
        
        $size = strlen($data);
        
        $filename = "contact.vcf";
        
        header("Content-Type: application/octet-stream");
        
        header("Content-Length: $size");
        
        header("Content-Disposition: attachment; filename=\"$filename\"");
        
        header("Content-Transfer-Encoding: binary");
        
        echo $data;
	    
	}
	
}

?>