<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Seo extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->user = $this->session->userdata($this->session_name);
		}	
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('GeneralModel'));

		$this->load->helper('form');
	}

	public function updatemeta(){
		
		$article_id = $this->input->post('article_id');
		$quiz_id = $this->input->post('quiz_id');
		$meta_title = $this->input->post('meta_title');
		$meta_desc = $this->input->post('meta_desc');
		$meta_key = $this->input->post('meta_key');
		
		if( !empty( $article_id ) )
			$where = array( 'article_id' => $article_id );	
		
		if( !empty( $quiz_id ) )
			$where = array( 'quiz_id' => $quiz_id );	
		
		$data = array( 'meta_title' => $meta_title, 'meta_desc' => $meta_desc, 'meta_key' => $meta_key );
		
		$this->GeneralModel->UpdateRow( "seo_data", $data, $where );
		
		echo '1';exit;
		
	}	
		
	public function get_seodata(){
		
		$article_id = $this->input->post('article_id');
		$quiz_id = $this->input->post('quiz_id');
		
		if( !empty( $article_id ) )
		{
			$seo_data = $this->GeneralModel->GetInfoRow( 'seo_data', array( 'article_id' => $article_id ) );
		}
		else if( !empty( $quiz_id ) )
		{
			$seo_data = $this->GeneralModel->GetInfoRow( 'seo_data', array( 'quiz_id' => $quiz_id ) );
		}
		
		echo json_encode( $seo_data );
		exit;
	
	}	
		
	public function index(){
		$data['page']  = 'seo';
		$data['script']  	= 1;
		
		$data['tbl_articelepost'] = $this->GeneralModel->GetInfoRow('tbl_articelepost', $key = '');
		$data['tbl_exams'] = $this->GeneralModel->GetInfoRow('tbl_exams', $key = '');
		
	    $this->myadmin->view('seo/seo', $data);
	}
	
	public function up(){
		// if(isset($_POST['action']) && $_POST['action'] == "insert"){
			
		$config['upload_path']   = './uploads/attatchments'; 
        $config['allowed_types'] = 'pdf|doc|docx'; 
        $config['max_size']      = 2000; 
		$config['file_name'] = strtolower($_FILES['ufile']['name']);
		
        $this->load->library('upload', $config);
			
         if ( ! $this->upload->do_upload('ufile')) {
            // $error = array('error' => $this->upload->display_errors()); 
            // $this->load->view('upload_form', $error); 
			
			$error['ufile'] = $this->upload->display_errors();
			$return  		= array('has_error'=>1, 'error' => $error);
			
         }
			
         else { 
            $data = array('upload_data' => $this->upload->data()); 
            // $this->load->view('upload_success', $data); 
			
/* 			echo "<hr><pre>data: ";
			var_dump( $data["upload_data"]["file_name"] );
			exit; */
			
			$return  	= array('has_error'=>0, 'page'=> admin_url('upload'), 'uurl' => base_url() . 'uploads/attatchments/' . $data["upload_data"]["file_name"] );

         } 
			

			echo json_encode($return);
/* 		}
		else{
			redirect(admin_url('upload'), 'refresh');
		} */
	}
	
	
	public function upasdf(){		



	}
	
	public function get_all_datas(){
		echo 'asdf fdsa';
	}

	public function mlevels(){
		$data['page']  = 'dashboard';
	    $this->myadmin->view('mlevels', $data);
	}
}

?>