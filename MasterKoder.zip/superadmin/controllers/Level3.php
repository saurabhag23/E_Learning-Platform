<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Level3 extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->helper('form');
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('user_model', 'db_model','GeneralModel','menus_model','dailyquiz_model'));
			$this->user = $this->session->userdata($this->session_name);
		}

	}

	public function index(){
		$data['page']  		= 'mentor';
		$data['page1']  	= 'level3';
		$data['script']  	= 1;
	    $this->myadmin->view('level3/home', $data);
	}
	
	public function get_all_level3(){
		echo $this->menus_model->all_mlevel3();
	}

	public function add(){
		$data['page']  = 'mentor';
		$data['page1']  	= 'level3';
		$data['script']  	= 1;
		$data['tbl_mlevel1']=$this->GeneralModel->GetInfoRow($table = 'tbl_mlevel1', $key = '');
		$data['tbl_mlevel2']=$this->GeneralModel->GetInfoRow($table = 'tbl_mlevel2', $key = '');
		$data['tbl_categories']=$this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');

	    $this->myadmin->view('level3/add', $data);
	}
	
	public function get_l2(){
		$l1_id = $this->input->post('l1_id');
		$cl2_id = $this->input->post('cl2_id');
		
		$tbl_mlevel2 = $this->GeneralModel->GetInfoRow('tbl_mlevel2', array( 'l1_id' => $l1_id ));

		$opt = array('' => 'Select');
		$sel = ( !empty( $cl2_id ) ) ? $cl2_id : '' ;
		if( !empty( $tbl_mlevel2 ) )
		{
	
			foreach( $tbl_mlevel2 as $key => $value )
			{
				$opt[ $value->id ] = $value->title;							
			}
			
		}
		
		echo form_dropdown('l2_id', $opt, $sel, 'id="l2_id" class="form-control"');
		exit;
	}
	
	public function get_l3ord(){
		
		$l2_id = $this->input->post('l2_id');
		$cl2_id = $this->input->post('cl2_id');
		$corder = $this->input->post('corder');
		
		$tbl_mlevel3 = $this->GeneralModel->GetInfoRow('tbl_mlevel3', array( 'l2_id' => $l2_id ));

		$l3ord = array();
		
		if( !empty( $tbl_mlevel3 ) )
		{
			foreach( $tbl_mlevel3 as $key => $value )
			{
				$l3ord[] = $value->order;							
			}	
		}
		
	  	$opt = array( "" => "Select" );
		$sel = '';
		
		for( $i  = 1; $i < 31 ; $i++ )
		{
			if( ! in_array( $i, $l3ord ) || ( $cl2_id == $l2_id && $i == $corder ) )
			$opt[ $i ] = $i ;
		
			if( $cl2_id == $l2_id && $i == $corder )
				$sel = $corder;
		}
		
		echo form_dropdown( 'order', $opt, $sel, 'id="order" class="form-control"' );
		exit;
		
	}
	
	public function addsub(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('l1_id', 'Parent 1', 'trim|required');
			$this->form_validation->set_rules('l2_id', 'Parent 2', 'trim|required');
			//$this->form_validation->set_rules('url', 'Url', 'trim|required');
			$this->form_validation->set_rules('order', 'Order', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
			 
				$error['title'] 			= form_error('title');
				$error['l1_id'] 			= form_error('l1_id');
				$error['l2_id'] 			= form_error('l2_id');
				//$error['url'] 	= form_error('url');
				$error['order'] 	= form_error('order');
				$error['order'] 	= form_error('order');
				$error['status'] 	= form_error('status');

				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
			   
				$idata['title'] = $this->input->post('title');
				$idata['l1_id'] = $this->input->post('l1_id');
				$idata['l2_id'] = $this->input->post('l2_id');
				$idata['url'] = $this->input->post('url');
				$idata['order'] = $this->input->post('order');
				$idata['status'] = $this->input->post('status');
				$idata['datec'] = date('Y-m-d H:i:s');
				
				$this->GeneralModel->AddNewRow( "tbl_mlevel3", $idata );
				
				$this->db->query('UPDATE tbl_mlevel1 SET l3count = l3count + 1 WHERE id = "' . $idata['l1_id'] . '"');
				$this->db->query('UPDATE tbl_mlevel2 SET l3count = l3count + 1 WHERE id = "' . $idata['l2_id'] . '"');
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('level3'), 'message' => 'Level 3 Menu inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('level3'), 'refresh');
		}
	}
	
	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
		$row	= $this->menus_model->get_single_lev3($this->input->post('id'));
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{

				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'View Level 3', 'fun' => 3),
								array('tag' => '#infoModal .modal-body',  'data' => $this->get_data3($this->input->post('id')), 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('level3'), 'refresh');
		}		
	}	

	
	private function get_data3($id = 0){
    	if(!empty($id)){
    		$row  	= $this->menus_model->get_single_lev3($id);
			
			$data = "";
		
			$data .= '<div class="card">
						<table class="table">
						<tr><td><b>Title</b></td><td>'.$row->title.'</td></tr>
						<tr><td><b>Url</b></td><td>'.$row->url.'</td></tr>
						<tr><td><b>Order</b></td><td>'.$row->order.'</td></tr>
						<tr><td><b>Parent Level 1</b></td><td>'.$row->lev1tit.'</td></tr>
						<tr><td><b>Parent Level 3</b></td><td>'.$row->lev2tit.'</td></tr>
						<tr><td><b>Status</b></td><td>'.$row->status.'</td></tr>
						<tr><td><b>Date</b></td><td>'. date('d M Y', strtotime( $row->datec ) ).'</td></tr>
						</table>
					</div>';
						
			return $data;
		    
    	}
		
	}
	
	public function edit($id = 0){
		
		if (!has_permission('level3', 'edit')) {
			 redirect(admin_url('login'), 'refresh');
		}
		
		if($id>0){
			$data['page']  		= 'mentor';
			
			$data['roles']  	= $this->user_model->get_all_roles();
			$data['row']  		= $this->menus_model->get_single_lev3($id);
			$data['tbl_mlevel1']=$this->GeneralModel->GetInfoRow($table = 'tbl_mlevel1', $key = '');
			$data['tbl_mlevel2']=$this->GeneralModel->GetInfoRow($table = 'tbl_mlevel2', $key = '');

			$data['page1']  		= 'level3';
			$data['script']  	= 1;
			
			$data['articles'] = $this->dailyquiz_model->get_all_articles();
			$data['tbl_categories'] = $this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');
			

			
			$tbl_mlevel1 = $this->GeneralModel->GetInfoRow('tbl_mlevel1', array( 'id' => @$data['row']->l1_id ) );

			$data['row']->catid = @$tbl_mlevel1[0]->catid;
			
/* 			var_dump( @$data['row']->l1_id );
			var_dump( @$tbl_mlevel1[0]->catid );
			exit; */

			$this->myadmin->view('level3/edit', $data);
		}
		else{
			redirect(admin_url('level3'), 'refresh');
		}
	}
	
	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row	= $this->menus_model->get_single_lev2($this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');

			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('l1_id', 'Parent 1', 'trim|required');
			$this->form_validation->set_rules('l2_id', 'Parent 2', 'trim|required');
			//$this->form_validation->set_rules('url', 'Url', 'trim|required');
			$this->form_validation->set_rules('order', 'Order', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				
				$error['title'] 			= form_error('title');
				$error['l1_id'] 			= form_error('l1_id');
				$error['l2_id'] 			= form_error('l2_id');
				//$error['url'] 	= form_error('url');
				$error['order'] 	= form_error('order');
				$error['order'] 	= form_error('order');
				$error['status'] 	= form_error('status');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
				$idata['title'] = $this->input->post('title');
				$idata['l1_id'] = $this->input->post('l1_id');
				$idata['l2_id'] = $this->input->post('l2_id');
				$idata['url'] = $this->input->post('url');
				$idata['order'] = $this->input->post('order');
				$idata['status'] = $this->input->post('status');
				$idata['datec'] = date('Y-m-d H:i:s');
				
				$this->GeneralModel->UpdateRow( "tbl_mlevel3", $idata, array( 'id' => $this->input->post('id') ) );
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('level3/edit/' .  $this->input->post('id') ), 'message' => 'Level 3 updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('level3'), 'refresh');
		}
	}
	
	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('tbl_mlevel3', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Level 3 status updated successfully', 'function'=> 'refreshlevel3Table');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('level3'), 'refresh');
		}		
	}
	
	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('tbl_mlevel3', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Level 3 status updated successfully', 'function'=> 'refreshlevel3Table');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('menus/level3'), 'refresh');
		}		
	}
	
	public function delete(){
			
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				
				$tbl_mlevel3 = $this->GeneralModel->GetInfoRow( 'tbl_mlevel3', array( 'id' => $this->input->post('id') ) );

				$this->db_model->delete('tbl_mlevel3', 'id', $this->input->post('id'));

				$this->db->query('UPDATE tbl_mlevel1 SET l3count = l3count - 1 WHERE id = "' . @$tbl_mlevel3[0]->l1_id . '"');
				$this->db->query('UPDATE tbl_mlevel2 SET l3count = l3count - 1 WHERE id = "' . @$tbl_mlevel3[0]->l2_id . '"');
				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Level 3 deleted successfully', 'function'=> 'refreshlevel3Table');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('menus/level3'), 'refresh');
		}		
	}
	
}

?>