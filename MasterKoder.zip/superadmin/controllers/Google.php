<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Google extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->user = $this->session->userdata($this->session_name);
		}	
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('db_model'));

		$this->load->helper('form');
	}

	public function updatedata(){
		
		$data1['code'] = $this->input->post('code');

		$this->db_model->updatecode('google_code', $data1 );
		
		redirect(admin_url(). 'google');
		
	}	
		
	public function index(){
		$data['page']  = 'google';
		
		$data['admin']=$this->db_model->getcode();

	    $this->myadmin->view('google/google', $data);
	}
	

	
	public function upasdf(){		



	}
	
	public function get_all_datas(){
		echo 'asdf fdsa';
	}

	public function mlevels(){
		$data['page']  = 'dashboard';
	    $this->myadmin->view('mlevels', $data);
	}
}

?>