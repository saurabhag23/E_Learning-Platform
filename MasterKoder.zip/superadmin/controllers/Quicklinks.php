<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Quicklinks extends MX_Controller{

	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->helper('form');
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('user_model', 'db_model','GeneralModel','quicklinks_model','dailyquiz_model','exam_model'));
			$this->user = $this->session->userdata($this->session_name);
		}

	}
	
	public function index(){
		$data['page']  		= 'mentor';
		$data['page1']  	= 'qlinks';
		$data['script']  	= 1;
	    $this->myadmin->view('qlinks/list', $data);
	}
	
	public function add(){
		$data['page']  = 'mentor';
		$data['page1']  = 'qlinks';
		$data['script']  	= 1;		
			
		$data['tbl_categories']=$this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');
		
	    $this->myadmin->view('qlinks/add', $data);
	}
	
	public function addsub(){
		
		/* $post = $this->input->post();

		echo "<hr><pre>post: ";
		var_dump( $post );
		exit; */
		
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('parent', 'Super Category', 'trim|required');
			$this->form_validation->set_rules('subcat', 'category', 'trim|required');
			$this->form_validation->set_rules('subsub', 'Sub category', 'trim|required');


			if ($this->form_validation->run() == FALSE) {
			 
				$error['title'] 	= form_error('title');
				$error['parent'] 	= form_error('parent');
				$error['subcat'] 	= form_error('subcat');
				$error['subsub'] 	= form_error('subsub');

				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
			   
				$save_pub = $this->input->post('save_pub');
												
				$idata['title'] = $this->input->post('title');
				$idata['supercat'] = $this->input->post('parent');
				$idata['cat'] = $this->input->post('subcat');
				$idata['subcat'] = $this->input->post('subsub');
				$idata['numposts'] = $this->input->post('numposts');
				$idata['status'] = ( $save_pub == '1' ) ? '1' : '0' ;			
				$idata['created_on'] = date('Y-m-d');
								
				$fid = $this->GeneralModel->AddNewRow( "quicklinks", $idata );
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('quicklinks'), 'message' => 'Quick links inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('quicklinks/add'), 'refresh');
		}
	}
	
	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
		$row	= $this->quicklinks_model->get_single_feed($this->input->post('id'));
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{

				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'View Feedback', 'fun' => 3),
								array('tag' => '#infoModal .modal-body',  'data' => $this->get_data($this->input->post('id')), 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			// redirect(admin_url('users'), 'refresh');
			$data['page']  		= 'level1';
			$data['page1']  	= 'feedback';
			$data['script']  	= 1;				
			$data['roles']  	= $this->user_model->get_all_roles();
			$data['row']  		= $this->quicklinks_model->get_single_feed( $id );
			// print "<hr><pre>".$this->db->last_query();exit;
			
			$data['fopt']  		= $this->quicklinks_model->get_feed_opt( $id );
			$data['ftscore']  	= $this->quicklinks_model->feedtotscore( $id );
			
/* echo "<hr><pre>ftscore: ";
var_dump( $data['ftscore'] );
exit; */			
			
			$data['tbl_categories'] = $this->GeneralModel->GetSelectedRows( $table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '' );
			
			$this->myadmin->view('feedback/view', $data);
		}		
	}
	
	private function get_data($id = 0){
    	if(!empty($id)){
			
    		$row  	= $this->quicklinks_model->get_single_feed($id);
			
			$data = "";
				
			$status = ( $row->status == '1' ) ? 'Active' : 'Deactive' ;
			
			$data .= '<div class="card">
						<table class="table">
						<tr><td><b>Title</b></td><td>'. $row->title .'</td></tr>
						<tr><td><b>Super Category</b></td><td>'. $row->category_name .'</td></tr>
						<tr><td><b>Category</b></td><td>'. $row->subcatnm .'</td></tr>
						<tr><td><b>Sub Category</b></td><td>'. $row->subsubcat .'</td></tr>
						<tr><td><b>Created On</b></td><td>'. date('d M Y', strtotime( $row->created_on ) ).'</td></tr>						
						<tr><td><b>Status</b></td><td>'.$status.'</td></tr>
						</table>
					</div>';
						
			return $data;
		    
    	}
		
	}
	
	public function edit($id = 0){
		
		if (!has_permission('quicklinks', 'edit')) {
			 redirect(admin_url('login'), 'refresh');
		}
		
		if($id>0){
			
			$data['page']  		= 'level1';
			$data['page1']  	= 'qlinks';
			$data['script']  	= 1;				
			$data['roles']  	= $this->user_model->get_all_roles();
			$data['row']  		= $this->quicklinks_model->get_single_feed($id);
			
			$data['tbl_categories'] = $this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');
			
            $data['subcats'] = $this->dailyquiz_model->get_all_subcategoriesbyquiz( array( @$data['row']->supercat ) );
			$data['subsub'] = $this->exam_model->get_all_subsub( array( @$data['row']->cat ) );
			
			$this->myadmin->view('qlinks/edit', $data);
		}
		else{
			redirect(admin_url('quicklinks'), 'refresh');
		}
	}
	
	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row  	= $this->quicklinks_model->get_single_feed( $this->input->post('id') );
			
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');

			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('parent', 'Super Category', 'trim|required');
			$this->form_validation->set_rules('subcat', 'category', 'trim|required');
			$this->form_validation->set_rules('subsub', 'Sub category', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				
				$error['title'] 	= form_error('title');
				$error['parent'] 	= form_error('parent');
				$error['subcat'] 	= form_error('subcat');
				$error['subsub'] 	= form_error('subsub');
				
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{

				$save_pub = $this->input->post('save_pub');
												
				$id = $this->input->post('id');
				$idata['title'] = $this->input->post('title');
				$idata['supercat'] = $this->input->post('parent');
				$idata['cat'] = $this->input->post('subcat');
				$idata['subcat'] = $this->input->post('subsub');
				$idata['numposts'] = $this->input->post('numposts');
				$idata['status'] = ( $save_pub == '1' ) ? '1' : '0' ;			
				$idata['created_on'] = date('Y-m-d');
								
				$this->GeneralModel->UpdateRow( "quicklinks", $idata, array( 'id' => $id ) );
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('quicklinks'), 'message' => 'Quick links updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url( 'quicklinks/update/' . $this->input->post('id') ), 'refresh');
		}
	}	
	
	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('quicklinks', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Quick links status updated successfully', 'function'=> 'refreshqlinksTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('quicklinks'), 'refresh');
		}		
	}
	
	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('quicklinks', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Quick links status updated successfully', 'function'=> 'refreshqlinksTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('quicklinks'), 'refresh');
		}		
	}
	
	public function delete(){
			
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				
				$this->db_model->delete('quicklinks', 'id', $this->input->post('id'));
				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Quick links deleted successfully', 'function'=> 'refreshqlinksTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('quicklinks'), 'refresh');
		}		
	}
	
	public function get_feedback(){
		echo $this->quicklinks_model->all_feedback();
	}
	
}
	
?>	