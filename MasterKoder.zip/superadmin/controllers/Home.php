<?php defined('BASEPATH') OR exit('No direct script access allowed');

error_reporting(E_ALL);
ini_set('display_errors', 1);

class Home extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		$this->load->model('login_model', 'login');
		
		if(!$this->session->userdata($this->session_name)){
		    
    		if( !empty( $_COOKIE["admin_login"] ) )
    		{ 
    		    $result 	= $this->login->get( $_COOKIE["admin_login"], md5( $_COOKIE["admin_password"] ));
    		    $this->session->set_userdata($this->session_name, $result);
    		    
    		}
		    
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->user = $this->session->userdata($this->session_name);
		}	
	}

	public function index(){
		$data['page']  = 'dashboard';
		
		//$data['tucount'] = $this->db->query( "SELECT count( * ) as tucount FROM `tbl_users`" )->row()->tucount;
        $data['ndacount'] = $this->db->query( "SELECT count( * ) as ndacount FROM `tbl_users` where exam_category like '%9%'" )->row()->ndacount;
        $data['cdscount'] = $this->db->query( "SELECT count( * ) as cdscount FROM `tbl_users` where exam_category like '%3%'" )->row()->cdscount;
        $data['afcount'] = $this->db->query( "SELECT count( * ) as afcount FROM `tbl_users` where exam_category like '%8%'" )->row()->afcount;

        
        /* mentor post 
		$data['msuppost'] = $this->db->query( "SELECT count( * ) as msuppost FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 2 and tbl_posts.exam_category != 0" )->row()->msuppost;
		$data['msubpost'] = $this->db->query( "SELECT count( * ) as msubpost FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 2 and tbl_posts.exam_subcat is not null" )->row()->msubpost;
		$data['msubsubpost'] = $this->db->query( "SELECT count( * ) as msubsubpost FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 2 and tbl_posts.exam_subsubcat is not null" )->row()->msubsubpost;
		
	
		
		/* user post asked doubt 
		$data['usupposta'] = $this->db->query( "SELECT count( * ) as usupposta FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.exam_category != 0 and tbl_posts.status = 1" )->row()->usupposta;
		$data['usubposta'] = $this->db->query( "SELECT count( * ) as usubposta FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.exam_subcat is not null and tbl_posts.status = 1" )->row()->usubposta;
		$data['usubsubposta'] = $this->db->query( "SELECT count( * ) as usubsubposta FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.exam_subsubcat is not null and tbl_posts.status = 1" )->row()->usubsubposta;
		
		/* user post share knowledge 
		$data['usupposta'] = $this->db->query( "SELECT count( * ) as usupposta FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.exam_category != 0 and tbl_posts.status = 2" )->row()->usupposta;
		$data['usubposta'] = $this->db->query( "SELECT count( * ) as usubposta FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.exam_subcat is not null and tbl_posts.status = 2" )->row()->usubposta;
		$data['usubsubposta'] = $this->db->query( "SELECT count( * ) as usubsubposta FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.exam_subsubcat is not null and tbl_posts.status = 2" )->row()->usubsubposta;
		
		/* user post MCQ 
		$data['usupposta'] = $this->db->query( "SELECT count( * ) as usupposta FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.exam_category != 0 and tbl_posts.status = 3" )->row()->usupposta;
		$data['usubposta'] = $this->db->query( "SELECT count( * ) as usubposta FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.exam_subcat is not null and tbl_posts.status = 3" )->row()->usubposta;
		$data['usubsubposta'] = $this->db->query( "SELECT count( * ) as usubsubposta FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.exam_subsubcat is not null and tbl_posts.status = 3" )->row()->usubsubposta;
		
		/* quiz created MCQ 
		$data['mqsup'] = $this->db->query( "SELECT count( * ) as mqsup FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'MCQ' and tbl_posts.exam_category != 0" )->row()->mqsup;
		$data['mqsub'] = $this->db->query( "SELECT count( * ) as mqsub FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'MCQ' and tbl_posts.exam_subcat is not null" )->row()->mqsub;
		$data['mqsubsub'] = $this->db->query( "SELECT count( * ) as mqsubsub FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'MCQ' and tbl_posts.exam_subsubcat is not null" )->row()->mqsubsub;
		
		/* quiz created MCQ 
		$data['mqsup'] = $this->db->query( "SELECT count( * ) as mqsup FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'MCQ' and tbl_posts.exam_category != 0" )->row()->mqsup;
		$data['mqsub'] = $this->db->query( "SELECT count( * ) as mqsub FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'MCQ' and tbl_posts.exam_subcat is not null" )->row()->mqsub;
		$data['mqsubsub'] = $this->db->query( "SELECT count( * ) as mqsubsub FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'MCQ' and tbl_posts.exam_subsubcat is not null" )->row()->mqsubsub;
		
		/* quiz created pictorial 
		$data['pqsup'] = $this->db->query( "SELECT count( * ) as pqsup FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'pictorial' and tbl_posts.exam_category != 0" )->row()->pqsup;
		$data['pqsub'] = $this->db->query( "SELECT count( * ) as pqsub FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'pictorial' and tbl_posts.exam_subcat is not null" )->row()->pqsub;
		$data['pqsubsub'] = $this->db->query( "SELECT count( * ) as pqsubsub FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'pictorial' and tbl_posts.exam_subsubcat is not null" )->row()->pqsubsub;
		
		/* quiz created textual 
		$data['tqsup'] = $this->db->query( "SELECT count( * ) as tqsup FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'textual' and tbl_posts.exam_category != 0" )->row()->tqsup;
		$data['tqsub'] = $this->db->query( "SELECT count( * ) as tqsub FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'textual' and tbl_posts.exam_subcat is not null" )->row()->tqsub;
		$data['tqsubsub'] = $this->db->query( "SELECT count( * ) as tqsubsub FROM `tbl_posts` inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` where quiz_type = 'textual' and tbl_posts.exam_subsubcat is not null" )->row()->tqsubsub;
		
		/* quiz attempted tot 
		$data['qatot'] = $this->db->query( "SELECT count( * ) as qatot 
            FROM `tbl_posts` 
            inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` 
            inner join `tbl_quizresults` on `tbl_exams`.`id_exam` = `tbl_quizresults`.`quizid`" )->row()->qatot;
            
		/* quiz attempted 
		$data['qasup'] = $this->db->query( "SELECT count( * ) as qasup 
            FROM `tbl_posts` 
            inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` 
            inner join `tbl_quizresults` on `tbl_exams`.`id_exam` = `tbl_quizresults`.`quizid` where tbl_posts.exam_category != 0" )->row()->qasup;
            
		/* quiz attempted 
		$data['qasub'] = $this->db->query( "SELECT count( * ) as qasub 
            FROM `tbl_posts` 
            inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` 
            inner join `tbl_quizresults` on `tbl_exams`.`id_exam` = `tbl_quizresults`.`quizid` where tbl_posts.exam_subcat is not null" )->row()->qasub;
            
		/* quiz attempted 
		$data['qasubsub'] = $this->db->query( "SELECT count( * ) as qasubsub 
            FROM `tbl_posts` 
            inner join `tbl_exams` on `tbl_posts`.`quiz_id` = `tbl_exams`.`id_exam` 
            inner join `tbl_quizresults` on `tbl_exams`.`id_exam` = `tbl_quizresults`.`quizid` where tbl_posts.exam_subsubcat is not null" )->row()->qasubsub;
            
		/* total questions attempted 
		$data['queatot'] = $this->db->query( "SELECT sum( qattempted ) as queatot FROM `tbl_quizresults`" )->row()->queatot;
		
		/* total questions attempted 
		$data['scoutof'] = $this->db->query( "SELECT round( avg( score / out_of ) ) as scoutof FROM `tbl_quizresults`" )->row()->scoutof;
		
		/* total questions attempted 
		$data['totquizexits'] = $this->db->query( "SELECT count( * ) as totquizexits FROM `tbl_resume`" )->row()->totquizexits;
		
		/* total feedback 
		$data['totfbk'] = $this->db->query( "SELECT count( * ) as totfbk FROM `feedback`" )->row()->totfbk;
		
		/* total feedback given 
		$data['totfbkg'] = $this->db->query( "SELECT count( * ) as totfbkg FROM `feedback_user`" )->row()->totfbkg;
		
		/* total ads 
		$data['adsleft'] = $this->db->query( "SELECT count( * ) as adsleft FROM `tble_advertizement` where location = 'Left Sidebar'" )->row()->adsleft;
		
		$data['adsright'] = $this->db->query( "SELECT count( * ) as adsright FROM `tble_advertizement` where location = 'Right Sidebar'" )->row()->adsright;
		
		$data['adsnfeed'] = $this->db->query( "SELECT count( * ) as adsnfeed FROM `tble_advertizement` where location = 'Newsfeed'" )->row()->adsnfeed;
		
		$data['adsquiz'] = $this->db->query( "SELECT count( * ) as adsquiz FROM `tble_advertizement` where location = 'Quiz'" )->row()->adsquiz;
		
		$data['adsbanner'] = $this->db->query( "SELECT count( * ) as adsbanner FROM `tble_advertizement` where location = 'Banner Ad'" )->row()->adsbanner;
		*/
		
	    $this->myadmin->view('home_user', $data);
	}
	
	public function posts(){
	    //echo 'dashposts';
	    $data['page']  = 'dashboard';
	    
		$data['mndapost'] = $this->db->query( "SELECT count( * ) as mndapost FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id where ( id_role = 2 and tbl_articelepost.id_parent = 9 ) or ( id_role = 2 and tbl_posts.parentcat_ids like '%,9,%' ) " )->row()->mndapost;
		
		$data['mcdspost'] = $this->db->query( "SELECT count( * ) as mcdspost FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id where ( id_role = 2 and tbl_articelepost.id_parent = 3 ) or ( id_role = 2 and tbl_posts.parentcat_ids like '%,3,%' ) " )->row()->mcdspost;
		
		$data['mfcatpost'] = $this->db->query( "SELECT count( * ) as mfcatpost FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id where ( id_role = 2 and tbl_articelepost.id_parent = 8 ) or ( id_role = 2 and tbl_posts.parentcat_ids like '%,8,%' ) " )->row()->mfcatpost;
		
		$data['mtpost'] = $this->db->query( "SELECT count( * ) as mtpost FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id where id_role = 2" )->row()->mtpost;
		
		$data['uaskp'] = $this->db->query( "SELECT count( * ) as uaskp FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 1" )->row()->uaskp;
		
		$data['ushp'] = $this->db->query( "SELECT count( * ) as ushp FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 2" )->row()->ushp;
		
		$data['umcqp'] = $this->db->query( "SELECT count( * ) as umcqp FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 3" )->row()->umcqp;
	    
	    $this->myadmin->view('home_post', $data);
	}
	
	public function quiz(){
	    //echo 'quiz';
	    
	    $data['page']  = 'dashboard';
	    
		$data['mcqqz'] = $this->db->query( "SELECT count( * ) as mcqqz FROM `tbl_exams` where quiz_type = 'MCQ'" )->row()->mcqqz;
		
		$data['pqqz'] = $this->db->query( "SELECT count( * ) as pqqz FROM `tbl_exams` where quiz_type = 'pictorial'" )->row()->pqqz;
		
		$data['txtqz'] = $this->db->query( "SELECT count( * ) as txtqz FROM `tbl_exams` where quiz_type = 'textual'" )->row()->txtqz;
		
		$data['qzatt'] = $this->db->query( "SELECT count( * ) as qzatt FROM `tbl_quizresults` inner join tbl_exams on tbl_quizresults.quizid = tbl_exams.id_exam" )->row()->qzatt;	
		
		$data['queatt'] = $this->db->query( "SELECT sum( qattempted ) as queatt FROM `tbl_quizresults` inner join tbl_exams on tbl_quizresults.quizid = tbl_exams.id_exam" )->row()->queatt;	
		
		$data['avgscore'] = $this->db->query( "SELECT round( avg( score ) ) as avgscore FROM `tbl_quizresults` inner join tbl_exams on tbl_quizresults.quizid = tbl_exams.id_exam" )->row()->avgscore;
		
		$data['avgoutof'] = $this->db->query( "SELECT round( avg( out_of ) ) as avgoutof FROM `tbl_quizresults` inner join tbl_exams on tbl_quizresults.quizid = tbl_exams.id_exam" )->row()->avgoutof;
		
		$data['qzexit'] = $this->db->query( "SELECT count( * ) as qzexit FROM `tbl_resume`" )->row()->qzexit;
	    
	    $this->myadmin->view('home_quiz', $data);
	}
	
	public function reports(){
	    //echo 'reports';
	    
	    $data['page']  = 'dashboard';
	    
		$data['reppost'] = $this->db->query( "SELECT count( * ) as reppost FROM `tble_report` where postid != 0" )->row()->reppost;
		
		$data['repcom'] = $this->db->query( "SELECT count( * ) as repcom FROM `tble_report` where comid != 0" )->row()->repcom;		
		
		$data['spampost'] = $this->db->query( "SELECT count( * ) as spampost FROM `tble_report` where postid != 0 and reason = 'Spam'" )->row()->spampost;
		
		$data['wipost'] = $this->db->query( "SELECT count( * ) as wipost FROM `tble_report` where postid != 0 and reason = 'Wrong Information'" )->row()->wipost;
		
		$data['shnotpost'] = $this->db->query( "SELECT count( * ) as shnotpost FROM `tble_report` where postid != 0 and reason = 'Should not be on TGM'" )->row()->shnotpost;
		
		$data['sellpost'] = $this->db->query( "SELECT count( * ) as sellpost FROM `tble_report` where postid != 0 and reason = 'Sell or Promotion of their own product/Services'" )->row()->sellpost;
		
		$data['spamcom'] = $this->db->query( "SELECT count( * ) as spampost FROM `tble_report` where comid != 0 and reason = 'Spam'" )->row()->spampost;
		
		$data['wicom'] = $this->db->query( "SELECT count( * ) as wipost FROM `tble_report` where comid != 0 and reason = 'Wrong Information'" )->row()->wipost;
		
		$data['shnotcom'] = $this->db->query( "SELECT count( * ) as shnotpost FROM `tble_report` where comid != 0 and reason = 'Should not be on TGM'" )->row()->shnotpost;
		
		$data['sellcom'] = $this->db->query( "SELECT count( * ) as sellpost FROM `tble_report` where comid != 0 and reason = 'Sell or Promotion of their own product/Services'" )->row()->sellpost;
	    
	    $this->myadmin->view('home_reports', $data);
	}
	
	public function feedback(){
	    //echo 'feedback';
	    
	    $data['page']  = 'dashboard';
	    
		$data['fccnt'] = $this->db->query( "SELECT count( * ) as fccnt FROM `feedback`" )->row()->fccnt;
		
		$data['fgcnt'] = $this->db->query( "SELECT count( * ) as fgcnt FROM `feedback_user`" )->row()->fgcnt;	
	    
	    $this->myadmin->view('home_feedback', $data);
	}
	
}