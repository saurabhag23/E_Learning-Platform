<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Advertizement extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('advertizement_model', 'db_model'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'category_slug',
							'title' => 'category_name',
							'table' => 'tbl_categories',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}

	public function index(){
	if (!has_permission('advertizement', 'dashboard_view')) {
         redirect(admin_url('login'), 'refresh');
    }
		$data['page']  		= 'advertizement';
		$data['script']  	= 1;
		$this->myadmin->view('advertizement/home', $data);
	}

	public function get_all_datas(){
		echo $this->advertizement_model->all_datas();
	}

	public function add(){
	if (!has_permission('advertizement', 'add')) {
         redirect(admin_url('login'), 'refresh');
    }
		$data['page']  		= 'advertizement';
		$data['script']  	= 1;
		$this->myadmin->view('advertizement/add', $data);
	}

	public function insert(){
		
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			
			$error = array();
			
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			
			
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('location', 'Location', 'trim|required');
			$this->form_validation->set_rules('type', 'Type', 'trim|required');
			
			/*
			if(empty($_FILES['image']['name'])) {
				
				$this->form_validation->set_rules('image', 'Image', 'trim|required');	
			}
			*/

			if ($this->form_validation->run() == FALSE) {
				
				
				$error['title']     = form_error('title');
				$error['location'] 	    = form_error('location');
				$error['type'] 	    = form_error('type');
				
				$return  				= array('has_error'=>1, 'error' => $error);
				
			}
			else{
				$image = $video = "";
			
			      if(!empty($_FILES['image']['name'])){
					  
				 		if (!is_dir('uploads/advertizement')) {
                            mkdir('uploads/advertizement');
							chmod('uploads/advertizement', 0755);
                        }
						
						$config['upload_path'] = 'uploads/advertizement/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = "";
						}
				 }	
				 
			      if(!empty($_FILES['video']['name'])){
					  
				 		if (!is_dir('uploads/advertizement')) {
                            mkdir('uploads/advertizement');
							chmod('uploads/advertizement', 0755);
                        }
						
						$config['upload_path'] = 'uploads/advertizement/';
						$config['allowed_types'] = 'wmv|mp4|3gp';
						$config['file_name'] = $_FILES['video']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('video')){
							$uploadData = $this->upload->data();
							$video = $uploadData['file_name'];
							
						}else{
							$video = "";
						}
				 }	
				 
				 
				$data['title']	= $this->input->post('title');
				$data['status']	= $this->input->post('save_pub');
				$data['location']	= $this->input->post('location');
				$data['type']	= $this->input->post('type');
				$data['google_link']	= $this->input->post('google_link');
				$data['gad_code']	= $this->input->post('gad_code');
				$data['image_link']	= $this->input->post('image_link');
				$data['hyperlink']	= $this->input->post('hyperlink');
				$data['image']	    = $image;
				$data['video']	= $video;
				$data['priority']	= $this->input->post('priority');
				$data['repeat_every']	= $this->input->post('repeat_every');
				$data['headline_text']	= $this->input->post('headline_text');
				$data['button_text']	= $this->input->post('button_text');
				$data['url_link']	= $this->input->post('url_link');				
				$data['youtube_link']	= $this->input->post('youtube_link');				
				$data['added_date']		= date("Y-m-d H:i:s");
				$invoice_id = $this->db_model->insert('tble_advertizement', $data); 
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('advertizement'), 'message' => 'Advertizement inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('advertizement'), 'refresh');
		}
	}

	public function edit( $id = 0 ){
		
		if (!has_permission('advertizement', 'edit')) {
			 redirect(admin_url('login'), 'refresh');
		}
		
		if(!empty($id)){
			$data['page']  		= 'advertizement';
			$data['script']  	= 1;
			$data['row']  		= $this->advertizement_model->get_single($id);
			$this->myadmin->view('advertizement/edit1', $data);
		}
		else{
			redirect(admin_url('advertizement'), 'refresh');
		}
		
	}

	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row	= $this->advertizement_model->get_single($this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('location', 'Location', 'trim|required');
			$this->form_validation->set_rules('type', 'Type', 'trim|required');
			
			if ($this->form_validation->run() == FALSE) {
				
				$error['title']     = form_error('title');
				$error['location'] 	= form_error('location');
				$error['type'] 	    = form_error('type');
				
				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
			
				$image = $video = "";
			
			      if(!empty($_FILES['image']['name'])){
					  
				 		if (!is_dir('uploads/advertizement')) {
                            mkdir('uploads/advertizement');
							chmod('uploads/advertizement', 0755);
                        }
						
						$config['upload_path'] = 'uploads/advertizement/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = "";
						}
				 }	
				 
			      if(!empty($_FILES['video']['name'])){
					  
				 		if (!is_dir('uploads/advertizement')) {
                            mkdir('uploads/advertizement');
							chmod('uploads/advertizement', 0755);
                        }
						
						$config['upload_path'] = 'uploads/advertizement/';
						$config['allowed_types'] = 'wmv|mp4|3gp';
						$config['file_name'] = $_FILES['video']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('video')){
							$uploadData = $this->upload->data();
							$video = $uploadData['file_name'];
							
						}else{
							$video = "";
						}
				 }	
				 
				 
				$data['title']	= $this->input->post('title');
				$data['status']	= $this->input->post('save_pub');
				$data['location']	= $this->input->post('location');
				$data['type']	= $this->input->post('type');
				$data['google_link']	= $this->input->post('google_link');
				$data['gad_code']	= $this->input->post('gad_code');
				$data['image_link']	= $this->input->post('image_link');
				$data['hyperlink']	= $this->input->post('hyperlink');
				$data['image']	    = $image;
				$data['video']	= $video;
				$data['priority']	= $this->input->post('priority');
				$data['repeat_every']	= $this->input->post('repeat_every');
				$data['headline_text']	= $this->input->post('headline_text');
				$data['button_text']	= $this->input->post('button_text');
				$data['url_link']	= $this->input->post('url_link');				
				$data['added_date']		= date("Y-m-d H:i:s");
				// $invoice_id = $this->db_model->insert('tble_advertizement', $data); 
				
				$this->db_model->update('tble_advertizement', $data,'id',$this->input->post('id')); 
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('advertizement'), 'message' => 'Advertizement updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('advertizement'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('tble_advertizement', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Advertizement status updated successfully', 'function'=> 'refreshCategoryTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('advertizement'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('tble_advertizement', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Advertizement status updated successfully', 'function'=> 'refreshCategoryTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('advertizement'), 'refresh');
		}		
	}

	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tble_advertizement', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Advertizement deleted successfully', 'function'=> 'refreshCategoryTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('advertizement'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$row	= $this->advertizement_model->get_single($this->input->post('id'));
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Advertizement Details', 'fun' => 3),
				          array('tag' => '#infoModal .modal-body',  'data' =>  $this->get_data($this->input->post('id')), 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('advertizement'), 'refresh');
		}		
	}
	
	private function get_data($id = 0){
    	if(!empty($id)){
    		$row  	= $this->advertizement_model->get_single($id);
			
			$data = "";
		
			$type = ( $row->type == 'I' ) ? 'Image' : 'Video' ;
			$status = ( $row->status == 1 ) ? 'Active' : 'Deactive' ;
			
			$data .= '<div class="">
						<table class="table">
						<tr><td><b>Title</b></td><td>'.$row->title.'</td></tr>
						<tr><td><b>Location</b></td><td>'.$row->location.'</td></tr>
						<tr><td><b>Type</b></td><td>'.$type.'</td></tr>
						<tr><td><b>Google Link</b></td><td>'.$row->google_link.'</td></tr>
						<tr><td><b>Image Link</b></td><td>'.$row->image_link.'</td></tr>
						<tr><td><b>Image</b></td><td><a targer="_blank" href="'. base_url() .'uploads/advertizement/'.$row->image.'">'.$row->image.'</a></td></tr>
						<tr><td><b>Video</b></td><td><a targer="_blank" href="'. base_url() .'uploads/Advertizement/'.$row->video.'">'.$row->video.'</a></td></tr>
						<tr><td><b>Priority</b></td><td>'.$row->priority.'</td></tr>
						<tr><td><b>Repeat Every</b></td><td>'.$row->repeat_every.'</td></tr>
						<tr><td><b>Headline Text</b></td><td>'.$row->headline_text.'</td></tr>
						<tr><td><b>Button Text</b></td><td>'.$row->button_text.'</td></tr>
						<tr><td><b>Url Link</b></td><td>'.$row->url_link.'</td></tr>
						<tr><td><b>Created On</b></td><td>'. date('d M Y', strtotime( $row->added_date ) ).'</td></tr>
						<tr><td><b>Status</b></td><td>'.$status.'</td></tr>
						</table>
					</div>';
						
			return $data;
		    
    	}
		
	}
	
}