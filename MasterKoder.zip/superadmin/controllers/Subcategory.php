<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Subcategory extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation', 'image_lib', 'upload'));
			$this->load->model(array('course_model', 'db_model'));
			$this->user 	= $this->session->userdata($this->session_name);
			$this->path    	= 'uploads/';
			$this->tmp_path = 'tmp/';
			if(!file_exists($this->path)) {
				mkdir($this->path);
				chmod($this->path, 0755);
			}	
		
		}	
	}

	public function index(){
		if (!has_permission('subcategory', 'dashboard_view')) {
			 redirect(admin_url('login'), 'refresh');
		}
		$data['page']  		= 'subcategory';
		$data['script']  	= 1;
		$this->myadmin->view('subcategory/home', $data);
	}

	public function get_all_datas(){
		echo $this->course_model->all_datas();
	}

	public function add(){
	if (!has_permission('subcategory', 'add')) {
         redirect(admin_url('login'), 'refresh');
    }
		$data['page']  		= 'subcategory';
		$data['script']  	= 1;
		$data['categories'] = $this->course_model->get_all_categories();
		$this->myadmin->view('subcategory/add', $data);
	}

	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('category',  'Exam Category', 'trim|required');
			$this->form_validation->set_rules('title',  'title', 'trim|required');
			$this->form_validation->set_rules('content',  'content ', 'trim|required');

			if ($this->form_validation->run() == FALSE || !empty($error)) {
				$error['title'] 			= form_error('title');
				$error['category'] 			= form_error('category');
				$error['editor'] 		    = form_error('content');
				$return  					= array('has_error'=>1, 'error' => $error);
			}

			if(empty($error)){
				 if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/Subcategory')) {
                            mkdir('uploads/Subcategory');
							chmod('uploads/Subcategory', 0755);
                        }
						$config['upload_path'] = 'uploads/Subcategory/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = "";
						}
					}
					else
					{
						$image = "";
					}
				$data['id_category'] 		    = $this->input->post('category');
				$data['title']		            = $this->input->post('title');
				$data['image']			        = $image;
				$data['description']	        =  base64_encode($this->input->post('content'));
				$data['added_by']				= $this->user->id;
				$data['added_date']				= date("Y-m-d H:i:s");
				$data['user_postallowed']		= $this->input->post('allow');
				$course_id 	= $this->db_model->insert('tbl_subcategories', $data); 

				$this->db->query( 'update `tbl_categories` set sccount = sccount + 1 where id= "' . $data['id_category'] . '"' );

				$return  	= array('has_error'=>0, 'page'=> admin_url('subcategory'), 'message' => 'Category inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}
	}

	public function edit($id = 0){
	if (!has_permission('subcategory', 'add')) {
         redirect(admin_url('login'), 'refresh');
    }
		$data['page']  			= 'subcategory';
		if(!empty($id)){
			$data['script']  	= 1;
			$data['categories'] = $this->course_model->get_all_categories();
			$data['row']  		= $this->course_model->get_single($id);
			if(count($data['row']) > 0){
				$this->myadmin->view('subcategory/edit', $data);
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			$this->myadmin->view('404', $data);
		}
	}

	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$row	= $this->course_model->get_single($this->input->post('id'));
			$this->form_validation->set_rules('category',  'Exam Category', 'trim|required');
			$this->form_validation->set_rules('title',  'title', 'trim|required');
			$this->form_validation->set_rules('content',  'content ', 'trim|required');

			
			

			if($this->form_validation->run() == FALSE || !empty($error)) {
				
				$error['title'] 			= form_error('title');
				$error['category'] 			= form_error('category');
				$error['editor'] 		    = form_error('content');
				$return  					= array('has_error'=>1, 'error' => $error);
			}

			if(empty($error)){
				 if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/Subcategory')) {
                            mkdir('uploads/Subcategory');
							chmod('uploads/Subcategory', 0755);
                        }
						$config['upload_path'] = 'uploads/Subcategory/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = $row->image;
						}
					}
					else
					{
						$image = $row->image;
					}
				
				$data['id_category'] 		    = $this->input->post('category');
				$data['title']		            = $this->input->post('title');
				$data['image']			        = $image;
				$data['description']	        =  base64_encode($this->input->post('content'));
				$data['user_postallowed']		= $this->input->post('allow');
				$this->db_model->update('tbl_subcategories', $data, 'id', $this->input->post('id')); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('subcategory'), 'message' => 'Subcategory updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}
	}

	public function hide(){
	if (!has_permission('subcategory', 'status')) {
         redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('tbl_subcategories', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Category status updated successfully', 'function'=> 'refreshCourseTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function unhide(){
	if (!has_permission('subcategory', 'status')) {
         redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('tbl_subcategories', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Category status updated successfully', 'function'=> 'refreshCourseTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function delete(){
	if (!has_permission('subcategory', 'delete')) {
         redirect(admin_url('login'), 'refresh');
    }
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$course_data	= $this->course_model->get_single($this->input->post('id'));
				
				$this->db_model->delete('tbl_subcategories', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Category deleted successfully', 'function'=> 'refreshCourseTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Category Details', 'fun' => 3),
								array('tag' => '#infoModal .modal-body',  'data' => $this->get_data($this->input->post('id')), 'fun' => 0)
			);
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	private function get_data($id = 0){
    	if(!empty($id)){
    		$course_data  	= $this->course_model->get_single($id);
	    	if(count($course_data) > 0){
			    $data   =  '<table class="table table-responsive">
                              <tbody>
                              
                                <tr>
                                  <th width="25%"> Title</th>
                                  <td>'.$course_data->title.'</td>
                                </tr>
                                
                                  <th>Added on</th>
                                  <td>'.date("M d, Y", strtotime($course_data->added_date)).'</td>
                                </tr>
                                <tr>
                                  <th>Added by</th>
                                  <td>'.$course_data->user_fname.'</td>
                                </tr>
                              </tbody>
                            </table>';
				return $data;
		    }
    	}
	}

	public function details($course_id = 0){
		$data['page']  	= 'subcategory';
		if(!empty($course_id)){
			$data['course_id']  	= $course_id;
    		$data['row']  			= $this->course_model->get_single($course_id);
			$data['examcount']  			= $this->course_model->quizcount($course_id);
    		if(count($data['row']) > 0){
				$this->myadmin->view('subcategory/details', $data);
    		}
    		else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			$this->myadmin->view('404', $data);
		}
	}
	
		
}