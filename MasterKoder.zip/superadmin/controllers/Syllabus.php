<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Syllabus extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('syllabus_model', 'db_model', 'course_model'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'syllabus_slug',
							'title' => 'syllabus_title',
							'table' => 'tbl_syllabus',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}



	public function index(){
	if (!has_permission('syllabus', 'dashboard_view')) {
         redirect(admin_url('login'), 'refresh');
    }
		    $data['page']  		= 'syllabus';
		    $data['script']  	= 1;
			//$data['row']  		= $this->syllabus_model->get_single();
			$this->myadmin->view('syllabus/home', $data);
	
	}
    public function get_all_datas(){
		echo $this->syllabus_model->all_datas();
	}



	public function add(){
	if (!has_permission('syllabus', 'add')) {
         redirect(admin_url('login'), 'refresh');
    }
		    $data['page']  		= 'syllabus';
		    $data['script']  	= 1;
			$data['examcats']  	= $this->course_model->get_all_categories();
			$data['curtypes']  = $this->course_model->getcurrent_affairtypes();
			
			$this->myadmin->view('syllabus/add', $data);
	}
    public function getsubcategory()
	{
		 $subcats =  $this->course_model->get_all_subcatscategoriesbyid($this->input->post('catid'));
		 $html = "";
		 foreach( $subcats as  $subcats)
		 {
		 	 $html.= '<option value="'.$subcats->id_course.'">'.$subcats->course_title.'</option>';
		 }
		 echo  $html;
	}


	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('examcat', 'Exam Category', 'trim|required');
			
			$this->form_validation->set_rules('title', 'Syllabus title', 'trim|required');
			$this->form_validation->set_rules('content', 'Syllabus content', 'trim|required');
			

			if ($this->form_validation->run() == FALSE) {
			    $error['examcat'] = form_error('examcat');
			    $error['type'] 	    = form_error('type');
				$error['title'] 	= form_error('title');
				$error['editor'] 	= form_error('content');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
				 if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/Syllabus')) {
                            mkdir('uploads/Syllabus');
							chmod('uploads/Syllabus', 0755);
                        }
						$config['upload_path'] = 'uploads/Syllabus/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
						}else{
							$image = '';
						}
				 }	
				 else
				 {
				 	$image = '';
				 }
			    $data['featured_image']		= $image;
			    $data['id_parent']          = $this->input->post('examcat');
				$data['id_subcategory']     = $this->input->post('examsubcat');
		     	$data['id_mainexam']        = $this->input->post('exam');
				$data['syllabus_title']		= $this->input->post('title');
				$data['syllabus_description']	= base64_encode($this->input->post('content'));
				$data['syllabus_slug']			= $this->slug->create_uri($this->input->post('title'));
				$data['feautured_post']		= $this->input->post('featured');
				$data['image_url']		    = $this->input->post('imgurl');
				$data['added_by']			= $this->user->id;
				$data['added_date']			= date("Y-m-d");
				$invoice_id = $this->db_model->insert('tbl_syllabus', $data); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('syllabus'), 'message' => 'Syllabus inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}
	}



	public function edit($id = 0){
	if (!has_permission('syllabus', 'edit')) {
         redirect(admin_url('login'), 'refresh');
    }

		if(!empty($id)){
			$data['page']  		= 'syllabus';
			$data['script']  	= 1;
			$data['row']  		= $this->syllabus_model->syllbusdetails($id);
		    
			$data['examcats']  	= $this->course_model->get_all_categories();
			$data['exams'] =  $this->course_model->getallmainexams();
			$this->myadmin->view('syllabus/edit', $data);
		}
	}



	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row  	= $this->syllabus_model->syllbusdetails($this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('examcat', 'Exam Category', 'trim|required');
		
			
			$this->form_validation->set_rules('title', 'topic title', 'trim|required');
			$this->form_validation->set_rules('content', 'topic content', 'trim|required');
			
			if ($this->form_validation->run() == FALSE) {
			    $error['examcats'] = form_error('examcat');
				
			   
				$error['title'] 	= form_error('title');
				$error['editor'] 	= form_error('content');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
			  	
				 if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/Syllabus')) {
                            mkdir('uploads/Syllabus');
							chmod('uploads/Syllabus', 0755);
                        }
						$config['upload_path'] = 'uploads/Syllabus/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							unlink('uploads/Syllabus/'.$row->featured_image);
						}else{
							$image = $row->featured_image;
						}
				 }	
				 else
				 {
				 	$image = $row->featured_image;
				 }
				 
			    $data['featured_image']	    = $image;
			    $data['id_parent']          = $this->input->post('examcat');
				$data['id_subcategory']     = $this->input->post('examsubcat');
			 	$data['id_mainexam']        = $this->input->post('exam');
				$data['syllabus_title']		= $this->input->post('title');
				$data['syllabus_description']= base64_encode($this->input->post('content'));
				$data['syllabus_slug']		= $this->slug->create_uri($this->input->post('title'));
				$data['feautured_post']		= $this->input->post('featured');
				$data['image_url']		    = $this->input->post('imgurl');
				$invoice_id 				= $this->db_model->update('tbl_syllabus', $data, 'id', $this->input->post('id')); 
				$return  					= array('has_error'=>0, 'page'=> admin_url('syllabus'), 'message' => 'Syllabus updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('topics'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['syllabus_status'] 	= 0;
				$this->db_model->update('tbl_syllabus', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Syllabus status updated successfully', 
				                'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['syllabus_status'] 	= 1;
				$this->db_model->update('tbl_syllabus', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Syllabus status updated successfully', 
				               'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('syllabus'), 'refresh');
		}		
	}

	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_syllabus', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Syllabus deleted successfully', 'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');
            $row = $this->syllabus_model->syllbusdetails($this->input->post('id'));
			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
			     $html = '';
			     $html.='<table class="table table-bordered">
						  <thead>
							
						  </thead>
						  <tbody>';
						 
						  
						  $html.='<tr>
								 <td>Syllabus Category</td>
								  <td>'.$row->course_title.'</td>
								</tr>
								<tr>
								 <td>Exam</td>
								  <td>'.$row->course_title.'</td>
								</tr>
								<tr>
								 <td>Title</td>
								  <td>'.$row->syllabus_title.'</td>
								</tr>
								<tr>
								  <td>Description</td>
								  <td>'.base64_decode($row->syllabus_description).'</td>
								</tr>';
								
								
						 
				  $html.='</tbody>
						</table>';
				
				
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Syllabus Details', 'fun' => 3),
				                array('tag' => '#infoModal .modal-body',  'data' => $html, 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
				
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('topics'), 'refresh');
		}		
	}
}