-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2018 at 02:11 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_edu_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_studyplan`
--

CREATE TABLE `tbl_studyplan` (
  `id` int(11) NOT NULL,
  `id_parent` int(11) DEFAULT '0',
  `id_subcategory` int(11) DEFAULT NULL,
  `id_mainexam` int(11) NOT NULL,
  `title` text,
  `description` text,
  `slug` text,
  `status` int(11) NOT NULL DEFAULT '1',
  `featured_image` varchar(100) NOT NULL,
  `feautured_post` int(100) NOT NULL DEFAULT '0',
  `added_date` datetime NOT NULL,
  `added_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_studyplan`
--
ALTER TABLE `tbl_studyplan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_studyplan`
--
ALTER TABLE `tbl_studyplan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
