<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Newsfeed extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('newsfeed_model', 'db_model', 'course_model','GeneralModel'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'topic_slug',
							'title' => 'topic_title',
							'table' => 'tbl_current_affairs',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
	}
	public function index(){
	if (!has_permission('newsfeed', 'dashboard_view')) {
         redirect(admin_url('login'), 'refresh');
    }
		    $data['page']  		= 'newsfeed';
		    $data['script']  	= 1;
			$data['row']  		= $this->newsfeed_model->get_single();
			$this->myadmin->view('newsfeed/home', $data);
	
	}



	public function get_all_datas(){
		echo $this->newsfeed_model->all_datas();
	}


	public function add(){
		error_reporting(E_ALL);
ini_set('display_errors', 1);
		if (!has_permission('newsfeed', 'add')) {
			 redirect(admin_url('login'), 'refresh');
		}
		$data['page']  		= 'newsfeed';
		$data['script']  	= 1;
			
		//print "<hr><pre>".$this->db->last_query();exit;
		/*
		`top` = 0 AND 
		*/
		
		$data['tbl_posts'] = $this->db->query( "SELECT tbl_articelepost.*, tbl_posts.id FROM `tbl_posts` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id WHERE `article_id` is not null order by tbl_articelepost.id desc")->result();
		
		$data['tbl_quiz'] = $this->db->query( "SELECT tbl_exams.*, tbl_posts.id FROM `tbl_posts` inner join tbl_exams on tbl_posts.quiz_id = tbl_exams.id_exam WHERE `quiz_id` is not null order by tbl_exams.id_exam desc")->result();
		
		$this->myadmin->view('newsfeed/add1', $data);
		
	}
   

	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('post_type', 'Post Type', 'trim|required');
			/*
			$this->form_validation->set_rules('post', 'Post', 'trim|required');
			$this->form_validation->set_rules('quiz', 'Quiz', 'trim|required');
			*/
			// $this->form_validation->set_rules('content', 'Post content', 'trim|required');
			
			if ($this->form_validation->run() == FALSE ) {
				
				$error['post_type'] 	= form_error('post_type');
				/*
				$error['post'] 	= form_error('post');
				$error['quiz'] 	= form_error('quiz');
				*/
				// $error['title'] 	= form_error('title');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
			
			/*
			     if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/userposts')) {
                            mkdir('uploads/userposts');
							chmod('uploads/userposts', 0755);
                        }
						$config['upload_path'] = 'uploads/userposts/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = "";
						}
				 }	
				else
				{
					$image ="";
				}
				$data['image']	     = $image;
			    $data['title']       =  $this->input->post('title');
				$data['upadated_status'] =  $this->input->post('content');
				//$data['description']	 = base64_encode($this->input->post('content'));
				$data['status']                 = 1;
				$data['userid']			= $this->user->id;
				$data['created']		=  date("Y-m-d H:i:s");
				$data['admin_posted']	 = 1;
				$data['active_status']	 = 1;
				$invoice_id = $this->db_model->insert('tbl_posts', $data); 
			*/
				$post_type		    =  $this->input->post('post_type');
				$post		    =  $this->input->post('post');
				$quiz		    =  $this->input->post('quiz');
				
				if( empty( $post ) && empty( $quiz ) )
				    exit;
				
				$postid = ( !empty( $post_type ) && $post_type == 'A'  ) ? $post : $quiz ;
				
				$data['top']		= 1;
				$data['toptime']	= date("Y-m-d H:i:s");
				
				$this->db_model->update('tbl_posts', $data, 'id', $postid );
				
				//print "<hr><pre>".$this->db->last_query();exit;
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('newsfeed'), 'message' => 'Post set on top');
				
				
				
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('newsfeed'), 'refresh');
		}
	}



	public function edit($id = 0){
	if (!has_permission('newsfeed', 'edit')) {
         redirect(admin_url('login'), 'refresh');
    }

		if(!empty($id)){
			$data['page']  		= 'newsfeed';
			$data['script']  	= 1;
			$data['row']  		= $this->newsfeed_model->postdetails($id);
			
			if(count($data['row']) > 0){
				$this->myadmin->view('newsfeed/edit', $data);
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			$this->myadmin->view('404', $data);
		}
	}



	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row 		= $this->newsfeed_model->postdetails( $this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			
			
			$this->form_validation->set_rules('content', 'content', 'trim|required');
			
			if ($this->form_validation->run() == FALSE) {
			  
			   
				$error['editor'] 	= form_error('content');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
				  if(!empty($_FILES['image']['name'])){
				 		if (!is_dir('uploads/userposts')) {
                            mkdir('uploads/userposts');
							chmod('uploads/userposts', 0755);
                        }
						$config['upload_path'] = 'uploads/userposts/';
						$config['allowed_types'] = 'jpg|jpeg|png|gif';
						$config['file_name'] = $_FILES['image']['name'];
						
						//Load upload library and initialize configuration
						$this->load->library('upload',$config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('image')){
							$uploadData = $this->upload->data();
							$image = $uploadData['file_name'];
							
						}else{
							$image = $row->image;
						}
				 }
				 else
				 {
				 	$image = $row->image;
				 }	
				$data['image']	    = $image;
			   
				$data['title']       =  $this->input->post('title');
				$data['upadated_status'] =  $this->input->post('content');
				$invoice_id 				= $this->db_model->update('tbl_posts', $data, 'id', $this->input->post('id')); 
				$return  					= array('has_error'=>0, 'page'=> admin_url('newsfeed'), 'message' => 'Newsfeed updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('newsfeed'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['active_status'] 	= 0;
				$this->db_model->update('tbl_posts', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Newsfeed Post status updated successfully', 
				                'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('newsfeed'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['active_status'] 	= 1;
				$this->db_model->update('tbl_posts', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Newsfeed Post status updated successfully', 
				               'function'=> 'refreshTopicTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('newsfeed'), 'refresh');
		}		
	}

	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				
				// $this->db_model->delete('tbl_posts', 'id', $this->input->post('id'));

				$data['top'] = 0;	
				$this->db_model->update('tbl_posts', $data, 'id', $this->input->post('id') );
				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Newsfeeed Post deleted successfully', 'function'=> 'refreshTopicTable');
				
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('subcategory'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');
            $row = $this->newsfeed_model->postdetails($this->input->post('id'));
			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
			     $html = '';
			     $html.='<table class="table table-bordered">
						  <thead>
							
						  </thead>
						  <tbody>';
						 
						  
						  $html.='<tr>
						  		<tr>
								  <td>Title</td>
								  <td>'.$row->title.'</td>
								</tr>
								<tr>
								  <td>Post</td>
								  <td>'.$row->upadated_status.'</td>
								</tr>
								<tr>
								  <td>Image</td>
								  <td><img src="'.base_url().'uploads/userposts/'.$row->image.'" alt="" style = "width: 150px;height: 120px;"/></td>
								</tr>';
							
				  $html.='</tbody>
						</table>';
				
				
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'Post Details', 'fun' => 3),
				                array('tag' => '#infoModal .modal-body',  'data' => $html, 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
				
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('topics'), 'refresh');
		}		
	}
}