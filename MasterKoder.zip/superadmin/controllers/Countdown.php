<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Countdown extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->helper('form');
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('user_model', 'db_model','GeneralModel','countdown_model','countdown_model'));
			$this->user = $this->session->userdata($this->session_name);
		}

	}

	public function add(){
		$data['page']  = 'mentor';
		$data['page1']  = 'countdown';
		$data['script']  	= 1;		
			
		$data['tbl_categories']=$this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');

		
	    $this->myadmin->view('countdown/add', $data);
	}
	
	public function addsub(){
		
		/* $post = $this->input->post();

		echo "<hr><pre>post: ";
		var_dump( $post );
		exit; */
		
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			
			$this->form_validation->set_rules('title', 'Feedback Title', 'trim|required');
			$this->form_validation->set_rules('exam_date', 'Exam Date', 'trim|required');
			$this->form_validation->set_rules('priority', 'Priority', 'trim|required');
			$this->form_validation->set_rules('url_text', 'Url Text', 'trim|required');
			$this->form_validation->set_rules('url_link', 'Url Link', 'trim|required');


			if ($this->form_validation->run() == FALSE) {
			 
				$error['title'] 	= form_error('title');
				$error['exam_date'] = form_error('exam_date');
				$error['priority'] 	= form_error('priority');
				$error['url_text'] 	= form_error('url_text');
				$error['url_link'] 	= form_error('url_link');
				
				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
								
				$idata['title'] = $this->input->post('title');
				$idata['exam_date'] = $this->input->post('exam_date');
				$idata['priority'] = $this->input->post('priority');
				$idata['url_text'] = $this->input->post('url_text');
				$idata['url_link'] = $this->input->post('url_link');
				$idata['datec'] = date('Y-m-d H:i:s');
				$idata['status'] = $this->input->post('save_pub');			
								
				$fid = $this->GeneralModel->AddNewRow( "countdown", $idata );

				$return  	= array('has_error'=>0, 'page'=> admin_url('countdown'), 'message' => 'Countdown added successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('countdown/add'), 'refresh');
		}
	}
		
	public function index(){
		$data['page']  		= 'mentor';
		$data['page1']  		= 'countdown';
		$data['script']  	= 1;
	    $this->myadmin->view('countdown/list', $data);
	}
	
	public function viewopt( $id, $optlet ){

		$data['page']  		= 'level1';
		$data['page1']  	= 'feedback';
		$data['script']  	= 1;				
		$data['roles']  	= $this->user_model->get_all_roles();
		$data['texts']  	= $this->countdown_model->get_texts( $id, $optlet );
		// print "<hr><pre>".$this->db->last_query();exit;		
		$data['foptname']  		= $this->countdown_model->get_feed_optname( $id, $optlet );
				
		$this->myadmin->view('feedback/viewopt', $data);
	
	}	
		
	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
		$row	= $this->countdown_model->get_single_feed($this->input->post('id'));
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{

				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'View Countdown', 'fun' => 3),
								array('tag' => '#infoModal .modal-body',  'data' => $this->get_data($this->input->post('id')), 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			// redirect(admin_url('users'), 'refresh');
			$data['page']  		= 'level1';
			$data['page1']  	= 'feedback';
			$data['script']  	= 1;				
			$data['roles']  	= $this->user_model->get_all_roles();
			$data['row']  		= $this->countdown_model->get_single_feed( $id );
			// print "<hr><pre>".$this->db->last_query();exit;
			
			$data['fopt']  		= $this->countdown_model->get_feed_opt( $id );
			$data['ftscore']  	= $this->countdown_model->feedtotscore( $id );
			
/* echo "<hr><pre>ftscore: ";
var_dump( $data['ftscore'] );
exit; */			
			
			$data['tbl_categories'] = $this->GeneralModel->GetSelectedRows( $table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '' );
			
			$this->myadmin->view('feedback/view', $data);
		}		
	}
	
	private function get_data($id = 0){
    	if(!empty($id)){
			
    		$row  	= $this->countdown_model->get_single_feed($id);
			
			$data = "";
		
			$status = ( $row->status == '1' ) ? 'Active' : 'Deactive' ;
			
			$data .= '<div class="card">
						<table class="table">
						<tr><td><b>Title</b></td><td>'.$row->title.'</td></tr>
						<tr><td><b>Exam Date</b></td><td>'. date('d M Y', strtotime( $row->exam_date ) ) .'</td></tr>
						<tr><td><b>Priority</b></td><td>'.$row->priority.'</td></tr>
						<tr><td><b>URL Text</b></td><td>'.$row->url_text.'</td></tr>
						<tr><td><b>URL Link</b></td><td>'.$row->url_link.'</td></tr>
						<tr><td><b>Status</b></td><td>'.$status.'</td></tr>
						</table>
					</div>';
						
			return $data;
		    
    	}
		
	}
	
	public function edit($id = 0){
	if (!has_permission('countdown', 'edit')) {
         redirect(admin_url('login'), 'refresh');
    }
		if($id>0){
			
			$data['page']  		= 'level1';
			$data['page1']  = 'countdown';
			$data['script']  	= 1;				
			$data['roles']  	= $this->user_model->get_all_roles();
			$data['row']  		= $this->countdown_model->get_single_feed($id);
			$data['fopt']  		= $this->countdown_model->get_feed_opt( $id );
			
			$data['tbl_categories'] = $this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');
			
			$this->myadmin->view('countdown/edit', $data);
		}
		else{
			redirect(admin_url('countdown'), 'refresh');
		}
	}
	
	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row  	= $this->countdown_model->get_single_feed( $this->input->post('id') );
			
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');

			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('exam_date', 'Exam Date', 'trim|required');
			$this->form_validation->set_rules('priority', 'Priority', 'trim|required');
			$this->form_validation->set_rules('url_text', 'Url Text', 'trim|required');
			$this->form_validation->set_rules('url_link', 'Url Link', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				
				$error['title'] 	= form_error('title');
				$error['exam_date'] = form_error('exam_date');
				$error['priority'] 	= form_error('priority');
				$error['url_text'] 	= form_error('url_text');
				$error['url_link'] 	= form_error('url_link');
				
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{

				$id = $this->input->post('id');
				$idata['title'] = $this->input->post('title');
				$idata['exam_date'] = $this->input->post('exam_date');
				$idata['priority'] = $this->input->post('priority');
				$idata['url_text'] = $this->input->post('url_text');
				$idata['url_link'] = $this->input->post('url_link');
				$idata['datec'] = date('Y-m-d H:i:s');
				$idata['status'] = $this->input->post('save_pub');			
								
				$this->GeneralModel->UpdateRow( "countdown", $idata, array( 'id' => $id ) );
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('countdown'), 'message' => 'Countdown updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url( 'countdown/update/' . $this->input->post('id') ), 'refresh');
		}
	}	
	
	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('countdown', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Countdown status updated successfully', 'function'=> 'refreshcdownTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('countdown'), 'refresh');
		}		
	}
	
	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('countdown', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Countdown status updated successfully', 'function'=> 'refreshcdownTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('countdown'), 'refresh');
		}		
	}
	
	public function delete(){
			
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('countdown', 'id', $this->input->post('id'));
				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Countdown deleted successfully', 'function'=> 'refreshcdownTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('countdown'), 'refresh');
		}		
	}
	
	public function get_countdown(){
		
		echo $this->countdown_model->all_countdown();
		
	}

	
}	
	
?>