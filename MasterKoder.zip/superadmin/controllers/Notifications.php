<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Notifications extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('db_model','notificationmodel'));
			$this->user = $this->session->userdata($this->session_name);
		}	
	}

	public function index(){
		$data['page']  		= 'notifications';
		$data['script']  	= 1;
		$this->myadmin->view('notifications/home', $data);
	}

	public function get_all_datas(){
		echo $this->notificationmodel->all_datas();
	}

	public function add(){
		$data['page']  		= 'notifications';
		$data['script']  	= 1;
		
	    $this->myadmin->view('notifications/add', $data);
	}

	public function insert(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
		
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('title', ' Notification Title', 'required');
			$this->form_validation->set_rules('content', 'Notification ', 'required');
			
			

			if ($this->form_validation->run() == FALSE) {
		        $error['title'] 	= form_error('title');
				$error['content'] 	= form_error('content');
				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['title']	 = $this->input->post('title');
				$data['description']		    =  $this->input->post('content');
				$data['created_date']		    = date("Y-m-d H:i:s");
				$data['created_by']		    = $this->user->id;
				$invoice_id = $this->db_model->insert('tbl_notifications', $data); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('notifications'), 'message' => 'Notification added successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notifications'), 'refresh');
		}
	}

	public function edit($id = 0){
		if(!empty($id)){
			$data['page']  		= 'notifications';
			$data['script']  	= 1;
			$data['row']  		= $this->notificationmodel->get_single($id);
			$this->myadmin->view('notifications/edit', $data);
		}
		else{
			redirect(admin_url('notifications'), 'refresh');
		}
	}

	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
		
			$error 	= array();
			
			$this->form_validation->set_rules('title', ' Notification Title', 'required');
			$this->form_validation->set_rules('content', 'Notification ', 'required');

			if ($this->form_validation->run() == FALSE) {
		        $error['title'] 	= form_error('title');
				$error['content'] 	= form_error('content');
				$return  				= array('has_error'=>1, 'error' => $error);
			
			}
			else{
				$data['title']	 = $this->input->post('title');
				$data['description']		    =  $this->input->post('content');
				$invoice_id = $this->db_model->update(' tbl_notifications', $data, 'id', $this->input->post('id')); 
				$return  	= array('has_error'=>0, 'page'=> admin_url('notifications'), 'message' => 'Notification  status updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notifications'), 'refresh');
		}
	}

	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
		   
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('tbl_notifications', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Notification status updated successfully', 'function'=> 'refreshNotificationTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notifications'), 'refresh');
		}		
	}

	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
		
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('tbl_notifications', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Notification updated successfully', 'function'=>  'refreshNotificationTable');
				       
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notifications'), 'refresh');
		}		
	}

	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tbl_notifications', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Notification deleted successfully', 'function'=> 'refreshNotificationTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notifications'), 'refresh');
		}		
	}

	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');
			$row 		= $this->notificationmodel->get_single($this->input->post('id'));
			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
			    $html = '';
				$html.='<table class="table table-bordered table-responsive">
						  <thead>
							<tr">
							
							  <th scope="col">'.$row->title.'</th>
							</tr>
							
						  </thead>
						  <tbody>
						   <tr>';
					$html.='<td width="40%">'.$row->description.'</td>
							  
                            </tr> 
						  </tbody>
						</table>';
				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' =>'Notifications', 'fun' => 3),
				                array('tag' => '#infoModal .modal-body',  'data' => $html, 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('notifications'), 'refresh');
		}		
	}
}