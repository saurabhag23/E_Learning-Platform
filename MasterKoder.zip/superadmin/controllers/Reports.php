<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Reports extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('report_model', 'db_model', 'course_model', 'GeneralModel','accountmodel'));
			$this->user = $this->session->userdata($this->session_name);
			$config = array('field' => 'examslug',
							'title' => 'title',
							'table' => 'tbl_examdetails',
							'id'    => 'id');
			$this->load->library('slug', $config);
		}	
		$this->load->helper('date');
		$this->load->helper('postdate');
		$this->load->helper("comment");		
		
	}



	public function index(){
	if (!has_permission('reports', 'dashboard_view')) {
         redirect(admin_url('login'), 'refresh');
    }
		    $data['page']  		= 'reports';
		    $data['script']  	= 1;
			//$data['row']  		= $this->examdetail_model->get_single();
			$this->myadmin->view('reports/home', $data);
	
	}



	public function get_all_datas(){
		echo $this->report_model->all_datas();
	}



	
	public function delete(){
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$this->db_model->delete('tble_report', 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => ' Report deleted successfully', 'function'=> 'refreshreportTable');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('report'), 'refresh');
		}		
	}

	public function takeact(){	
	    
	    error_reporting(E_ALL);
        ini_set('display_errors', 1);
	
		$repid = $this->input->post('repid');		
		$action = $this->input->post('action');		
		$reppostid = $this->input->post('reppostid');		
		$repcomid = $this->input->post('repcomid');		
		
		if( $action == 'D' && !empty( $reppostid ) )
		{
			$this->GeneralModel->DeleteRow( 'tbl_posts', array( 'id' => $reppostid ) );
			$this->GeneralModel->UpdateRow( "tble_report", array( 'action' => 'D' ), array( 'id' => $repid ) );
			
		}		
		else if( $action == 'D' && !empty( $repcomid ) )
		{
			$this->GeneralModel->DeleteRow( 'tble_postcomments', array( 'id' => $repcomid ) );
			$this->GeneralModel->UpdateRow( "tble_report", array( 'action' => 'D' ), array( 'id' => $repid ) );
		}		
		else if( $action == 'B' && !empty( $reppostid ) )
		{		
		    /*
			$join_ar = array(
								0 => array(
									"table" => "tbl_users",
									"condition" => "tbl_posts.userid = tbl_users.id",
									"type" => "INNER"
								)
							);

			$tbl_posts = $this->GeneralModel->GetSelectedRowsJoins( 'tbl_posts', $limit = '', $start = '', $columns = '', $orderby ='', array( 'id' => $reppostid ), $search = '', $join_ar, $group_by = '' );
			*/
			
			$tbl_posts = $this->db->query( 'select * from tbl_posts where id = "'. $reppostid . '"' )->result();
			
			//print "<hr><pre>".$this->db->last_query();exit;
			
			if( !empty( $tbl_posts ) )
			{
				$this->GeneralModel->UpdateRow( "tbl_users", array( 'user_status' => '0' ), array( 'id' => @$tbl_posts[0]->userid ) );
			}
			
			$this->GeneralModel->UpdateRow( "tble_report", array( 'action' => 'B' ), array( 'id' => $repid ) );
			
		}		
		else if( $action == 'B' && !empty( $repcomid ) )
		{	
		    /*
			$join_ar = array(
								0 => array(
									"table" => "tbl_users",
									"condition" => "tbl_posts.userid = tbl_users.id",
									"type" => "INNER"
								)
							);

			$tble_postcomments = $this->GeneralModel->GetSelectedRowsJoins( 'tble_postcomments', $limit = '', $start = '', $columns = '', $orderby ='', array( 'id' => $repcomid ), $search = '', $join_ar, $group_by = '' );
			*/
			
			$tble_postcomments = $this->db->query( 'select * from tble_postcomments where id = "'. $repcomid . '"' )->result();
			
			if( !empty( $tble_postcomments ) )
			{
				$this->GeneralModel->UpdateRow( "tbl_users", array( 'user_status' => '0' ), array( 'id' => @$tble_postcomments[0]->userid ) );
			}
			
			$this->GeneralModel->UpdateRow( "tble_report", array( 'action' => 'B' ), array( 'id' => $repid ) );
		}
		else if( $action == 'N' )
		{			
			$this->GeneralModel->UpdateRow( "tble_report", array( 'action' => 'N' ), array( 'id' => $repid ) );
		}
				
	}
	
	public function details($reportid = 0){	
	
		$data['page']  			= 'reports';
		$data['script']  	= 1;
		if(!empty($reportid)){						
			
			$data['row']  		= $this->report_model->get_single($reportid);	
			
			//print "<hr><pre>".$this->db->last_query();exit;
			
			/*			SELECT concat( user_fname, " " , user_lname ) as uname, tbl_posts.created from tbl_posts inner join tbl_users on tbl_posts.userid = tbl_users.id where tbl_posts.id = 43;			*/						
			$qry = 'SELECT concat( user_fname, " " , user_lname ) as uname, tbl_posts.created from tbl_posts inner join tbl_users on tbl_posts.userid = tbl_users.id where tbl_posts.id = ' . $data['row']->rpostid;						
			// echo $qry; exit;						
			$data['postres'] = $this->report_model->get_postres( $data['row']->rpostid );	
			$data['comres'] = $this->report_model->get_comres( $data['row']->comid );	
			
			$data['posts']= $this->accountmodel->searchuserposts('P.id = ' . $data['row']->rpostid);
			
			/*
			echo "<hr><pre>postres: ";			
			var_dump( $data['postres'] );			
			exit; 
			*/
			
			
			if(count($data['row']) > 0){
				
				if($data['row']->pststus==4)
				  {
					 $data['quiz'] = $this->report_model->get_quizname($data['row']->quiz_id);
				  }
				  elseif($data['row']->pststus==6)
				  {
					$data['article'] = $this->report_model->get_article($data['row']->article_id);
				  }
				  elseif($data['row']->pststus==3)
				  {
					
				  }
				  else
				  {
					
				  }
				$this->myadmin->view('reports/details', $data);
				
			}
			else{
				$this->myadmin->view('404', $data);
			}
		}
		else{
			redirect(admin_url('report'), 'refresh');
		}
	}
	function deletepost($id)
	{
		$this->db_model->delete('tbl_posts', 'id', $id);
		$return = array('has_error'=>0, 'refresh'=>'1', 'message' => ' Report deleted successfully', 'function'=> 'refreshreportTable');	
		redirect(admin_url('report'), 'refresh');
	}
}