<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dailyquiz extends MX_Controller {

    function __construct() {

        parent :: __construct();

        $this->session_name = admin_session_name();
        
        //echo $this->session_name;exit;

        if (!$this->session->userdata($this->session_name)) {

            redirect(admin_url('login'), 'refresh');

            exit();

        } else {

            $this->load->library(array('datatables', 'form_validation', 'upload'));

            $this->load->model(array('exam_model', 'db_model', 'course_model', 'dailyquiz_model', 'GeneralModel'));

            $this->user = $this->session->userdata( $this->session_name );

            $this->tmp_path = 'tmp/';

            $config = array('field' => 'exam_slug','title' => 'exam_title','table' => 'tbl_exams','id' => 'id_exam');
			
            $this->load->library('slug', $config);

        }

    }

    public function index() {

        if (!has_permission('dailyquiz', 'dashboard_view')) {

            redirect(admin_url('login'), 'refresh');

        }

        $data['page'] = 'dailyquiz';

        $data['script'] = 1;

        //  $data['row']  		= $this->dailyquiz_model->get_single($course_id);

        $this->myadmin->view('dailyquiz/home', $data);

    }

    public function importqb() {
        
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
		
		$singqb = $this->input->post('singqb');
		$exam_id = $this->input->post('exam_id');
		
		$singqb = explode( ",", $singqb ); 

/*		
echo "<hr><pre>singqb: ";
var_dump( $singqb );
*/
		if( empty( $exam_id ) )
		{
		    $res = $this->db->query( "SELECT max( question_no ) as mqnum FROM `tbl_exams_questions` WHERE `id_exam` = $exam_id" )->row();
		    $mqnum = @$res->mqnum;
		}
		else
		{
		    $mqnum = 0;
		}
		
		if( !empty( $singqb ) )
		{	
			foreach( $singqb as $key => $value )
			{	
				$mqnum++;
			
				// copying additional table
				
				$qry .= "INSERT INTO tbl_exams_questions (id_exam,id_course,question_no,question_name,question_option_1,question_option_2,question_option_3,question_option_4,question_option_5,question_answer,explanation,question_image,question_option_1_image,question_option_2_image,question_option_3_image,question_option_4_image,question_option_5_image,question_upload_path,image,image_upload_path,image_duration,image_duration_slug,answer,answer_duration,answer_duration_slug,status,added_by,added_date) ";
				
				$qry .= "SELECT '$exam_id',id_course,'$mqnum',question_name,question_option_1,question_option_2,question_option_3,question_option_4,question_option_5,question_answer,explanation,question_image,question_option_1_image,question_option_2_image,question_option_3_image,question_option_4_image,question_option_5_image,question_upload_path,image,image_upload_path,image_duration,image_duration_slug,answer,answer_duration,answer_duration_slug,status,added_by,'". date('Y-m-d H:i:s') ."'";
				
				$qry .= "FROM tbl_exams_questions 
				WHERE id_question = '$value';";

/*				
echo "<hr><pre>post: ";
var_dump( $qry );
*/
				
				$this->db->query( $qry );
			}
		}
		
		echo '1';exit;
		
	}	
		
    public function exportqb() {
	
		$mcqchk = $this->input->post('mcqchk');
		
		$mcqchk = explode( ",", $mcqchk ); 
		
		if( !empty( $mcqchk ) )
		{	
			foreach( $mcqchk as $key => $value )
			{	
				$this->GeneralModel->AddNewRow( "quebank", array( 'id_question' => $value ) );
			}
		}
		
		echo '1';exit;
		
	}	
	
	public function getexamslug() {
	    
		$exam_id = $this->input->post('exam_id');
		
		$res = $this->db->query( "SELECT quiz_type, exam_slug FROM `tbl_exams` where id_exam = ". $exam_id ."" )->result();
		
		$url = base_url() . '';
		
		if( @$res[0]->quiz_type == 'MCQ' )
		    $url .= 'quiz/prev/';
		else if( @$res[0]->quiz_type == 'pictorial' )
		    $url .= 'quiz_image/prev/';
        else if( @$res[0]->quiz_type == 'textual' )
		    $url .= 'quiz_textual/prev/';
		
		$url .= @$res[0]->exam_slug;
		
		echo $url;exit;
		
	}
	
    public function getqbque() {
		
		$quiztype = $this->input->post('quiztype');
				
		$res = $this->db->query( "SELECT quebank.*, tbl_exams_questions.*, tbl_exams.quiz_type FROM `quebank` inner join tbl_exams_questions on quebank.id_question = tbl_exams_questions.id_question inner join tbl_exams on tbl_exams_questions.id_exam = tbl_exams.id_exam where quiz_type = '". $quiztype ."'" )->result();

		// print "<hr><pre>".$this->db->last_query();exit;
		
		$ret = '' ;
		
		if( !empty( $res ) )
		{	
			foreach( $res as $key => $value )
			{	
			
			
				$question = '';
				
				if( $value->quiz_type == 'pictorial' )
				{
					$question = '<img src="'. base_url() . $value->image_upload_path . $value->image .'" width="100" style="margin: 0;">';
				}
				else
				{
					$question = $value->question_name;
				}
				
				/*
				<td>'. date('F d, Y', strtotime( $value->added_date ) ) .'</td>
				<td>'. $status .'</td>
				*/
				
			
				$ret .= '<tr>
						  <td> <input type="checkbox" class="singqb" name="singqb[]" id="singqb" value="'. $value->id_question .'" /> </td>
						  <td>'. $question .'</td>						  
						</tr>' ;
			}
		}
		
		echo $ret;exit;
		
	}
		
    public function get_all_datas() {


        echo $this->dailyquiz_model->all_datas();


    }




    public function subrec($recart, $exam_id, $recid) {

        echo $this->dailyquiz_model->saverecart();
		exit;
		
	}
	
    public function add() {


        if (!has_permission('dailyquiz', 'add')) {


            redirect(admin_url('login'), 'refresh');


        }


        $data['page'] = 'dailyquiz';


        $data['script'] = 1;


        $data['examcats'] = $this->course_model->get_all_categories();
        $data['articles'] = $this->dailyquiz_model->get_all_articles();

        //$data['subcats']  	= $this->dailyquiz_model->get_all_subcategoriesbyquiz();

        $this->session->unset_userdata('exam_id');


        $this->session->unset_userdata('newsfeefpost');


        $this->session->unset_userdata('examcat');


        $this->myadmin->view('dailyquiz/add', $data);


    }



    public function update_step_1() {

        if (isset($_POST['action']) && $_POST['action'] == "exam-step1") {


            $error = array();


            $exam_id = $this->input->post('exam_id');


            if (!empty($exam_id)) {


                $row = $this->exam_model->get_single($exam_id);


            }


            $course_id = $this->input->post('exam_id');


            $course_data = $this->course_model->get_single($course_id);


            if (count($exam_id) > 0) {

                $path = 'uploads/' . $this->tmp_path;

                if (!is_dir($path)) {


                    mkdir($path);


                    chmod($path, 0755);


                }





                $config['upload_path'] = $path;


                $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';


                $config['file_name'] = strtolower($this->input->post('exam_name'));


                $config['file_ext_tolower'] = TRUE;


                $config['remove_spaces'] = TRUE;


                $this->upload->initialize($config);


                $this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
		

				$this->form_validation->set_rules('quiztype', 'Quiz Type', 'trim|required');


				$quiztype = $this->input->post('quiztype');

				
				if( $quiztype == 'MCQ' || $quiztype == 'pictorial' || $quiztype == 'textual' ){


					$this->form_validation->set_rules('exam_name', 'Quiz name', 'trim|required');


					$this->form_validation->set_rules('exam_description', 'exam description', 'trim|required');





					$this->form_validation->set_rules('coin', 'Coin', 'trim|required');


					$this->form_validation->set_rules('total_questions', 'total questions', 'trim|required|numeric');


				}


				


				if( $quiztype == 'MCQ' )
				{


					$this->form_validation->set_rules('examcat[]', 'Exam Category', 'trim|required');


					// $this->form_validation->set_rules('subcat','Exam SubCategory', 'trim|required');


					//$this->form_validation->set_rules('subsub','SubsubCategory', 'trim|required');


					$this->form_validation->set_rules('diff_level', 'Difficulty Level', 'trim|required');

				}


				if( $quiztype == 'MCQ' || $quiztype == 'pictorial' ){

				}


				if( $quiztype == 'MCQ' || $quiztype == 'textual' ){


					$this->form_validation->set_rules('total_time', 'exam duration', 'trim|required|numeric');


					$this->form_validation->set_rules('duration_slug', 'exam duration', 'trim|required');

				}



				/*

                if (empty($exam_id)) {


                    if ($_FILES['featured_image']['size'] == '0') {


                        // $this->form_validation->set_rules('featured_image', 'featured_image', 'required');


                    }


                }


                if (!empty($_FILES['featured_image']['name'])) {





                    if (!$this->upload->do_upload('featured_image')) {


                        //$error['featured_image'] 	= set_error($this->upload->display_errors());


                        //$this->form_validation->set_rules('featured_image', 'featured_image', 'required');


                    }


                }
				*/





                if ($this->form_validation->run() == FALSE) {


					$error['quiztype'] = form_error('quiztype');


					if( $quiztype == 'MCQ' )


					{


						$error['examcat'] = form_error('examcats[]');


						//$error['subcat'] 		    = form_error('subcat');


						//$error['subsub'] 		    = form_error('subsub');


						$error['diff_level'] = form_error('diff_level');





					}





					if( $quiztype == 'MCQ' || $quiztype == 'pictorial' || $quiztype == 'textual' )


					{


						





						$error['exam_name'] = form_error('exam_name');


						$error['editor'] = form_error('exam_description');


						$error['total_questions'] = form_error('total_questions');





						$error['total_time'] = form_error('total_time');


						//$error['featured_image'] 	= form_error('featured_image');


						$error['coin'] = form_error('coin');


						if (form_error('duration') != "") {


							$error['total_time'] = form_error('total_time');


						} else {


							$error['total_time'] = form_error('duration_slug');


						}


					}


					


					if( $quiztype == 'MCQ' || $quiztype == 'textual' )


					{





						$error['duration_slug'] = form_error('duration_slug');





					}



					/*

					if (empty($exam_id)) {


						if ($_FILES['featured_image']['size'] == '0') {


							// $this->form_validation->set_rules('featured_image', 'featured_image', 'required');


						}


					}


					if (!empty($_FILES['featured_image']['name'])) {





						if (!$this->upload->do_upload('featured_image')) {


							//$error['featured_image'] 	= set_error($this->upload->display_errors());


							//$this->form_validation->set_rules('featured_image', 'featured_image', 'required');


						}


					}
					*/

 


					//


                    $return = array('has_error' => 1, 'error' => $error , 'all_err' => validation_errors() );


                } else {


                    $exam_no = $this->exam_model->get_next_exam_no($course_id);

					/*

                    if (!empty($_FILES['featured_image']['name']) && !empty($exam_id)) {


                        if (file_exists($row->exam_upload_path . $row->exam_featured_image)) {


                            unlink($row->exam_upload_path . $row->exam_featured_image);


                        }


                        $image = $this->upload->data();


                        $data['exam_featured_image'] = $image['file_name'];


                    } elseif (!empty($_FILES['featured_image']['name'])) {


                        $image = $this->upload->data();


                        $data['exam_featured_image'] = $image['file_name'];


                    }
					*/


                    $nfpost = $this->input->post('newffedpost');


                    $this->session->set_userdata('newsfeefpost', $nfpost);


                    $excat[] = $this->input->post('examcat');


                    $firstcat = $excat[0];


                    $this->session->set_userdata('examcat', $firstcat);





                    $data['id_cat'] = 0;


                    //$data['id_course']			= $this->input->post('subcat');


                    //$data['id_subsubcat']			= $this->input->post('subsub');


                    $data['quiz_type'] = $this->input->post('quiztype');


                    $data['exam_name'] = $this->input->post('exam_name');


                    $data['exam_description'] = base64_encode($this->input->post('exam_description'));


                    $data['exam_duration'] = $this->input->post('total_time');


                    $data['exam_duration_slug'] = $this->input->post('duration_slug');


                    $data['total_questions'] = $this->input->post('total_questions');


                    $data['coins'] = $this->input->post('coin');


                    $data['marks_per_ques'] = $this->input->post('marks');


                    $data['negative_mark'] = $this->input->post('negativemarks');


                    $data['difficulty_level'] = $this->input->post('diff_level');


                    $data['exam_slug'] = $this->slug->create_uri($this->input->post('exam_name'));


                    $data['daily_quiz'] = 1;


                    $data['newsfeedpost'] = $this->input->post('newffedpost');


                    // $data['featured_quiz'] = $this->input->post('featured');


                    $data['image_url'] = $this->input->post('imgurl');


                    // {

						/*

                        if (!empty($_FILES['featured_image']['name'])) {


                            $new_path = $row->exam_upload_path;


                            if (!is_dir($new_path)) {


                                mkdir($new_path);


                                chmod($new_path, 0755);


                            }


                            rename('uploads/' . $this->tmp_path . $image['file_name'], $new_path . $image['file_name']);


                            $data['exam_upload_path'] = $new_path;


                        }
						*/


                        $this->db_model->update('tbl_exams', $data, 'id_exam', $exam_id);


                        $this->db_model->delete('tbl_quizparentcats', 'quiz_id', $exam_id);


                        $examcat = $this->input->post('examcat');
                        $subcat = $this->input->post('subcat');
                        $examsubsubcat = $this->input->post('subsub');
						
/* echo "<hr><pre>examcat: ";
var_dump( $examcat );
exit; */
						
                        $parentcat_ids = implode(",", $examcat) ;
                        $parentinnercat_ids = implode(",", $subcat) ;
                        $parentsubcat_ids = implode(",", $examsubsubcat) ;
                        
                        $parentcat_ids = "," . $parentcat_ids . ",";
                        $parentinnercat_ids = "," . $parentinnercat_ids . ",";
                        $parentsubcat_ids = "," . $parentsubcat_ids . ",";
                        
						$this->GeneralModel->UpdateRow( "tbl_posts", array( 'parentcat_ids' => $parentcat_ids,'parentinnercat_ids' => $parentinnercat_ids,'parentsubcat_ids' => $parentsubcat_ids ), array( 'quiz_id' => $exam_id ) );
					

$id_cat = $id_course = $id_subsubcat = 0;	
$catcnt = $coursecnt = $subsubcatcnt = -1;	

                        foreach ($examcat as $examcat) {


                            $data3['quiz_id'] = $exam_id;


                            $data3['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data3);

	if( empty( $id_cat ) )
		$id_cat = $examcat ;

	$catcnt++;

                        }


                        $subcat = $this->input->post('subcat');


                        foreach ($subcat as $examsubcat) {


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);

	if( empty( $id_course ) )
		$id_course = $examsubcat ;
	$coursecnt++;
                        }

						
                        $subsub = $this->input->post('subsub');


                        foreach ($subsub as $examsubsubcat) {


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);

	if( empty( $id_subsubcat ) )
		$id_subsubcat = $examsubsubcat ;

	$subsubcatcnt++;
                        }


						$this->GeneralModel->UpdateRow( "tbl_exams", array( 'id_cat' => $id_cat, 'id_course' => $id_course, 'id_subsubcat' => $id_subsubcat, 'catcnt' => $catcnt, 'coursecnt' => $coursecnt, 'subsubcatcnt' => $subsubcatcnt ), array( 'id_exam' => $exam_id ) );


                    // }

                    $set = array(array('tag' => '.exam_id', 'data' => $exam_id, 'fun' => 1));

                    $return = array('has_error' => 0, 'set' => $set, 'step' => '1', 'nextStep' => 2, 'message' => 'Step 1 completed');


                }


                echo json_encode($return);


            }


        } else {


            redirect(admin_url('dailyquiz'), 'refresh');


        }


    }

    public function insert_step_1() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-step1") {


            $error = array();


            $exam_id = $this->input->post('exam_id');


            if (!empty($exam_id)) {


                $row = $this->exam_model->get_single($exam_id);


            }


            $course_id = $this->input->post('exam_id');


            $course_data = $this->course_model->get_single($course_id);


            if (count($exam_id) > 0) {

                $path = 'uploads/' . $this->tmp_path;

                if (!is_dir($path)) {


                    mkdir($path);


                    chmod($path, 0755);


                }


                $config['upload_path'] = $path;


                $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';


                $config['file_name'] = strtolower($this->input->post('exam_name'));


                $config['file_ext_tolower'] = TRUE;


                $config['remove_spaces'] = TRUE;


                $this->upload->initialize($config);


				


                $this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');


				


				$this->form_validation->set_rules('quiztype', 'Quiz Type', 'trim|required');





				$quiztype = $this->input->post('quiztype');


				


				if( $quiztype == 'MCQ' || $quiztype == 'pictorial' || $quiztype == 'textual' )


				{


					$this->form_validation->set_rules('exam_name', 'Quiz name', 'trim|required');


					$this->form_validation->set_rules('exam_description', 'exam description', 'trim|required');





					$this->form_validation->set_rules('coin', 'Coin', 'trim|required');


					$this->form_validation->set_rules('total_questions', 'total questions', 'trim|required|numeric');


				}


				


				if( $quiztype == 'MCQ' )


				{


					$this->form_validation->set_rules('examcat[]', 'Exam Category', 'trim|required');


					// $this->form_validation->set_rules('subcat','Exam SubCategory', 'trim|required');


					//$this->form_validation->set_rules('subsub','SubsubCategory', 'trim|required');


					$this->form_validation->set_rules('diff_level', 'Difficulty Level', 'trim|required');


				


				}





				


				if( $quiztype == 'MCQ' || $quiztype == 'pictorial' )


				{





				}


				


				if( $quiztype == 'MCQ' || $quiztype == 'textual' )


				{


					$this->form_validation->set_rules('total_time', 'exam duration', 'trim|required|numeric');


					$this->form_validation->set_rules('duration_slug', 'exam duration', 'trim|required');








				}



				/*

                if (empty($exam_id)) {


                    if ($_FILES['featured_image']['size'] == '0') {


                        // $this->form_validation->set_rules('featured_image', 'featured_image', 'required');


                    }


                }


                if (!empty($_FILES['featured_image']['name'])) {





                    if (!$this->upload->do_upload('featured_image')) {


                        //$error['featured_image'] 	= set_error($this->upload->display_errors());


                        //$this->form_validation->set_rules('featured_image', 'featured_image', 'required');


                    }


                }
				*/





                if ($this->form_validation->run() == FALSE) {


					


						$error['quiztype'] = form_error('quiztype');





					if( $quiztype == 'MCQ' )


					{


						$error['examcat'] = form_error('examcats[]');


						//$error['subcat'] 		    = form_error('subcat');


						//$error['subsub'] 		    = form_error('subsub');


						$error['diff_level'] = form_error('diff_level');





					}





					if( $quiztype == 'MCQ' || $quiztype == 'pictorial' || $quiztype == 'textual' )


					{


						





						$error['exam_name'] = form_error('exam_name');


						$error['editor'] = form_error('exam_description');


						$error['total_questions'] = form_error('total_questions');





						$error['total_time'] = form_error('total_time');


						//$error['featured_image'] 	= form_error('featured_image');


						$error['coin'] = form_error('coin');


						if (form_error('duration') != "") {


							$error['total_time'] = form_error('total_time');


						} else {


							$error['total_time'] = form_error('duration_slug');


						}


					}


					


					if( $quiztype == 'MCQ' || $quiztype == 'textual' )


					{





						$error['duration_slug'] = form_error('duration_slug');





					}



					/*

					if (empty($exam_id)) {


						if ($_FILES['featured_image']['size'] == '0') {


							// $this->form_validation->set_rules('featured_image', 'featured_image', 'required');


						}


					}


					if (!empty($_FILES['featured_image']['name'])) {





						if (!$this->upload->do_upload('featured_image')) {


							//$error['featured_image'] 	= set_error($this->upload->display_errors());


							//$this->form_validation->set_rules('featured_image', 'featured_image', 'required');


						}


					}
					*/

 


					


                    $return = array('has_error' => 1, 'error' => $error , 'all_err' => validation_errors() );


                } else {


                    $exam_no = $this->exam_model->get_next_exam_no($course_id);

					/*

                    if (!empty($_FILES['featured_image']['name']) && !empty($exam_id)) {


                        if (file_exists($row->exam_upload_path . $row->exam_featured_image)) {


                            unlink($row->exam_upload_path . $row->exam_featured_image);


                        }


                        $image = $this->upload->data();


                        $data['exam_featured_image'] = $image['file_name'];


                    } elseif (!empty($_FILES['featured_image']['name'])) {


                        $image = $this->upload->data();


                        $data['exam_featured_image'] = $image['file_name'];


                    }
					*/


                    $nfpost = $this->input->post('newffedpost');


                    $this->session->set_userdata('newsfeefpost', $nfpost);


                    $excat[] = $this->input->post('examcat');


                    $firstcat = $excat[0];


                    $this->session->set_userdata('examcat', $firstcat);
					

                    $data['id_cat'] = 0;


                    //$data['id_course']			= $this->input->post('subcat');


                    //$data['id_subsubcat']			= $this->input->post('subsub');


                    $data['quiz_type'] = $this->input->post('quiztype');


                    $data['exam_name'] = $this->input->post('exam_name');


                    $data['exam_description'] = base64_encode($this->input->post('exam_description'));


                    $data['exam_duration'] = $this->input->post('total_time');


                    $data['exam_duration_slug'] = $this->input->post('duration_slug');


                    $data['total_questions'] = $this->input->post('total_questions');


                    $data['coins'] = $this->input->post('coin');


                    $data['marks_per_ques'] = $this->input->post('marks');


                    $data['negative_mark'] = $this->input->post('negativemarks');


                    $data['difficulty_level'] = $this->input->post('diff_level');


                    $data['exam_slug'] = $this->slug->create_uri($this->input->post('exam_name'));


                    $data['daily_quiz'] = 1;


                    $data['newsfeedpost'] = $this->input->post('newffedpost');


                    // $data['featured_quiz'] = $this->input->post('featured');


                    $data['image_url'] = $this->input->post('imgurl');


                    if (empty($exam_id)) {

                        $data['exam_no'] = $exam_no;


                        $data['added_by'] = $this->user->id;


                        $data['added_date'] = date("Y-m-d H:i:s");


                        $exam_id = $this->db_model->insert('tbl_exams', $data);

        				$ndata = array();
        
        				$ndata['title'] = $this->input->post('exam_name');
        				
        				$ndata['exam_slug'] = $data['exam_slug'];
        				
        				$ndata['quiz_type'] = $this->input->post('quiztype');
        
        				$ndata['description'] = date("Y-m-d H:i:s");
        
        				$ndata['created_date'] = date("Y-m-d H:i:s");
        
        				$ndata['created_by'] = $this->user->id;
        				
                        $this->session->set_userdata('ses_pnot',$ndata);
        
        				

                        $examcat = $this->input->post('examcat');


                        foreach ($examcat as $examcat) {


                            $data3['quiz_id'] = $exam_id;


                            $data3['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data3);


                        }


                        foreach ($_POST['subcat'] as $examsubcat) {


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);


                        }





                        foreach ($_POST['subsub'] as $examsubsubcat) {


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);


                        }


                        $this->session->set_userdata('exam_id', $exam_id);


                        $new_path = 'uploads/exam_' . $exam_no . '/';


                        if (!is_dir($new_path)) {


                            mkdir($new_path);


                            chmod($new_path, 0755);


                        }





/*                         if (!empty($_FILES['featured_image']['name'])) {


                            rename('uploads/' . $this->tmp_path . $image['file_name'], $new_path . $image['file_name']);


                        } */
						


                        $data2['exam_upload_path'] = $new_path;


                        $this->db_model->update('tbl_exams', $data2, 'id_exam', $exam_id);


                        $this->db_model->delete('tbl_quizparentcats', 'quiz_id', $exam_id);








                        $examcat = $this->input->post('examcat');


						$id_cat = $id_course = $id_subsubcat = 0;	
						$catcnt = $coursecnt = $subsubcatcnt = -1;	


                        foreach ($examcat as $examcat) {


                            $data14['quiz_id'] = $exam_id;


                            $data14['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data14);

							if( empty( $id_cat ) )
								$id_cat = $examcat ;

							$catcnt++;

                        }





                        foreach ($_POST['subcat'] as $examsubcat) {


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);

							if( empty( $id_course ) )
								$id_course = $examsubcat ;
							$coursecnt++;

                        }


                        foreach ($_POST['subsub'] as $examsubsubcat) {


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);

							if( empty( $id_subsubcat ) )
								$id_subsubcat = $examsubsubcat ;

							$subsubcatcnt++;

                        }

						$this->GeneralModel->UpdateRow( "tbl_exams", array( 'id_cat' => $id_cat, 'id_course' => $id_course, 'id_subsubcat' => $id_subsubcat, 'catcnt' => $catcnt, 'coursecnt' => $coursecnt, 'subsubcatcnt' => $subsubcatcnt ), array( 'id_exam' => $exam_id ) );


                    } else {

						/*

                        if (!empty($_FILES['featured_image']['name'])) {


                            $new_path = $row->exam_upload_path;


                            if (!is_dir($new_path)) {


                                mkdir($new_path);


                                chmod($new_path, 0755);


                            }


                            rename('uploads/' . $this->tmp_path . $image['file_name'], $new_path . $image['file_name']);


                            $data['exam_upload_path'] = $new_path;


                        }
						*/


                        $this->db_model->update('tbl_exams', $data, 'id_exam', $exam_id);


                        $this->db_model->delete('tbl_quizparentcats', 'quiz_id', $exam_id);


                        $examcat = $this->input->post('examcat');

	
								
                        foreach ($examcat as $examcat) {



                            $data3['quiz_id'] = $exam_id;


                            $data3['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data3);
							

                        }





                        foreach ($_POST['subcat'] as $examsubcat) {
							


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);
							

                        }


                        foreach ($_POST['subsub'] as $examsubsubcat) {
							


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);
							

                        }
						
						



                    }

                    $set = array(array('tag' => '.exam_id', 'data' => $exam_id, 'fun' => 1));

                    $return = array('has_error' => 0, 'set' => $set, 'step' => '1', 'nextStep' => 2, 'message' => 'Step 1 completed');


                }


                echo json_encode($return);


            }


        } else {


            redirect(admin_url('dailyquiz'), 'refresh');


        }


    }

    public function insert_step_2() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-step2") {


            $error = array();


            $exam_id = $this->input->post('exam_id');
			
/* 			echo "<hr><pre>exam_id: ";
			var_dump( $exam_id );
			exit; */
			
            $exam_data = $this->exam_model->get_single($exam_id);


            if (count($exam_data) > 0) {


                $this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');


                $this->form_validation->set_rules('question_name', 'question name', 'trim|required');


                $this->form_validation->set_rules('answer_option', 'answer', 'trim|required');


                $temp_path = $exam_data->exam_upload_path . $this->tmp_path;


                if (!is_dir($temp_path)) {


                    mkdir($temp_path);


                    chmod($temp_path, 0755);


                }


                $question_image = do_image_upload($temp_path, 'question_image', array("file_name" => "question_image", "overwrite" => TRUE), 0);


                if (!empty($question_image['error'])) {


                    $error['question_image'] = $question_image['error'];


                }


                $option_1_image = do_image_upload($temp_path, 'option_1_image', array("file_name" => "option_1_image", "overwrite" => TRUE), 0);


                if (!empty($option_1_image['error'])) {


                    $error['option_1_image'] = $option_1_image['error'];


                } elseif (!empty($option_1_image['name'])) {


                    $this->form_validation->set_rules('option_1', 'first option', 'trim');


                } else {


                    $this->form_validation->set_rules('option_1', 'first option', 'trim|required');


                }


                $option_2_image = do_image_upload($temp_path, 'option_2_image', array("file_name" => "option_2_image", "overwrite" => TRUE), 0);


                if (!empty($option_2_image['error'])) {


                    $error['option_2_image'] = $option_2_image['error'];


                } elseif (!empty($option_2_image['name'])) {


                    $this->form_validation->set_rules('option_2', 'Second option', 'trim');


                } else {


                    $this->form_validation->set_rules('option_2', 'Second option', 'trim|required');


                }

                $option_3_image = do_image_upload($temp_path, 'option_3_image', array("file_name" => "option_3_image", "overwrite" => TRUE), 0);


                if (!empty($option_3_image['error'])) {


                    $error['option_3_image'] = $option_3_image['error'];


                } elseif (!empty($option_3_image['name'])) {


                    $this->form_validation->set_rules('option_3', 'Third option', 'trim');


                } else {


                    $this->form_validation->set_rules('option_3', 'Third option', 'trim|required');


                }

                $option_4_image = do_image_upload($temp_path, 'option_4_image', array("file_name" => "option_4_image", "overwrite" => TRUE), 0);


                if (!empty($option_4_image['error'])) {


                    $error['option_4_image'] = $option_4_image['error'];


                } elseif (!empty($option_4_image['name'])) {


                    $this->form_validation->set_rules('option_4', 'Fourth option', 'trim');


                } else {


                    $this->form_validation->set_rules('option_4', 'Fourth option', 'trim|required');


                }


                $option_5_image = do_image_upload($temp_path, 'option_1_image', array("file_name" => "option_5_image", "overwrite" => TRUE), 0);

                if ($this->form_validation->run() == FALSE || !empty($error)) {


                    $error['question_name'] = form_error('question_name');


                    $error['option_1'] = form_error('option_1');


                    $error['option_2'] = form_error('option_2');


                    $error['option_3'] = form_error('option_3');


                    $error['option_4'] = form_error('option_4');


                    $error['answer_option '] = form_error('answer_option');


                    $return = array('has_error' => 1, 'error' => $error);


                }

                if (empty($error)) {


                    $question_no = $this->exam_model->get_next_qstn_no($exam_id);


                    $data['id_exam'] = $exam_id;


                    $data['id_course'] = $this->input->post('course_id');


                    $data['question_no'] = $question_no;


                    $data['question_name'] = $this->input->post('question_name');


                    $data['question_option_1'] = $this->input->post('option_1');


                    $data['question_option_2'] = $this->input->post('option_2');


                    $data['question_option_3'] = $this->input->post('option_3');


                    $data['question_option_4'] = $this->input->post('option_4');


                    $data['question_option_5'] = $this->input->post('option_5');


                    $data['question_answer'] = $this->input->post('answer_option');


                    $data['explanation'] = $this->input->post('explanation');


                    $data['added_by'] = $this->user->id;


                    $data['added_date'] = date("Y-m-d H:i:s");


                    $question_id = $this->db_model->insert('tbl_exams_questions', $data);


                    $path = $exam_data->exam_upload_path . 'question_' . $question_no . '/';


                    if (!is_dir($path)) {


                        mkdir($path);


                        chmod($path, 0755);


                    }

                    if (!empty($question_image['name'])) {


                        rename($temp_path . $question_image['name'], $path . $question_image['name']);


                        $data2['question_image'] = $question_image['name'];


                    }

                    if (!empty($option_1_image['name'])) {


                        rename($temp_path . $option_1_image['name'], $path . $option_1_image['name']);


                        $data2['question_option_1_image	'] = $option_1_image['name'];


                    }

                    if (!empty($option_2_image['name'])) {


                        rename($temp_path . $option_2_image['name'], $path . $option_2_image['name']);


                        $data2['question_option_2_image	'] = $option_2_image['name'];


                    }

                    if (!empty($option_3_image['name'])) {


                        rename($temp_path . $option_3_image['name'], $path . $option_3_image['name']);


                        $data2['question_option_3_image	'] = $option_3_image['name'];


                    }

                    if (!empty($option_4_image['name'])) {


                        rename($temp_path . $option_4_image['name'], $path . $option_4_image['name']);


                        $data2['question_option_4_image	'] = $option_4_image['name'];


                    }


                    if (!empty($option_5_image['name'])) {


                        rename($temp_path . $option_5_image['name'], $path . $option_5_image['name']);


                        $data2['question_option_5_image	'] = $option_5_image['name'];


                    }


                    $data2['question_upload_path'] = $path;


                    $this->db_model->update('tbl_exams_questions', $data2, 'id_question', $question_id);


                    $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Question added successfully', 'function' => 'refreshQuestionsTable', 'reset' => '1');


                }


                echo json_encode($return);


            }


        } else {


            redirect(admin_url('dailyquiz'), 'refresh');


        }


    }





    public function insert_step_3() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-step3") {


			


			/* $set = array(array('tag' => '.exam_id', 'data' => $exam_id, 'fun' => 1));


			, 'set' => $set */


			


			$return = array('has_error' => 0, 'step' => '2', 'nextStep' => 3, 'message' => 'Step 2 completed');





            echo json_encode($return);


        }


    }


	


    public function insert_textual_step_final() {

		$data = array();
		
        if (isset($_POST['action']) && $_POST['action'] == "exam-stepfinal") {

		$path = 'uploads/' . $this->tmp_path;
		
/* 		var_dump( $path );
		exit; */

		if (!is_dir($path)) {

			mkdir($path);

			chmod($path, 0755);

		}

		$config['upload_path'] = $path;

		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';

		$config['file_name'] = strtolower(@$_FILES['featured_image']['name']);

		$config['file_ext_tolower'] = TRUE;

		$config['remove_spaces'] = TRUE;

		$this->upload->initialize($config);
		
		$exam_id = $this->input->post('exam_id');

		if (!empty($exam_id)) {


		}
		
		$row = $this->exam_model->get_single($exam_id);

/* echo "<hr><pre>row: ";
var_dump( $row );
exit; */
				
		if (empty($exam_id)) {

			if (@$_FILES['featured_image']['size'] == '0') {

				//$this->form_validation->set_rules('featured_image', 'featured_image', 'required');

			}

		}
		

		
		if ( !empty( $_FILES['featured_image']['name'] ) ) {



			if (!$this->upload->do_upload('featured_image')) {

				//$error['featured_image'] 	= set_error($this->upload->display_errors());

				//$this->form_validation->set_rules('featured_image', 'featured_image', 'required');

			}

		}
		
				
		if (!empty($_FILES['featured_image']['name']) && !empty($exam_id)) {

			if (file_exists($row->exam_upload_path . $row->exam_featured_image)) {

				//unlink($row->exam_upload_path . $row->exam_featured_image);

			}

			$image = $this->upload->data();

			$data['exam_featured_image'] = $image['file_name'];

		} elseif (!empty($_FILES['featured_image']['name'])) {

			$image = $this->upload->data();

			$data['exam_featured_image'] = $image['file_name'];

		}

		//$error['featured_image'] 	= form_error('featured_image');
		
		/*
		$exam_no = $this->exam_model->get_next_exam_no($exam_id);

		$new_path = 'uploads/exam_' . $exam_no . '/';

		if (!is_dir($new_path)) {

			mkdir($new_path);

			chmod($new_path, 0755);

		}

		if (!empty($_FILES['featured_image']['name'])) {

			rename('uploads/' . $this->tmp_path . $image['file_name'], $new_path . $image['file_name']);

		}
		*/
		

		if (!empty($_FILES['featured_image']['name'])) {

			$new_path = $row->exam_upload_path;

			if (!is_dir($new_path)) {

				mkdir($new_path);

				chmod($new_path, 0755);

			}

			rename('uploads/' . $this->tmp_path . $image['file_name'], $new_path . $image['file_name']);

			$data['exam_upload_path'] = $new_path;

		}
		
			if( !empty( $data ) )
				$this->db_model->update('tbl_exams', $data, 'id_exam', $exam_id);


            $data2['status'] = 1;


            //$this->db_model->delete('tbl_quizparentcats', 'quiz_id', $this->session->userdata('exam_id'));
			
            //$this->db_model->update('tbl_quizparentcats', $data2, 'quiz_id', $this->session->userdata('exam_id'));





            $ecat = $this->exam_model->getquizparentid($this->session->userdata('exam_id'));
            
            $parentcat_id = $this->db->query( "SELECT parentcat_id FROM `tbl_quizparentcats` WHERE `quiz_id` = ". $this->session->userdata('exam_id') ." and parentcat_id is not null order by id limit 1" )->row()->parentcat_id;

			$data = array();	

            $data['exam_category'] = $parentcat_id;


            $data['quiz_id'] = $this->session->userdata('exam_id');


            $data['status'] = 4;


            $data['userid'] = $this->user->id;


            $data['created'] = date("Y-m-d H:i:s");


            $newsfeedpost = $this->session->userdata('newsfeefpost');


            $rowexist = $this->exam_model->checkpost($this->session->userdata('exam_id'));


            if ($rowexist == "") {


                $question_id = $this->db_model->insert('tbl_posts', $data);
				
				$res = $this->db->query( "select * from tbl_quizparentcats where quiz_id = " . $this->session->userdata('exam_id') . " and parentcat_id is not null" )->result();
				
				$parentcat_ids = '';
				
				if( !empty( $res ) )
				{	
					foreach( $res as $key => $value )
					{	
						$parentcat_ids .= $value->parentcat_id . ',';
					}
					
					$parentcat_ids = ',' . $parentcat_ids;
				}
				
				$resinnercat = $this->db->query( "select * from tbl_quizparentcats where quiz_id = " . $this->session->userdata('exam_id') . " and sub_catid is not null" )->result();
				
				$parentinnercat_ids = '';
				
				if( !empty( $resinnercat ) )
				{	
					foreach( $resinnercat as $key => $valueicat )
					{	
						$parentinnercat_ids .= $valueicat->sub_catid . ',';
					}
					
					$parentinnercat_ids = ',' . $parentinnercat_ids;
				}
				
				$resscat = $this->db->query( "select * from tbl_quizparentcats where quiz_id = " . $this->session->userdata('exam_id') . " and sub_sub_catid is not null" )->result();
				
				$parentsubcat_ids = '';
				
				if( !empty( $resscat ) )
				{	
					foreach( $resscat as $key => $valuescat )
					{	
						$parentsubcat_ids .= $valuescat->sub_sub_catid . ',';
					}
					
					$parentsubcat_ids = ',' . $parentsubcat_ids;
				}
				
				$this->GeneralModel->UpdateRow( "tbl_posts", array( 'parentcat_ids' => $parentcat_ids, 'parentinnercat_ids' => $parentinnercat_ids, 'parentsubcat_ids' => $parentsubcat_ids ), array( 'quiz_id' => $this->session->userdata('exam_id') ) );
				
            }


            $data2['finished_status'] = 1;


			


            $data2['featured_quiz'] = $this->input->post('featured');
			
			$data2['recommended_1'] = $this->input->post('fpost1');
			$data2['recommended_2'] = $this->input->post('fpost2');
			$data2['recommended_3'] = $this->input->post('fpost3');
			$data2['recommended_4'] = $this->input->post('fpost4');
			
			$data2['scheduleddate'] = date('Y-m-d', strtotime( $this->input->post('scheduleddate') ) );
			$data2['scheduledtime'] = $this->input->post('scheduledtime');
			
			if( !empty( $data2['scheduledtime'] ) )
			{
				$data2['scheduled'] = 'Y';
			}
			else
			{
			    $ses_pnot = $this->session->userdata('ses_pnot');
			    $ses_pnot['created_date'] = date("Y-m-d H:i:s");
			    $this->GeneralModel->AddNewRow( "tbl_notifications", $ses_pnot );
			}

            $this->db_model->update('tbl_exams', $data2, 'id_exam', $this->input->post('exam_id'));

			$msg = ( !empty( $_POST['action_up'] ) ) ? 'Exam edited successfully' : 'Exam added successfully' ;
			
            $return = array('has_error' => 0, 'page' => admin_url('dailyquiz'), 'message' => $msg);

            echo json_encode($return);

        }


    }


	


    public function insert_step_3_old() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-step3") {


            $course_id = $this->input->post('course_id');








            $data2['status'] = 1;


            $this->db_model->update('tbl_quizparentcats', $data2, 'quiz_id', $this->session->userdata('exam_id'));





            $ecat = $this->exam_model->getquizparentid($this->session->userdata('exam_id'));


            $data['exam_category'] = 0;


            $data['quiz_id'] = $this->session->userdata('exam_id');


            $data['status'] = 4;


            $data['userid'] = $this->user->id;


            $data['created'] = date("Y-m-d H:i:s");


            $newsfeedpost = $this->session->userdata('newsfeefpost');


            $rowexist = $this->exam_model->checkpost($this->session->userdata('exam_id'));


            if ($rowexist == "") {


                $question_id = $this->db_model->insert('tbl_posts', $data);


            }


            $data2['finished_status'] = 1;


            $this->db_model->update('tbl_exams', $data2, 'id_exam', $this->input->post('exam_id'));


            $return = array('has_error' => 0, 'page' => admin_url('dailyquiz'), 'message' => 'Exam details added successfully');


            echo json_encode($return);


        }


    }
	
    public function del_que_txt_det() {
		
		$id_question = $this->input->post('id_question');
		$ret = $this->GeneralModel->DeleteRow($table = 'tbl_exams_questions', $key = array('id_question'=>$id_question));
		echo $ret;exit;
	}

    public function del_que_img_det() {
		
		$id_question = $this->input->post('id_question');
		$ret = $this->GeneralModel->DeleteRow($table = 'tbl_exams_questions', $key = array('id_question'=>$id_question));
		echo $ret;exit;
	}

    public function del_que_det() {
		
		$id_question = $this->input->post('id_question');
		$ret = $this->GeneralModel->DeleteRow($table = 'tbl_exams_questions', $key = array('id_question'=>$id_question));
		echo $ret;exit;
	}
	
    public function up_que_det() {
		
		$id_question = $this->input->post('id_question');
		$cke_question_name = $this->input->post('cke_question_name');
		$cke_option_1 = $this->input->post('cke_option_1');
		$cke_option_2 = $this->input->post('cke_option_2');
		$cke_option_3 = $this->input->post('cke_option_3');
		$cke_option_4 = $this->input->post('cke_option_4');
		$cke_option_5 = $this->input->post('cke_option_5');
		$cke_explanation = $this->input->post('cke_explanation');
		$answer_option = $this->input->post('answer_option');
		
		$ret = $this->GeneralModel->UpdateRow( "tbl_exams_questions", array( 'question_name' => $cke_question_name, 'question_option_1' => $cke_option_1, 'question_option_2' => $cke_option_2, 'question_option_3' => $cke_option_3, 'question_option_4' => $cke_option_4, 'question_option_5' => $cke_option_5, 'explanation' => $cke_explanation, 'question_answer' => $answer_option), array( 'id_question' => $id_question ) );

		echo $ret;exit;
	
	}

    public function up_que_img_det() {
		
		$id_question = $this->input->post('id_question');
		
		$tbl_exams_questions = $this->GeneralModel->GetInfoRow('tbl_exams_questions', array('id_question'=>$id_question));
		
		$exam_id = $this->input->post('exam_id');
		$answer = $this->input->post('answer');
		$image_duration = $this->input->post('image_duration');
		$image_duration_slug = $this->input->post('image_duration_slug');
		$answer_duration = $this->input->post('answer_duration');
		$answer_duration_slug = $this->input->post('answer_duration_slug');

		$qimg = $this->input->post('question_image');
		$exam_data = $this->exam_model->get_single($exam_id);
		$path = $exam_data->exam_upload_path . @$tbl_exams_questions[0]->question_name . '/';

		if (!is_dir($path)) {

			mkdir($path);

			chmod($path, 0755);

		}

		$question_image = do_image_upload($path, 'question_image', array("file_name" => $qimg, "overwrite" => TRUE), 0);
		
		$ret = 0;
		
		if (empty($question_image['error'])) {
			$ret = $this->GeneralModel->UpdateRow( "tbl_exams_questions", array( 'image' => $question_image['name'], 'image_upload_path' => $path, 'answer' => $answer, 'image_duration' => $image_duration, 'image_duration_slug' => $image_duration_slug, 'answer_duration' => $answer_duration, 'answer_duration_slug' => $answer_duration_slug), array( 'id_question' => $id_question ) );
		}

		echo $ret;exit;
	
	}
	
    public function up_que_txt_det() {
		
		$id_question = $this->input->post('id_question');
		$question_name = $this->input->post('question_name');
		$answer = $this->input->post('answer');
		
		$ret = $this->GeneralModel->UpdateRow( "tbl_exams_questions", array( 'question_name' => $question_name, 'answer' => $answer ), array( 'id_question' => $id_question ) );

		echo $ret;exit;
	
	}	
	
    public function get_que_txt_det() {
		
		$id_question = $this->input->post('id_question');
		
		$tbl_exams_questions = $this->GeneralModel->GetInfoRow($table = 'tbl_exams_questions', $key = array('id_question'=>$id_question));

/* echo "<hr><pre>tbl_exams_questions: ";
var_dump( $tbl_exams_questions );
exit; */
		$res = array();
		
		if( !empty( $tbl_exams_questions ) )
		{
			$res = array( 
			'id_question' => $tbl_exams_questions[0]->id_question, 
			'question_name' => $tbl_exams_questions[0]->question_name, 
			'answer' => $tbl_exams_questions[0]->answer
			);
		}
		
		echo json_encode($res);exit;
		
	}
			
    public function get_que_img_det() {
		
		$id_question = $this->input->post('id_question');
		
		$tbl_exams_questions = $this->GeneralModel->GetInfoRow($table = 'tbl_exams_questions', $key = array('id_question'=>$id_question));

/* echo "<hr><pre>tbl_exams_questions: ";
var_dump( $tbl_exams_questions );
exit; */
		$res = array();
		
		if( !empty( $tbl_exams_questions ) )
		{
			$res = array( 
			'id_question' => $tbl_exams_questions[0]->id_question, 
			'answer' => $tbl_exams_questions[0]->answer, 
			'image_duration' => $tbl_exams_questions[0]->image_duration, 
			'image_duration_slug' => $tbl_exams_questions[0]->image_duration_slug, 
			'answer_duration' => $tbl_exams_questions[0]->answer_duration, 
			'answer_duration_slug' => $tbl_exams_questions[0]->answer_duration_slug
			);
		}
		
		echo json_encode($res);exit;
		
	}
	
    public function get_que_det() {
		
		$id_question = $this->input->post('id_question');
		
		$tbl_exams_questions = $this->GeneralModel->GetInfoRow($table = 'tbl_exams_questions', $key = array('id_question'=>$id_question));

/* echo "<hr><pre>tbl_exams_questions: ";
var_dump( $tbl_exams_questions );
exit; */
		$res = array();
		
		if( !empty( $tbl_exams_questions ) )
		{
			$res = array( 
			'id_question' => $tbl_exams_questions[0]->id_question, 
			'question_name' => $tbl_exams_questions[0]->question_name, 
			'question_option_1' => $tbl_exams_questions[0]->question_option_1, 
			'question_option_2' => $tbl_exams_questions[0]->question_option_2, 
			'question_option_3' => $tbl_exams_questions[0]->question_option_3, 
			'question_option_4' => $tbl_exams_questions[0]->question_option_4, 
			'question_option_5' => $tbl_exams_questions[0]->question_option_5, 
			'question_answer' => $tbl_exams_questions[0]->question_answer, 
			'explanation' => $tbl_exams_questions[0]->explanation
			);
		}
		
		echo json_encode($res);exit;
		
		
	}	
	
	
		
    public function get_all_questions() {


        $exam_id = 98;


        if ($this->session->userdata('exam_id') != "") {


            $exam_id = $this->session->userdata('exam_id');


        }
		
        echo $this->dailyquiz_model->all_questions($exam_id);


    }





    public function edit($exam_id = 0) {


        if (!has_permission('dailyquiz', 'edit')) {


            redirect(admin_url('login'), 'refresh');


        }


        $data['page'] = 'dailyquiz';
		
        $data['exam_id'] = $exam_id;


        if (!empty($exam_id)) {


            $data['script'] = 1;


            $data['row'] = $this->exam_model->get_single($exam_id);

			// print "<hr><pre>".$this->db->last_query();exit;

            $data['examcats'] = $this->course_model->get_all_categories();

			
			$catids = str_replace(" ","", $data['row']->quizcatid);
			
			if( strpos( $data['row']->quizcatid, "," ) )
			{
				$catids = explode(",", $data['row']->quizcatid );
			}
			

            $data['subcats'] = $this->dailyquiz_model->get_all_subcategoriesbyquiz( $catids );
			
/* echo "<hr><pre>subcats: ";
var_dump( $data['subcats'] );
exit; */			

			
            $data['exams'] = $this->course_model->getallmainexams();

			$subsubcats = str_replace(" ","", $data['row']->sub_catid);
			
			if( strpos( $data['row']->sub_catid, "," ) )
			{
				$subsubcats = explode(",", $data['row']->sub_catid );
			}

            $data['subsub'] = $this->exam_model->get_all_subsub($subsubcats);
			
			// print "<hr><pre>".$this->db->last_query();exit;


            $data['course_id'] = $data['row']->id_course;


            $this->session->set_userdata('exam_id', $exam_id);


            if (count($data['row']) > 0) {

				$data['articles'] = $this->dailyquiz_model->get_all_articles();

                $this->myadmin->view('dailyquiz/edit', $data);


            } else {


                $this->myadmin->view('404', $data);


            }


        } else {


            redirect(admin_url('examdetails'), 'refresh');


        }


    }





    public function hide() {


        if (!has_permission('dailyquiz', 'status')) {


            redirect(admin_url('login'), 'refresh');


        }


        if (isset($_POST['action']) && $_POST['action'] == "hideRow") {


            $error = array();


            $this->form_validation->set_rules('id', 'id', 'trim|required');





            if ($this->form_validation->run() == FALSE) {


                $error['id'] = (form_error('id'));


                $return = array('has_error' => 1, 'error' => $error);


            } else {


                $data['status'] = 0;


                $this->db_model->update('tbl_exams', $data, 'id_exam', $this->input->post('id'));


                $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Exam status updated successfully', 'function' => 'refreshExamTable');


            }


            echo json_encode($return);


        } else {


            redirect(admin_url('exam'), 'refresh');


        }


    }





    public function unhide() {


        if (!has_permission('dailyquiz', 'status')) {


            redirect(admin_url('login'), 'refresh');


        }


        if (isset($_POST['action']) && $_POST['action'] == "unhideRow") {


            $error = array();


            $this->form_validation->set_rules('id', 'id', 'trim|required');





            if ($this->form_validation->run() == FALSE) {


                $error['id'] = (form_error('id'));


                $return = array('has_error' => 1, 'error' => $error);


            } else {


                $data['status'] = 1;


                $this->db_model->update('tbl_exams', $data, 'id_exam', $this->input->post('id'));


                $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Exam status updated successfully', 'function' => 'refreshExamTable');


            }


            echo json_encode($return);


        } else {


            redirect(admin_url('exam'), 'refresh');


        }


    }





    public function delete() {


        if (!has_permission('dailyquiz', 'delete')) {


            redirect(admin_url('login'), 'refresh');


        }


        if (isset($_POST['action']) && $_POST['action'] == "deleteRow") {


            $error = array();


            $this->form_validation->set_rules('id', 'id', 'trim|required');





            if ($this->form_validation->run() == FALSE) {


                $error['id'] = (form_error('id'));


                $return = array('has_error' => 1, 'error' => $error);


            } else {


                $row = $this->exam_model->get_single($this->input->post('id'));


                if (!empty($row)) {


                    if (is_dir($row->exam_upload_path)) {


                        deleteDirectory($row->exam_upload_path);


                    }


                }


                $this->db_model->delete('tbl_exams', 'id_exam', $this->input->post('id'));


                $this->db_model->delete('tbl_exams_questions', 'id_exam', $this->input->post('id'));


                $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Exam deleted successfully', 'function' => 'refreshExamTable');


            }


            echo json_encode($return);


        } else {


            redirect(admin_url('exam'), 'refresh');


        }


    }





    public function details($exam_id = 0) {





        $data['page'] = 'exam';


        if (!empty($exam_id)) {


            $data['script'] = 1;


            $data['row'] = $this->exam_model->get_single($exam_id);


            $data['cats'] = $this->exam_model->quizcatdetails($exam_id);


            $data['subcats'] = $this->exam_model->quizsubcatdetails($exam_id);


            $data['subsubcats'] = $this->exam_model->quizsubsubcatdetails($exam_id);


            $this->session->set_userdata('exam_id', $exam_id);


            if (count($data['row']) > 0) {


                $data['course_id'] = $data['row']->id_course;


                $this->myadmin->view('dailyquiz/details', $data);


            } else {


                $this->myadmin->view('404', $data);


            }


        } else {


            redirect(admin_url('courses'), 'refresh');


        }


    }





    


    public function add_image() {


        if (!has_permission('dailyquiz', 'add')) {


            redirect(admin_url('login'), 'refresh');


        }


        $data['page'] = 'dailyquiz_image';


        $data['script'] = 1;


        $data['examcats'] = $this->course_model->get_all_categories();


        //$data['subcats']  	= $this->dailyquiz_model->get_all_subcategoriesbyquiz();


        $this->session->unset_userdata('exam_id');


        $this->session->unset_userdata('newsfeefpost');


        $this->session->unset_userdata('examcat');


        $this->myadmin->view('dailyquiz_image/add_image', $data);


    }


    


    public function insert_image_step_1() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-image-step1") {


            $error = array();


            $exam_id = $this->input->post('exam_id');


            if (!empty($exam_id)) {


                $row = $this->exam_model->get_single($exam_id);


            }


            $course_id = $this->input->post('exam_id');


            $course_data = $this->course_model->get_single($course_id);


            if (count($exam_id) > 0) {





                $path = 'uploads/' . $this->tmp_path;





                if (!is_dir($path)) {


                    mkdir($path);


                    chmod($path, 0755);


                }





                $config['upload_path'] = $path;


                $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';


                $config['file_name'] = strtolower($this->input->post('exam_name'));


                $config['file_ext_tolower'] = TRUE;


                $config['remove_spaces'] = TRUE;


                $this->upload->initialize($config);


                $this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');


                $this->form_validation->set_rules('examcat[]', 'Exam Category', 'trim|required');


                // $this->form_validation->set_rules('subcat','Exam SubCategory', 'trim|required');


                //$this->form_validation->set_rules('subsub','SubsubCategory', 'trim|required');


                $this->form_validation->set_rules('exam_name', 'Quiz Title', 'trim|required');


                $this->form_validation->set_rules('total_questions', 'total questions', 'trim|required|numeric');


                //$this->form_validation->set_rules('total_time', 'exam duration', 'trim|required|numeric');


                //$this->form_validation->set_rules('duration_slug', 'exam duration', 'trim|required');


                $this->form_validation->set_rules('exam_description', 'exam description', 'trim|required');


                $this->form_validation->set_rules('coin', 'Coin', 'trim|required');


                //$this->form_validation->set_rules('diff_level', 'Difficulty Level', 'trim|required');


                


                





                if ($this->form_validation->run() == FALSE) {


                    $error['examcat'] = form_error('examcats[]');


                    //$error['subcat'] 		    = form_error('subcat');


                    //$error['subsub'] 		    = form_error('subsub');


                    $error['exam_name'] = form_error('exam_name');


                    $error['total_questions'] = form_error('total_questions');


                   // $error['total_time'] = form_error('total_time');


                    $error['editor'] = form_error('exam_description');


                    //$error['featured_image'] 	= form_error('featured_image');


                    $error['coin'] = form_error('coin');


                    //$error['diff_level'] = form_error('diff_level');


//                    if (form_error('duration') != "") {


//                        $error['total_time'] = form_error('total_time');


//                    } else {


//                        $error['total_time'] = form_error('duration_slug');


//                    }


                    $return = array('has_error' => 1, 'error' => $error);


                } else {


                    $exam_no = $this->exam_model->get_next_exam_no($course_id);


//                    if (!empty($_FILES['featured_image']['name']) && !empty($exam_id)) {


//                        if (file_exists($row->exam_upload_path . $row->exam_featured_image)) {


//                            unlink($row->exam_upload_path . $row->exam_featured_image);


//                        }


//                        $image = $this->upload->data();


//                        $data['exam_featured_image'] = $image['file_name'];


//                    } elseif (!empty($_FILES['featured_image']['name'])) {


//                        $image = $this->upload->data();


//                        $data['exam_featured_image'] = $image['file_name'];


//                    }


                    $nfpost = $this->input->post('newffedpost');


                    $this->session->set_userdata('newsfeefpost', $nfpost);


                    $excat[] = $this->input->post('examcat');


                    $firstcat = $excat[0];


                    $this->session->set_userdata('examcat', $firstcat);





                    $data['id_cat'] = 0;


                    //$data['id_course']			= $this->input->post('subcat');


                    //$data['id_subsubcat']			= $this->input->post('subsub');


                    $data['exam_name'] = $this->input->post('exam_name');


                    $data['exam_description'] = base64_encode($this->input->post('exam_description'));


                    //$data['exam_duration'] = $this->input->post('total_time');


                    //$data['exam_duration_slug'] = $this->input->post('duration_slug');


                    $data['quiz_type'] = $this->input->post('quiz_type');


                    $data['total_questions'] = $this->input->post('total_questions');


                    $data['coins'] = $this->input->post('coin');


                    //$data['marks_per_ques'] = $this->input->post('marks');


                    //$data['negative_mark'] = $this->input->post('negativemarks');


                    //$data['difficulty_level'] = $this->input->post('diff_level');


                    $data['exam_slug'] = $this->slug->create_uri($this->input->post('exam_name'));


                    $data['daily_quiz'] = 1;


                    //$data['newsfeedpost'] = $this->input->post('newffedpost');


                    //$data['featured_quiz'] = $this->input->post('featured');


                    //$data['image_url'] = $this->input->post('imgurl');


                    if (empty($exam_id)) {





                        $data['exam_no'] = $exam_no;


                        $data['added_by'] = $this->user->id;


                        $data['added_date'] = date("Y-m-d H:i:s");


                        $exam_id = $this->db_model->insert('tbl_exams', $data);


                        $examcat = $this->input->post('examcat');


                        foreach ($examcat as $examcat) {


                            $data3['quiz_id'] = $exam_id;


                            $data3['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data3);


                        }


                        foreach ($_POST['subcat'] as $examsubcat) {


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);


                        }





                        foreach ($_POST['subsub'] as $examsubsubcat) {


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);


                        }


                        $this->session->set_userdata('exam_id', $exam_id);


                        $new_path = 'uploads/exam_' . $exam_no . '/';


                        if (!is_dir($new_path)) {


                            mkdir($new_path);


                            chmod($new_path, 0755);


                        }





                        if (!empty($_FILES['featured_image']['name'])) {


                            rename('uploads/' . $this->tmp_path . $image['file_name'], $new_path . $image['file_name']);


                        }


                        $data2['exam_upload_path'] = $new_path;


                        $this->db_model->update('tbl_exams', $data2, 'id_exam', $exam_id);


                        $this->db_model->delete('tbl_quizparentcats', 'quiz_id', $exam_id);








                        $examcat = $this->input->post('examcat');





                        foreach ($examcat as $examcat) {


                            $data14['quiz_id'] = $exam_id;


                            $data14['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data14);


                        }





                        foreach ($_POST['subcat'] as $examsubcat) {


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);


                        }


                        foreach ($_POST['subsub'] as $examsubsubcat) {


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);


                        }


                    } else {


                        if (!empty($_FILES['featured_image']['name'])) {


                            $new_path = $row->exam_upload_path;


                            if (!is_dir($new_path)) {


                                mkdir($new_path);


                                chmod($new_path, 0755);


                            }


                            rename('uploads/' . $this->tmp_path . $image['file_name'], $new_path . $image['file_name']);


                            $data['exam_upload_path'] = $new_path;


                        }


                        $this->db_model->update('tbl_exams', $data, 'id_exam', $exam_id);


                        $this->db_model->delete('tbl_quizparentcats', 'quiz_id', $exam_id);





                        $examcat = $this->input->post('examcat');


                        foreach ($examcat as $examcat) {


                            $data3['quiz_id'] = $exam_id;


                            $data3['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data3);


                        }





                        foreach ($_POST['subcat'] as $examsubcat) {


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);


                        }


                        foreach ($_POST['subsub'] as $examsubsubcat) {


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);


                        }


                    }


                    $set = array(array('tag' => '.exam_id', 'data' => $exam_id, 'fun' => 1));





                    $return = array('has_error' => 0, 'set' => $set, 'step' => '1', 'nextStep' => 2, 'message' => 'Step 1 completed');


                }


                echo json_encode($return);


            }


        } else {


            redirect(admin_url('dailyquiz'), 'refresh');


        }


    }





    public function insert_image_step_2() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-image-step2") {


            $error = array();


            $exam_id = $this->input->post('exam_id');


            $qimg = $this->input->post('question_image');


            $exam_data = $this->exam_model->get_single($exam_id);


			


			// print "<hr><pre>".$this->db->last_query();//exit;


			


            if (count($exam_data) > 0) {


                $this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');


                //$this->form_validation->set_rules('question_image', 'question image', 'trim|required');


                $this->form_validation->set_rules('answer', 'answer', 'trim|required');





                


                $temp_path = $exam_data->exam_upload_path . $this->tmp_path;


                if (!is_dir($temp_path)) {


                    mkdir($temp_path);


                    chmod($temp_path, 0755);


                }





                $question_image = do_image_upload($temp_path, 'question_image', array("file_name" => $qimg, "overwrite" => TRUE), 0);


                if (!empty($question_image['error'])) {


                    $error['question_image'] = $question_image['error'];


                }





                if ($this->form_validation->run() == FALSE || !empty($error)) {


                   // $error['question_image'] = form_error('question_image');


                    $error['answer'] = form_error('answer');


                    $return = array('has_error' => 1, 'error' => $error);


                }





                if (empty($error)) {


                    $question_no = $this->exam_model->get_next_qstn_no($exam_id);


                    $data['id_exam'] = $exam_id;


                    $data['id_course'] = $this->input->post('course_id');


                    $data['question_no'] = $question_no;


                    $data['question_name'] = 'Question '.$question_no;


                    $data['image'] = $question_image['name'];


                    $data['image_upload_path'] = $temp_path;


                    $data['image_duration'] = $this->input->post('image_duration');


                    $data['image_duration_slug'] = $this->input->post('image_duration_slug');


                    $data['answer'] = $this->input->post('answer');


                    $data['answer_duration'] = $this->input->post('answer_duration');


                    $data['answer_duration_slug'] = $this->input->post('answer_duration_slug');


                    $data['added_by'] = $this->user->id;


                    $data['added_date'] = date("Y-m-d H:i:s");


                    $question_id = $this->db_model->insert('tbl_exams_questions', $data);


                    $path = $exam_data->exam_upload_path . 'question_' . $question_no . '/';


                    if (!is_dir($path)) {


                        mkdir($path);


                        chmod($path, 0755);


                    }





                    if (!empty($question_image['name'])) {


                        rename($temp_path . $question_image['name'], $path . $question_image['name']);


                        $data2['image'] = $question_image['name'];


                    }





                    $data2['image_upload_path'] = $path;


                    $this->db_model->update('tbl_exams_questions', $data2, 'id_question', $question_id);


                    $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Question Image added successfully', 'function' => 'refreshpictorialTable', 'reset' => '1');


                }


                echo json_encode($return);


            }


        } else {


            redirect(admin_url('dailyquiz'), 'refresh');


        }


    }





    public function insert_image_step_3() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-step3") {


            $course_id = $this->input->post('course_id');


            $data2['status'] = 1;


            $this->db_model->update('tbl_quizparentcats', $data2, 'quiz_id', $this->session->userdata('exam_id'));





            $ecat = $this->exam_model->getquizparentid($this->session->userdata('exam_id'));


            $data['exam_category'] = 0;


            $data['quiz_id'] = $this->session->userdata('exam_id');


            $data['status'] = 4;


            $data['userid'] = $this->user->id;


            $data['created'] = date("Y-m-d H:i:s");


            $newsfeedpost = $this->session->userdata('newsfeefpost');


            $rowexist = $this->exam_model->checkpost($this->session->userdata('exam_id'));


            if ($rowexist == "") {


                $question_id = $this->db_model->insert('tbl_posts', $data);


            }


            $data2['finished_status'] = 1;


            $this->db_model->update('tbl_exams', $data2, 'id_exam', $this->input->post('exam_id'));


            $return = array('has_error' => 0, 'page' => admin_url('dailyquiz'), 'message' => 'Exam details added successfully');


            echo json_encode($return);


        }


    }





    public function get_all_questions_image() {


        $exam_id = 100;


        if ($this->session->userdata('exam_id') != "") {


            $exam_id = $this->session->userdata('exam_id');


        }


        echo $this->dailyquiz_model->all_questions($exam_id);


    }
	

    public function edit_image($exam_id = 0) {


        if (!has_permission('dailyquiz', 'edit')) {


            redirect(admin_url('login'), 'refresh');


        }


        $data['page'] = 'dailyquiz';


        if (!empty($exam_id)) {


            $data['script'] = 1;


            $data['row'] = $this->exam_model->get_single($exam_id);


            $data['examcats'] = $this->course_model->get_all_categories();


            $data['subcats'] = $this->dailyquiz_model->get_all_subcategoriesbyquiz($data['row']->quizcatid);


            $data['exams'] = $this->course_model->getallmainexams();


            $data['subsub'] = $this->exam_model->get_all_subsub($data['row']->sub_catid);





            $data['course_id'] = $data['row']->id_course;


            $this->session->set_userdata('exam_id', $exam_id);


            if (count($data['row']) > 0) {


                $this->myadmin->view('dailyquiz/edit', $data);


            } else {


                $this->myadmin->view('404', $data);


            }


        } else {


            redirect(admin_url('examdetails'), 'refresh');


        }


    }





    public function hide_image() {


        if (!has_permission('dailyquiz', 'status')) {


            redirect(admin_url('login'), 'refresh');


        }


        if (isset($_POST['action']) && $_POST['action'] == "hideRow") {


            $error = array();


            $this->form_validation->set_rules('id', 'id', 'trim|required');





            if ($this->form_validation->run() == FALSE) {


                $error['id'] = (form_error('id'));


                $return = array('has_error' => 1, 'error' => $error);


            } else {


                $data['status'] = 0;


                $this->db_model->update('tbl_exams', $data, 'id_exam', $this->input->post('id'));


                $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Exam status updated successfully', 'function' => 'refreshExamTable');


            }


            echo json_encode($return);


        } else {


            redirect(admin_url('exam'), 'refresh');


        }


    }





    public function unhide_image() {


        if (!has_permission('dailyquiz', 'status')) {


            redirect(admin_url('login'), 'refresh');


        }


        if (isset($_POST['action']) && $_POST['action'] == "unhideRow") {


            $error = array();


            $this->form_validation->set_rules('id', 'id', 'trim|required');





            if ($this->form_validation->run() == FALSE) {


                $error['id'] = (form_error('id'));


                $return = array('has_error' => 1, 'error' => $error);


            } else {


                $data['status'] = 1;


                $this->db_model->update('tbl_exams', $data, 'id_exam', $this->input->post('id'));


                $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Exam status updated successfully', 'function' => 'refreshExamTable');


            }


            echo json_encode($return);


        } else {


            redirect(admin_url('exam'), 'refresh');


        }


    }





    public function delete_image() {


        if (!has_permission('dailyquiz', 'delete')) {


            redirect(admin_url('login'), 'refresh');


        }


        if (isset($_POST['action']) && $_POST['action'] == "deleteRow") {


            $error = array();


            $this->form_validation->set_rules('id', 'id', 'trim|required');





            if ($this->form_validation->run() == FALSE) {


                $error['id'] = (form_error('id'));


                $return = array('has_error' => 1, 'error' => $error);


            } else {


                $row = $this->exam_model->get_single($this->input->post('id'));


                if (!empty($row)) {


                    if (is_dir($row->exam_upload_path)) {


                        deleteDirectory($row->exam_upload_path);


                    }


                }


                $this->db_model->delete('tbl_exams', 'id_exam', $this->input->post('id'));


                $this->db_model->delete('tbl_exams_questions', 'id_exam', $this->input->post('id'));


                $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Exam deleted successfully', 'function' => 'refreshExamTable');


            }


            echo json_encode($return);


        } else {


            redirect(admin_url('exam'), 'refresh');


        }


    }





    public function details_image($exam_id = 0) {





        $data['page'] = 'exam';


        if (!empty($exam_id)) {


            $data['script'] = 1;


            $data['row'] = $this->exam_model->get_single($exam_id);


            $data['cats'] = $this->exam_model->quizcatdetails($exam_id);


            $data['subcats'] = $this->exam_model->quizsubcatdetails($exam_id);


            $data['subsubcats'] = $this->exam_model->quizsubsubcatdetails($exam_id);


            $this->session->set_userdata('exam_id', $exam_id);


            if (count($data['row']) > 0) {


                $data['course_id'] = $data['row']->id_course;


                $this->myadmin->view('dailyquiz/details', $data);


            } else {


                $this->myadmin->view('404', $data);


            }


        } else {


            redirect(admin_url('courses'), 'refresh');


        }


    }


    


    


    public function add_textual() {


        if (!has_permission('dailyquiz', 'add')) {


            redirect(admin_url('login'), 'refresh');


        }


        $data['page'] = 'dailyquiz_textual';


        $data['script'] = 1;


        $data['examcats'] = $this->course_model->get_all_categories();


        //$data['subcats']  	= $this->dailyquiz_model->get_all_subcategoriesbyquiz();


        $this->session->unset_userdata('exam_id');


        $this->session->unset_userdata('newsfeefpost');


        $this->session->unset_userdata('examcat');


        $this->myadmin->view('dailyquiz_textual/add_textual', $data);


    }





    public function insert_textual_step_1() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-textual-step1") {


            $error = array();


            $exam_id = $this->input->post('exam_id');


            if (!empty($exam_id)) {


                $row = $this->exam_model->get_single($exam_id);


            }


            $course_id = $this->input->post('exam_id');


            $course_data = $this->course_model->get_single($course_id);


            if (count($exam_id) > 0) {





                $path = 'uploads/' . $this->tmp_path;





                if (!is_dir($path)) {


                    mkdir($path);


                    chmod($path, 0755);


                }





                $config['upload_path'] = $path;


                $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';


                $config['file_name'] = strtolower($this->input->post('exam_name'));


                $config['file_ext_tolower'] = TRUE;


                $config['remove_spaces'] = TRUE;


                $this->upload->initialize($config);


                $this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');


                $this->form_validation->set_rules('examcat[]', 'Exam Category', 'trim|required');


                // $this->form_validation->set_rules('subcat','Exam SubCategory', 'trim|required');


                //$this->form_validation->set_rules('subsub','SubsubCategory', 'trim|required');


                $this->form_validation->set_rules('exam_name', 'Quiz Title', 'trim|required');


                $this->form_validation->set_rules('total_questions', 'total questions', 'trim|required|numeric');


                $this->form_validation->set_rules('total_time', 'exam duration', 'trim|required|numeric');


                $this->form_validation->set_rules('duration_slug', 'exam duration', 'trim|required');


                $this->form_validation->set_rules('exam_description', 'exam description', 'trim|required');


                $this->form_validation->set_rules('coin', 'Coin', 'trim|required');


                //$this->form_validation->set_rules('diff_level', 'Difficulty Level', 'trim|required');


                


                





                if ($this->form_validation->run() == FALSE) {


                    $error['examcat'] = form_error('examcats[]');


                    //$error['subcat'] 		    = form_error('subcat');


                    //$error['subsub'] 		    = form_error('subsub');


                    $error['exam_name'] = form_error('exam_name');


                    $error['total_questions'] = form_error('total_questions');


                    $error['total_time'] = form_error('total_time');


                    $error['editor'] = form_error('exam_description');


                    //$error['featured_image'] 	= form_error('featured_image');


                    $error['coin'] = form_error('coin');


                    $error['diff_level'] = form_error('diff_level');


                    if (form_error('duration') != "") {


                        $error['total_time'] = form_error('total_time');


                    } else {


                        $error['total_time'] = form_error('duration_slug');


                    }


                    $return = array('has_error' => 1, 'error' => $error);


                } else {


                    $exam_no = $this->exam_model->get_next_exam_no($course_id);


                    


                    $nfpost = $this->input->post('newffedpost');


                    $this->session->set_userdata('newsfeefpost', $nfpost);


                    $excat[] = $this->input->post('examcat');


                    $firstcat = $excat[0];


                    $this->session->set_userdata('examcat', $firstcat);





                    $data['id_cat'] = 0;


                    //$data['id_course']			= $this->input->post('subcat');


                    //$data['id_subsubcat']			= $this->input->post('subsub');


                    $data['exam_name'] = $this->input->post('exam_name');


                    $data['quiz_type'] = $this->input->post('quiz_type');


                    $data['exam_description'] = base64_encode($this->input->post('exam_description'));


                    $data['exam_duration'] = $this->input->post('total_time');


                    $data['exam_duration_slug'] = $this->input->post('duration_slug');


                    $data['total_questions'] = $this->input->post('total_questions');


                    $data['coins'] = $this->input->post('coin');


                    $data['marks_per_ques'] = $this->input->post('marks');


                    //$data['negative_mark'] = $this->input->post('negativemarks');


                    //$data['difficulty_level'] = $this->input->post('diff_level');


                    $data['exam_slug'] = $this->slug->create_uri($this->input->post('exam_name'));


                    $data['daily_quiz'] = 1;


                    $data['newsfeedpost'] = $this->input->post('newffedpost');


                    //$data['featured_quiz'] = $this->input->post('featured');


                    //$data['image_url'] = $this->input->post('imgurl');


                    if (empty($exam_id)) {





                        $data['exam_no'] = $exam_no;


                        $data['added_by'] = $this->user->id;


                        $data['added_date'] = date("Y-m-d H:i:s");


                        $exam_id = $this->db_model->insert('tbl_exams', $data);


                        $examcat = $this->input->post('examcat');


                        foreach ($examcat as $examcat) {


                            $data3['quiz_id'] = $exam_id;


                            $data3['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data3);


                        }


                        foreach ($_POST['subcat'] as $examsubcat) {


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);


                        }





                        foreach ($_POST['subsub'] as $examsubsubcat) {


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);


                        }


                        $this->session->set_userdata('exam_id', $exam_id);


                        $new_path = 'uploads/exam_' . $exam_no . '/';


                        if (!is_dir($new_path)) {


                            mkdir($new_path);


                            chmod($new_path, 0755);


                        }





                        


                        $data2['exam_upload_path'] = $new_path;


                        $this->db_model->update('tbl_exams', $data2, 'id_exam', $exam_id);


                        $this->db_model->delete('tbl_quizparentcats', 'quiz_id', $exam_id);








                        $examcat = $this->input->post('examcat');





                        foreach ($examcat as $examcat) {


                            $data14['quiz_id'] = $exam_id;


                            $data14['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data14);


                        }





                        foreach ($_POST['subcat'] as $examsubcat) {


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);


                        }


                        foreach ($_POST['subsub'] as $examsubsubcat) {


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);


                        }


                    } else {


                        


                        $this->db_model->update('tbl_exams', $data, 'id_exam', $exam_id);


                        $this->db_model->delete('tbl_quizparentcats', 'quiz_id', $exam_id);





                        $examcat = $this->input->post('examcat');


                        foreach ($examcat as $examcat) {


                            $data3['quiz_id'] = $exam_id;


                            $data3['parentcat_id'] = $examcat;


                            $this->db_model->insert('tbl_quizparentcats', $data3);


                        }





                        foreach ($_POST['subcat'] as $examsubcat) {


                            $data4['quiz_id'] = $exam_id;


                            $data4['sub_catid'] = $examsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data4);


                        }


                        foreach ($_POST['subsub'] as $examsubsubcat) {


                            $data5['quiz_id'] = $exam_id;


                            $data5['sub_sub_catid'] = $examsubsubcat;


                            $this->db_model->insert('tbl_quizparentcats', $data5);


                        }


                    }


                    $set = array(array('tag' => '.exam_id', 'data' => $exam_id, 'fun' => 1));





                    $return = array('has_error' => 0, 'set' => $set, 'step' => '1', 'nextStep' => 2, 'message' => 'Step 1 completed');


                }


                echo json_encode($return);


            }


        } else {


            redirect(admin_url('dailyquiz'), 'refresh');


        }


    }





    public function insert_textual_step_2() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-textual-step2") {


            $error = array();


            $exam_id = $this->input->post('exam_id');


            $exam_data = $this->exam_model->get_single($exam_id);


            if (count($exam_data) > 0) {


                $this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');


                $this->form_validation->set_rules('question_name', 'question', 'trim|required');


                $this->form_validation->set_rules('answer', 'answer', 'trim|required');


                $temp_path = $exam_data->exam_upload_path . $this->tmp_path;


                if (!is_dir($temp_path)) {


                    mkdir($temp_path);


                    chmod($temp_path, 0755);


                }





                if ($this->form_validation->run() == FALSE || !empty($error)) {


                    $error['question_name'] = form_error('question_name');


                    $error['answer'] = form_error('answer');


                    $return = array('has_error' => 1, 'error' => $error);


                }





                if (empty($error)) {


                    $question_no = $this->exam_model->get_next_qstn_no($exam_id);


                    $data['id_exam'] = $exam_id;


                    $data['id_course'] = $this->input->post('course_id');


                    $data['question_no'] = $question_no;


                    $data['question_name'] = $this->input->post('question_name');


                    


                    $data['answer'] = $this->input->post('answer');


                    //$data['explanation'] = $this->input->post('explanation');


                    $data['added_by'] = $this->user->id;


                    $data['added_date'] = date("Y-m-d H:i:s");


                    $question_id = $this->db_model->insert('tbl_exams_questions', $data);


                    $path = $exam_data->exam_upload_path . 'question_' . $question_no . '/';


                    if (!is_dir($path)) {


                        mkdir($path);


                        chmod($path, 0755);


                    }





                    $data2['question_upload_path'] = $path;


                    $this->db_model->update('tbl_exams_questions', $data2, 'id_question', $question_id);


                    $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Question added successfully', 'function' => 'refreshtextualTable', 'reset' => '1');


                }


                echo json_encode($return);


            }


        } else {


            redirect(admin_url('dailyquiz'), 'refresh');


        }


    }





    public function insert_textual_step_3() {


        if (isset($_POST['action']) && $_POST['action'] == "exam-step3") {


            $course_id = $this->input->post('course_id');








            $data2['status'] = 1;


            $this->db_model->update('tbl_quizparentcats', $data2, 'quiz_id', $this->session->userdata('exam_id'));





            $ecat = $this->exam_model->getquizparentid($this->session->userdata('exam_id'));


            $data['exam_category'] = 0;


            $data['quiz_id'] = $this->session->userdata('exam_id');


            $data['status'] = 4;


            $data['userid'] = $this->user->id;


            $data['created'] = date("Y-m-d H:i:s");


            $newsfeedpost = $this->session->userdata('newsfeefpost');


            $rowexist = $this->exam_model->checkpost($this->session->userdata('exam_id'));


            if ($rowexist == "") {


                $question_id = $this->db_model->insert('tbl_posts', $data);


            }


            $data2['finished_status'] = 1;


            $this->db_model->update('tbl_exams', $data2, 'id_exam', $this->input->post('exam_id'));


            $return = array('has_error' => 0, 'page' => admin_url('dailyquiz'), 'message' => 'Exam details added successfully');


            echo json_encode($return);


        }


    }





    public function get_all_questions_textual() {


        $exam_id = 97;


		
        if ($this->session->userdata('exam_id') != "") {


            $exam_id = $this->session->userdata('exam_id');


        }
		

        echo $this->dailyquiz_model->all_questions($exam_id);


    }





    public function edit_textual($exam_id = 0) {


        if (!has_permission('dailyquiz', 'edit')) {


            redirect(admin_url('login'), 'refresh');


        }


        $data['page'] = 'dailyquiz';


        if (!empty($exam_id)) {


            $data['script'] = 1;


            $data['row'] = $this->exam_model->get_single($exam_id);


            $data['examcats'] = $this->course_model->get_all_categories();


            $data['subcats'] = $this->dailyquiz_model->get_all_subcategoriesbyquiz($data['row']->quizcatid);


            $data['exams'] = $this->course_model->getallmainexams();


            $data['subsub'] = $this->exam_model->get_all_subsub($data['row']->sub_catid);





            $data['course_id'] = $data['row']->id_course;


            $this->session->set_userdata('exam_id', $exam_id);


            if (count($data['row']) > 0) {


                $this->myadmin->view('dailyquiz/edit', $data);


            } else {


                $this->myadmin->view('404', $data);


            }


        } else {


            redirect(admin_url('examdetails'), 'refresh');


        }


    }





    public function hide_textual() {


        if (!has_permission('dailyquiz', 'status')) {


            redirect(admin_url('login'), 'refresh');


        }


        if (isset($_POST['action']) && $_POST['action'] == "hideRow") {


            $error = array();


            $this->form_validation->set_rules('id', 'id', 'trim|required');





            if ($this->form_validation->run() == FALSE) {


                $error['id'] = (form_error('id'));


                $return = array('has_error' => 1, 'error' => $error);


            } else {


                $data['status'] = 0;


                $this->db_model->update('tbl_exams', $data, 'id_exam', $this->input->post('id'));


                $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Exam status updated successfully', 'function' => 'refreshExamTable');


            }


            echo json_encode($return);


        } else {


            redirect(admin_url('exam'), 'refresh');


        }


    }





    public function unhide_textual() {


        if (!has_permission('dailyquiz', 'status')) {


            redirect(admin_url('login'), 'refresh');


        }


        if (isset($_POST['action']) && $_POST['action'] == "unhideRow") {


            $error = array();


            $this->form_validation->set_rules('id', 'id', 'trim|required');





            if ($this->form_validation->run() == FALSE) {


                $error['id'] = (form_error('id'));


                $return = array('has_error' => 1, 'error' => $error);


            } else {


                $data['status'] = 1;


                $this->db_model->update('tbl_exams', $data, 'id_exam', $this->input->post('id'));


                $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Exam status updated successfully', 'function' => 'refreshExamTable');


            }


            echo json_encode($return);


        } else {


            redirect(admin_url('exam'), 'refresh');


        }


    }





    public function delete_textual() {


        if (!has_permission('dailyquiz', 'delete')) {


            redirect(admin_url('login'), 'refresh');


        }


        if (isset($_POST['action']) && $_POST['action'] == "deleteRow") {


            $error = array();


            $this->form_validation->set_rules('id', 'id', 'trim|required');





            if ($this->form_validation->run() == FALSE) {


                $error['id'] = (form_error('id'));


                $return = array('has_error' => 1, 'error' => $error);


            } else {


                $row = $this->exam_model->get_single($this->input->post('id'));


                if (!empty($row)) {


                    if (is_dir($row->exam_upload_path)) {


                        deleteDirectory($row->exam_upload_path);


                    }


                }


                $this->db_model->delete('tbl_exams', 'id_exam', $this->input->post('id'));


                $this->db_model->delete('tbl_exams_questions', 'id_exam', $this->input->post('id'));


                $return = array('has_error' => 0, 'refresh' => '1', 'message' => 'Exam deleted successfully', 'function' => 'refreshExamTable');


            }


            echo json_encode($return);


        } else {


            redirect(admin_url('exam'), 'refresh');


        }


    }





    public function details_textual($exam_id = 0) {





        $data['page'] = 'exam';


        if (!empty($exam_id)) {


            $data['script'] = 1;


            $data['row'] = $this->exam_model->get_single($exam_id);


            $data['cats'] = $this->exam_model->quizcatdetails($exam_id);


            $data['subcats'] = $this->exam_model->quizsubcatdetails($exam_id);


            $data['subsubcats'] = $this->exam_model->quizsubsubcatdetails($exam_id);


            $this->session->set_userdata('exam_id', $exam_id);


            if (count($data['row']) > 0) {


                $data['course_id'] = $data['row']->id_course;


                $this->myadmin->view('dailyquiz/details', $data);


            } else {


                $this->myadmin->view('404', $data);


            }


        } else {


            redirect(admin_url('courses'), 'refresh');


        }


    }


}


