<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Articles extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->library(array('datatables', 'form_validation', 'image_lib', 'upload','permissions'));
			$this->load->model(array('course_model', 'db_model','article_model'));
			$this->user 	= $this->session->userdata($this->session_name);
			$this->path    	= 'uploads/';
			$this->tmp_path = 'tmp/';
			if(!file_exists($this->path)) {
				mkdir($this->path);
				chmod($this->path, 0755);
			}	
			$config = array('field' => 'course_slug',
							'title' => 'category_title',
							'table' => 'tbl_courses',
							'id'    => 'id_course');
			$this->load->library('slug', $config);
		}	
	}

	public function index(){
	        $data['page']  	= 'artcles';
		
			
    		//$data['row']  			= $this->article_model->get_single();
	     	$data['quizcount'] = $this->db->query( "SELECT count(*) as quizcount FROM `tbl_exams`" )->row()->quizcount;
	     	$data['postcount'] = $this->db->query( "SELECT count(*) as postcount FROM `tbl_articelepost`" )->row()->postcount;
	     	$data['examcount'] = $this->db->query( "SELECT count(*) as examcount FROM `tbl_examdetails`" )->row()->examcount;
	     	$data['syllabuscount'] = $this->db->query( "SELECT count(*) as syllabuscount FROM `tbl_exams`" )->row()->syllabuscount;
	     	$data['notescount'] = $this->db->query( "SELECT count(*) as notescount FROM `tbl_notes`" )->row()->notescount;
	     	$data['studycount'] = $this->db->query( "SELECT count(*) as studycount FROM `tbl_studyplan`" )->row()->studycount;
	     	$data['downloadcount'] = $this->db->query( "SELECT count(*) as downloadcount FROM `tbl_download`" )->row()->downloadcount;

    		$this->myadmin->view('articles/details', $data);
		
	}

	public function get_all_datas(){
		echo $this->course_model->all_datas();
	}

	
}