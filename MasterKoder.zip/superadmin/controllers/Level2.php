<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Level2 extends MX_Controller{
	function __construct(){
		parent :: __construct();
		$this->session_name  = admin_session_name();
		if(!$this->session->userdata($this->session_name)){
			redirect(admin_url('login'), 'refresh');
			exit();
		}else{
			$this->load->helper('form');
			$this->load->library(array('datatables', 'form_validation'));
			$this->load->model(array('user_model', 'db_model','GeneralModel','menus_model','dailyquiz_model'));
			$this->user = $this->session->userdata($this->session_name);
		}

	}

	public function index(){
		$data['page']  		= 'mentor';
		$data['page1']  		= 'level2';
		$data['script']  	= 1;
	    $this->myadmin->view('level2/home', $data);
	}
	
	public function get_all_level2(){
		echo $this->menus_model->all_mlevel2();
	}

	public function add(){
		$data['page']  = 'mentor';
		$data['tbl_mlevel1']=$this->GeneralModel->GetInfoRow($table = 'tbl_mlevel1', $key = '');
		$data['page1']  		= 'level2';
		$data['script']  	= 1;
		
        $data['articles'] = $this->dailyquiz_model->get_all_articles();
		$data['tbl_categories']=$this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');

	    $this->myadmin->view('level2/add', $data);
	}
	
	public function addsub(){
		if(isset($_POST['action']) && $_POST['action'] == "insert"){
			$error = array();
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('l1_id', 'Parent', 'trim|required');
			//$this->form_validation->set_rules('url', 'Url', 'trim|required');
			$this->form_validation->set_rules('order', 'Order', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
			 
				$error['title'] 			= form_error('title');
				$error['l1_id'] 			= form_error('l1_id');
				//$error['url'] 	= form_error('url');
				$error['order'] 	= form_error('order');
				$error['order'] 	= form_error('order');
				$error['status'] 	= form_error('status');

				$return  				= array('has_error'=>1, 'error' => $error);
			}
			else{
			   
				$idata['title'] = $this->input->post('title');
				$idata['l1_id'] = $this->input->post('l1_id');
				$idata['url'] = $this->input->post('url');
				$idata['order'] = $this->input->post('order');
				$idata['status'] = $this->input->post('status');
				$idata['fpost1'] = $this->input->post('fpost1');
				$idata['fpost2'] = $this->input->post('fpost2');
				$idata['fpost3'] = $this->input->post('fpost3');
				$idata['fpost4'] = $this->input->post('fpost4');
				$idata['datec'] = date('Y-m-d H:i:s');
				
				$this->GeneralModel->AddNewRow( "tbl_mlevel2", $idata );
				
				$this->db->query('UPDATE tbl_mlevel1 SET l2count = l2count + 1 WHERE id = "' . $idata['l1_id'] . '"');
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('level2'), 'message' => 'Level 2 Menu inserted successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('menus/add1'), 'refresh');
		}
	}
	
	public function view(){
		if(isset($_POST['action']) && $_POST['action'] == "viewRow"){
		$row	= $this->menus_model->get_single_lev1($this->input->post('id'));
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{

				$set 	= array(array('tag' => '#infoModal .modal-title',  'data' => 'View Level 2', 'fun' => 3),
								array('tag' => '#infoModal .modal-body',  'data' => $this->get_data2($this->input->post('id')), 'fun' => 0));
				$return = array('has_error'=>0, 'popup'=>'1', 'model'=>'#infoModal', 'set' => $set);
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('level2'), 'refresh');
		}		
	}	

	private function get_data($id = 0){
    	if(!empty($id)){
    		$row  	= $this->menus_model->get_single_lev1($id);
			
			$data = "";
		
			$data .= '<div class="card">
						<table class="table">
						<tr><td><b>Title</b></td><td>'.$row->title.'</td></tr>
						<tr><td><b>Url</b></td><td>'.$row->url.'</td></tr>
						<tr><td><b>Order</b></td><td>'.$row->order.'</td></tr>
						<tr><td><b>Level 2 child</b></td><td>'.$row->l2count.'</td></tr>
						<tr><td><b>Level 3 child</b></td><td>'.$row->l3count.'</td></tr>
						<tr><td><b>Status</b></td><td>'.$row->status.'</td></tr>
						<tr><td><b>Date</b></td><td>'. date('d M Y', strtotime( $row->datec ) ).'</td></tr>
						</table>
					</div>';
						
			return $data;
		    
    	}
		
	}
	
	private function get_data2($id = 0){
    	if(!empty($id)){
    		$row  	= $this->menus_model->get_single_lev2($id);
			
			$data = "";
		
			$data .= '<div class="card">
						<table class="table">
						<tr><td><b>Title</b></td><td>'.$row->title.'</td></tr>
						<tr><td><b>Url</b></td><td>'.$row->url.'</td></tr>
						<tr><td><b>Order</b></td><td>'.$row->order.'</td></tr>
						<tr><td><b>Parent Level 1</b></td><td>'.$row->lev1tit.'</td></tr>
						<tr><td><b>Level 3 child</b></td><td>'.$row->l3count.'</td></tr>
						<tr><td><b>Status</b></td><td>'.$row->status.'</td></tr>
						<tr><td><b>Date</b></td><td>'. date('d M Y', strtotime( $row->datec ) ).'</td></tr>
						</table>
					</div>';
						
			return $data;
		    
    	}
		
	}
	
	public function edit($id = 0){
		
		if (!has_permission('level2', 'edit')) {
			 redirect(admin_url('login'), 'refresh');
		}
		
		if($id>0){
			$data['page']  		= 'mentor';
			$data['roles']  	= $this->user_model->get_all_roles();
			$data['row']  		= $this->menus_model->get_single_lev2($id);
			$data['tbl_mlevel1']=$this->GeneralModel->GetInfoRow($table = 'tbl_mlevel1', $key = '');
			
			$data['page1']  		= 'level2';
			$data['script']  	= 1;
			
			$data['articles'] = $this->dailyquiz_model->get_all_articles();
			
			$data['tbl_categories'] = $this->GeneralModel->GetSelectedRows($table = 'tbl_categories', $limit = '', $start = '', $columns = '', $orderby ='category_name', $key = '', $search = '');
			
			$tbl_mlevel1 = $this->GeneralModel->GetInfoRow('tbl_mlevel1', array( 'id' => @$data['row']->l1_id ) );

			$data['row']->catid = @$tbl_mlevel1[0]->catid;

			$this->myadmin->view('level2/edit', $data);
		}
		else{
			redirect(admin_url('level2'), 'refresh');
		}
	}
	
	public function update(){
		if(isset($_POST['action']) && $_POST['action'] == "update"){
			$error 	= array();
			$row	= $this->menus_model->get_single_lev2($this->input->post('id'));
			$this->form_validation->set_error_delimiters('<label class="control-label error">', '</label>');

			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('l1_id', 'Parent', 'trim|required');
			//$this->form_validation->set_rules('url', 'Url', 'trim|required');
			$this->form_validation->set_rules('order', 'Order', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				
				$error['title'] 			= form_error('title');
				$error['l1_id'] 			= form_error('l1_id');
				//$error['url'] 	= form_error('url');
				$error['order'] 	= form_error('order');
				$error['order'] 	= form_error('order');
				$error['status'] 	= form_error('status');
				$return  			= array('has_error'=>1, 'error' => $error);
			}
			else{
				$idata['title'] = $this->input->post('title');
				$idata['l1_id'] = $this->input->post('l1_id');
				$idata['url'] = $this->input->post('url');
				$idata['order'] = $this->input->post('order');
				$idata['status'] = $this->input->post('status');
				$idata['fpost1'] = $this->input->post('fpost1');
				$idata['fpost2'] = $this->input->post('fpost2');
				$idata['fpost3'] = $this->input->post('fpost3');
				$idata['fpost4'] = $this->input->post('fpost4');
				
				$this->GeneralModel->UpdateRow( "tbl_mlevel2", $idata, array( 'id' => $this->input->post('id') ) );
				
				$return  	= array('has_error'=>0, 'page'=> admin_url('level2/edit/' .  $this->input->post('id') ), 'message' => 'Level 2 updated successfully');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('level2'), 'refresh');
		}
	}
	
	public function hide(){
		if(isset($_POST['action']) && $_POST['action'] == "hideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 0;
				$this->db_model->update('tbl_mlevel2', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Level 2 status updated successfully', 'function'=> 'refreshlevel2Table');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('level2'), 'refresh');
		}		
	}
	
	public function unhide(){
		if(isset($_POST['action']) && $_POST['action'] == "unhideRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				$data['status'] 	= 1;
				$this->db_model->update('tbl_mlevel2', $data, 'id', $this->input->post('id'));				
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Level 2 status updated successfully', 'function'=> 'refreshlevel2Table');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('menus/level2'), 'refresh');
		}		
	}
	
	public function delete(){
			
		if(isset($_POST['action']) && $_POST['action'] == "deleteRow"){
			$error = array();
			$this->form_validation->set_rules('id', 'id', 'trim|required');

			if ($this->form_validation->run() == FALSE) {
				$error['id'] 	= (form_error('id'));
				$return  		= array('has_error'=>1, 'error' => $error);
			}
			else{
				
				$tbl_mlevel2 = $this->GeneralModel->GetInfoRow( 'tbl_mlevel2', array( 'id' => $this->input->post('id') ) );
				
				$this->db_model->delete('tbl_mlevel2', 'id', $this->input->post('id'));
				
				$this->db->query('UPDATE tbl_mlevel1 SET l2count = l2count - 1 WHERE id = "' . @$tbl_mlevel2[0]->l1_id . '"');
								
				$return = array('has_error'=>0, 'refresh'=>'1', 'message' => 'Level 2 deleted successfully', 'function'=> 'refreshlevel2Table');
			}	
			echo json_encode($return);
		}
		else{
			redirect(admin_url('menus/level2'), 'refresh');
		}		
	}
	
	public function get_l2ord(){
		
		$l1_id = $this->input->post('l1_id');
		$cl1_id = $this->input->post('cl1_id');
		$corder = $this->input->post('corder');
		
		$tbl_mlevel2 = $this->GeneralModel->GetInfoRow('tbl_mlevel2', array( 'l1_id' => $l1_id ));

		$l2ord = array();
		
		if( !empty( $tbl_mlevel2 ) )
		{
			foreach( $tbl_mlevel2 as $key => $value )
			{
				$l2ord[] = $value->order;							
			}	
		}
		
	  	$opt = array( "" => "Select" );
		$sel = '';
		
		for( $i  = 1; $i < 31 ; $i++ )
		{
			if( ! in_array( $i, $l2ord ) || ( $cl1_id == $l1_id && $i == $corder ) )
			$opt[ $i ] = $i ;
		
			if( $cl1_id == $l1_id && $i == $corder )
				$sel = $corder;
		}
		
		echo form_dropdown( 'order', $opt, $sel, 'id="order" class="form-control"' );
		exit;
		
	}
	
	public function get_l1(){
		$catid = $this->input->post('catid');
		$l1_id = $this->input->post('l1_id');
		
		$tbl_mlevel1 = $this->GeneralModel->GetInfoRow('tbl_mlevel1', array( 'catid' => $catid ));

		$opt = array('' => 'Select');
		$sel = ( !empty( $l1_id ) ) ? $l1_id : '' ;
		if( !empty( $tbl_mlevel1 ) )
		{
	
			foreach( $tbl_mlevel1 as $key => $value )
			{
				$opt[ $value->id ] = $value->title;							
			}
			
		}
		
		echo form_dropdown('l1_id', $opt, $sel, 'id="l1_id" class="form-control"');
		exit;
	}
	
}

?>