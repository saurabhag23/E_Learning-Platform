<?php
	class Capability {
		var $ci;
		var $except;
		public function __construct(){
			global $CI;
			$this->ci = $CI;
			$this->except = array('login', 'support');
		}
		
		function index(){
			$class 	= $this->ci->router->fetch_class();
			$method = $this->ci->router->fetch_method();
			if(!in_array($class, $this->except)){
				redirect(admin_url('login'), 'refresh');
				exit();
			}
		}
	}
?>