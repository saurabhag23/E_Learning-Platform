<?php
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Myadmin
	{
		public $data, $ses;
		private $ci, $cap, $fb;
	
		public function __construct(){
			$this->ci =& get_instance();
			$this->ci->load->helper('url');
			$this->ci->load->library('session');
			$this->ci->load->database();
			$this->session_name  = admin_session_name();
			$this->user 		 = $this->ci->session->userdata($this->session_name);
			$this->data['menus'] = array();	
			$this->init();
		}
	
		public function view($page, $data = array()){
			$data['site']  			= (object)$this->data['site'];
			$data['menus'] 			= $this->data['menus'];
			$data['logged_user'] 	= $this->user;
			$this->ci->load->view('layout/header', $data);
			$this->ci->load->view($page, $data);
			$this->ci->load->view('layout/footer', $data);
		}

		private function init(){
			$query 		= $this->ci->db->get('tbl_settings');
			$settings 	= $query->result();
			foreach($settings as $setting){
				$this->data['site'][$setting->option_title] = $setting->option_value;		
			}
			//if($this->ci->session->userdata('admin_user')){
				$this->admin_menus();	
			//}		
		}
		
		private function admin_menus(){
			$this->data['menus']   = array(array('name' 	=> 'Dashboard', 
												 'url'  	=> 'dashboard', 
												 'page' 	=> 'dashboard', 
												 'icon'		=> 'fa-dashboard', 
												 'has_sub' 	=> 0),
										   array('name' 	=> 'Article Management', 
												 'url'  	=> 'articles', 
												 'page' 	=> 'articles', 
												 'icon'		=> 'fa-file', 
												 'has_sub' 	=> 0),
										
										   array('name' 		=>'Categories', 
												 'url'  	=> 'categories', 
												 'page' 	=> 'categories', 
												 'icon'		=> 'fa-list', 
												 'has_sub' 	=> 0),
										  array('name' 	=> 'Newsfeed Top post', 
												 'url'  	=> 'newsfeed', 
												 'page' 	=> 'newsfeed', 
												 'icon'		=> 'fa fa-bell',
												 'has_sub' 	=> 0),
										   array('name' 	=> 'Reports', 
												 'url'  	=> 'reports', 
												 'page' 	=> 'reports', 
												 'icon'		=> 'fa-file-text-o', 
												 
												 'has_sub' 	=> 0),
										   array('name' 	=> 'Advertizement', 
												 'url'  	=> 'advertizement', 
												 'page' 	=> 'advertizement', 
												 'icon'		=> 'fab fa-adn',
												 'has_sub' 	=> 0),

									   	   array('name' 	=> 'Users', 
												 'url'  	=> 'users', 
												 'page' 	=> 'users', 
												 'icon'		=> 'fa-users', 
												 'permission'	=> 'Usermanagement', 
												 'has_sub' 	=> 1, 
												 'submenus' => array(array('name' 	=> 'All Users', 
																     	   'url'    => 'users', 
																     	   'page'   => 'users', 
																     	   'icon' 	=> 'fa-user',
																		 
																     	   'has_sub'=> 0),
																	 array('name' 	=> 'Roles', 
																     	   'url'    => 'roles', 
																     	   'page'   => 'roles', 
																		  
																     	   'icon' 	=> 'fa-lock', 
																     	   'has_sub'=> 0))),
										       array('name' 	=> 'Default Images', 
													 'url'  	=> 'defaultimages', 
													 'page' 	=> 'defaultimages', 
													
													 'icon'		=> 'fa-picture-o', 
													 'has_sub' 	=> 0),
										   	   array('name' 	=> 'Membership Plans', 
													 'url'  	=> 'membership_plans', 
													 'page' 	=> 'membership_plans', 
													 'icon'		=> 'fa-money', 
													 'has_sub' 	=> 0),
													 
											
												
												);

			
			
		}
	}