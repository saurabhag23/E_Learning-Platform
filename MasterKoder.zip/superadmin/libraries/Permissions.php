<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Permissions {
	private $modules=array(), $permissions_html='', $modules_html='', $ci, $table='tbl_permissions', $ajaxurl='', $token = '';

	public function __construct($table){
		$this->ci =& get_instance();
		$this->ci->load->dbforge();
	    $this->table  = 'tbl_permissions';
		
	}
	
	public function init($config){
		if(!empty($config['table_name'])){
			$this->table   = $config['table_name'];
		}
		if(!empty($config['ajax_url'])){
			$this->ajaxurl = $config['ajax_url'];
		}
		if(!empty($config['csrf_token'])){
			$this->token = $config['csrf_token'];
		}
		$this->create_table();
		$this->default_modules();
	}

	public function set_modules($modules = array()){
		if(count($modules) > 0){
			foreach($modules as $module => $permissions){
				$this->modules[$module] = $permissions;
			}
		}
	}

	public function unset_modules($modules = array()){
		if(count($modules) > 0){
			foreach($modules as $module){
				unset($this->modules[$module]);
			}
		}
	}

	public function generate($group_id){
		if(count($this->modules) > 0){
			$this->modules_html .= '<ul class="nav nav-pills brand-pills nav-stacked" role="tablist">';
			$index = 0;
			foreach($this->modules as $module => $permissions){
				$this->modules_html .= '<li role="presentation" class="brand-nav '.($index == 0? "active" : "").'">
                      					<a href="#tab'.($index+1).'" aria-controls="tab'.($index+1).'" role="tab" data-toggle="tab">'.ucfirst($module).'</a>
                    	  			   </li>';
            	$this->generate_permissions($permissions, $group_id, $index);
            	$index++;
			}
			$this->modules_html .= '</ul><script>function changePermission(e,a,i){var n=e.data("module"),t=e.data("mode"),c=e.data("group");if(e.is(":checked"))var o=1;else o=0;$.ajax({url:a,type:"POST",data:{module:n,mode:t,group:c,value:o,token:i}})}function changeAllPermissions(e){e.is(":checked")?$(".tab-pane.active").find("input.set-permission").prop("checked",!0).trigger("onchange"):$(".tab-pane.active").find("input.set-permission").prop("checked",!1).trigger("onchange")}</script>';
		}
		$html = '<div class="row">
                	<div class="col-sm-3">'.$this->modules_html.'</div>
                	<div class="col-sm-9">
                    	<div class="tab-content ">'.$this->permissions_html.'</div>
                	</div>
              	</div>';
        return $html;
	}

	private function generate_permissions($modules, $group_id, $index){
		if(count($modules) > 0){
			$this->permissions_html .= '<div role="tabpanel" class="tab-pane fade in '.($index == 0? "active" : "").' gibbss" id="tab'.($index+1).'"><div class="edibox permission-box">';

			foreach($modules as $module => $permissions){
				$this->permissions_html .= '<div class="row"><div class="col-lg-12"><h4>'.ucfirst(str_replace('_', ' ', $module)).' Permissions</h4></div></div><div class="row">';
				foreach($permissions as $pindex => $permission){
					$query		 	= $this->ci->db->select("*")->where('module', strtolower($module))->where('group_id', $group_id)->get($this->table);
					$cpermissions 	= $query->row_array();
					$checked     	= (isset($cpermissions[$permission]) && $cpermissions[$permission] == 1)? "checked" : "";

					$this->permissions_html .= '<div class="col-lg-3">
                            <label class="input-group">
                              <span class="input-group-addon">
                                <input type="checkbox" data-mode="'.$permission.'" data-module="'.strtolower($module).'" data-group="'.$group_id.'" class="set-permission" '.$checked.' onchange="changePermission($(this), '."'".$this->ajaxurl."'".', '."'".$this->token."'".' )">
                              </span>
                              <div class="form-control">'.ucfirst(str_replace('_', ' ', $permission)).'</div>
                            </label>
                          </div>';
                    if(($pindex+1)%4 == 0){
                		$this->permissions_html .= '<div class="clearfix"></div>';
                	}
				}
				$this->permissions_html .= '</div>';
			}

			$this->permissions_html .= '</div></div>';
		}
	}

	public function set_permission(){
		$group  = $this->ci->input->post('group');
		$module = $this->ci->input->post('module');
		$mode   = $this->ci->input->post('mode');
		$value  = $this->ci->input->post('value');

		#create new permission field in table if not exsist
    	if(!$this->ci->db->field_exists($mode, $this->table)){
	    	$fields = array($mode => array('type' => 'INT', 'default'=>'0'));
			$this->ci->dbforge->add_column($this->table, $fields);
    	}

    	$this->ci->db->select("id")->from($this->table)->where('module', $module)->where('group_id', $group);
		$res = $this->ci->db->get();
		if($res->num_rows() > 0){
			$r  		 = $res->row();
    		$data[$mode] = $value;
    		$this->ci->db->where('id', $r->id);
			$this->ci->db->update($this->table, $data); 
		}
		else{
			$data['group_id'] 	= $group;
			$data['module'] 	= $module;
    		$data[$mode] 		= $value;
			$this->ci->db->insert($this->table, $data); 
		}
	}

	public function has_permission($group, $page, $mode){
		$this->ci->db->where("group_id", $group);
		$res = $this->ci->db->get($this->table);
		
		if($res->num_rows() > 0){
			$results = $res->result();
			if(count($results) > 0){
				foreach($results as $result){
					$module = str_replace("_", " ", $result->module);
					unset($result->module);
					unset($result->group_id);
					unset($result->id);
					foreach($result as $i => $r){
						$permission[$module][$i] = $r;
					}
				}
			}
		}

		if(isset($permission[$page][$mode])){
			if($permission[$page][$mode] == 1){
				return TRUE;
				
			}
		}

		return FALSE;
	}

	private function default_modules(){
		
		
		
													
	$this->modules['Dashboard'] 	   = array("dashboard"  =>array('dashboard_view') );
	                                                 
													
	$this->modules['Category Management'] 	   = array("categories"  =>array('dashboard_view'),
	                                                   "categories" 		  =>array('view', 'add', 'edit', 'delete', 'status','dashboard_view'),	
													   "subcategory" 		  =>array('view', 'add', 'edit', 'delete', 'status','dashboard_view'),
													   "subsubcategory" 	  =>array('view', 'add', 'edit', 'delete', 'status','dashboard_view'));
	$this->modules['Article Management'] 	   = array("articles"  =>array('dashboard_view'),
	                                                   "dailyquiz" 		=>array('view', 'add', 'edit', 'delete', 'status','dashboard_view'),	
													   "Posts" 		  =>array('view', 'add', 'edit', 'delete', 'status', 'dashboard_view'),
													   "Syllabus" 	  =>array('view', 'add', 'edit', 'delete', 'status', 'dashboard_view'),
													   "Studyplan" 	  =>array('view', 'add', 'edit', 'delete', 'status', 'dashboard_view'),
													   "Notes" 	  =>array('view', 'add', 'edit', 'delete', 'status', 'dashboard_view'),
													   "Examdetails" 	  =>array('view', 'add', 'edit', 'delete', 'status', 'dashboard_view'));
	$this->modules['User Management'] 	       = array("users"  =>array('dashboard_view'),
	                                                    "users" 	  =>array('view','delete','edit','status', 'dashboard_view'),
													    "mentor" 	  =>array('view', 'add', 'edit', 'delete', 'status', 'dashboard_view'),
														"admin" 	  =>array('view', 'add', 'edit', 'delete', 'status', 'dashboard_view'),
														"roles" 	  =>array('view', 'add', 'edit', 'delete', 'status', 'dashboard_view','permission'));
  $this->modules['Newsfeed TopPost Management'] = array("newsfeed" 		  =>array('view', 'add', 'edit', 'delete', 'status','dashboard_view')  );	
  $this->modules['Reports']                     = array("Reports" 	=>array('view','delete','dashboard_view')  );
  $this->modules['Advertizement Management']    = array("Advertizement" 		  =>array('view', 'add', 'edit', 'delete', 'status','dashboard_view')  );
  $this->modules['Default Image Management']    = array("defaultimages" 		  =>array('dashboard_view','update')  );
													
   /*$this->modules['Article Management'] 	   = array("Article_managment"  =>array('dashboard_view'),
	                                                   "Categories" 		  =>array('view', 'add', 'edit', 'delete', 'status', 'details','dashboard_view'),	
													   "Sub_categories" 		  =>array('view', 'add', 'edit', 'delete', 'status', 'details','dashboard_view'),
													   "Sub_Sub_Categories" 	  =>array('view', 'add', 'edit', 'delete', 'status', 'details','dashboard_view'));	*/	
			
				
									    			
									    		
	}

	private function create_table(){
		if(!$this->ci->db->table_exists($this->table)){
		   	$fields = array(
		        'id' => array('type' => 'INT','constraint' => '11','auto_increment' => TRUE),
		        'group_id' => array('type' => 'INT', 'constraint' => '11'),
		        'module' => array('type' =>'VARCHAR', 'constraint' => '50'));
		   	$this->ci->dbforge->add_field($fields);
		   	$this->ci->dbforge->add_key('id', TRUE);
		   	$this->ci->dbforge->create_table($this->table);
		}
	}
}