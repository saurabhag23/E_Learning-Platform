<?php 
	class Notificationmodel extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
	    function all_datas(){
	    	    $this->datatables->select("id, title, description,status,created_date,created_by,id as action")
				->from('tbl_notifications')
				->edit_column('action','$1','action_buttons(action,"notifications", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single($id){
			$this->db->where("id", $id);
			$res = $this->db->get('tbl_notifications');
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
	}