<?php 
	class Subsubcategory_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("SS.title,SS.description, DATE_FORMAT(SS.added_date, '%M %d, %Y %h:%i %p') as added_date, SS.id as action,SS.status as status,
			                         S.title as subtitle, C.category_name, SS.id, SS.postcount, CONCAT( 'https://www.thegreatmentor.com/account?scat=' , SS.id ) as url_link")
				->from('tbl_subsubcategory SS')
				->join('tbl_subcategories S', 'S.id = SS.id_subcategory', 'LEFT')
				->join('tbl_categories C', 'C.id = SS.id_category', 'LEFT')							
				->edit_column('action','$1','action_buttons(action, "subsubcategory", 1, 1, 1, status)');

				// $this->db->order_by('SS.id ','desc');

			return $this->datatables->generate();	
	    }

	    function get_single($id){
	    	$this->db->select('SS.*,S.title as subtitle,C.category_name');
	    	$this->db->from('tbl_subsubcategory SS');
			$this->db->join('tbl_subcategories S', 'S.id = SS.id_subcategory', 'LEFT');
			$this->db->join('tbl_categories C', 'C.id = SS.id_category', 'LEFT');
			$this->db->where("SS.id", $id);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function quizcount($id)
		{
		    $this->db->select('COUNT(*)AS cacount');
			$this->db->where("id_subcategory", $id);
			$res = $this->db->get('tbl_current_affairs');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}

	     function get_all_categories(){
			$this->db->where("category_status", 1);
			$res = $this->db->get('tbl_categories');
			if($res->num_rows() > 0){
				return $res->result();
			}
	    }
		function getcurrent_affairtypes()
		{
		    $this->db->select("*");
			$res = $this->db->get('tbl_mastercurrentaffairs');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function get_all_subcatscategoriesbyid($catid)
		{
			$this->db->select("*");
			$this->db->where("id_category", $catid);
			$res = $this->db->get('tbl_courses');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function getsubcatscategoriesbyid()
		{
			$this->db->select("*");
			
			$res = $this->db->get('tbl_courses');
			// $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function get_all_subcategories()
		{
			$this->db->select("*");
			$res = $this->db->get('tbl_subcategories');
			//$this->db->where("c.status", 1);
			// $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
	}