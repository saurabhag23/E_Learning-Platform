<?php 
	class Article_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("C.id_course, C.course_title, DATE_FORMAT(C.added_date, '%M %d, %Y %h:%i %p') as added_date, C.id_course as action, C.course_status as status, R.category_name")
				->from('tbl_courses C')
				->join('tbl_categories R', 'R.id = C.id_category', 'LEFT')
				->edit_column('action','$1','action_buttons(action, "subcategory", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single($id){
	    	$this->db->select('C.*, R.category_name, U.user_fname,(SELECT COUNT(id_exam) FROM tbl_exams WHERE id_course = C.id_course) 
			                  as exam_count');
	    	$this->db->from('tbl_courses C');
			$this->db->join('tbl_categories R', 'R.id = C.id_category', 'LEFT');
			$this->db->join('tbl_users U', 'U.id = C.added_by', 'LEFT');
			$this->db->where("C.id_course", $id);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function quizcount($id)
		{
		    $this->db->select('COUNT(*)AS cacount');
			$this->db->where("id_subcategory", $id);
			$res = $this->db->get('tbl_current_affairs');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		
	
	     function get_all_categories(){
			$this->db->where("category_status", 1);
			$res = $this->db->get('tbl_categories');
			if($res->num_rows() > 0){
				return $res->result();
			}
	    }
		function getcurrent_affairtypes()
		{
		   $this->db->select("*");
			$res = $this->db->get('tbl_mastercurrentaffairs');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
	}