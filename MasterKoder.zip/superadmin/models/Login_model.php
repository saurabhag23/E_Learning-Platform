<?php 
	class Login_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		public function get($email = '', $password = ''){
			$this->db->select('U.*, U.id as uid');
			$this->db->from('tbl_users U');			
			$this->db->where('U.user_email', $email);
			$this->db->where('U.user_pass', $password);
			// $this->db->where('U.id_role',1);
			$this->db->where('U.id_role in (1,2)');
			$qry = $this->db->get();
			if($qry->num_rows() > 0){
				return $qry->row();
			}	  
		}
	}