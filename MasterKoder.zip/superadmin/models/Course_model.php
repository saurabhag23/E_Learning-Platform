<?php 
	class Course_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("C.category_name, S.title, DATE_FORMAT(S.added_date, '%M %d, %Y %h:%i %p') as added_date,S.id as action, S.status as status, S.ssccount, S.postcount, S.id")
				->from('tbl_subcategories S')
				->join('tbl_categories C', 'C.id = S.id_category', 'LEFT')
				->edit_column('action','$1','action_buttons(action, "subcategory", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single($id){
	    	$this->db->select('S.*,U.user_fname,(SELECT COUNT(id_exam) FROM tbl_exams WHERE id_course = S.id) 
			                  as exam_count');
	    	$this->db->from('tbl_subcategories S');
		
			$this->db->join('tbl_users U', 'U.id = S.added_by', 'LEFT');
			$this->db->where("S.id", $id);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function quizcount($id)
		{
		    $this->db->select('COUNT(*)AS cacount');
			$this->db->where("id_subcategory", $id);
			$res = $this->db->get('tbl_current_affairs');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}

	     function get_all_categories(){
			$this->db->where("category_status", 1);
			$res = $this->db->get('tbl_categories');
			if($res->num_rows() > 0){
				return $res->result();
			}
	    }
		function getcurrent_affairtypes()
		{
		    $this->db->select("*");
			$res = $this->db->get('tbl_mastercurrentaffairs');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function get_all_subcatscategoriesbyid($catid)
		{
			$this->db->select("S.id,CONCAT(S.title,' -- ', C.category_name ) AS  title");
			$this->db->join('tbl_categories C','C.id = S.id_category','LEFT');
			$this->db->from("tbl_subcategories S");
			$this->db->where_in("id_category",$catid);
		
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function getsubcatsbyid($catid)
		{
			$this->db->select("*");
			$this->db->where("id_category", $catid);
			$res = $this->db->get('tbl_subcategories');
			// $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function get_all_examsid($id)
		{
		    $this->db->select("*");
			$this->db->where("id_subcategory", $id);
			$this->db->where("exam_status", 1);
			$res = $this->db->get('tbl_mainexam');
			
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function getallmainexams()
		{
			 $this->db->select("*");
			
			$this->db->where("exam_status", 1);
			$res = $this->db->get('tbl_mainexam');
			
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		
		function getsubsubcat()
		{
			$this->db->select("*");
			
			$res = $this->db->get('tbl_subsubcategory');
			
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		
	}