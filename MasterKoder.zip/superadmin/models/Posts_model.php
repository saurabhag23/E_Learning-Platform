<?php 
  class Posts_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){

	    	$this->datatables->select("T.id, T.id_subcategory,T.topic_title, DATE_FORMAT(T.added_date, '%M %d, %Y %h:%i %p') as added_date, 
				   T.id as action, T.topic_status as status,GROUP_CONCAT(C1.category_name SEPARATOR ',') as category_name,
				   CONCAT(U.user_fname,  ' ',U.user_lname) AS  username, concat( C.category_name, IF( T.catcnt> 0, '+', '') , IF( T.catcnt> 0, T.catcnt, '') ) as scat, concat( SC.title, IF( T.coursecnt> 0, '+', ''), IF( T.coursecnt> 0, T.coursecnt, '') ) as cat, concat( SSC.title, IF( T.subsubcatcnt> 0, '+', ''), IF( T.subsubcatcnt> 0, T.subsubcatcnt, '') ) as subcat, T.viewcount")
				->from('tbl_articelepost T')
				->join('article_parentcats A','A.article_id = T.id','LEFT')
				->join('tbl_categories C1','C1.id = A.parentcat_id','LEFT')
				->join('tbl_users U','U.id = T.added_by','LEFT')
				->join('tbl_categories C','C.id = T.id_parent','LEFT')
				->join('tbl_subcategories SC','SC.id = T.id_subcategory','LEFT')
				->join('tbl_subsubcategory SSC','SSC.id = T.id_subsub','LEFT')
				->group_by('T.id')
				->replace_column('category_name', 'C.category_name')
				->replace_column('added_date', 'T.added_date')
				->edit_column('action','$1','action_buttons(action, "posts", 1, 1, 1, status)');
				
				//$this->db->order_by("T.id","desc");
				$this->db->order_by( $_POST['columns'][ $_POST['order'][0]['column'] ]['data'], $_POST['order'][0]['dir']);
			return $this->datatables->generate();	

	    }

	    function get_single(){
	    	$this->db->select("T.*, C.course_title");
	    	$this->db->from("tbl_articelepost T");
	    	$this->db->join("tbl_courses C", "C.id_course = T.id_subcategory", "Left");
			
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function get_all_subcategoriesbypost($catid)
		{
			$this->db->select("S.id,CONCAT(S.title,' -- ', C.category_name ) AS  title");
			$this->db->join('tbl_categories C','C.id = S.id_category','LEFT');
			$this->db->from("tbl_subcategories S");
			// $this->db->where_in("S.id_category", $catid);			$this->db->where("S.id_category IN ('$catid')");		
			$res = $this->db->get();
			// $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function get_all_subsubbyid($catid)
		{
			$this->db->select("S.id,CONCAT(S.title,' -- ', C.category_name ) AS  title");
	    	$this->db->from("tbl_subsubcategory S");
			$this->db->join('tbl_categories C','C.id = S.id_category','LEFT');
	    	$this->db->where("status","1");
			$this->db->where("S.id_subcategory",$catid);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function get_all_subsubbcats($catid)
		{
			$this->db->select("S.id,CONCAT(S.title,' -- ', C.category_name ) AS  title");
	    	$this->db->from("tbl_subsubcategory S");
			$this->db->join('tbl_categories C','C.id = S.id_category','LEFT');
	    	$this->db->where("status","1");
			$this->db->where_in("S.id_subcategory",$catid);
		
			$res = $this->db->get();
			// $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function articledetails($id)
		{
			$this->db->select('T.*, S.title as subcat_title,SS.title as subsubtitle,GROUP_CONCAT(A.parentcat_id SEPARATOR "'. "','". '") as catid,
			                  GROUP_CONCAT(A.sub_catid SEPARATOR ",") as subcatid,GROUP_CONCAT(A.sub_sub_catid SEPARATOR ",") as subsubcatid');
	    	$this->db->from("tbl_articelepost T");
			$this->db->join('article_parentcats A','A.article_id = T.id','LEFT');
	    	$this->db->join("tbl_subcategories S", "S.id = T.id_subcategory", "Left");
			$this->db->join("tbl_subsubcategory SS", "SS.id = T.id_subsub", "Left");
			$this->db->where("T.id", $id);
			
			$res = $this->db->get();
			// $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
		function get_all_subsubcategories($catid)
		{
			 $this->db->select("S.id,CONCAT(S.title,' -- ', C.category_name ) AS  title");
	    	 $this->db->from("tbl_subsubcategory S");
		     $this->db->join('tbl_categories C','C.id = S.id_category','LEFT');
	    	 $this->db->where("status","1");
		     // $this->db->where_in("S.id_subcategory",$catid);		     $this->db->where("S.id_subcategory in( '$catid' ) ");
		
			$res = $this->db->get();
			// $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function getallexamcategories()
		{
			$this->db->select("*");
	    	$this->db->from("tbl_categories");
	    	$this->db->where("category_status","1");
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function articlecategorydeatils($postid)
		{
			$this->db->select("C.category_name");
	    	$this->db->from("article_parentcats P");
			$this->db->join("tbl_categories C","C.id = P.parentcat_id","Left");
	    	$this->db->where("P.article_id",$postid);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function articlesubcategorydeatils($postid)
		{
			$this->db->select("C.title");
	    	$this->db->from("article_parentcats P");
			$this->db->join("tbl_subcategories C","C.id = P.sub_catid","Left");
	    	$this->db->where("P.article_id",$postid);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function articlesubsubcategorydeatils($postid)
		{
			$this->db->select("C.title");
	    	$this->db->from("article_parentcats P");
			$this->db->join("tbl_subsubcategory C","C.id = P.sub_sub_catid","Left");
	    	$this->db->where("P.article_id",$postid);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function checkdraftstatus($id)
		{
		    $this->db->select("draft");
	    	$this->db->from("tbl_articelepost");
	    	$this->db->where("id",$id);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row()->draft;
		    }
		}
		function reinsertpost($id)
		{
			
			$sql1 = "INSERT INTO tbl_articelepost (`id_subsub`,`topic_title`, `topic_description`, `topic_slug`,       
			        `featured_image`, `topic_status`, `feautured_post`, `added_date`, `added_by`, `viewcount`, `draft`)
                     SELECT `id_subsub`, `topic_title`, `topic_description`, `topic_slug`,       
			        `featured_image`, 1, `feautured_post`,now(),`added_by`, `viewcount`,0 FROM tbl_articelepost
                     WHERE id = $id";
			$this->db->query($sql1);
			$lastid = $this->db->insert_id();
			
			$sql2 = "UPDATE `article_parentcats` SET `article_id` = $lastid WHERE `article_parentcats`.`article_id` = $id";
			$this->db->query($sql2);
			
			$sql3 = "DELETE FROM `tbl_articelepost` WHERE `tbl_articelepost`.`id` = $id";
			$this->db->query($sql3);
		}
	}