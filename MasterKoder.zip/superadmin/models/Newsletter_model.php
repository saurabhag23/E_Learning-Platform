<?php 
  class Newsletter_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("n.*, DATE_FORMAT( n.datec, '%M %d, %Y') as datec, c.category_name, n.id as action")
				->from('newsletter n')
				->join('tbl_categories c', 'n.catid = c.id', 'INNER')				
				->edit_column('action','$1','action_buttons(action,"newsletter", 1, 1, 1, status)');
				$this->db->order_by("n.id", "desc");
			return $this->datatables->generate();	
	    }

	    function get_single(){
	    	$this->db->select("*");
	    	$this->db->from("tbl_posts");
			$this->db->where("admin_posted",1);
	    	$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function postdetails($id)
		{
			$this->db->select("*");
	    	$this->db->from("tbl_posts");
			$this->db->where("id", $id);
			
			$res = $this->db->get();
			
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
	}