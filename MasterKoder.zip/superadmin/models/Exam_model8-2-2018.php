<?php 
	class Exam_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas($course_id){
	    	$this->datatables->select("E.id_exam, E.exam_name, E.total_questions, E.exam_duration, E.exam_duration_slug, DATE_FORMAT(E.added_date, '%M %d, %Y') as added_date, E.id_exam as action, E.status as status")
				->from('tbl_exams E')
				->where("id_course", $course_id)
				->edit_column('action','$1','action_buttons(action, "exam", 0, 1, 1, status, 1)');
			return $this->datatables->generate();	
	    }

	    function get_single($id){
			$this->db->where("id_exam", $id);
			$res = $this->db->get('tbl_exams');
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }

	    function all_questions($exam_id){
	    	$this->datatables->select("Q.id_question, Q.question_name, DATE_FORMAT(Q.added_date, '%M %d, %Y') as added_date, Q.id_question as action, Q.status as status")
				->from('tbl_exams_questions Q')
				->where("Q.id_exam", $exam_id)
				->edit_column('action','$1','action_buttons(action, "questions", 1, 0, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_next_qstn_no($exam_id){
			$this->db->select("MAX(question_no) as question_no");
			$this->db->where("id_exam", $exam_id);
			$res = $this->db->get('tbl_exams_questions');
			if($res->num_rows() > 0){
				$row = $res->row();
				return $row->question_no + 1;
			}
			else{
				return 1;
			}
		}

		function get_next_exam_no($course_id){
			$this->db->select("MAX(exam_no) as exam_no");
			$this->db->where("id_course", $course_id);
			$res = $this->db->get('tbl_exams');
			if($res->num_rows() > 0){
				$row = $res->row();
				return $row->exam_no + 1;
			}
			else{
				return 1;
			}
		}
	}