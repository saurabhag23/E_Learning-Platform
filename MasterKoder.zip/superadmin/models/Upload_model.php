<?php 
	class Upload_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
		
	    	$this->datatables->select("u.id as id, u.file_name, u.file_link, u.created_at, u.id as action")
				->from('tbl_upload u');
				//->edit_column('action','$1','action_buttons(action, "menus", 1, 1, 1, status)');
			return $this->datatables->generate();	
			
	    }
		
		function all_mlevel2(){
		
	    	$this->datatables->select("l2.id, l2.title, l2.l1_id, l2.l3count, l2.status, l2.id as action, l1.title as lev1tit")
				->from('tbl_mlevel2 l2')
				->join('tbl_mlevel1 l1', 'l2.l1_id = l1.id', 'INNER')
				->edit_column('action','$1','action_buttons(action, "level2", 1, 1, 1, status)');
				
			return $this->datatables->generate();	
			
	    }
		
		function all_mlevel3(){
		
	    	$this->datatables->select("l3.id, l3.title, l3.status, l3.id as action, l1.title as lev1tit, l2.title as lev2tit")
				->from('tbl_mlevel3 l3')
				->join('tbl_mlevel2 l2', 'l3.l2_id = l2.id', 'INNER')
				->join('tbl_mlevel1 l1', 'l2.l1_id = l1.id', 'INNER')
				->edit_column('action','$1','action_buttons(action, "level3", 1, 1, 1, status)');
				
			return $this->datatables->generate();	
			
	    }

	    function get_all_roles(){
			$this->db->where("role_status", 1);
			$res = $this->db->get('tbl_roles');
			if($res->num_rows() > 0){
				return $res->result();
			}
	    }

	    function get_single_lev1($id){
			$this->db->select("l1.*, c.category_name");
			$this->db->where("l1.id", $id);
			$this->db->join('tbl_categories c', 'l1.catid = c.id', 'INNER');
			$res = $this->db->get('tbl_mlevel1 l1');
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		
	    function get_single_lev2($id){


			$this->db->select('l2.*, l1.title as lev1tit')
					 ->where('l2.id', $id)
					 ->from('tbl_mlevel2 l2')
					 ->join('tbl_mlevel1 l1', 'l2.l1_id = l1.id', 'INNER');
			$res = $this->db->get();
			
			return $res->row();
			
	    }		
		
	    function get_single_lev3($id){


			$this->db->select('l3.*, l1.title as lev1tit, l2.title as lev2tit')
					 ->where('l3.id', $id)
					 ->from('tbl_mlevel3 l3')
					->join('tbl_mlevel2 l2', 'l3.l2_id = l2.id', 'INNER')
					->join('tbl_mlevel1 l1', 'l2.l1_id = l1.id', 'INNER');
			$res = $this->db->get();
			
			return $res->row();
			
	    }
		
		function getallexamcats()
		{
			$this->db->where("category_status", 1);
			$res = $this->db->get('tbl_categories');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function userscount()
		{
			$this->db->select('count(*) as userscount');
			$this->db->where("user_status", 1);
			$this->db->where("id_role", 3);
			$res = $this->db->get('tbl_users');
			if($res->num_rows() > 0){
				return $res->row()->userscount;
			}
		}
		function admincount()
		{
			$this->db->select('count(*) as userscount');
			$this->db->where("user_status", 1);
			$this->db->where("id_role", 1);
			$res = $this->db->get('tbl_users');
			if($res->num_rows() > 0){
				return $res->row()->userscount;
			}
		}
		function mentorcount()
		{
			$this->db->select('count(*) as userscount');
			$this->db->where("user_status", 1);
			$this->db->where("id_role", 2);
			$res = $this->db->get('tbl_users');
			if($res->num_rows() > 0){
				return $res->row()->userscount;
			}
		}
	}