<?php 
  class Report_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("R.postid ,R.reason,R.comment,DATE_FORMAT(R.date, '%M %d, %Y ') as added_date, 
			                           CONCAT(U.user_fname, ' ', U.user_lname) as 'username',R.id as action, R.id, R.status")
				->from('tble_report R')
				->join("tbl_users U", "U.id = R.userid", "Left")
				->edit_column('action','$1','action_buttons(action, "reports", 0,0,1,-2,1)');
			return $this->datatables->generate();	
	    }				
		
		function get_postres($rpostid)		{
			$this->db->select('concat( user_fname, " " , user_lname ) as uname, P.created');	    	
			$this->db->from('tbl_posts P');			
			$this->db->join('tbl_users U', 'U.id = P.userid', 'INNER');						
			$this->db->where('P.id', $rpostid);			
			$res = $this->db->get();			
			if($res->num_rows() > 0){				
			return $res->row();			
			}					
		}
		
		function get_comres($comid)		{
			$this->db->select('concat( user_fname, " " , user_lname ) as cuname, C.created as ccreated, C.comment');	    	
			$this->db->from('tble_postcomments C');			
			$this->db->join('tbl_users U', 'U.id = C.userid', 'INNER');						
			$this->db->where('C.id', $comid);			
			$res = $this->db->get();			
			if($res->num_rows() > 0){				
				return $res->row();			
			}					
		}
		
		function get_single($reportid)
		{
			$this->db->select("R.*,CONCAT(U.user_fname, ' ', U.user_lname) as 'username',P.status as pststus,CONCAT(q.user_fname, ' ', q.user_lname) as 'postedby',
			                   q.user_email as 'postermemail',P.id as 'postid',P.upadated_status,P.quiz_id as 'quiz_id', R.postid as rpostid");
	    	$this->db->from('tble_report R');
			$this->db->join('tbl_users U', 'U.id = R.userid', 'LEFT');
			$this->db->join('tbl_posts P', 'P.id = R.postid', 'LEFT');
			$this->db->join('tbl_users q', 'q.id = P.userid', 'LEFT');
			$this->db->where("R.id", $reportid);
			$res = $this->db->get();
		//	$this->db->last_query();
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
		function get_quizname($quizid)
		{
		    $this->db->select('*');
			$this->db->where("id_exam", $quizid);
			$res = $this->db->get('tbl_exams');
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
	   function get_article($articleid)
	   {
	   		$this->db->select('*');
			$this->db->where("id",$articleid);
			$res = $this->db->get('tbl_articelepost');
			if($res->num_rows() > 0){
				return $res->row();
			}
	   }
	}