<?php 
	class Rolemodel extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	    $this->datatables->select("id, role_name, role_status , role_added_by, role_added_date,id as action")
				->from('tbl_roles')
			    ->edit_column('action','$1','action_buttons(action,"roles", 1, 1, 1, role_status,0,1)');
			return $this->datatables->generate();	
	    }

	  
	    function get_single($id){
			$this->db->where("id", $id);
			$res = $this->db->get('tbl_roles');
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
	}