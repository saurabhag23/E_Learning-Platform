<?php 
class Advertizement_model extends CI_Model {
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}

	function all_datas(){
		$this->datatables->select("A.id,A.title,A.type,A.location,A.id,A.hyperlink,image, A.status,A.priority, DATE_FORMAT( A.added_date, '%M %d, %Y') as added_date, A.id as action, A.status as status")
			->from('tble_advertizement A')
			->edit_column('action','$1','action_buttons(action, "advertizement", 1, 1, 1, status)');
			$this->db->order_by("id",'desc');
		return $this->datatables->generate();	
	}

	function get_single($id){
		$this->db->where("id", $id);
		$res = $this->db->get('tble_advertizement');
		if($res->num_rows() > 0){
			return $res->row();
		}
	}
}