<?php 
  class Ssbtest_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("T.id_subcategory,T.topic_title, DATE_FORMAT(T.added_date, '%M %d, %Y %h:%i %p') as added_date, 
			                           T.id as action, T.topic_status as status")
				->from('tbl_ssb T')
				->edit_column('action','$1','action_buttons(action, "ssbtest", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single(){
	    	$this->db->select("*");
	    	$this->db->from("tbl_ssb");
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function ssbdetails($id)
		{
			$this->db->select("*");
	    	$this->db->from("tbl_ssb");
			$this->db->where("id", $id);
			$res = $this->db->get();
			
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
	}