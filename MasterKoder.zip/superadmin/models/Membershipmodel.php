<?php 
	class Membershipmodel extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	    $this->datatables->select("id, membership_title, duration,duration_slug, membership_amount, added_date,
				 added_user, status,id as action")
				->from('tbl_membership')
				->edit_column('action','$1','action_buttons(action,"membership_plans", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	  
	    function get_single($id){
			$this->db->where("id", $id);
			$res = $this->db->get('tbl_membership');
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function get_membershipfeatures($id)
		{
			$this->db->select('*');
			
			$this->db->where('membership_id',$id);
			$res = $this->db->get('tbl_membership_features');
			
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function deletefeature($id)
		{
			$this->db->where('membership_id', $id);
            $this->db->delete('tbl_membership_features'); 
		}
	}