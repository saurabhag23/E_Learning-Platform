<?php 
  class Studyplan_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("T.id_subcategory,T.title, DATE_FORMAT(T.added_date, '%M %d, %Y %h:%i %p') as added_date, 
			                           T.id as action, T.status as status,c.category_name")
				->from('tbl_studyplan T')
				->join('tbl_categories c',"c.id = T.id_parent", "Left")
				->edit_column('action','$1','action_buttons(action, "studyplan", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single(){
	    	$this->db->select("T.*, C.course_title");
	    	$this->db->from("tbl_current_affairs T");
	    	$this->db->join("tbl_courses C", "C.id_course = T.id_subcategory", "Left");
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function studypandeatils($id)
		{
			$this->db->select("S.*,C.category_name");
	    	$this->db->from("tbl_studyplan S");
	    	$this->db->join("tbl_categories C", "C.id = S.id_parent", "Left");
		    $this->db->where("S.id",$id);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
	}