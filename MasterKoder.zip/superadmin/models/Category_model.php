<?php 
	class Category_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("C.id, C.category_name, C.category_status, DATE_FORMAT(C.added_date, '%M %d, %Y') as added_date, C.id as action, C.category_status as status, C.sccount, C.ssccount, C.postcount")
				->from('tbl_categories C')
				->edit_column('action','$1','action_buttons(action, "categories", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single($id){
			$this->db->where("id", $id);
			$res = $this->db->get('tbl_categories');
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }

		function category_count()
		{
			$this->db->select('count(*) as catcount');
			$res = $this->db->get('tbl_categories');
			if($res->num_rows() > 0){
				return $res->row()->catcount;
			}
		}
		function subcategory_count()
		{
			$this->db->select('count(*) as catcount');
			$res = $this->db->get('tbl_subcategories');
			if($res->num_rows() > 0){
				return $res->row()->catcount;
			}
		}
		function subsubcategory_count()
		{
			$this->db->select('count(*) as catcount');
			$res = $this->db->get('tbl_subsubcategory');
			if($res->num_rows() > 0){
				return $res->row()->catcount;
			}
		}
	}