<?php 
	class User_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_users($role){
		
	    	$this->datatables->select("U.user_fname, U.user_lname, U.user_email,U.ContactNo,U.user_status,U.id as action, DATE_FORMAT(U.last_seen, '%M %d, %Y %h:%i %p') as last_seen,
			 U.user_status as status, R.role_name, U.location, U.exam_category, U.postcnt, U.queanscnt, U.coinscnt, U.testsubcnt")
				->from('tbl_users U')
				->where("U.id_role =",$role)
				->join('tbl_roles R', 'R.id = U.id_role', 'LEFT')
				->edit_column('action','$1','action_buttons(action, "users", 1, 1, 1, status)');
				
			return $this->datatables->generate();	
			
	    }

	    function get_all_roles(){
			$this->db->where("role_status", 1);
			$res = $this->db->get('tbl_roles');
			if($res->num_rows() > 0){
				return $res->result();
			}
	    }

	    function get_single_user($id){
			$this->db->where("id", $id);
			$res = $this->db->get('tbl_users');
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function getallexamcats()
		{
			$this->db->where("category_status", 1);
			$res = $this->db->get('tbl_categories');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function userscount()
		{
			$this->db->select('count(*) as userscount');
			$this->db->where("user_status", 1);
			$this->db->where("id_role", 3);
			$res = $this->db->get('tbl_users');
			if($res->num_rows() > 0){
				return $res->row()->userscount;
			}
		}
		function admincount()
		{
			$this->db->select('count(*) as userscount');
			$this->db->where("user_status", 1);
			$this->db->where("id_role", 1);
			$res = $this->db->get('tbl_users');
			if($res->num_rows() > 0){
				return $res->row()->userscount;
			}
		}
		function mentorcount()
		{
			$this->db->select('count(*) as userscount');
			$this->db->where("user_status", 1);
			$this->db->where("id_role", 2);
			$res = $this->db->get('tbl_users');
			if($res->num_rows() > 0){
				return $res->row()->userscount;
			}
		}
	}