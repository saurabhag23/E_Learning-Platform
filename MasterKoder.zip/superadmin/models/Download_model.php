<?php 
  class Download_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("N.id_subcategory,N.title, DATE_FORMAT(N.added_date, '%M %d, %Y %h:%i %p') as added_date, 
			                           N.id as action, N.status as status,M.exam_title,C.category_name")
				->from('tbl_download N')
				->join('tbl_mainexam M',"M.id = N.id", "Left")
				->join('tbl_categories C',"C.id = N.id_parent", "Left")
				->edit_column('action','$1','action_buttons(action, "download", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single(){
	    	$this->db->select("T.*, C.course_title");
	    	$this->db->from("tbl_current_affairs T");
	    	$this->db->join("tbl_courses C", "C.id_course = T.id_subcategory", "Left");
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function downloaddetails($id)
		{
			$this->db->select("D.*,C.category_name");
	    	$this->db->from("tbl_download D");
	    	$this->db->join("tbl_categories C", "C.id = D.id_parent", "Left");
			//$this->db->join("tbl_mainexam M", "M.id = S.id_mainexam", "Left");
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
	}