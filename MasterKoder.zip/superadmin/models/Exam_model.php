<?php 
	class Exam_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas($course_id){
	    	$this->datatables->select("E.id_exam, E.exam_name, E.total_questions, E.exam_duration, E.exam_duration_slug, DATE_FORMAT(E.added_date, '%M %d, %Y') as added_date, E.id_exam as action, E.status as status")
				->from('tbl_exams E')
				->where("id_course", $course_id)
				->edit_column('action','$1','action_buttons(action, "exam", 0, 1, 1, status, 1)');
				//$this->db->order_by("E.id_exam","desc");
			return $this->datatables->generate();	
	    }

	    function get_single($id){
		    $this->db->select("E.*,GROUP_CONCAT(P.parentcat_id SEPARATOR ',') as quizcatid,
			                 GROUP_CONCAT(P.sub_catid SEPARATOR ',') as sub_catid,GROUP_CONCAT(P.sub_sub_catid SEPARATOR ',') as subsub_catid,S.title");
			$this->db->from('tbl_exams E');
			$this->db->join("tbl_quizparentcats P", "P.quiz_id = E.id_exam", "Left");
			$this->db->join("tbl_subsubcategory S", "S.id = E.id_subsubcat", "Left");
			$this->db->where("E.id_exam",$id);
			$res = $this->db->get();
	    	
			//  $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }

	    function all_questions($exam_id){
	    	$this->datatables->select("Q.id_question, Q.question_name, DATE_FORMAT(Q.added_date, '%M %d, %Y') as added_date, Q.id_question as action, Q.status as status")
				->from('tbl_exams_questions Q')
				->where("Q.id_exam", $exam_id)
				->edit_column('action','$1','action_buttons(action, "questions", 1, 0, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_next_qstn_no($exam_id){
			$this->db->select("MAX(question_no) as question_no");
			$this->db->where("id_exam", $exam_id);
			$res = $this->db->get('tbl_exams_questions');
			if($res->num_rows() > 0){
				$row = $res->row();
				return $row->question_no + 1;
			}
			else{
				return 1;
			}
		}

		function get_next_exam_no($course_id){
			$this->db->select("MAX(exam_no) as exam_no");
			$this->db->where("id_course", $course_id);
			$res = $this->db->get('tbl_exams');
			if($res->num_rows() > 0){
				$row = $res->row();
				return $row->exam_no + 1;
			}
			else{
				return 1;
			}
		}
		function checkpost($quizid)
		{
			$this->db->where("quiz_id", $quizid);
			$res = $this->db->get('tbl_posts');
			 $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
		function get_all_subsub($subcatid)
		{
			 $this->db->select("S.id,CONCAT(S.title,' -- ', C.category_name ) AS  title");
	    	 $this->db->from("tbl_subsubcategory S");
		     $this->db->join('tbl_categories C','C.id = S.id_category','LEFT');
	    	 $this->db->where("status","1");
		     $this->db->where_in("S.id_subcategory",$subcatid);
		
			$res = $this->db->get();
		// $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function getquizparentid($quizid)
		{
			$this->db->select("parentcat_id");
	    	$this->db->from("tbl_quizparentcats");
	    	$this->db->where("quiz_id",$quizid);
			$this->db->order_by("id","asc");
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row()->parentcat_id;
			}
		}
		function quizcatdetails($quizid)
		{
			$this->db->select("C.category_name");
	    	$this->db->from("tbl_quizparentcats p");
			$this->db->join("tbl_categories C","C.id = p.parentcat_id","Left");
	    	$this->db->where("p.quiz_id",$quizid);
			$res = $this->db->get();
		     // $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function quizsubcatdetails($quizid)
		{
			$this->db->select("C.title");
	    	$this->db->from("tbl_quizparentcats p");
			$this->db->join("tbl_subcategories C","C.id = p.sub_catid","Left");
	    	$this->db->where("p.quiz_id",$quizid);
			$res = $this->db->get();
		      $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function quizsubsubcatdetails($quizid)
		{
			$this->db->select("C.title");
	    	$this->db->from("tbl_quizparentcats p");
			$this->db->join("tbl_subsubcategory C","C.id = p.sub_sub_catid","Left");
	    	$this->db->where("p.quiz_id",$quizid);
			$res = $this->db->get();
		      $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
	}