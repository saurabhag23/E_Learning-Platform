<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Db_model extends CI_Model
{
	function __construct()
	{
		parent::__construct(); // construct the Model class
		
		$this->load->database();
	}
	
		function updatecode($table=null,$data=null)
	{
	    $this->db->where(id,'1');
	return $this->db->update($table,$data);

	}
		public function getcode(){
		$this->db->select('*');
		$this->db->where(id,'1');
		$res = $this->db->get('google_code');
		return $res->result();
	}
	
	function insert_upload($table=null,$data=null)
	{
	return	$this->db->insert($table,$data);
	}
	
	function insert($table=null,$data=null)
	{
		$this->db->insert($table,$data);
		return $this->db->insert_id();
	}
	function update($table=null,$data=array(),$where=null,$id=null)
	{
		$this->db->where($where,$id);
		$update		=	$this->db->update($table,$data);
		return $update;
	}
	function delete($tables=array(),$where=null,$value=null)
	{
		$this->db->where($where,$value);
		$delete		=	$this->db->delete($tables);
		return $delete;
	}
	
	function updateAll($table=null,$data=array())
	{
		$update		=	$this->db->update($table,$data);
		return $update;
	}
	function deleterow($table,$code_field,$id){

    	$this->db->query("UPDATE $table SET active_flag = 1 WHERE $code_field = '$id'");

    }
	public function get_last_code($id,$table){
		return $this->db
			   -> select($id)
			   -> from($table)
			   -> limit(1)
			   -> order_by($id,'desc')
			   -> get()
			   -> result();
	}
	public function checkId($field,$id,$table){
		$this->db->select('*');
		$this->db->where($field,$id);
		$this->db->limit(1);
		$this->db->order_by($id,'desc');
		$res = $this->db->get($table);
		return $res->result();
	}
	
	/// GET LIST ////
	
	public function get_List($table,$where,$id){
		$this->db->select('*');
		$this->db->where($where,$id);
		$res = $this->db->get($table);
		return $res->result();
	}
	
		public function all_datas(){
		$this->db->select('*');
		$res = $this->db->get('tbl_upload');
		return $res->result();
	}
	
	
	function get_datas($where,$id,$table){
		return $this->db
			   -> select('*')
			   -> where($where,$id)
			   -> get($table)
			   -> row();
	}
	public function get_Total($val,$table){
		return $this->db
			   -> select('*')
			   -> where('is_remainder',$val)
			   -> get('tbl_comments')
			   -> num_rows();
	}
}