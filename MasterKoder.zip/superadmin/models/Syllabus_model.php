<?php 
  class Syllabus_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("T.id_subcategory,T.syllabus_title, DATE_FORMAT(T.added_date, '%M %d, %Y %h:%i %p') as added_date, 
			                           T.id as action, T.syllabus_status as status")
				->from('tbl_syllabus T')
				->edit_column('action','$1','action_buttons(action, "syllabus", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single(){
	    	$this->db->select("T.*, C.course_title");
	    	$this->db->from("tbl_current_affairs T");
	    	$this->db->join("tbl_courses C", "C.id_course = T.id_subcategory", "Left");
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function syllbusdetails($id)
		{
			$this->db->select("S.*, C.course_title");
	    	$this->db->from("tbl_syllabus S");
	    	$this->db->join("tbl_courses C", "C.id_course = S.id_subcategory", "Left");
			$this->db->where("S.id", $id);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
	}