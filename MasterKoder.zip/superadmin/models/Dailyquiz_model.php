<?php 
	class Dailyquiz_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("E.id_exam, E.exam_name, concat( C.category_name, IF( E.catcnt> 0, '+', '') , IF( E.catcnt> 0, E.catcnt, '') ) as scat, concat( SC.title, IF( E.coursecnt> 0, '+', ''), IF( E.coursecnt> 0, E.coursecnt, '') ) as cat, concat( SSC.title, IF( E.subsubcatcnt> 0, '+', ''), IF( E.subsubcatcnt> 0, E.subsubcatcnt, '') ) as subcat, E.total_questions, E.exam_duration, E.exam_duration_slug, DATE_FORMAT(E.added_date, '%M %d, %Y') as added_date, E.id_exam as action, E.status as status,CONCAT(U.user_fname,  ' ',U.user_lname) AS  username, E.attempt_count")
				->from('tbl_exams E')
				->join('tbl_users U','U.id = E.added_by','LEFT')
				->join('tbl_categories C','C.id = E.id_cat','LEFT')
				->join('tbl_subcategories SC','SC.id = E.id_course','LEFT')
				->join('tbl_subsubcategory SSC','SSC.id = E.id_subsubcat','LEFT')
				->where('E.daily_quiz','1')
				->edit_column('action','$1','action_buttons(action, "dailyquiz", 0, 1, 1, status, 1)');
				
				//return var_dump( $_POST['order'][0]['column'] );
				//return var_dump( $_POST['columns'][ $_POST['order'][0]['column'] ]['data'] );
				//return var_dump( $_POST['order'][0]['dir'] );
				
				//if( $_POST['columns'][ $_POST['order']['column'] ] )
				$this->db->order_by( $_POST['columns'][ $_POST['order'][0]['column'] ]['data'], $_POST['order'][0]['dir']);
				
			return $this->datatables->generate();	
	    }

	    function get_single(){
			//$this->db->where("id_exam", $id);
			$res = $this->db->get('tbl_exams');
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }

	    function all_questions($exam_id){
			
	    	$this->datatables->select("Q.id_question, Q.question_name, DATE_FORMAT(Q.added_date, '%M %d, %Y') as added_date, Q.id_question as action, Q.status as status, CONCAT( Q.question_name , '-***-' , Q.answer, '-***-' , Q.id_question ) as question_ans, CONCAT( Q.image_upload_path, Q.image , '-***-' , Q.answer, '-***-' , Q.id_question ) as img_path, CONCAT( Q.question_name , '-***-' , Q.question_option_1, '-***-' , Q.question_option_2, '-***-' , Q.question_option_3, '-***-' , Q.question_option_4, '-***-' , Q.question_option_5, '-***-' , Q.question_answer, '-***-' , Q.explanation, '-***-' , Q.id_question ) as mque_ans")
				->from('tbl_exams_questions Q')
				->where("Q.id_exam", $exam_id)
				->edit_column('action','$1','action_buttons(action, "questions", 1, 0, 1, status)');
			return $this->datatables->generate();	
	    }
		
	     function get_all_articles(){
			$res = $this->db->get('tbl_articelepost');
			if($res->num_rows() > 0){
				return $res->result();
			}
	    }

	    function get_next_qstn_no($exam_id){
			$this->db->select("MAX(question_no) as question_no");
			$this->db->where("id_exam", $exam_id);
			$res = $this->db->get('tbl_exams_questions');
			if($res->num_rows() > 0){
				$row = $res->row();
				return $row->question_no + 1;
			}
			else{
				return 1;
			}
		}

		function get_next_exam_no($course_id){
			$this->db->select("MAX(exam_no) as exam_no");
			$this->db->where("id_course", $course_id);
			$res = $this->db->get('tbl_exams');
			if($res->num_rows() > 0){
				$row = $res->row();
				return $row->exam_no + 1;
			}
			else{
				return 1;
			}
		}
		function checkpost($quizid)
		{
			$this->db->where("quiz_id", $quizid);
			$res = $this->db->get('tbl_posts');
			 $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
		function  get_all_subcategoriesbyquiz($catid)
		{
		
			$this->db->select("S.id,CONCAT(S.title,' -- ', C.category_name ) AS  title");
	    	$this->db->from("tbl_subcategories S");
			$this->db->join('tbl_categories C','C.id = S.id_category','LEFT');
			$this->db->where_in("S.id_category",$catid);
	    	$this->db->where("status","1");
			$res = $this->db->get();
			//  $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
			
			
		}
		
		function saverecart($id_exam, $articleid, $recid)
		{
			$sql = "UPDATE `tbl_exams` SET `recommended_$recid` = '$articleid' where id_exam = '$id_exam'";
			return $this->db->query($sql);
		}
	}