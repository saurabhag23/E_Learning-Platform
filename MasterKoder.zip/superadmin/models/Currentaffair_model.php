<?php 
  class Currentaffair_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("T.id_subcategory,T.topic_title, DATE_FORMAT(T.added_date, '%M %d, %Y %h:%i %p') as added_date, 
			                           T.id as action, T.topic_status as status")
				->from('tbl_current_affairs T')
				->edit_column('action','$1','action_buttons(action, "currentaffairs", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single(){
	    	$this->db->select("T.*, C.course_title");
	    	$this->db->from("tbl_current_affairs T");
	    	$this->db->join("tbl_courses C", "C.id_course = T.id_subcategory", "Left");
			
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function currentaffairdetails($id)
		{
			$this->db->select("T.*, C.course_title,M.current_affair");
	    	$this->db->from("tbl_current_affairs T");
	    	$this->db->join("tbl_courses C", "C.id_course = T.id_subcategory", "Left");
			$this->db->join("tbl_mastercurrentaffairs M", "M.id = T.current_affair_type", "Left");
			$this->db->where("T.id", $id);
			
			$res = $this->db->get();
			
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
	}