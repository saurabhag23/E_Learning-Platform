<?php 
  class Notes_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("N.id_subcategory,N.title, DATE_FORMAT(N.added_date, '%M %d, %Y %h:%i %p') as added_date, 
			                           N.id as action, N.status as status,C.category_name")
				->from('tbl_notes N')
				->join('tbl_categories C',"C.id = N.id_parent", "LEFT")
				->edit_column('action','$1','action_buttons(action, "notes", 1, 1, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single(){
	    	$this->db->select("T.*, C.course_title");
	    	$this->db->from("tbl_current_affairs T");
	    	$this->db->join("tbl_courses C", "C.id_course = T.id_subcategory", "Left");
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function notesdetails($id)
		{
			$this->db->select("N.*,C.category_name,S.title as subtitle");
	    	$this->db->from("tbl_notes N");
			$this->db->join('tbl_categories C',"C.id = N.id_parent", "LEFT");
			$this->db->join('tbl_subcategories S',"S.id = N.id_subcategory", "LEFT");
			$this->db->where("N.id",$id);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
		function get_all_subcatscategoriesbyid($catid)
		{
			$this->db->select("S.id,CONCAT(S.title,' -- ', C.category_name ) AS  title");
	    	$this->db->from("tbl_subcategories S");
			$this->db->join('tbl_categories C','C.id = S.id_category','LEFT');
			$this->db->where("S.id_category",$catid);
	    	$this->db->where("status","1");
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function get_all_subcategoriesbycat($catid)
		{
			$this->db->select("*");
	    	$this->db->from("tbl_subcategories");
	    	$this->db->where("id_category",$catid);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
	}