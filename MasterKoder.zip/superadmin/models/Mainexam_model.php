<?php 
	class Mainexam_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("M.id, M.exam_title,TC.category_name, DATE_FORMAT(M.added_date, '%M %d, %Y %h:%i %p') as added_date, M.id as action, M.exam_status as status,
			                         C.course_title")
				->from('tbl_mainexam M')
				->join('tbl_categories TC', 'TC.id = M.id_category', 'LEFT')
				->join('tbl_courses C', 'C.id_course = M.id_subcategory', 'LEFT')
				->edit_column('action','$1','action_buttons(action, "mainexam", 1, 1, 1, status)');
				$this->db->order_by('M.id ','desc');
			return $this->datatables->generate();	
	    }

	    function get_single($id){
	    	$this->db->select('*,M.id as examid');
	    	$this->db->from('tbl_mainexam M');
			$this->db->join('tbl_categories TC', 'TC.id = M.id_category', 'LEFT');
			$this->db->join('tbl_courses C', 'C.id_course = M.id_subcategory', 'LEFT');
			$this->db->where("M.id", $id);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function quizcount($id)
		{
		    $this->db->select('COUNT(*)AS cacount');
			$this->db->where("id_subcategory", $id);
			$res = $this->db->get('tbl_current_affairs');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}

	     function get_all_categories(){
			$this->db->where("category_status", 1);
			$res = $this->db->get('tbl_categories');
			if($res->num_rows() > 0){
				return $res->result();
			}
	    }
		function getcurrent_affairtypes()
		{
		    $this->db->select("*");
			$res = $this->db->get('tbl_mastercurrentaffairs');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function get_all_subcatscategoriesbyid($catid)
		{
			$this->db->select("*");
			$this->db->where("id_category", $catid);
			$res = $this->db->get('tbl_courses');
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
		function getsubcatscategoriesbyid()
		{
			$this->db->select("*");
			
			$res = $this->db->get('tbl_courses');
			echo $this->db->last_query();
			if($res->num_rows() > 0){
				return $res->result();
			}
		}
	}