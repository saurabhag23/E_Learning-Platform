<?php 
	class Question_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
	    function get_single($id){
			$this->db->where("id_question", $id);
			$res = $this->db->get('tbl_exams_questions');
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
	}