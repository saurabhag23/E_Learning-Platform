<?php 
  class Newsfeed_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
		    
error_reporting(E_ALL);
ini_set('display_errors', 1);
		    
	    	$this->datatables->select("P.upadated_status as title,DATE_FORMAT(P.created, '%M %d, %Y %h:%i %p') as added_date, 
			                           P.id as action, P.active_status as status, A.topic_title , E.exam_name")
				->from('tbl_posts P')
				->join('tbl_articelepost A','P.article_id = A.id','LEFT')
				->join('tbl_exams E','P.quiz_id = E.id_exam','LEFT')
				->where('top',1)
				->edit_column('action','$1','action_buttons(action,"newsfeed", 1, 1, 1, status)');
				$this->db->order_by("P.toptime", "desc");
			return $this->datatables->generate();	
	    }

	    function get_single(){
	    	$this->db->select("*");
	    	$this->db->from("tbl_posts");
			$this->db->where("admin_posted",1);
	    	$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function postdetails($id)
		{
			$this->db->select("*");
	    	$this->db->from("tbl_posts");
			$this->db->where("id", $id);
			
			$res = $this->db->get();
			
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
	}