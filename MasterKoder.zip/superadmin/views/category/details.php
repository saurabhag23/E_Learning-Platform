
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('articles') ?>">Article Management</a></li>
        <li class="active">Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-lg-12 col-xs-12 col-md-12">

            <div class="box box-solid bc-transparent box-sd">
                <div class="box-header with-border">
                  <i class="fa fa-book"></i>

                  <h3 class="box-title">Category Management</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">

               <?php if(has_permission('categories', 'dashboard_view')): ?>			
                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('categories/details')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3><?=$catcount?></h3>

								  <p>Super Categories</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-pencil"></i>
                            </div>
                            <a href="<?=admin_url('categories/details')?>" class="small-box-footer">
                              More info <i class="fa fa-arrow-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
				<?php endif; ?>
				<?php if(has_permission('subcategory', 'dashboard_view')): ?>			
					 <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('subcategory')?>">
                          <div class="small-box bg-aqua content-posts">
                            <div class="inner">
                              <h3><?=$subcatcount?></h3>

                              <p>Categories</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-book"></i>
                            </div>
                            <a href="<?=admin_url('subcategory')?>" class="small-box-footer">
                                More info <i class="fa fa-arrow-circle-right"></i>
                            </a>
                          </div>
                      </a>
                  </div>
				 <?php endif; ?>
				 <?php if(has_permission('subsubcategory', 'dashboard_view')): ?>
					<div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('subsubcategory')?>">
                          <div class="small-box bg-green content-exam-details">
                            <div class="inner">
                              <h3><?=$subsubcatcount?></h3>

								  <p>Sub Categories</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-list-alt"></i>
                            </div>
                            <a href="<?=admin_url('subsubcategory')?>" class="small-box-footer">
                              More info <i class="fa fa-arrow-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
				 <?php endif; ?>	
					
                <!-- /.box-body -->
              </div>
          </div>





        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

