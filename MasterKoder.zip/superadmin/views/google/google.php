
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><!--<i class="fa fa-dashboard"></i>-->Home</a></li>
        <li class="active">Google Analytics Code</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-lg-12 col-xs-12 col-md-12">

            <div class="box box-solid bc-transparent box-sd">
                <div class="box-header with-border">
                  <i class="fa fa-book"></i>

                  <h3 class="box-title">Google Analytics Code</h3>
                </div>
                <!-- /.box-header -->
			
<style>			

.error {
    color: #b94a48;
}

</style>			
			
		<?php echo form_open_multipart( admin_url('google/updatedata'), array( 'id' => 'uploadfrm' ));?>

                <div class="box-body" style="margin-top: 20px;">
				
				
               <div class="form-group">
					
					<label for="url"> Google Analytics Code </label>
				
					<textarea class="form-control" id="code" placeholder="" name="code" rows="10" required><?php echo $admin[0]->code;?></textarea>
					
                </div>
				
              <div class="box-footer">
			  
				<span style="color: #00B050;display: none;" id="metmsg"> Code updated successfully </span>
			  
                <input type="hidden" name="action" value="insert">
				<input type="hidden" name="role" value="<?=$this->uri->segment('4')?>">
                <button type="submit"  class="btn btn-primary btn-sm pull-right btn-green">Update</button>
              </div>
					
                <!-- /.box-body -->
              </div>
			
			</form>
			  
          </div>





        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

