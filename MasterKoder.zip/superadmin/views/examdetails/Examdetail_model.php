<?php 
  class Examdetail_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
	
		function all_datas(){
	    	$this->datatables->select("T.sub_catid,T.title, DATE_FORMAT(T.created, '%M %d, %Y %h:%i %p') as added_date, 
			                           T.id as action, T.status as status")
				->from('tbl_examdetails T')
				->edit_column('action','$1','action_buttons(action, "examdetails", 1, 0, 1, status)');
			return $this->datatables->generate();	
	    }

	    function get_single(){
	    	$this->db->select("T.*, C.course_title");
	    	$this->db->from("tbl_examdetails T");
	    	$this->db->join("tbl_courses C", "C.id_course = T.sub_catid", "Left");
			
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
	    }
		function getexamdeatils($id)
		{
			$this->db->select("T.*, C.course_title,M.category_name");
	    	$this->db->from("tbl_examdetails T");
	    	$this->db->join("tbl_courses C", "C.id_course = T.sub_catid", "Left");
			$this->db->join("tbl_categories M", "M.id = T.id_parent", "Left");
			$this->db->where("T.id", $id);
			$res = $this->db->get();
			if($res->num_rows() > 0){
				return $res->row();
			}
		}
	}