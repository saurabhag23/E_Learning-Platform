<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/select2/dist/js/select2.full.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/wizard/wizard.js"></script> 

<script>
  $(function () {
      
      cat = [];
      
<?php

    foreach($subsubcats as $subsubcat)
    {
    
    
        echo 'cat['. $subsubcat->id .'] = "'. $subsubcat->title .'";';
    
    }
?>

    console.log('cat');
    console.log(cat);
      
    $('#userTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('mentor/get_all_users') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
              
                { "data": "action",
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    } },
              { "data" : "user_fname", render: function(data, type, row, meta) {
                                                      return row.user_fname+' '+row.user_lname;
                                                    }
                           },
                           { "data" : "ContactNo"},
                           { "data" : "user_email"},
						   { "data" : "subjects", render: function(data, type, row, meta) {
                               
                                    data = ( data != null  ) ? ',' + data + ',' : '' ;
                               
                                    console.log('subjects');
                                    console.log(data);
                                    exam_category = '';
                                    
                                    $.each(cat, function( index, value ) {
                                          console.log( index + ": " + value );
                                          
                                          index = ',' + index + ',';
                                          
                                          if( data != '' && data.indexOf(index) >= 0 )
                                                exam_category += value + ', ';
                                        });
                                                
                                    return exam_category;
                                    
                                        }
						       
						   },
						   { "data" : "postcnt"},
						   { "data" : "queanscnt"},
						   { "data" : "last_seen"},
                           { "data" : "user_status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Blocked </span>';
                                          } 
										  else if (data == -1){
                                              return '<span class="label label-warning"> Not approved </span>';
                                          } 
                                        }
                           },
                           { "data" : "action", "sortable": false}],
    });
    
    $(".examcat").select2();
    
  });
  function refreshUserTable(){
    $('#userTable').DataTable().draw();
  }
</script>