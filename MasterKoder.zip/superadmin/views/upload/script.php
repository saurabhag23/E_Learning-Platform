<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/select2/dist/js/select2.full.min.js"></script>

<script>
  $(function () {
    $('#courseTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          //"order"       : [[2, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('upload/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
                            { "data": "action",
                            render: function (data, type, row, meta) {
                                return meta.row + meta.settings._iDisplayStart + 1;
                            } },
                            { "data" : "file_name"},
                           { "data" : "file_link"},
                           { "data" : "created_at"}
                            ],
    });
  });
  
  function refreshCourseTable(){
    $('#courseTable').DataTable().draw();
  }
</script>


<script>

	/* posting image files through ajax */		
	
	$('#subbut').click( function() {
		
    var form = $('#uploadfrm')[0];

	// Create an FormData object 
	var data = new FormData(form);

	// If you want to add an extra field for the FormData
	// data.append("CustomField", "This is some extra data, testing");

	// disabled the submit button
	// $("#btnSubmit").prop("disabled", true);

	$.ajax({
		type: "POST",
		enctype: 'multipart/form-data',
		url: "<?php echo admin_url('upload/up'); ?>",
		data: data,
		processData: false,
		contentType: false,
		cache: false,
		timeout: 600000,
		success: function (res) {
			
					console.log( "res");
					console.log( res );
					var obj = JSON.parse( res );
					
					if( obj.has_error == 1 )
					{
						$('#ufileerr').html(obj.error.ufile).show();
					}
					else
					{
						$('#ufileerr').html('').hide();
						$('#url').val(obj.uurl);
					}	
									
		},
		error: function (e) {

			// $("#result").text(e.responseText);
			console.log("ERROR : ", e);
			// $("#btnSubmit").prop("disabled", false);

		}
	});
		
	} );// click end
	
	$('#copyurl').click( function() {
		
	   var copyText = document.getElementById("url");

	   /* Select the text field */
	   copyText.select();
	  
	   /* Copy the text inside the text field */
	   document.execCommand("copy");
		
	} );// click end
	


</script>

  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>  
  <script>
    initSample();
  </script>