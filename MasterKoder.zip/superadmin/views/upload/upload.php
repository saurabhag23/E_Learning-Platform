
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><!--<i class="fa fa-dashboard"></i>-->Home</a></li>
        <li><a href="<?= admin_url('upload') ?>">Upload Files</a></li>
        <li class="active">Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-lg-12 col-xs-12 col-md-12">

            <div class="box box-solid bc-transparent box-sd">
                <div class="box-header with-border">
                  <i class="fa fa-book"></i>

                  <h3 class="box-title">Upload File</h3>
                </div>
                <!-- /.box-header -->
			
<style>			

.error {
    color: #b94a48;
}

</style>			
			
			<?php echo form_open_multipart( admin_url('upload/up'), array( 'id' => 'uploadfrm' ));?>

                <div class="box-body" style="margin-top: 20px;">
				
				
                <div class="form-group">
					
					<label for="url"> File Name </label>
					<input type="text" class="form-control" id="file_name" placeholder="" name="file_name" required >
				
					
                </div>
				
                <div class="form-group">
					<label for="ufile"> Select file </label>
					<input type="file" name="ufile" id="ufile" class="form-control" placeholder="" required >
					<div class="control-label label error" id="ufileerr" style="display: none;text-align: left;"></div>
				  	<!--<label class="control-label error" id="ufile_err" style="display: none;color: #b94a48;">This field is required.</label>		  -->
                </div>
				
                <div class="form-group">
					
					<label for="url"> Url </label>
					<input type="text" readonly class="form-control" id="url" placeholder="" name="url" required >
				
					
                </div>
				
                <div class="form-group">
					<label for="ufile"></label>
					<button type="button" id="copyurl" class="btn btn-primary btn-sm pull-left btn-green" style="background-color: grey;">Copy</button>
					
                </div>
				
              <div class="box-footer">
                <input type="hidden" name="action" value="insert">
				<input type="hidden" name="role" value="<?=$this->uri->segment('4')?>">
                <button type="button" id="subbut" class="btn btn-primary btn-sm pull-right btn-green">Submit</button>
              </div>
					
                <!-- /.box-body -->
              </div>
			
			</form>
			  
          </div>





        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

