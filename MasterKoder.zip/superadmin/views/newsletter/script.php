<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
	  
/*
{ "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },
*/	  
	  
    $('#topicTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[3, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('newsletter/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
						   { "data" : "category_name"},                          
						   { "data" : "email"},                          
                           { "data" : "contact"},
                           { "data" : "datec"},
                           
                           { "data" : "action", "sortable": false}],
    });
	
setInterval(function() {
    
	$("button").each(function(){
		if( $(this).attr('title') == 'Unhide' )
			$(this).hide();
	}); 
	
	$("tr").each(function(){
		$(this).find('th').last().hide();
		$(this).find('td').last().hide();
	}); 
	
}, 1000);  
	
  });
  function refreshTopicTable(){
    $('#topicTable').DataTable().draw();
  }
  
</script>