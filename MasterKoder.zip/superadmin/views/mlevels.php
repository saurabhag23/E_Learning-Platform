
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><!--<i class="fa fa-dashboard"></i>-->Home</a></li>
        <li><a href="<?= admin_url('articles') ?>">Article Management</a></li>
        <li class="active">Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-lg-12 col-xs-12 col-md-12">

            <div class="box box-solid bc-transparent box-sd">
                <div class="box-header with-border">
                  <i class="fa fa-book"></i>

                  <h3 class="box-title">Article Management</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body" style="margin-top: 20px;">
  

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('menus/level1')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3>5</h3>

								  <p>Level 1</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('menus/level1')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			
			
                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('level2')?>">
                          <div class="small-box bg-aqua content-daily-quiz">
                            <div class="inner">
                              <h3>8</h3>

								  <p>Level 2</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-pencil"></i>
                            </div>
                            <a href="<?= admin_url('level2')?>" class="small-box-footer">
                              More info <i class="fa fa-pencil"></i>
                            </a>
                          </div>
                      </a>
                    </div>
					
                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('level3')?>">
                          <div class="small-box bg-orange content-daily-quiz">
                            <div class="inner">
                              <h3>24</h3>

								  <p>Level 3</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-search"></i>
                            </div>
                            <a href="<?= admin_url('level3')?>" class="small-box-footer">
                              More info <i class="fa fa-list-alt"></i>
                            </a>
                          </div>
                      </a>
                    </div>
					
                <!-- /.box-body -->
              </div>
          </div>





        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

