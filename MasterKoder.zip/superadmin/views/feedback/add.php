
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>	 
        Add Feedback
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('tools') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('feedback') ?>">Feedback</a></li>
        <li class="active">Add New Feedback</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content admin_feedback">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('feedback/addsub') ?>" method="post" id="feedadd" name="feedadd" >
              <div class="box-body">
                
                <div class="form-group">
                  <label for="title">Feedback Title</label>
                  <input type="text" class="form-control" id="title" placeholder="Title" name="title">
				  
				 <?php echo form_error('title'); ?>				  
                </div>

                <div class="form-group">
                  <label for="title">Choose Feedback Type</label>
                  <?php
				  	$opt = array( "" => "Select", "S" => "Single choice", "M" => "Multiple Choice" );
					echo form_dropdown( 'type', $opt, '', 'id="type" class="form-control"' );
				  ?>				  
				 <?php echo form_error('type'); ?>				  
                </div>

                <div class="form-group">
                  <label for="url">Choose Super Category</label>
                  <?php
				  /*
				  	$opt = array( "" => "Select", "0" => "Parent" );
					echo form_dropdown( 'parent', $opt, '', 'id="parent" class="form-control"' );
					*/
				  ?>				  
				  
                  <?php
				  
					if( !empty( $tbl_categories ) )
					{
						$opt = array(''=>'Select');
						
						foreach( $tbl_categories as $key => $value )
						{
							$opt[ $value->id ] = $value->category_name;							
						}
						
						echo form_dropdown('parent', $opt, '', 'id="parent" class="form-control"');
					}
					
				  ?>
				  
				 <?php echo form_error('parent'); ?>			  
                </div>

				<div id="optdiv">
				
				<div class="optrow">
				
					<div class="form-group" style="margin-top: 20px;">
					  <label for="order">Option A</label>
					  <input type="text" class="form-control" placeholder="Add Option A" name="opt[]">
					  <input type="hidden" class="form-control" name="optlet[]" value="A">
						
					  <?php echo form_error('opt'); ?>
					</div>
					
					<div class="form-group">
						<div style="display: none;">
						  <label for="order">Show Star Rating </label>
						  <?php
							$opt = array( "" => "Select", "Y" => "Yes", "N" => "No" );
							
							echo form_dropdown( 'star_rat[]', $opt, '', 'class="form-control"' );
						  ?>
						  <?php echo form_error('star_rat'); ?>
						</div>
						
						<div>
						  <label for="order">Show Onclick Text Input </label>
						  <?php
							$opt = array( "" => "Select", "Y" => "Yes", "N" => "No" );
							
							echo form_dropdown( 'txt_input[]', $opt, '', 'class="form-control"' );
						  ?>
						  <?php echo form_error('txt_input'); ?>
						</div>
					</div>
					
				</div>	
					
				<div class="optrow">
				
						<div class="form-group">
						  <label for="order">Option B</label>
						  <input type="text" class="form-control" placeholder="Add Option B" name="opt[]">
						  <input type="hidden" class="form-control" name="optlet[]" value="B">

						  <?php echo form_error('opt'); ?>
						</div>
						
						<div class="form-group">
							<div style="display: none;">
							  <label for="order">Show Star Rating </label>
							  <?php
								$opt = array( "" => "Select", "Y" => "Yes", "N" => "No" );
								
								echo form_dropdown( 'star_rat[]', $opt, '', 'class="form-control"' );
							  ?>
							  <?php echo form_error('star_rat'); ?>
							</div>
							
							<div>
							  <label for="order">Show Onclick Text Input </label>
							  <?php
								$opt = array( "" => "Select", "Y" => "Yes", "N" => "No" );
								
								echo form_dropdown( 'txt_input[]', $opt, '', 'class="form-control"' );
							  ?>
							  <?php echo form_error('txt_input'); ?>
							</div>
						
						</div>
					
				</div>
					
				</div>
				
                <div class="form-group">
				
					<label for="order"></label>
					<button type="button" id="add_opt" class="btn btn-primary btn-green" style="margin-top: 20px;width: 50%;float: left;">Add More Option</button>

                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="insert">
                <input type="hidden" name="save_pub" id="save_pub" value="0">
				<input type="hidden" name="role" value="<?=$this->uri->segment('4')?>">
				<input type="button" id="save" name="save" value="Save" class="btn btn-primary btn-sm pull-right btn-green">
				<input type="button" id="publish" name="publish" value="Publish" class="btn btn-primary btn-sm pull-right btn-green">
				
				
                
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
