
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->

        <!-- new dashboard -->
        
        
		<div class="admin-count-tabs">
            <ul class="nav nav-pills">
                <li class="active"><a class="tabs-link" data-toggle="pill" href="#mentors-post">Quiz Created</a></li>
                <li class=""><a class="tabs-link" data-toggle="pill" href="#users-post">Quiz Attempted</a></li>
            </ul>

            <div class="tab-content">
                <div id="mentors-post" class="tab-pane active">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="admin-count-box">
                                <p class="admin-count-box-title">Quiz Created</p>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">MCQ Quiz</p>
                                            <p class="admin-count-small-box-count"><?=$mcqqz?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">Pictorial Quiz</p>
                                            <p class="admin-count-small-box-count"><?=$pqqz?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">Textual Quiz</p>
                                            <p class="admin-count-small-box-count"><?=$txtqz?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="admin-count-box">
                                <p class="admin-count-box-title">Total Quiz Created</p>
                                <div class="admin-count-small-box">
                                    <p class="admin-count-small-box-title">&nbsp;</p>
                                    <p class="admin-count-small-box-count"><?=$mcqqz+$pqqz+$txtqz?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">MCQ Quiz</span>
                            <span class="exam-count"><?=$mcqqz?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
							
								<div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $cat = $this->db->query( "SELECT * FROM `tbl_categories`" )->result();
                                    
                                    if( !empty( $cat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $cat as $key => $value )
                                    	{	
                                    	    
										//echo "SELECT count( * ) as catcnt FROM `tbl_exams` where quiz_type = 'MCQ' and id_cat = " . $value->id ;

											
                                    	$catcnt = $this->db->query( "SELECT count( * ) as catcnt FROM `tbl_exams` inner join tbl_posts on tbl_exams.id_exam = tbl_posts.quiz_id where quiz_type = 'MCQ' and ( id_cat = " . $value->id . " or tbl_posts.parentcat_ids like '%," . $value->id . ",%' ) " )->row()->catcnt;
										
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active mqzcat" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->category_name .'</span>
                                            <span class="exam-count-box-list-count">'. $catcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
							
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
									
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list mqzsub" id="mqzsub'.$value->id.'" style="display: none;">';
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{	
                                    	  
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_exams` inner join tbl_posts on tbl_exams.id_exam = tbl_posts.quiz_id where quiz_type = 'MCQ' and ( id_course = " . $subval->id . " or tbl_posts.parentinnercat_ids like '%," . $subval->id . ",%' ) " )->row()->subcatcnt;  
                                    	  
                                    	/*    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_exams` where quiz_type = 'MCQ' and id_course = " . $subval->id )->row()->subcatcnt;
                                    	*/
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active mcqsuba" id="'. $subval->id .'">
                                            <span class="exam-count-box-list-text">'. $subval->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
									
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
								
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{
                                    
											$subsub = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $subval->id )->result();
											
											if( !empty( $subsub ) )
											{	
												echo '<div class="exam-count-box-list mcqsubsub" id="mcqsubsub'. $subval->id .'" style="display: none;">';
												
												foreach( $subsub as $key => $subsubval )
												{	
												    
												    
										$sscnt = $this->db->query( "SELECT count( * ) as sscnt FROM `tbl_exams` inner join tbl_posts on tbl_exams.id_exam = tbl_posts.quiz_id where quiz_type = 'MCQ' and ( id_subsubcat = " . $subsubval->id . " or tbl_posts.parentsubcat_ids like '%," . $subsubval->id . ",%' ) " )->row()->sscnt;		    
												/*	
												$sscnt = $this->db->query( "SELECT count( * ) as sscnt FROM `tbl_exams` where quiz_type = 'MCQ' and id_subsubcat = " . $subsubval->id )->row()->sscnt;
												*/
												
												/*
												echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
												*/
												
												echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $subsubval->id .'">
													<span class="exam-count-box-list-text">'. $subsubval->title .'</span>
													<span class="exam-count-box-list-count">'. $sscnt .'</span>
												</a>';
												
												}
												
												echo '</div>';
											}
									
                                    	}                                    	
                                    
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">Pictorial Quiz</span>
                            <span class="exam-count"><?=$pqqz?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
							
								<div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $cat = $this->db->query( "SELECT * FROM `tbl_categories`" )->result();
                                    
                                    if( !empty( $cat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $cat as $key => $value )
                                    	{	
                                    	    
										//echo "SELECT count( * ) as catcnt FROM `tbl_exams` where quiz_type = 'pictorial' and id_cat = " . $value->id ;

											
                                    	$catcnt = $this->db->query( "SELECT count( * ) as catcnt FROM `tbl_exams` where quiz_type = 'pictorial' and id_cat = " . $value->id )->row()->catcnt;
										
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active piqcat" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->category_name .'</span>
                                            <span class="exam-count-box-list-count">'. $catcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
							
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
									
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list piqsub" id="piqsub'.$value->id.'" style="display: none;">';
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{	
                                    	    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_exams` where quiz_type = 'pictorial' and id_course = " . $subval->id )->row()->subcatcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active piqsuba" id="'. $subval->id .'">
                                            <span class="exam-count-box-list-text">'. $subval->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
									
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
								
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{
                                    
											$subsub = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $subval->id )->result();
											
											if( !empty( $subsub ) )
											{	
												echo '<div class="exam-count-box-list piqsubsub" id="piqsubsub'. $subval->id .'" style="display: none;">';
												
												foreach( $subsub as $key => $subsubval )
												{	
													
												$sscnt = $this->db->query( "SELECT count( * ) as sscnt FROM `tbl_exams` where quiz_type = 'pictorial' and id_subsubcat = " . $subsubval->id )->row()->sscnt;
												
												/*
												echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
												*/
												
												echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $subsubval->id .'">
													<span class="exam-count-box-list-text">'. $subsubval->title .'</span>
													<span class="exam-count-box-list-count">'. $sscnt .'</span>
												</a>';
												
												}
												
												echo '</div>';
											}
									
                                    	}                                    	
                                    
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">Textual Quiz</span>
                            <span class="exam-count"><?=$txtqz?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
							
								<div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $cat = $this->db->query( "SELECT * FROM `tbl_categories`" )->result();
                                    
                                    if( !empty( $cat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $cat as $key => $value )
                                    	{	
                                    	    
										//echo "SELECT count( * ) as catcnt FROM `tbl_exams` where quiz_type = 'textual' and id_cat = " . $value->id ;

											
                                    	$catcnt = $this->db->query( "SELECT count( * ) as catcnt FROM `tbl_exams` where quiz_type = 'textual' and id_cat = " . $value->id )->row()->catcnt;
										
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active askcat" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->category_name .'</span>
                                            <span class="exam-count-box-list-count">'. $catcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
							
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
									
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list asksub" id="asksub'.$value->id.'" style="display: none;">';
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{	
                                    	    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_exams` where quiz_type = 'textual' and id_course = " . $subval->id )->row()->subcatcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active asksuba" id="'. $subval->id .'">
                                            <span class="exam-count-box-list-text">'. $subval->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
									
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
								
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{
                                    
											$subsub = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $subval->id )->result();
											
											if( !empty( $subsub ) )
											{	
												echo '<div class="exam-count-box-list asksubsub" id="asksubsub'. $subval->id .'" style="display: none;">';
												
												foreach( $subsub as $key => $subsubval )
												{	
													
												$sscnt = $this->db->query( "SELECT count( * ) as sscnt FROM `tbl_exams` where quiz_type = 'textual' and id_subsubcat = " . $subsubval->id )->row()->sscnt;
												
												/*
												echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
												*/
												
												echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $subsubval->id .'">
													<span class="exam-count-box-list-text">'. $subsubval->title .'</span>
													<span class="exam-count-box-list-count">'. $sscnt .'</span>
												</a>';
												
												}
												
												echo '</div>';
											}
									
                                    	}                                    	
                                    
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>

                </div>
                
                <div id="users-post" class="tab-pane">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="admin-count-box">                                
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">Quiz Attempted</p>
                                            <p class="admin-count-small-box-count"><?=$qzatt?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">Questions Attempted</p>
                                            <p class="admin-count-small-box-count"><?=$queatt?></p>
                                        </div>
                                    </div>                                    
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">Avg. Score / Out Of</p>
                                            <p class="admin-count-small-box-count"><?=$avgscore?> / <?=$avgoutof?></p>
                                        </div>
                                    </div>
									<div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">Quiz Exit</p>
                                            <p class="admin-count-small-box-count"><?=$qzexit?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">Quiz Attempted</span>
                            <span class="exam-count"><?=$qzatt?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
							
								<div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $cat = $this->db->query( "SELECT * FROM `tbl_categories`" )->result();
                                    
                                    if( !empty( $cat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $cat as $key => $value )
                                    	{	
                                    	    
                                    	$catcnt = $this->db->query( "SELECT count( * ) as catcnt FROM `tbl_quizresults` inner join tbl_exams on tbl_quizresults.quizid = tbl_exams.id_exam where tbl_exams.id_cat = " . $value->id )->row()->catcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active qatcat" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->category_name .'</span>
                                            <span class="exam-count-box-list-count">'. $catcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
							
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
									
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list qzatsub" id="qzatsub'.$value->id.'" style="display: none;">';
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{	
                                    	    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_quizresults` inner join tbl_exams on tbl_quizresults.quizid = tbl_exams.id_exam where tbl_exams.id_course = " . $subval->id )->row()->subcatcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active qzatsuba" id="'. $subval->id .'">
                                            <span class="exam-count-box-list-text">'. $subval->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
									
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
								
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{
                                    
											$subsub = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $subval->id )->result();
											
											if( !empty( $subsub ) )
											{	
												echo '<div class="exam-count-box-list qzatsubsub" id="qzatsubsub'. $subval->id .'" style="display: none;">';
												
												foreach( $subsub as $key => $subsubval )
												{	
													
												$sscnt = $this->db->query( "SELECT count( * ) as sscnt FROM `tbl_quizresults` inner join tbl_exams on tbl_quizresults.quizid = tbl_exams.id_exam where tbl_exams.id_subsubcat = " . $subsubval->id )->row()->sscnt;
												
												/*
												echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
												*/
												
												echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $subsubval->id .'">
													<span class="exam-count-box-list-text">'. $subsubval->title .'</span>
													<span class="exam-count-box-list-count">'. $sscnt .'</span>
												</a>';
												
												}
												
												echo '</div>';
											}
									
                                    	}                                    	
                                    
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
		

        <!-- new dashboard end -->
          
        
        
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

