<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>TGM Superadmin</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?= site_url() ?>assets/admin/plugins/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= site_url() ?>assets/admin/plugins/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?= site_url() ?>assets/admin/plugins/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/plugins/swal/sweetalert.css">
  <link rel="stylesheet" href="<?= site_url() ?>assets/admin/css/AdminLTE.min.css">
  <link rel="stylesheet" href="<?= site_url() ?>assets/admin/css/custom.css">
  <link rel="stylesheet" href="<?= site_url() ?>assets/admin/plugins/iCheck/square/blue.css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="<?= admin_url('') ?>"><b>The Great Mentor</b > </a>
  </div>
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to access your dashboard</p>

    <form class="process-form" action="<?= admin_url('login/signin') ?>" method="post">
      <div class="form-group has-feedback">
        <input type="email" class="form-control" placeholder="Email" name="username" id="username">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Password" name="password" id="password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <!--<div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>-->
        <div class="col-xs-4">
          <input type="hidden" name="action" value="login">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
      </div>
    </form>

    <a href="<?= admin_url('forgot-password') ?>">I forgot my password</a><br>

  </div>
</div>

<script src="<?= site_url() ?>assets/admin/plugins/jquery/dist/jquery.min.js"></script>
<script src="<?= site_url() ?>assets/admin/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?= site_url() ?>assets/admin/plugins/iCheck/icheck.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/swal/sweetalert.min.js"></script>
<script src="<?= site_url() ?>assets/admin/js/system.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
