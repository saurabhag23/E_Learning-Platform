
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
	 
        Add Level 2
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('menu') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('mentor') ?>">Level</a></li>
        <li class="active">Add Level 2</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('level2/addsub') ?>" method="post">
              <div class="box-body">
                
                <div class="form-group">
                  <label for="title">Level 2 Item Title</label>
                  <input type="text" class="form-control" id="title" placeholder="Title" name="title">
				  
				 <?php echo form_error('title'); ?>				  
                </div>
				
                <div class="form-group">
                  <label for="title">Category</label>
                  <?php
				  
					if( !empty( $tbl_categories ) )
					{
						$opt = array(''=>'Select');
						
						foreach( $tbl_categories as $key => $value )
						{
							$opt[ $value->id ] = $value->category_name;							
						}
						
						echo form_dropdown('catid', $opt, '', 'id="catid" class="form-control"');
					}
					
				  ?>
				  
				 <?php echo form_error('catid'); ?>				  
                </div>
				
                <div class="form-group">
                  <label for="title">Parent Level 1</label>
				  <div id="lev1div">
                  <?php
				  
					if( !empty( $tbl_mlevel1 ) )
					{
						$opt = array(''=>'Select');
						
/* 						foreach( $tbl_mlevel1 as $key => $value )
						{
							$opt[ $value->id ] = $value->title;							
						} */
						
						echo form_dropdown('l1_id', $opt, set_value( 'FK_Product_Category' ), 'id="l1_id" class="form-control"');
					}
					
				  ?>
				  </div>
				 <?php echo form_error('l1_id'); ?>				  
                </div>

                <div class="form-group">
                  <label for="url">Url Link</label>
                  <input type="text" class="form-control" id="url" placeholder="Url" name="url">
				  <?php echo form_error('url'); ?>				  
                </div>

                <div class="form-group">
                  <label for="order">Order</label>
				  <div id="l2ord">
                  <?php
				  	$opt = array( "" => "Select" );
					
/* 					for( $i  = 1; $i < 11 ; $i++ )
						$opt[ $i ] = $i ; */
	
					echo form_dropdown( 'order', $opt, '', 'id="order" class="form-control"' );
				  ?>
				  </div>
				  <?php echo form_error('order'); ?>
                </div>
				
                <div class="form-group">
                  <label for="order">Status</label>
                  <?php
					$opt = array( "" => "Select", "1" => "Active", "0" => "Inactive" );
					
					echo form_dropdown( 'status', $opt, '', 'id="status" class="form-control"' );
				  ?>
				  <?php echo form_error('status'); ?>
                </div>
				
                <div class="form-group">
                  <label for="order">Add Featured Post</label> <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"> <span class="glyphicon glyphicon-plus"></span> </button>

				  <br>
					<span id="fpost1_nm"></span>
					<br>
					<span id="fpost2_nm"></span>
					<br>
					<span id="fpost3_nm"></span>
					<br>
					<span id="fpost4_nm"></span>
					
					<input type="hidden" name="fpost1" id="fpost1" value="" />
					<input type="hidden" name="fpost2" id="fpost2" value="" />
					<input type="hidden" name="fpost3" id="fpost3" value="" />
					<input type="hidden" name="fpost4" id="fpost4" value="" />

                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="insert">
				<input type="hidden" name="role" value="<?=$this->uri->segment('4')?>">
                <button type="submit" class="btn btn-primary btn-sm pull-right btn-green">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Select Article</h4>
			</div>
			<div class="modal-body">
				
				<label for="order">Article</label>
				<select class="form-control" name="artid" id="artid" >
					<option value="">Select</option>
					<?php
					foreach($articles as $article)
					{
					?>
					  <option value="<?=$article->id?>"><?=$article->topic_title?></option>
					<?php
					}
					?>
					
				</select>
				
				<label for="order">Order</label>
				<select class="form-control" name="artord" id="artord" >
					<option value="">Select</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					
				</select>				
				
				<input type="hidden" name="recid" id="recid" value="1" />

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" id="recsub">Ok</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>

	</div>
</div>
