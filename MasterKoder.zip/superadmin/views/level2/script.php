<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
    $('#level2Table').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('level2/get_all_level2') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
							{ "data" : "id"},
							{ "data" : "title"},
                           { "data" : "lev1tit"},
                           { "data" : "l3count"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Blocked </span>';
                                          } 
										  else if (data == -1){
                                              return '<span class="label label-warning"> Not approved </span>';
                                          } 
                                        }},
                           { "data" : "action", "sortable": false}],
    });
  });
  function refreshlevel2Table(){
    $('#level2Table').DataTable().draw();
  }
  
	$(document).ready( function() {

		$("#myModal").on("click", "#recsub", function(){
			
			var artid = $('#artid').val();
			var artnm = $('#artid option:selected').text();
			var artord = $('#artord').val();
			
			console.log( 'artid:' + artid );
			console.log( 'artnm:' + artnm );
			console.log( 'artord:' + artord );
			
			$('#fpost' + artord).val( artid );
			$('#fpost'+artord+'_nm').text( 'Article ' + artord + ' - ' + artnm );
			
		});
		
		$("body").on("change", "#l1_id", function(){
			console.log( 'l1_id click' );
			var l1_id = $(this).val();
			var corder = $('#corder').val();
			var cl1_id = $('#cl1_id').val();
			
			$.ajax({
						url:"<?=admin_url('level2/get_l2ord')?>",
						type: "POST",
						data:{l1_id: l1_id, cl1_id: cl1_id, corder: corder},
						 success: function (res) {

								console.log( res );
													
								$("#l2ord").html( res );
								
						 }
			});		

		});	

		
		$("body").on("change", "#catid", function(){
			console.log( 'catid click' );
			var catid = $(this).val();
			var l1_id = $('#l1_id').val();

			$.ajax({
						url:"<?=admin_url('level2/get_l1')?>",
						type: "POST",
						data:{catid: catid, l1_id: l1_id},
						 success: function (res) {

								console.log( res );
													
								$("#lev1div").html( res );
								
						 }
			});		

		});
		
		$('#catid').trigger('change');	
		$('#l1_id').trigger('change');	

	} );
  
</script>