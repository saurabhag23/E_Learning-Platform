<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
    $('#topicTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[3, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('notes/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
		  				   { "data" : "title" },
						   { "data" : "category_name" },
                          
                           { "data" : "added_date"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },
                           { "data" : "action", "sortable": false}],
    });
  });
  function refreshTopicTable(){
    $('#topicTable').DataTable().draw();
  }
 function geteaxamsubcategory()
  {
  	
  	 var catid = $('#examcat').val();
	
	   $.ajax({
		    url: "<?= admin_url('subsubcategory/getsubcategory') ?>",
		    type: "POST",
		    data: {catid : catid}, 
            success: function(data){
            $('#examsubcat').html(data);
            }
		});
  }
</script>

  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>  
  <script>
    initSample();
  </script>