
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Update user
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('users') ?>">Users</a></li>
        <li class="active">Update user</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('users/update') ?>" method="post">
              <div class="box-body">
                

                <div class="form-group">
                  <label for="first_name">First Name</label>
                  <input type="text" class="form-control" id="first_name" placeholder="First Name" name="first_name" value="<?=  $row->user_fname ?>">
                </div>

                <div class="form-group">
                  <label for="last_name">Last Name</label>
                  <input type="text" class="form-control" id="last_name" placeholder="Last name" name="last_name" value="<?=  $row->user_lname ?>">
                </div>

                <div class="form-group">
                  <label for="email">Email address</label>
                  <input type="email" class="form-control" id="email" placeholder="Email" name="email" value="<?=  $row->user_email ?>">
                </div>

                <div class="form-group">
                  <label for="password">Password</label>
                  <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                </div>
                
                <div class="form-group">
                  <label for="password">Re-Enter Password</label>
                  <input type="password" class="form-control" id="confirm_password" placeholder="Password" name="confirm_password">
                </div>
                
				 <div class="form-group">
                  <label for="password">Mobile Number</label>
                  <input type="number" class="form-control" id="contactnum" placeholder="Mobile Number" name="contactnum" value="<?=  $row->ContactNo ?>">
                </div>
                
                <div class="form-group">
                  <label for="password">Location</label>
                  <input type="text" class="form-control" id="location" placeholder="Location" name="location" value="<?=  $row->location ?>">
                </div>
                
                <div class="form-group">
                  <label for="exam_category">Exam Preparing For</label>
                  
                  <!--
                        <select class="form-control examcat" multiple="multiple" id="exam_category" name="exam_category[]" >
						
						<option value="">Select Super Category</option>
						<?php
						/*
						foreach($examcats as $examcats)
						{
						?>
						  <option value="<?=$examcats->id?>"><?=$examcats->category_name?></option>
						<?php
						}
						*/
						?>
						
                        </select>
                        -->
                        
                        <?php
                      
                        
                        ?>
                        
                        <select class="form-control examcat"  multiple="multiple" id="exam_category" name="exam_category[]" onChange="geteaxamsubcategory()">
    						<option value="">Select Super Category</option>
    						<?php
    						$catid = explode(',',$row->exam_category);
    						foreach($examcats as $examcat)
    						{
    						      if(in_array($examcat->id,$catid ))
    							   {
    								 $sel = "selected='selected'";
    							   }
    							   else
    							   {
    								 $sel ="";
    							   }
    						?>
    						  <option value="<?=$examcat->id?>" <?=$sel?>><?=$examcat->category_name?></option>
    						<?php
    						}
    						?>
						
                        </select>
                  
                </div>
                
                <div class="form-group">
                  <label for="user_status">Status</label>
                 
                  <?php
                  	$opt = array( "" => "Select", "1" => "Active", "0" => "In Active" );
	
	                echo form_dropdown( 'user_status', $opt, $row->user_status, 'id="user_status" class="form-control"' );
                  ?>
                  
                </div>
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="<?=  $row->id ?>">
                <button type="submit" class="btn btn-primary btn-sm pull-right btn-green">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
