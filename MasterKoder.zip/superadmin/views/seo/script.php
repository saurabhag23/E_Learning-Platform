<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/select2/dist/js/select2.full.min.js"></script>


<script>

	/* posting image files through ajax */		
	
	$('#subbut').click( function() {
		
    var form = $('#uploadfrm')[0];

	// Create an FormData object 
	var data = new FormData(form);

	// If you want to add an extra field for the FormData
	// data.append("CustomField", "This is some extra data, testing");

	// disabled the submit button
	// $("#btnSubmit").prop("disabled", true);

	$.ajax({
		type: "POST",
		enctype: 'multipart/form-data',
		url: "<?php echo admin_url('upload/up'); ?>",
		data: data,
		processData: false,
		contentType: false,
		cache: false,
		timeout: 600000,
		success: function (res) {
			
					console.log( "res");
					console.log( res );
					var obj = JSON.parse( res );
					
					if( obj.has_error == 1 )
					{
						$('#ufileerr').html(obj.error.ufile).show();
					}
					else
					{
						$('#ufileerr').html('').hide();
						$('#url').val(obj.uurl);
					}	
									
		},
		error: function (e) {

			// $("#result").text(e.responseText);
			console.log("ERROR : ", e);
			// $("#btnSubmit").prop("disabled", false);

		}
	});
		
	} );// click end
	
	function getseo(){
		
		var article_id = $('#article_id').val();		
		console.log("article_id : " + article_id);
		
		var quiz_id = $('#quiz_id').val();		
		console.log("quiz_id : " + quiz_id);
		
		$.ajax({
					url:"<?php echo admin_url(''); ?>seo/get_seodata/",
					type: "POST",
					data:{article_id: article_id, quiz_id: quiz_id},
					 success: function (res) {

							console.log( res );
							var obj = JSON.parse( res ) ;
							if( obj.length > 0 )
							{
								console.log( 'obj: ' +  obj[0].article_id );
													
								$('#meta_title').val( obj[0].meta_title );
								$('#meta_desc').val( obj[0].meta_desc );
								$('#meta_key').val( obj[0].meta_key );
							}
							else
							{
								$('#meta_title').val( '' );
								$('#meta_desc').val( '' );
								$('#meta_key').val( '' );
							}							
					 }
		});
		
	}
		
	$('#type').change( function() {
	
		var type = $(this).val();
		
		console.log("type : " + type);
		
		if( type == 'P' )
		{
			$('#postdiv').show();
			$('#quizdiv').hide();
		}
		else
		{
			$('#postdiv').hide();
			$('#quizdiv').show();
		}	
	
	});	
		
	$('#subbut').click( function() {
		
		var form_data = $("#uploadfrm").serialize();
				
		$.ajax({
					url:"<?php echo admin_url('')?>seo/updatemeta",
					type:"POST",
					data:form_data,
					success: function(res)
					{
						$('#metmsg').show();
												
						setTimeout(function(){ 
						
							$('#metmsg').hide();
							
							$("#uploadfrm").find('select,input, textarea').val('');

						}, 3000); 
						
					}
		});
		
	});	
		
	$('#copyurl').click( function() {
		
	   var copyText = document.getElementById("url");

	   /* Select the text field */
	   copyText.select();
	  
	   /* Copy the text inside the text field */
	   document.execCommand("copy");
		
	} );// click end
	


</script>

  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>  
  <script>
    initSample();
  </script>