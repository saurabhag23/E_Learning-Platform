
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><!--<i class="fa fa-dashboard"></i>-->Home</a></li>
        <li><a href="<?= admin_url('upload') ?>">Seo</a></li>
        <li class="active">Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-lg-12 col-xs-12 col-md-12">

            <div class="box box-solid bc-transparent box-sd">
                <div class="box-header with-border">
                  <i class="fa fa-book"></i>

                  <h3 class="box-title">Seo</h3>
                </div>
                <!-- /.box-header -->
			
<style>			

.error {
    color: #b94a48;
}

</style>			
			
			<?php echo form_open_multipart( admin_url('upload/up'), array( 'id' => 'uploadfrm' ));?>

                <div class="box-body" style="margin-top: 20px;">
				
				
                <div class="form-group">
					<label for="ufile"> Type </label>
					<?php

					$opt = array( "" => "Select", "P" => "Post", "Q" => "Quiz" );
					
					echo form_dropdown( 'type', $opt, '', 'id="type" class="form-control"' );

					?>
					<div class="control-label label error" id="ufileerr" style="display: none;text-align: left;"></div>
				  	<!--<label class="control-label error" id="ufile_err" style="display: none;color: #b94a48;">This field is required.</label>		  -->
                </div>
				
                <div class="form-group" id="quizdiv" style="display: none;">
					<label for="ufile"> Quiz </label>
					<?php

					if( !empty( $tbl_exams ) )
					{
						$opt = array( '' => 'Select' );
						
						foreach( $tbl_exams as $key => $value )
						{
							$opt[ $value->id_exam ] = $value->exam_name;							
						}
						
						echo form_dropdown('quiz_id', $opt, set_value( 'quiz_id' ), 'id="quiz_id" class="form-control" onChange="getseo()"');
					}

					?>
					<div class="control-label label error" id="ufileerr" style="display: none;text-align: left;"></div>
				  	<!--<label class="control-label error" id="ufile_err" style="display: none;color: #b94a48;">This field is required.</label>		  -->
                </div>
				
                <div class="form-group" id="postdiv" style="display: none;">
					<label for="ufile"> Post </label>
					<?php
					
					if( !empty( $tbl_articelepost ) )
					{
						$opt = array( '' => 'Select' );
						
						foreach( $tbl_articelepost as $key => $value )
						{
							$opt[ $value->id ] = $value->topic_title;							
						}
						
						echo form_dropdown('article_id', $opt, set_value( 'article_id' ), 'id="article_id" class="form-control" onChange="getseo()"');
					}

					?>
					<div class="control-label label error" id="ufileerr" style="display: none;text-align: left;"></div>
				  	<!--<label class="control-label error" id="ufile_err" style="display: none;color: #b94a48;">This field is required.</label>		  -->
                </div>
				
                <div class="form-group">
					
					<label for="url"> Meta Title </label>
					<input type="text" class="form-control" id="meta_title" placeholder="" name="meta_title" required >
				
					
                </div>
				
               <div class="form-group">
					
					<label for="url"> Meta Description </label>
				
					<textarea class="form-control" id="meta_desc" placeholder="" name="meta_desc" required></textarea>
					
                </div>
				
				<div class="form-group">
					
					<label for="url"> Meta Key </label>
					<input type="text" class="form-control" id="meta_key" placeholder="" name="meta_key" required >
				
					
                </div>
				
              <div class="box-footer">
			  
				<span style="color: #00B050;display: none;" id="metmsg"> Meta updated successfully </span>
			  
                <input type="hidden" name="action" value="insert">
				<input type="hidden" name="role" value="<?=$this->uri->segment('4')?>">
                <button type="button" id="subbut" class="btn btn-primary btn-sm pull-right btn-green">Update</button>
              </div>
					
                <!-- /.box-body -->
              </div>
			
			</form>
			  
          </div>





        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

