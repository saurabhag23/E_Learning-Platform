<style type="text/css">
.modal-body img{
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 30%;
}
</style>
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add new Quiz
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('courses') ?>">Exam</a></li>
        <li class="active">Add new Exam</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
              <div class="box-body">
                <div class="col-md-12">
                    <div class="stepwizard">
                        <div class="stepwizard-row setup-panel">
                            <div class="stepwizard-step">
                                <a href="#step-1" type="button" class="btn btn-success btn-circle">1</a>
                                <p>Quiz details</p>
                            </div>
                            <div class="stepwizard-step">
                                <a href="#step-2" type="button" class="btn btn-default btn-circle disabled">2</a>
                                <p>Question details</p>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
          </div>
          <div class="col-md-12">
            <form class="process-form-img-editor" action="<?= admin_url('dailyquiz/insert_step_1')?>" method="post" role="form">
                <div class="row setup-content" id="step-1">
                  <div class="box box-primary">
                      <div class="box-header with-border">
                          <i class="fa fa-book"></i>
                          <h3 class="box-title">Quiz Details</h3>
                      </div>
                      <div class="box-body">
					  
                        <div class="col-xs-12">
						<div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label for="first_name">Super Category</label>
                        
						<select class="form-control examcat" multiple="multiple" name="examcat[]" id="examcat"  onChange="geteaxamsubcategory()">
						<option value="">Select Super Category</option>
						<?php
						foreach($examcats as $examcats)
						{
						?>
						  <option value="<?=$examcats->id?>"><?=$examcats->category_name?></option>
						<?php
						}
						?>
						
                        </select>
                      </div>
                  </div>
				  <div class="col-sm-12">
                    <div class="form-group">
                        <label for="first_name"> Category</label>
                        
						<select class="form-control examsubcat" id="subcat"  multiple="multiple" name="subcat[]" onChange="getsubsubcats()">
						<option value="">Select Category</option>
						
						
                        </select>
                      </div>
                  </div>
          			<div class="col-sm-12">
            						<div class="form-group">
            							 <label for="first_name">Sub Category</label>
                        
											<select class="form-control subsub" multiple="multiple" id="subsub" name="subsub[]" >
											<option value="">Select  Sub Category </option>
											
						                    </select>
            						</div>
          					   </div>
          		 </div>
				  
               
				         
								  
				
                             <div class="row">
          						<div class="col-sm-12">
            						<div class="form-group">
            							<label for="exam_name">Quiz Name</label>
            								<input type="text" class="form-control" id="exam_name" placeholder="Exam Name" name="exam_name">
            						</div>
          					   </div>
          						</div>  

                            <div class="row">
                              <div class="col-sm-12">
                              <div class="form-group">
                                <label class="control-label">Description</label>
                                <textarea id="editor" name="exam_description" class="form-control" placeholder="Exam description" rows="15"></textarea>
                                </div>
                              </div>
                            </div> 


          									<div class="row">
          									  

          									  <div class="col-sm-4">
            										<div class="form-group">
            											<label class="control-label">Total Questions</label>
            											<input type="number" class="form-control" id="total_questions" placeholder="Total Questions" name="total_questions" min="1">
          										  </div>
          									  </div>

                              <div class="col-sm-4">
                                <div class="form-group">
                                  <label for="first_name">Exam Duration</label>
                                  <div class="input-group input-group-md">
                                    <input type="number" class="form-control" id="total_time" placeholder="Total Time" name="total_time" min="1">
                                    <div class="input-group-btn">
                                      <select class="btn btn-default btn-flat form-control-1" name="duration_slug" id="duration_slug">
                                        <option value="">Select</option>
                                        <option value="minutes">Minutes</option>
                                        <option value="hours">Hours</option>
                                      </select>
                                    </div>                        
                                  </div>
                                </div>
                              </div>

                              
                              <div class="col-sm-4">
                                <div class="form-group">
                                  <label for="meta_tags">Coins per Correct Question</label>
                                 <input type="number" class="form-control" name="coin" id="coin">
                                </div>
            									</div>
                            </div>
							<div class="row">
          									  <div class="col-sm-4">
            										<div class="form-group">
            											<label class="control-label">Marks per Question</label>
            											<input type="number" class="form-control" id="marks" name="marks" placeholder="Marks"style="max-width: 100%" value="1">
          										  </div>
          									  </div>

          									  <div class="col-sm-4">
            										<div class="form-group">
            											<label class="control-label">Negative Marks Per Questions</label>
            											<input type="number" class="form-control" step="0.01"  id="negativemarks" value="0" placeholder="Negative Marks" name="negativemarks" min="0">
          										  </div>
          									  </div>

                              <div class="col-sm-4">
                                <div class="form-group">
                                  <label for="first_name">Difficulty Level</label>
                                 
                                     <select class="form-control" name="diff_level" id="diff_level">
                                        <option value="">Select</option>
                                        <option value="Easy">Easy</option>
										 <option value="Medium">Medium</option>
                                        <option value="Difficult">Difficult</option>
                                      </select>
                               
                                </div>
                              </div>

                              
                              
                            </div>
							<div class="row">
								<div class="col-sm-4">
            										<div class="form-group">
            											<label class="control-label">Featured Image</label>
            											<input type="file" class="btn btn-default btn-flat" id="featured_image" name="featured_image" >
													 <a href="#" class="show-img-popup" data-src="<?= base_url('assets/images/default_quiz.png') ?>"  data-toggle="modal" data-target="#infoModal">Default-image</a>
          										  </div>
          									  </div>
							   <div class="col-sm-8">
            										<div class="form-group">
            											<label class="control-label">Image Url</label>
            											<input type="text" class="form-control" id="imgurl" name="imgurl" >
          										  </div>
          									  </div>
							</div>
                            <div class="row">
          						<!--<div class="col-sm-6">
									<div class="form-group">
										<label class="" style="width:100%">&nbsp;</label>
										
										<label class="form-check-label" for="exampleCheck1">
											<input type="checkbox" class="form-check-input" name="newffedpost" value="1">
										Add Quiz to Newsfeed </label>
									</div>
								  </div>-->
							  <div class="col-sm-12">
								<div class="form-group">
									<label class="" style="width:100%">&nbsp;</label>
									
									<label class="form-check-label" for="exampleCheck1">
										<input type="checkbox" class="form-check-input" name="featured" value="1">
									Mark as Featured Quiz</label>
								</div>
							  </div>
          						</div>

                            <div class="row">
                              <div class="col-xs-12 ">
							
                               <div class="loadimg" style="display:none;">
							<img src="<?= base_url('assets/images/reload.gif') ?>" style="margin-left:45%;" width="50px;" height="50px;">
						   </div>
                                <input type="hidden" name="action" value="exam-step1">
                                <input type="hidden" name="exam_id" class="exam_id" value="">
                                <input class="btn btn-primary btn-sm pull-right icon" type="submit" name="step1" value="Next">
                              </div>
                            </div>
                        </div>
                      </div>
                  </div>
                </div>
            </form>
          </div>  

          <div class="setup-content" id="step-2">
            <form class="process-form-img-editor" id="secondstep" action="<?= admin_url('dailyquiz/insert_step_2') ?>" method="post" role="form">    
              <div class="box box-primary">
                <div class="box-header with-border">
                    <i class="fa fa-book"></i>
                    <h3 class="box-title">Add Questions</h3>
                </div>

                  <div class="box-body">
                      <div class="col-xs-12">

                          <div class="row">
                              <div class="col-sm-12">
                                <div class="form-group">
                                  <label for="first_name">Question</label>
                                  
								    <textarea class="form-control" name="question_name" id="question_name" rows="3"   placeholder="Question"></textarea>
                                  
                                    
                                      <input type="file" id="question_image" name="question_image" >
                                                    
                               
                                </div>
                              </div>
                          </div>

                          <div class="row">
                              <div class="col-sm-6">
                                <div class="form-group">
                                  <label for="first_name">First option</label>
                                  
                                     <textarea name="option_1" id="option_1" class="form-control abc" placeholder="First option" /></textarea>
                                   
                                      <input type="file" id="option_1_image" name="option_1_image" >
                                                      
                                
                                </div>
                              </div>

                              <div class="col-md-6">
                                <div class="form-group">
                                  <label for="first_name">Second option</label>
                       
                                     <textarea name="option_2" id="option_2" class="form-control abc" placeholder="Second option" /></textarea>
                                      <input type="file" id="option_2_image" name="option_2_image">
                                                        
                                
                                </div>
                              </div>
                          </div>

                          <div class="row">
                              <div class="col-md-6">
                                <div class="form-group">
                                  <label for="first_name">Third option</label>
                                
                                    <textarea name="option_3" name="option_3" id="option_3" class="form-control" placeholder="Third option" /></textarea>
                                    <input type="file" id="option_3_image" name="option_3_image" >
                                    
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="form-group">
                                  <label for="first_name">Fourth option</label>
                                  
                                    <textarea name="option_4" id="option_4" class="form-control" placeholder="Third option" /></textarea>
                                     <input type="file" id="option_4_image" name="option_4_image" >
                                   
                                </div>
                              </div>
                          </div>
						<div class="row">
                              <div class="col-md-6">
                                <div class="form-group">
                                  <label for="first_name">Fifth option</label>
                                
                                    <textarea  name="option_5" id="option_5" class="form-control" placeholder="Fifth option" /></textarea>
                                    <input type="file" id="option_4_image" name="option_4_image" >
                                    
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="form-group">
                                  <div class="form-group">
                                  <label for="first_name">Explanation</label>
                                    <textarea rows="3" cols="50" name="explanation" id="explanation" class="form-control" placeholder="Explanation"> </textarea>                      
                                </div>
                                   
                                </div>
                              </div>
                          </div>
                          <div class="row">
                              <div class="col-md-6">
                                <div class="form-group">
                                  <label class="control-label">Answer</label>
                                  <select class="form-control" name="answer_option" id="answer_option">
                                      <option value="">Select</option>
                                      <option value="1">First option</option>
                                      <option value="2">Second option</option>
                                      <option value="3">Third option</option>
                                      <option value="4">Fourth option</option>
									   <option value="5">Fifth option</option>
                                    </select>
                                </div>
                              </div>
                          </div>
                        

                          <div class="row">
                              <div class="col-md-12">
                            <div class="loadimg" style="display:none;">
							<img src="<?= base_url('assets/images/reload.gif') ?>" style="margin-left:45%;" width="50px;" height="50px;">
						   </div>
                                <input type="hidden" name="action" value="exam-step2">
                                <input type="hidden" name="exam_id" class="exam_id" value="">
                                <input class="btn btn-primary btn-sm pull-right " type="submit" name="step2" value="Add" >
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
            </form>

            <div class="box box-primary">
                <div class="box-header with-border">
                    <i class="fa fa-book"></i>
                    <h3 class="box-title">Added Questions</h3>
                </div>
                <div class="box-body">
                    <div class="col-xs-12">
                      <table id="questionsTable" class="table table-responsive table-bordered table-striped" style="width: 100%; min-width: 100%">
                        <thead>
                        <tr>
                          <th>Question</th>
                          <th>Added on</th>
                          <th>Status</th>
                          <th width="10%">Actions</th>
                        </tr>
                        </thead>
                      </table>
                    </div>
                </div>
            </div>

            <form class="process-form" action="<?= admin_url('dailyquiz/insert_step_3') ?>" method="post" role="form">
              <div class="box box-primary">
                  <div class="box-body">
                      <div class="col-xs-12">
                          <div class="row">
                              <div class="col-md-12">
                                <input type="hidden" name="action" value="exam-step3">
                                
                                <input type="hidden" name="exam_id" class="exam_id" value="">
                                <input class="btn btn-success btn-sm pull-right" type="submit" name="step3" value="Finish">
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
            </form>
          </div>                          
          
           

                
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<div id="infoModal" class="modal fade" role="dialog" aria-labelledby="alertModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default cl_btn" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>