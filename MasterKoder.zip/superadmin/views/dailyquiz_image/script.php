<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/select2/dist/js/select2.full.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/wizard/wizard.js"></script>  

<script>
  $(function () {
    $('#examTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[4, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('dailyquiz/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [{ "data" : "exam_name"},
                           { "data" : "total_questions"},
                           { "data" : "exam_duration", render: function(data, type, row, meta) {
                                return data + ' ' + row.exam_duration_slug;
                            }
                           },
                           { "data" : "added_date"},
                            { "data" : "username"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },
                           { "data" : "action", "sortable": false}],
    });
  });
  function refreshExamTable(){
    $('#examTable').DataTable().draw();
  }

  $(function () {
    $('#questionsTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[3, 'desc']],
          "pageLength"  : 10,
          "ajax"        : { "url"       : "<?= admin_url('dailyquiz/get_all_questions', 1) ?>",
                            "dataType"  : "json",
                            "type"      : "POST",
                          },
          "columns"     : [{ "data" : "question_name"},
                           { "data" : "added_date"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },
                           { "data" : "action", "sortable": false}],
    });
  });
  function refreshQuestionsTable(){
    $('#questionsTable').DataTable().draw();
  }
  
  function geteaxamsubcategory()
  {
  	
  	var catid = $('#examcat').val();
	
	   $.ajax({
		    url: "<?= admin_url('posts/getsubcategory') ?>",
		    type: "POST",
		    data: {catid : catid}, 
            success: function(data){
            $('#subcat').html(data);
            }
		});
  }
 
   function getsubsubcats()
   {
  	 var subid = $('#subcat').val();

	   $.ajax({
		    url: "<?= admin_url('posts/getsubsub') ?>",
		    type: "POST",
		    data: {subid : subid}, 
            success: function(data){
			
            $('#subsub').html(data);
		     
            }
		});
   }
</script>

<script>

  initSample();
  
 
  $('.select2').select2({
    tags: true,
    tokenSeparators: [',', ' ']
  });
   $(".examcat").select2();
    $(".examsubcat").select2();
	 $(".subsub").select2();
</script>
 <script>
  jQuery('<div class="quantity-nav"><div class="quantity-button quantity-up"></div><div class="quantity-button quantity-down"></div></div>').insertAfter('.quantity input[type="number"]');
    jQuery('.quantity').each(function() {
      var spinner = jQuery(this),
        input = spinner.find('input[type="number"]'),
        btnUp = spinner.find('.quantity-up'),
        btnDown = spinner.find('.quantity-down'),
        min = input.attr('min'),
        max = input.attr('max');

        btnUp.click(function() {
          var value = input.val();
          if(value){
                var oldValue = parseFloat(input.val());
                if (oldValue >= max) {
                    var newVal = oldValue;
                } else {
                    var newVal = oldValue + 1;
                }
            } else {
                var newVal = 1;
            }
            spinner.find("input").val(newVal);
            spinner.find("input").trigger("change");
        });

        btnDown.click(function() {
            var value = input.val();
            if(value){
                var oldValue = parseFloat(input.val());
                if (oldValue <= min) {
                  var newVal = oldValue;
                } else {
                  var newVal = oldValue - 1;
                }
            }else{
                var newVal = 1;
            }
            spinner.find("input").val(newVal);
            spinner.find("input").trigger("change");
      });

    });
  </script>