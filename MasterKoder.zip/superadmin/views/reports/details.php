
<body class="hold-transition skin-blue sidebar-mini fixed">

<link rel="stylesheet" href="https://www.thegreatmentor.com/assets/css/style.css">

<div class="wrapper">
  <?php
  //error_reporting('0'); 
  $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Report Details
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('courses') ?>">Exam</a></li>
        <li class="active">Exam details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
           <div class="nav-tabs-custom cont">
                      
                      <div class="tab-content newsfeed">
                        <div class="tab-pane active" id="tab_1">
                          <table class="table table-responsive table-striped" style="width: 100%; min-width: 100%">
                              <thead>							  							  <tr>                                  <th width="20%">Report Details </th>                                  <td>								 								  </td>                                </tr>							  							   <tr>                                  <th width="20%">Report No. </th>                                  <td>								 <?=$row->id?>								  </td>                                </tr>																<tr>                                  <th width="20%">Report Title. </th>                                  <td>								 <?=$row->reason?>								  </td>                                </tr>																<tr>                                  <th width="20%">Category</th>                                  <td>								  <?php								  $postname = "";								  $url = "";								  if($row->pststus==4)								  {								  	echo 'Quiz';									$postname =$quiz->exam_name;									$url = base_url().'quiz/attend/'.$quiz->exam_slug;								  }								  elseif($row->pststus==6)								  {								  	echo 'Article';									$postname =$article->topic_title;									$url = base_url().'articles/details/'.$article->id;								  }								  elseif($row->pststus==3)								  {								  	echo 'MCQ';									$postname =$row->upadated_status;								  }								  else								  {								  	echo 'User Post';									$postname =$row->upadated_status;								  }								  ?>								  </td>                                </tr>																<tr>                                  <th width="20%">Reported By </th>                                  <td>								 <?=$row->username?>								  </td>                                </tr>																<tr>                                  <th width="20%">Reported On </th>                                  <td>								 <?=date('d M Y', strtotime($row->date))?>								  </td>                                </tr>																
							  <tr>                                  
								<th>Commented By / Posted By</th>                                  
								<td>
								<?php 
								
								
								if( !empty( $row->rpostid ) )
									echo $postres->uname;
								else
									echo $comres->cuname;
								
								
								?>
								</td>                                
							</tr>																
							  <tr>                                  
								<th>Commented On / Posted On</th>                                  
								<td>
								<?php 
								if( !empty( $row->rpostid ) )
									echo $postres->created;
								else
									echo $comres->ccreated;
								
								
								?>
								</td>                                
							</tr>																<!--								
								<tr>
                                  <th width="20%">Reporter Email </th>
                                  <td>
								 <?=$row->postermemail?>
								  </td>
                                </tr>                               
                                <tr>
                                  <th>Postname</th>
                                  <td><?=$postname?></td>
                                </tr>
								
								<?php
								if(!empty($url))
								{
								?>
                                <tr>
								<th>Link</th>
                                  <td><?=$url?></td>
								  </tr>
								<?php
								}
								?>
								
								<tr>
								<th>Comment</th>
                                <td><?=$row->comment?></td>
								</tr>								-->
								
							<!--<tr>
							<?php
							if($row->pststus==1||$row->pststus==3||$row->pststus==5)
							{
							?>
							   <th></th>
                               <td><a href="<?=admin_url('reports/deletepost/'.$row->postid.'')?>"><button type="button" class="btn btn-danger">Delete Post</button></a></td>
							<?php
							}
							?>
							</tr>-->
                              </thead>
                            </table>
							
							
							
<?php
/*
error_reporting(E_ALL);
ini_set('display_errors', 1);
*/		
		
if( !empty( $row->rpostid ) )
{		

	if(!empty($posts))
	{
/* echo "<hr><pre>result: ";
var_dump( $posts->result() );
exit; */

					$idex_arr = array();
					
					$postnum = 1;

                  	foreach( $posts->result() as $prow )
                  	{	
						// echo '<hr>postnum' . $postnum;
					
						// $quizposteddate = postdate($prow->created);
                  	    // $posteddate = postdate($prow->created);
						
						/* echo "<pre>row: ";
						var_dump( $prow ); */
						//exit;
						
						//echo $posteddate = postdate($prow->created);//exit;

                  	    // $posteddate = date("d F Y", strtotime($prow->created)) . " at " . date("h:i A", strtotime($prow->created));
						
						// $userid = $this->session->userdata('logged_user')->id;
						
						$post_type = '';
						
						$userid = 0;

						$posteddate = postdate($prow->created);
						
                  		$commentcount = $this->accountmodel->getcommentcount( $prow->postid );
	
/* echo "------article_id: ";
var_dump( $prow->article_id );  */
// exit; 

						if( $commentcount > 1 )
							$commentcount = $commentcount - 1; 
						
/* 						echo "------exam_subsubcat: ";
						var_dump( $prow->exam_subsubcat ); */

						if( !empty( $prow->exam_subsubcat ) )
							$subsubcategory = " in " . $this->accountmodel->getsubsubcat($prow->exam_subsubcat);
						else
							$subsubcategory = "";
						
						if( !empty( $prow->article_id ) && empty( $subsubcategory ) )
						{							
							$subsubcategory = " in " . $this->accountmodel->getsscatart( $prow->article_id );
						}
						

						
						// echo $prow->quiz_id ;
						
						if( !empty( $prow->quiz_id ) && empty( $subsubcategory ) )
						{							
							$subsubcategory = " in " . $this->accountmodel->getsscateid( $prow->quiz_id );
						}
						
						
/* 						echo "------subsubcategory: ";
						var_dump( $subsubcategory ); */

						
						if( !empty( $prow->id_role ) )
						{
							$role_name = $this->accountmodel->getrole_name($prow->id_role);
						}
						else
						{
							$role_name = 'User';

						}
						
						// $roleclass = ( $prow->id_role == 3 || $prow->id_role == 0 ) ? 'userp' : 'adminp' ;
						 
						if( $prow->id_role == 1 )
						{
							$roleclass = 'adminp';
						}
						else if( $prow->id_role == 2 )
						{
							$roleclass = 'mentorp';
						}
						else if( $prow->id_role == 3 || $prow->id_role == 0 )
						{
							$roleclass = 'userp';
						}
						 
						// echo '---' . $role_name;

						// print "".$this->db->last_query();//exit;
								
                  		$likecount    = $this->accountmodel->getlikecount($prow->postid);
						// print "<hr><pre>".$this->db->last_query();exit;
						$viewcount      = $this->accountmodel->getpviewcount($prow->postid);

                  		$comments     = $this->accountmodel->getpostcomments($prow->postid);
						
						// print "----comments" .$this->db->last_query();//exit;

                  		$liked    	  = $this->accountmodel->set_likes($prow->postid, $userid);
                  		$checkbookmark = $this->accountmodel->checkbookmark($prow->postid, $userid);
						// var_dump( $checkbookmark );exit;

                  		$checkreported = $this->accountmodel->checkreported($prow->postid, $userid);

						$saved = ( empty($checkbookmark) ) ? 0 : 1;
						$reported = ( empty($checkreported) ) ? 0 : 1;
						
						/* echo "<hr><pre>checkbookmark: ";
						var_dump( $checkbookmark );
						exit; */
						
                  		if($prow->logintype == 2)
                  		{
                  			$userimage = $prow->user_img;
                  		}
                  		elseif($prow->logintype == 3)
                  		{
                  			$userimage = $prow->user_img;
                  		}
                  		else
                  		{
                  			$userimage = base_url().$prow->user_img;
                  		}
						
						
						if($liked>0)
						{
							$likeimg = base_url().'assets/images/svg/like-blue.svg';
						}
						else
						{
							$likeimg = base_url().'assets/images/svg/like.svg';
						}
						
						$qry = 'select *, tbl_users.id as uid, tbl_users.user_img from tbl_tags inner join tbl_users on tbl_tags.tag_to = tbl_users.id where postid = ' . $prow->postid;
						
						// echo '----' . $qry;
						
						$res = $this->db->query( $qry )->result();
						
						$qry = 'SELECT count(*) as tagcnt FROM `tbl_tags` WHERE `postid` = '. $prow->postid .' ORDER BY `id` DESC';
						
						// echo '----' . $qry;
						
						$tagcnt = $this->db->query( $qry )->result();
						
						$tstr = '';
						
/* 						echo '----';
						var_dump( $tagcnt[0]->tagcnt );
						echo '----res';
						var_dump( $res );  */
						
						if( !empty( $res ) )
						{	
							$tstr = ' tagged ';
							$tagtit = '';
							/*					
							if( @$tagcnt[0]->tagcnt > 2 )
							{
							*/								

								foreach( $res as $rkey => $rvalue )
								{	
									// echo 'asdfasdfasdfasdf' . $rvalue->uid . ' - ' . @$res[0]->uid ;
									if( $rvalue->uid != @$res[0]->uid )
									{
										
										// echo 'asgzxcvzxcvzxcv' ;
										$tagtit .= '<tr><td><a href="'.base_url().'account/userprofile/'. $rvalue->uid .'" style="color: #280071 !important;padding: 0;"><img src="'. base_url() .''. $rvalue->user_img .'" class="img-responsive" alt="" style="width: 25px !important;height: auto !important;"></a></td><td><a href="'.base_url().'account/userprofile/'. $rvalue->uid .'" style="color: #280071 !important;padding: 0;">'. ucfirst( $rvalue->user_fname ) . ' ' . ucfirst( $rvalue->user_lname ) .' </a></td></tr>'; 									
									}
										// $tagtit .= ucfirst( $rvalue->user_fname ) . ' ' . ucfirst( $rvalue->user_lname ) . ','; 									;
								}
								
								// $tagtit = trim( $tagtit, ', ' );
								
								// $tagtit = '';
								
								// echo '<pre>' . $tagtit . '</pre>' ;
							
								$tstr .= '<a href="'.base_url().'account/userprofile/'. $res[0]->uid .'" style="color: #280071 !important;">' . ucfirst( $res[0]->user_fname ) . ' ' . ucfirst( $res[0]->user_lname ) . '</a>';
								
								$other = ( ( @$tagcnt[0]->tagcnt - 1 ) > 1 ) ? 'others' : 'other' ;
								
								if( @$tagcnt[0]->tagcnt > 1 )								
									$tstr .= ' and <span>'. ( @$tagcnt[0]->tagcnt - 1 ) . ' ' . $other .' </span>';
							/*	
							}
							else
							{		
								$tstr .= '<a href="'.base_url().'account/userprofile/'.$res[0]->uid.'" style="color: #280071 !important;">' . ucfirst( $res[0]->user_fname ) . ' ' . ucfirst( $res[0]->user_lname ) . '</a>';
								
								if( !empty( $res[1] ) )
									$tstr .= ' and <a href="'.base_url().'account/userprofile/'.$res[1]->uid.'" style="color: #280071 !important;">' . ucfirst( $res[1]->user_fname ) . ' ' . ucfirst( $res[1]->user_lname ) . '</a>';
							}
							*/
							
							$tstr = trim( $tstr );
							
						}
						
						// status = 1 means asked doubts
						// status = 2 means shared knowledge
						
                  		if($prow->status==1||$prow->status==2)
                  		{
							
							  if($prow->status==1)
							  {
								// $post_type = 'Shared Info';
								// $post_type = ( $prow->admin_posted == '1' ) ? "" . str_replace(" in","",$subsubcategory) : "Asked a doubt " . $subsubcategory ;
								$post_type = ( $prow->admin_posted == '1' ) ? "" . str_replace(" in","",$subsubcategory) : "Asked a doubt ";
							  }
							  else
							  {
								// $post_type = 'ASKED A DOUBT';
								if( $role_name == 'User' )
									$post_type = "Shared Knowledge";
									// $post_type = "Shared Knowledge $subsubcategory";
								else if( $role_name == 'Mentor' )
									$post_type = "" . str_replace(" in","",$subsubcategory);
							  }
							  
						}
						
					}
					
					//echo 'asdf123';
			
	
	
?>							
						
<table class="table table-responsive table-striped" style="width: 100%; min-width: 100%">
                            <thead>							  							  <tr>                                  <th width="20%">Post </th>                                  <td>								 								  </td>                                </tr>
							
							</thead>
							  
</table>							  
						
							
				<div class="box update comdiv postf <?=$roleclass?>" id="post<?=$row->postid?>">
                  <div class="box-header <?=($prow->admin_posted =='1') ? 'adminpost' : '' ?>">
                     <h3>
						<a href="<?=base_url()?>account/userprofile/<?=$row->id?>" style="color: #280071 !important;"><img src="<?=$userimage?>"><?=$prow->user_fname .' '.$prow->user_lname?></a>
						
						<?php
						
						if( !empty( $tstr ) )
						{
							// echo '<span class="taglist">' . $tstr = trim( $tstr, ',' ) . '</span>';
							
							echo '<div class="dropdown">
										<span class="taglist dropbtn">' . $tstr = trim( $tstr, ',' ) . '</span>
										  <div class="dropdown-content">
											<table>'. $tagtit .'
											</table>
										  </div>
								</div>';
						}
						?>
						

						
						
					 <!--<i class="fa fa-check vertick"></i>-->
                        <?=($prow->admin_posted =='1' || $role_name == 'Mentor' ) ? '<img src="'.base_url().'assets/images/svg/verify.svg" class="verified_user" />' : '' ?> <span> <?=$posteddate?> | <?php echo $post_type; ?> </span>
                     </h3>
					 
					 <!--
                     <span class="dropdown dropdown-toggle bookmark-span pbmark <?=(!empty( $checkbookmark ) )? 'bookmarked': '' ?>" type="button" onclick="bookmarkpost('<?=$prow->postid?>',$(this))" data-toggle="dropdown">
					 
                        <?php
						/*
						if(empty($checkbookmark))
							echo '<i class="fa fa-bookmark-o fa-1x" ></i>';
						else
							echo '<i class="fa fa-1x fa-bookmark"></i>';
						*/
					   
						?>
						 
					 </span>
					 -->

					 <!-- class="dropdown dropdown-toggle save-to-notes" -->


					 <?php
					 
					 // echo '------' . $userid . '-' . $row->userid;
					 $showdel = ( $userid == $prow->userid ) ? 1 : 0 ;
					 ?>

					 <!--
                    <span class="dropdown dropdown-toggle save-to-notes" type="button" data-toggle="modal" data-target="#tgm_bookmark_post_modal" id="dot3sp<?=$prow->postid?>" data-pid="<?=$prow->postid?>" data-saved="<?=$saved?>" data-reported="<?=$reported?>" data-showdel="<?=$showdel?>">
						<img src="<?=base_url()?>assets/images/svg/more.svg" class="dot3"/>
					</span>
					-->
					 
					 <!--
                     <ul class="rog save-to-notes-dropdown">
                        <?php
						
                           if(empty($checkbookmark))
                           {
                           	?>
                        <li>
						<span class=""><i class="fa fa-bookmark-o fa-1x" ></i></span><a href="javascript:void(0)" class="savenotes" id="savenotes_<?=$prow->postid?>" onclick="savetonotes('<?=$prow->postid?>')"> Save Post</a>
						<p>Save & Read it later</p>
						</li>
                        <?php
                           }
                           else
                           {
                           ?>
                        <li><span class="bookmarked"><i class="fa fa-1x fa-bookmark"></i></span><a href="javascript:void(0)" class="savenotes" id="savenotes_<?=$prow->postid?>" onclick="savetonotes('<?=$prow->postid?>')">Saved</a>
						<p>To read it later go to profile</p>
						</li>
                        <?php
                           }
                           ?>
						   
                        <?php
						
						
						
                           if(empty($checkreported))
                           {
                           	?>
						   
                        <li>
							<span><i class="fa fa-exclamation-triangle"></i></span>
							<a href="javascript:void(0)" onclick="reportpost('<?=$row->postid?>')" class="reportnotes" id="reportnotes_<?=$row->postid?>" data-toggle="modal" data-target="#reportmodal">Report Post</a>
							Mark as offensive or inappropriate
						</li>
                        <?php
                           }
							else
                           {
                           	?>
						   
                        <li><span class="reported"><i class="fa fa-exclamation-triangle"></i></span><a href="javascript:void(0)" onclick="reportpost('<?=$row->postid?>')" class="reportnotes" id="reportnotes_<?=$row->postid?>" data-toggle="modal" data-target="#reportmodal">Reported</a></li>
                        <?php
                           }
                           ?>
						
                        <?PHP
                           if($row->userid == $userid)
                           {
                           ?>
                        <li><i class="fa fa-trash" aria-hidden="true"></i><a href="javascript:void(0)" id="delete_<?=$row->postid?>" onclick="deletepost('<?=$row->postid?>', $(this))" class="delpost">Delete</a></li>
                        <?php
                           }
                           ?>
                     </ul>
					 -->
					 

					 
                  </div>
                  <div class="box-content">
                     <div class="content">
					 
                       <?php
						if( !empty( $role_name ) && $role_name == 'User' )
					    {
						?>
						
                        <p>
                           <b><a href="<?=base_url()?>account/details/<?=$row->postid?>" class="mentor_title"> <?= $prow->title?></a></b>
                        </p>
					   
						<?php
						
						   if(!empty($row->upadated_status))
						   {
							   $pcontent = $row->upadated_status;
							   $pcontent_rem = '';
							   $readbut = '';
							   
							   $words = 500;
							   
							   if( strlen( $row->upadated_status ) > $words )
							   {
									$pcontent = substr( $row->upadated_status, 0, ($words - 1 ));
									$pcontent_rem = substr( $row->upadated_status, ($words - 1 ));
									$readbut = '<a class="readmore" style="color: blue !important;cursor: pointer !important;">Read More</a>';
							   }
							   
						 
								if($prow->admin_posted != 1)							 
								echo'<p class="pcontent" style="padding-top: 0;">'.$pcontent.'<span class="pcontent_rem" style="display: none;">'.$pcontent_rem.'</span> '.$readbut.'</p>';
						
						
						   }
						   
                           if(!empty($row->image))
                           {
                           ?>
							<a href="<?=base_url()?>account/details/<?=$row->postid?>" target="_blank">
								<div class="img"> 
									<img src="<?=base_url()?>uploads/userposts/<?=$row->image?>" alt="" />
								</div>
							</a>
							<?php
                           }
						   else if( $roleclass == 'adminp' )
						   {
                           ?>
							<a href="<?=base_url()?>account/details/<?=$row->postid?>" target="_blank">
								<div class="img"> 
									<img src="<?=base_url()?>assets/images/default_article.png" alt="" class="default_img" />
								</div>
							</a>
							<?php
						   }
						
						}
						else
						{
						
                           if(!empty($row->image))
                           {
                           ?>
							<a href="<?=base_url()?>account/details/<?=$row->postid?>" target="_blank">
								<div class="img"> 
									<img src="<?=base_url()?>uploads/userposts/<?=$row->image?>" alt="" />
								</div>
							</a>
                        <?php
                           }
						   else if( $roleclass == 'adminp' )
						   {
                           ?>
							<a href="<?=base_url()?>account/details/<?=$row->postid?>" target="_blank">
								<div class="img"> 
									<img src="<?=base_url()?>assets/images/default_article.png" alt="" class="default_img"/>
								</div>
							</a>
							<?php
						   }
						   
                           
                                             ?>
					 
                        <?php
                           if($prow->admin_posted == 1)
                           {
                           ?>
                        <p>
                           <b><a href="<?=base_url()?>account/details/<?=$prow->postid?>" class="mentor_title"> <?= $prow->title?></a></b>
                        </p>
                     <?php }
                           else
                           {
                           
                           }
                                						 
						   if(!empty($prow->upadated_status))
						   {
							   $pcontent = $prow->upadated_status;
							   $pcontent_rem = '';
							   $readbut = '';
							   
							   $words = 500;
							   
							   if( strlen( $prow->upadated_status ) > $words )
							   {
									$pcontent = substr( $prow->upadated_status, 0, ($words - 1 ));
									$pcontent_rem = substr( $prow->upadated_status, ($words - 1 ));
									$readbut = '<a class="readmore" style="color: blue !important;cursor: pointer !important;">Read More</a>';
							   }
							   
							   
						 
if($prow->admin_posted != 1)							 
echo'<p class="pcontent" style="padding-top: 0;">'.$pcontent.'<span class="pcontent_rem" style="display: none;">'.$pcontent_rem.'</span> '.$readbut.'</p>';
						
						
						   }
						   
						}
						   
						?>

                     </div>
                     <div class="likes_comments_shares_box">
                        <p>
						<?php
							if($role_name == "Admin" || $role_name == "Mentor")
							{
						?>
								<span><a href="javascript:void(0)"> <span class="like-count-<?=$row->postid?>" id="<?=$row->postid?>"><?=$viewcount?></span></a></span>
								<span>Views</span>
								<span>&#124;</span>
						<?php
							}
						?>						
                           <span><a href="javascript:void(0)"> <span class="like-count-<?=$row->postid?>" id="likecnt<?=$row->postid?>"><?=$likecount?></span></a></span>
                           <span>Likes</span>
                           <span>&#124;</span>
                           <span><a href="javascript:void(0)"><span id="comment-count-1-<?=$row->postid?>"><?=$comments->num_rows()?> </span></a></span>
                           <span>Comments</span>
                           <span>&#124;</span>
						   <span><a href="javascript:void(0)"><span id="comment-count-1-<?=$row->postid?>"><?=$comments->num_rows()?> </span></a></span>
                           <span>Share</span>
                        </p>
                     </div>
                  </div>
				  
				  <!--
                  <div class="box-buttons">
                     <div class="row">
                 
                        <button onclick="likepost('<?=$row->postid?>',$(this))" class="<?= ($liked != 0)? 'liked': '' ?> plikebut"> <span>
						<img src="<?=$likeimg?>" class="fa fa-thumbs-up likeimg-<?=$row->postid?> " style="width: 26px !important; height: 26px !important;"/><span class="box_button_text">Like</span>
                        </button>
                        <button class="combtn"> <img src="<?=base_url()?>assets/images/svg/chat.svg" class="fa fa-comments-o" style="width: 26px !important; height: 26px !important;"/><span class="box_button_text">Comment</span></button>

                        <?php
/*                            if($row->admin_posted == 1)
                           { */
					   
					   /*
							$slink = ( $role_name == 'User' ) ? base_url() .'account/upost/'.$row->postid : base_url() .'account/details/'.$row->postid ;
							*/
					   
                           ?>
						   
                        <button class="sharebtn" data-link="" data-role=""><span>
                        <img src="<?=base_url()?>assets/images/svg/share.svg" class="fa fa-share sharebtn" style="width: 26px !important; height: 26px !important;"/><span class="box_button_text">Share</span> </span>
						</button>
                        <?php
                           // }
                           ?>
                     </div>
                  </div>
                  <div class="clearfix"></div>
                  <div class="box-click"><span><i class="ion-chatbox-working"></i>View <span id="comment-count-<?=$row->postid?>"><?=$commentcount?></span> more comments</span>
                  </div>
                  <div class="newcmt" id="newcmt-<?=$row->postid?>">
                    <?php
                        //echo comment_sec( $comments, $userid );
					?>
                  </div>
                  <div class="box-new-comment">
                     <img src="<?=base_url()?>uploads/userprofile/default.png">
                     <div class="content">
                        <div data-emojiarea data-type="css" data-global-picker="false">
                           <img src="<?=base_url()?>assets/images/svg/emoji.svg" class="emoji  emoji-button open-emoji" style="width: 20px !important; height: 20px !important;" />
						   
						   <input type="hidden" name="comuid" class="comuid" value="0" />
						   <input type="hidden" name="comid" class="comid" value="0" />
						   <input type="hidden" name="ccomid" class="ccomid" value="0" />
						   
                           <textarea placeholder="write a comment..." class="coment" id="<?=$row->postid?>"></textarea>						   
                        </div>
						
                        <div class="row postcoment">
							<img src="<?=base_url()?>assets/images/svg/send.svg" class="pcombtn" style="width: 20px !important;height: 20px !important;visibility: hidden;" >
                           <img src="<?=base_url()?>assets/images/svg/camera.svg" class="fa fa-camera" data-pid="<?=$row->postid?>" style="width: 22px !important; height: 22px !important;" />
                        </div>
                     </div>
					 <div class="ulistdiv"></div>
					 
                  </div>
				  
				<div class="row comimg" style="display: none;">
				   <div class="col-md-12" style="text-align: center;">
						<img src="<?=base_url()?>assets/images/load_icon2.gif" class="loadicon" style="width: 24px !important;" />
						<img src="" style="width: 100px;display: none;" class="upimg" />
						<input type="hidden" class="comimg_val" value=""/>
				   </div>
				</div>
				
				-->
				  
               </div>
			   
<?php

	}

}
else
{
?>
	
<table class="table table-responsive table-striped" style="width: 100%; min-width: 100%">
                            <thead>							  							  <tr>                                  <th width="20%">Comment </th>                                  <td>								 								  </td>                                </tr>
							
							</thead>
							  
</table>	
	
<?php	
	if( !empty( $comres ) )
		echo $comres->comment;
}

?>		

<br>
<br>

<?php
if( $row->action == 'O' )
{
?>

<table class="table table-responsive table-striped" style="width: 100%; min-width: 100%">
	<thead>
		<tr>                                  
			<th width="20%">Take Action</th>                                  
			<td></td>                                
		</tr>	
	</thead>							  
</table>	   

<select class="form-control" id="action" name="action">
	<option value="">Select Action</option>
	<option value="D">Delete Post / Comment</option>
	<option value="B">Block Account</option>
	<option value="N">No Action</option>
</select>

<br>
<br>

<input type="hidden" name="repid" id="repid" value="<?=$row->id?>" />
<input type="hidden" name="reppostid" id="reppostid" value="<?=$row->postid?>" />
<input type="hidden" name="repcomid" id="repcomid" value="<?=$row->comid?>" />

<input class="btn btn-primary btn-sm pull-right icon" type="submit" id="takeact" name="takeact" value="Submit">		
		
<br>
<br>
<br>
<br>

<?php
}
else if( $row->action == 'D' )
{
	echo 'Action : Post / Comment has been deleted.';
}
else if( $row->action == 'B' )
{
	echo 'Action : User has been blocked.';
}
else if( $row->action == 'B' )
{
	echo 'Action : No action.';
}

?>



		
                        </div>
                        
                      </div>
                    </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<div id="infoModal" class="modal fade" role="dialog" aria-labelledby="alertModal" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default cl_btn" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>