<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script src="<?= base_url() ?>assets/admin/plugins/select2/dist/js/select2.full.min.js"></script>
<script>
  $(function () {
      
      console.log('ready');	
      
    $('#reportTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[3, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('reports/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [		  							{ "data" : "id" },														{ "data" : "reason" },														{ "data" : "reason" },
		  				    { "data" : "username" },                          
                            { "data" : "added_date"},  						                               { "data" : "status", render: function(data, type, row, meta) {                                          if (data == '1'){                                              return '<span class="label label-success"> Closed </span>';                                          }                                           else if (data == '0'){                                              return '<span class="label label-warning"> Open </span>';                                          }                                         }},
                            { "data" : "action", "sortable": false}						   ],
    });
  });
 function refreshreportTable(){
    $('#reportTable').DataTable().draw();
  }
  
$('body').on("click", "#takeact", function(){
		
	console.log('takeact: ');	
		
	var repid = $('#repid').val();	
	var action = $('#action').val();	
	var reppostid = $('#reppostid').val();	
	var repcomid = $('#repcomid').val();	
		
	$.ajax({
				url:"<?php echo admin_url('reports'); ?>/takeact/",
				type: "POST",
				data:{repid: repid, action: action, reppostid: reppostid, repcomid: repcomid},
				 success: function (res) {

						console.log( res );
											
						alert('Action taken successfully.');
						
				 }
	});
		
});	
  
</script>