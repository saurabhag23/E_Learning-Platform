<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= $site->site_title ?> - <?= $site->site_sub_title ?> | Dashboard</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/plugins/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/plugins/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/plugins/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/plugins/jvectormap/jquery-jvectormap.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/plugins/swal/sweetalert.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/plugins/select2/dist/css/select2.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/css/AdminLTE.min.css">
  <link rel="stylesheet" href="<?= site_url() ?>assets/admin/css/custom.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>assets/admin/plugins/wizard/wizard.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>