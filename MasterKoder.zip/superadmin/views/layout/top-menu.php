<header class="main-header">

  <!-- Logo -->
  <a href="<?= admin_url('dashboard') ?>" class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels -->
    <!--      <span class="logo-mini"><b><?= $site->site_title ?></b></span>-->
    <!-- logo for regular state and mobile devices -->
    <!--      <span class="logo-lg"><b><?= $site->site_title ?> </b><?= $site->site_sub_title ?></span>-->
  </a>

  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top">
    <!-- Sidebar toggle button-->
    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
      <!--<span class="sr-only">Toggle navigation</span>-->
      <img src="<?=base_url()?>assets/images/admin-logo.png" width="80px" />
    </a>

    <ul class="nav navbar-nav admin-top-nav">
      <li>
        <form action="#" method="get" class="sidebar-form">
          <div class="input-group">
            <input type="text" name="q" class="form-control" placeholder="Search...">
            <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                  <i class="fa fa-search"></i>
                </button>
              </span>
          </div>
        </form>
      </li>
    </ul>

    <!-- Navbar Right Menu -->
    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">
        <!-- User Account: style can be found in dropdown.less -->

        <li><a href="<?=base_url()?>account" class="admin-top-nav-links" target="_blank">
          <img src="<?=base_url()?>assets/images/share-top-nav.png" class="img-responsive"/>
        </a></li>
        <li class="dropdown"><a href="#" class="admin-top-nav-links dropdown-toggle" data-toggle="dropdown" style="background-image: url(https://www.thegreatmentor.com/assets/images/white-bg.png);background-size: 14px 14px;background-repeat: no-repeat;background-position: 5px;">
          <img src="<?=base_url()?>assets/images/plus-sign-in-a-black-circle.png" class="img-responsive" style="width: 22px;"/>
        </a>
          <ul class="dropdown-menu plus-button-dropdown">
            <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>
            <li><a href="<?=admin_url('dailyquiz')?>"><img src="<?=base_url()?>assets/images/checklist-black.png" alt="">Quiz</a></li>
            <?php endif; ?>
            <?php if(has_permission('posts', 'dashboard_view')): ?>
            <li><a href="<?=admin_url('posts')?>"><img src="<?=base_url()?>assets/images/pencil-black.png" alt="">Post</a></li>
            <?php endif; ?>
            <?php if(has_permission('studyplan', 'dashboard_view')): ?>
            <li><a href="<?=admin_url('notes')?>"><img src="<?=base_url()?>assets/images/open-book-black.png" alt="">Notes</a></li>
            <?php endif; ?>
            <?php if(has_permission('studyplan', 'dashboard_view')): ?>
            <li><a href="<?=admin_url('studyplan')?>"><img src="<?=base_url()?>assets/images/planning-black.png" alt="">Study Plans</a></li>
            <?php endif; ?>
            <?php if(has_permission('syllabus', 'dashboard_view')): ?>
            <li><a href="<?=admin_url('syllabus')?>"><img src="<?=base_url()?>assets/images/shopping-list-black.png" alt="">Syllabus</a></li>
            <?php endif; ?>
            <?php if(has_permission('studyplan', 'dashboard_view')): ?>
            <li><a href="<?=admin_url('examdetails')?>"><img src="<?=base_url()?>assets/images/loupe-black.png" alt="">Exam Details</a></li>
            <?php endif; ?>
          </ul>
        </li>
        <li class="dropdown"><a href="" class="admin-top-nav-links" data-toggle="dropdown">
          <img src="<?=base_url()?>assets/images/notification-top-nav.png" class="img-responsive" style="width: 22px;position: relative;"/>
          <span class="notifmsg" style="display: none;"><span class="notification_number">
			   <p class="notif-count" style="display: table-cell; vertical-align: middle;">0</p></span></span>
        </a>
          <ul class="dropdown-menu plus-button-dropdown notification-dropdown">
            <li class="notification-head clearfix"><span class="fl">Notifications</span><span class="fr"><a href="">Mark all as read</a><span>.</span><a href="">Settings</a></span></li>
            <li class="new-notification"><span>New</span></li>
            <li class="bgc-light-blue clearfix"><div class="notification-profile"><img src="https://www.thegreatmentor.com/assets/admin/img/avatar5.png" alt=""></div><div class="notification-details"><span class="notification-bold">Shivam Bundelkhand, Praveen Ojha</span> and 4 others like your Page <div class="notification-bold">The Great Mentor for NDA, CDS & AFCAT Exam...</div><div class="notification-time">2 hours ago</div></div></li>
            <li class="bgc-light-blue clearfix">
              <div class="notification-profile"><img src="https://www.thegreatmentor.com/assets/admin/img/avatar5.png" alt=""></div><div class="notification-details"><span class="notification-bold">Shivam Bundelkhand, Praveen Ojha</span> and 4 others like your Page <div class="notification-bold">The Great Mentor for NDA, CDS & AFCAT Exam...</div><div class="notification-time">2 hours ago</div></div>
            </li>
            <li class="bgc-light-blue clearfix">
              <div class="notification-profile"><img src="https://www.thegreatmentor.com/assets/admin/img/avatar5.png" alt=""></div><div class="notification-details"><span class="notification-bold">Shivam Bundelkhand, Praveen Ojha</span> and 4 others like your Page <div class="notification-bold">The Great Mentor for NDA, CDS & AFCAT Exam...</div><div class="notification-time">2 hours ago</div></div>
            </li>
            <li class="bgc-light-blue clearfix">
              <div class="notification-profile"><img src="https://www.thegreatmentor.com/assets/admin/img/avatar5.png" alt=""></div><div class="notification-details"><span class="notification-bold">Shivam Bundelkhand, Praveen Ojha</span> and 4 others like your Page <div class="notification-bold">The Great Mentor for NDA, CDS & AFCAT Exam...</div><div class="notification-time">2 hours ago</div></div>
            </li>
            <li class="bgc-light-blue clearfix">
              <div class="notification-profile"><img src="https://www.thegreatmentor.com/assets/admin/img/avatar5.png" alt=""></div><div class="notification-details"><span class="notification-bold">Shivam Bundelkhand, Praveen Ojha</span> and 4 others like your Page <div class="notification-bold">The Great Mentor for NDA, CDS & AFCAT Exam...</div><div class="notification-time">2 hours ago</div></div>
            </li>
            <li class="bgc-light-blue clearfix">
              <div class="notification-profile"><img src="https://www.thegreatmentor.com/assets/admin/img/avatar5.png" alt=""></div><div class="notification-details"><span class="notification-bold">Shivam Bundelkhand, Praveen Ojha</span> and 4 others like your Page <div class="notification-bold">The Great Mentor for NDA, CDS & AFCAT Exam...</div><div class="notification-time">2 hours ago</div></div>
            </li>
            <li class="notification-head text-center clearfix"><a href="">See All</a></li>
          </ul>
        </li>

        <li class="dropdown user user-menu">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
		  
		  <?php
		  
/* echo "<hr><pre>logged_user: ";
var_dump( $logged_user );
exit; */

		  ?>
		  
              <img src="<?= base_url() ?>assets/admin/img/avatar5.png" class="user-image" alt="<?= $logged_user->user_fname ?>">
<!--              <span class="hidden-xs"><?= $logged_user->user_fname ?> <?= $logged_user->user_lname ?></span>-->
            </a>
          <ul class="dropdown-menu">
            <!-- User image -->
            <li class="user-header">
              <img src="<?= base_url() ?>assets/admin/img/avatar5.png" class="img-circle" alt="<?= $logged_user->user_fname ?>">

              <p>
                <?= $logged_user->user_fname ?>
                  <?= $logged_user->user_lname ?>
                    <small>Member since <?= date("M d, Y", strtotime($logged_user->user_reg_date)) ?></small>
              </p>
            </li>
            <!-- Menu Footer-->
            <li class="user-footer">
              <div class="pull-left">
                <a href="<?= admin_url('profile') ?>" class="btn btn-default btn-flat">My Profile</a>
              </div>
              <div class="pull-right">
                <a href="<?= admin_url('login/signout') ?>" class="btn btn-default btn-flat">Sign out</a>
              </div>
            </li>
          </ul>
        </li>
        <!-- Control Sidebar Toggle Button -->
      </ul>
    </div>

  </nav>
</header>
<!-- Left side column. contains the logo and sidebar -->