
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?= $row->exam_name ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('courses') ?>">Exam</a></li>
        <li class="active">Exam details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
           <div class="nav-tabs-custom">
                      <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab_1" data-toggle="tab">Details</a></li>
                        <li><a href="#tab_2" data-toggle="tab">Questions</a></li>
                      </ul>
                      <div class="tab-content">
                        <div class="tab-pane active" id="tab_1">
                          <table class="table table-responsive table-striped" style="width: 100%; min-width: 100%">
                              <thead>
                                <tr>
                                  <th width="20%">Total questions</th>
                                  <td><?= $row->total_questions ?></td>
                                </tr>
                                <tr>
                                  <th>Exam Durarion</th>
                                  <td><?= $row->exam_duration ?> <?= $row->exam_duration_slug ?></td>
                                </tr>
                                <tr>
                                  <th>Exam meta tags</th>
                                  <td>
                                    <?php if(!empty($row->exam_meta_tags)): $metatags = json_decode($row->exam_meta_tags); ?>
                                      <?php foreach($metatags as $meta): ?>
                                        <label class="label label-default"><?= $meta ?></label>
                                      <?php endforeach; ?>
                                    <?php endif; ?>
                                  </td>
                                </tr>
                                <tr>
                                  <th>Featured image</th>
                                  <td>
                                      <a href="#" class="show-img-popup" data-src="<?= base_url($row->exam_upload_path.$row->exam_featured_image) ?>" data-toggle="modal" data-target="#infoModal"><?= $row->exam_featured_image ?></a>
                                  </td>
                                </tr>
                                <tr>
                                  <th>Exam Description</th>
                                  <td><?= base64_decode($row->exam_description) ?></td>
                                </tr>

                                
                              </thead>
                            </table>
                        </div>
                        <div class="tab-pane" id="tab_2">
                            <table id="questionsTable" class="table table-responsive table-bordered table-striped" style="width: 100%; min-width: 100%">
                              <thead>
                              <tr>
                                <th>Question</th>
                                <th>Added on</th>
                                <th>Status</th>
                                <th width="10%">Actions</th>
                              </tr>
                              </thead>
                            </table>
                        </div>
                      </div>
                    </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<div id="infoModal" class="modal fade" role="dialog" aria-labelledby="alertModal" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default cl_btn" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>