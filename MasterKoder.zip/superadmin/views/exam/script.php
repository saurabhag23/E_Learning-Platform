<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/select2/dist/js/select2.full.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/wizard/wizard.js"></script>  

<script>
  $(function () {
    $('#examTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[3, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('exam/get_all_datas/'.$course_id.'') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [{ "data" : "exam_name"},
                           { "data" : "total_questions"},
                           { "data" : "exam_duration", render: function(data, type, row, meta) {
                                                      return data + ' ' + row.exam_duration_slug;
                                                }
                           },
                           { "data" : "added_date"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },
                           { "data" : "action", "sortable": false}],
    });
  });
  function refreshExamTable(){
    $('#examTable').DataTable().draw();
  }

  $(function () {
    $('#questionsTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[3, 'desc']],
          "pageLength"  : 10,
          "ajax"        : { "url"       : "<?= admin_url('exam/get_all_questions', 1) ?>",
                            "dataType"  : "json",
                            "type"      : "POST",
                          },
          "columns"     : [{ "data" : "question_name"},
                           { "data" : "added_date"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },
                           { "data" : "action", "sortable": false}],
    });
  });
  function refreshQuestionsTable(){
    $('#questionsTable').DataTable().draw();
  }
</script>

<script>
  initSample();
  $('.select2').select2({
    tags: true,
    tokenSeparators: [',', ' ']
  });
</script>