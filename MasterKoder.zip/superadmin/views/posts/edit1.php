<style type="text/css">

.modal-body img{

    display: block;

    margin-left: auto;

    margin-right: auto;

    width: 30%;

}

</style>

<body class="hold-transition skin-blue sidebar-mini fixed">

<div class="wrapper">

  <?php $this->load->view('layout/top-menu'); ?>

  <?php $this->load->view('layout/side-menu'); ?>

  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

      <h1>

        Edit post

      </h1>

      <ol class="breadcrumb">

        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>

        <li><a href="<?= admin_url('courses') ?>">Post</a></li>

        <li class="active">Edit post</li>

      </ol>

    </section>



    <!-- Main content -->

    <section class="content">

      <div class="row">

        <!-- left column -->

        <div class="col-md-12">

          <!-- general form elements -->

          <div class="box box-primary">

            <!-- form start -->

              <div class="box-body">

                <div class="col-md-12">

                    <div class="stepwizard">

                        <div class="stepwizard-row setup-panel">

                            <div class="stepwizard-step">

                                <a href="#step-1" type="button" class="btn btn-default btn-circle ">1</a>

                                <p>Edit Post</p>

                            </div>

                            <div class="stepwizard-step">

                                <a href="#step-2" type="button" class="btn btn-default btn-circle ">2</a>

                                <p>Publish</p>

                            </div>

                        </div>

                    </div>

                </div>

              </div>

          </div>

          <div class="col-md-12">

            <form class="process-form-img-editor" action="<?=admin_url('posts/update')?>" method="post" role="form">

                <div class="row setup-content" id="step-1" style="display: none;">

                  <div class="box box-primary">

                      <div class="box-header with-border">

                          <i class="fa fa-book"></i>

                          <h3 class="box-title">Edit Post</h3>

                      </div>

                      <div class="box-body">

					  

                        <div class="col-xs-12">

						<div class="row">

				<div class="row" style="display: none;">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label for="first_name"> Type of post</label>
						
						<?php
						$opt = array( "T" => "TEXT", "V" => "VIDEO", "I" => "IMAGE" );
						//$tbl_posts[0]->posttype
						echo form_dropdown( 'typepost', $opt, 'T', 'id="typepost" class="form-control"' );

						?>
						
                      </div>
                  </div>
                </div>

				<div class="row">

                  <div class="col-sm-12">

                    <div class="form-group">

                        <label for="first_name"> Title</label>

                        <input type="text" class="form-control" id="title" placeholder="Title" name="title" value="<?= $row->topic_title ?>">

                      </div>

                  </div>

                </div>			  

			  

			  <div class="row">

                  <div class="col-sm-12">

                    <div class="form-group">

                        <label for="first_name">Super Category</label>

                        
						<!--
						<select class="form-control examcat" multiple="multiple" id="examcat" name="examcat[]" onChange="geteaxamsubcategory()" >

						

						<option value="">Select Super Category</option>

						<?php

						/*
						foreach($examcats as $examcats)

						{

						?>

						  <option value="<?=$examcats->id?>"><?=$examcats->category_name?></option>

						<?php

						}
						*/

						?>

						

                        </select>
						-->

						<select class="form-control examcat"  multiple="multiple" id="examcat" name="examcat[]" onChange="geteaxamsubcategory()">
						<option value="">Select Super Category</option>
						<?php
/*						
echo "<hr><pre>catid: ";
var_dump( $row->catid );
exit;
*/	
						$row->catid = str_replace("'", "", $row->catid);
						$catid = explode(',',$row->catid);
						foreach($examcats as $examcats)
						{
						      if(in_array($examcats->id,$catid ))
							   {
								 $sel = "selected='selected'";
							   }
							   else
							   {
								 $sel ="";
							   }
						?>
						  <option value="<?=$examcats->id?>" <?=$sel?>><?=$examcats->category_name?></option>
						<?php
						}
						?>
						
                        </select>
						

                      </div>

                  </div>

				  

				 <div class="col-sm-12">

                    <div class="form-group">

                        <label for="first_name"> Category</label>

                        
						<!--
						<select class="form-control examsubcat" multiple="multiple"  id="examsubcat" name="examsubcat[]"  onChange="getsubsubcats()">

						<option value="">Select  Category</option>

							<?php

							/*

							foreach($subcats as $subcats)

							{

							?>

							  <option value="<?=$subcats->id?>"><?=$subcats->title?></option>

							<?php

							}

							*/

							?>

						

                        </select>
						-->
						
						<select class="form-control examsubcat" multiple="multiple" id="examsubcat" name="examsubcat[]" onChange="getsubsubcats()">
						<option value="0">Select Category</option>
						<?php
					     $subcatid = explode(',',$row->subcatid);
						
						 foreach($subcats as  $subcats)
						 {
							  
							   if(in_array($subcats->id,$subcatid))
							   {
								 $sel = "selected='selected'";
							   }
							   else
							   {
								 $sel ="";
							   }
		             	   echo '<option value="'.$subcats->id.'" '.$sel.'>'.$subcats->title.'</option>';
		                 }
						 ?>
                        </select>

                      </div>

                  </div>

				

                </div>

			 

				<div class="row">

          						<div class="col-sm-12">

            						<div class="form-group">

            							 <label for="first_name">Select Sub Category</label>

                        
											<!--
											<select class="form-control subsub"  multiple="multiple" id="subsub" name="subsub[]">

											<option value="">Select Sub  Category </option>

											

						                    </select>
											-->
											<select class="form-control subsub"  multiple="multiple" id="subsub" name="subsub[]">
											<option value="">Select  Sub Category </option>
											<?php
					                          $subsubcatid = explode(',',$row->subsubcatid); 
											 foreach($subsubcats as  $subsubcats)
											 {
												    if(in_array($subsubcats->id,$subsubcatid))
												   {
													 $sel = "selected='selected'";
												   }
												   else
												   {
													 $sel ="";
												   }
											   echo '<option value="'.$subsubcats->id.'" '.$sel.'>'.$subsubcats->title.'</option>';
											 }
											?>
						                    </select>											

            						</div>

          					   </div>

          		</div> 

                



                <div class="row" id="descdiv">

                  <div class="col-sm-12">

                    <div class="form-group">

                        <label class="control-label">Description</label>

                        <textarea id="editor" name="content" class="form-control" placeholder="Content" rows="15"><?= base64_decode($row->topic_description) ?></textarea>

                      </div>

                  </div>

                </div>

				

				



                            <div class="row">

                              <div class="col-xs-12 ">

							

                               <div class="loadimg" style="display:none;">

							<img src="<?= base_url('assets/images/reload.gif') ?>" style="margin-left:45%;" width="50px;" height="50px;">

						   </div>

                                <input type="hidden" name="action" value="update">

                                <input type="hidden" name="id" value="<?= $row->id ?>">

                                <input class="btn btn-primary btn-sm pull-right icon" type="submit" name="step1" value="Next">

                              </div>

                            </div>

                        </div>

                      </div>

                  </div>

                </div>

            </form>

          </div>  



          <div class="setup-content" id="step-2" style="display: none;">

			<div id="mcq_frm" style="display: block;">

			

            <form class="process-form-img-editor" id="secondstep" action="<?=admin_url('posts/update_publish')?>" method="post" role="form" enctype="multipart/form-data">    

			

              <div class="box box-primary">

                <div class="box-header with-border">

                    <i class="fa fa-book"></i>

                    <h3 class="box-title">Publish</h3>

                </div>



                  <div class="box-body">

                      <div class="col-xs-12">



				<div class="row" id="fidiv">

                  <div class="col-sm-6">

                    <div class="form-group">

                        <label class="control-label">Featured Image</label>

                         <input type="file" class="form-control"  name="image" id="image">

						 
							<a href="<?php echo base_url('uploads/posts/') . $row->featured_image; ?>" class="show-img-popup" target="_blank"><?=$row->featured_image?></a>

						<!--	
						  <a href="#" class="show-img-popup" data-src="<?= base_url('assets/images/default_article.png') ?>"  data-toggle="modal" data-target="#infoModal">Default-image</a>
						  -->

						

                      </div>

                  </div>

              

			  <!--

                  <div class="col-sm-6">

                    <div class="form-group">

                        <label class="control-label">Document</label>

                         <input type="file" class="form-control"  name="document" id="document">

                      </div>

                  </div>

				  -->

              </div>
			  
			  
				<div class="row" id="fvdiv">
				  <div class="col-sm-6">
					<div class="form-group">
						<label class="control-label">Featured Video</label>
						
						<textarea id="featured_video" name="featured_video" class="form-control"><?=$row->featured_video?></textarea>
						
					</div>
				  </div>
			  
				<!--
				  <div class="col-sm-6">
					<div class="form-group">
						<label class="control-label">Document</label>
						 <input type="file" class="form-control"  name="document" id="document">
					  </div>
				  </div>
				  -->
				</div>

			  <!--

			  <div class="row">

                  <div class="col-sm-12">

                    <div class="form-group">

                        <label class="control-label">Image Url</label>

                         <input type="text" class="form-control"  name="imageurl" id="imageurl">

				     </div>

                  </div>

              

                  

				  



              </div>

			  -->

			  

					<div class="row" style="display: none;">

									<div class="col-sm-6">

										<div class="form-group">

											<label for="question_name">Mark as featured post</label>

											

											<select class="form-control examcat" name="featured" id="featured">

												<option value="1">Yes</option>

												<option value="0">No</option>

												

											</select>

											

										</div>

									</div>



									

									<div class="col-sm-6">

										<div class="form-group">

											<label for="feautured_order">Order</label>

											

											  <?php

												$opt = array( "" => "Select" );

												

												for( $i  = 1; $i < 11 ; $i++ )

													$opt[ $i ] = $i ;

								

												echo form_dropdown( 'feautured_order', $opt, '', 'id="feautured_order" class="form-control examcat"' );

											  ?>

											

										</div>

									</div>

					</div>

					



					

					<div class="row" style="display: none;">

						<div class="col-sm-12">

							<div class="form-group">

								<label for="question_name">Send Notification</label>

								

								<select class="form-control examcat" name="notification" id="notification">

									<option value="1">Yes</option>

									<option value="0">No</option>

									

								</select>

								

							</div>

						</div>					

					</div>

					
					
					<div class="row" style="display: none;">

						<div class="col-sm-12">

						

							<div class="form-group">

							  <label for="order">Add Featured Post</label> <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"> <span class="glyphicon glyphicon-plus"></span> </button>



							  <br>

								<span id="fpost1_nm"></span>

								<br>

								<span id="fpost2_nm"></span>

								<br>

								<span id="fpost3_nm"></span>

								<br>

								<span id="fpost4_nm"></span>

								

								<input type="hidden" name="fpost1" id="fpost1" value="<?=$row->recommended_1?>" />

								<input type="hidden" name="fpost2" id="fpost2" value="<?=$row->recommended_2?>" />

								<input type="hidden" name="fpost3" id="fpost3" value="<?=$row->recommended_3?>" />

								<input type="hidden" name="fpost4" id="fpost4" value="<?=$row->recommended_4?>" />



							</div>

							

						</div>

					

					</div>


				<div class="form-group">

					<div id="admin-recommended-box">
					
						<div class="row">
						
						<?php
						//echo $row->recommended_1 . ' - ' . $row->recommended_2 ;
						
						$sel_fp1dis = '';
						$show_fp1dis = 'display:none;';						
						$sel_fp1img = '';
						$sel_fp1art = '';
						
						if( !empty( $row->recommended_1 ) )
						{
						  	$sel_fp1dis = 'display:none;';
							$show_fp1dis = '';
							
							$tbl_articelepost = $this->GeneralModel->GetInfoRow( 'tbl_articelepost', array( 'id' => $row->recommended_1 ) );
							
							// print "<hr><pre>".$this->db->last_query();exit;
							
							$sel_fp1img = $tbl_articelepost[0]->featured_image;
							$sel_fp1art = $tbl_articelepost[0]->topic_title;
						}
						
						?>
						
							<div class="col-md-3 sel_fp" id="sel_fp1" data-id="1" style="<?=$sel_fp1dis?>">
								<div class="select-recommended min-height-post">
									<div class="add-post-box">
										<i class="fa fa-plus" aria-hidden="true"></i>
										<p class="rec-post-title">Select Article</p>
									</div>
								</div>
							</div>
												
							
							<div class="col-md-3" id="show_fp1" style="<?=$show_fp1dis?>">
								<div class="recommended-post min-height-post">
									<img src="<?php echo base_url() . 'uploads/posts/' . $sel_fp1img; ?>" class="img-responsive" alt="">
									<p class="rec-post-title"><?=$sel_fp1art?></p>
								</div>
								<button type="button" class="closeart" data-id="1">X</button>
							</div>
							
						<?php
						//echo $row->recommended_1 . ' - ' . $row->recommended_2 ;
						
						$sel_fp1dis = '';
						$show_fp1dis = 'display:none;';						
						$sel_fp1img = '';
						$sel_fp1art = '';
						
						if( !empty( $row->recommended_2 ) )
						{
						  	$sel_fp1dis = 'display:none;';
							$show_fp1dis = '';
							
							$tbl_articelepost = $this->GeneralModel->GetInfoRow( 'tbl_articelepost', array( 'id' => $row->recommended_2 ) );
							
							// print "<hr><pre>".$this->db->last_query();exit;
							
							$sel_fp1img = $tbl_articelepost[0]->featured_image;
							$sel_fp1art = $tbl_articelepost[0]->topic_title;
						}
						
						?>
						
							<div class="col-md-3 sel_fp" id="sel_fp2" data-id="2" style="<?=$sel_fp1dis?>">
								<div class="select-recommended min-height-post">
									<div class="add-post-box">
										<i class="fa fa-plus" aria-hidden="true"></i>
										<p class="rec-post-title">Select Article</p>
									</div>
								</div>
							</div>
						
							
							<div class="col-md-3" id="show_fp2" style="<?=$show_fp1dis?>">
								<div class="recommended-post min-height-post">
									<img src="<?php echo base_url() . 'uploads/posts/' . $sel_fp1img; ?>" class="img-responsive" alt="">
									<p class="rec-post-title"><?=$sel_fp1art?></p>
								</div>
								<button type="button" class="closeart" data-id="2">X</button>
							</div>

						<?php
						//echo $row->recommended_1 . ' - ' . $row->recommended_2 ;
						
						$sel_fp1dis = '';
						$show_fp1dis = 'display:none;';						
						$sel_fp1img = '';
						$sel_fp1art = '';
						
						if( !empty( $row->recommended_3 ) )
						{
						  	$sel_fp1dis = 'display:none;';
							$show_fp1dis = '';
							
							$tbl_articelepost = $this->GeneralModel->GetInfoRow( 'tbl_articelepost', array( 'id' => $row->recommended_3 ) );
							
							// print "<hr><pre>".$this->db->last_query();exit;
							
							$sel_fp1img = $tbl_articelepost[0]->featured_image;
							$sel_fp1art = $tbl_articelepost[0]->topic_title;
						}
						
						?>
							
							<div class="col-md-3 sel_fp" id="sel_fp3" data-id="3" style="<?=$sel_fp1dis?>">
								<div class="select-recommended min-height-post">
									<div class="add-post-box">
										<i class="fa fa-plus" aria-hidden="true"></i>
										<p class="rec-post-title">Select Article</p>
									</div>
								</div>
							</div>
							

							
							<div class="col-md-3" id="show_fp3" style="<?=$show_fp1dis?>">
								<div class="recommended-post min-height-post">
									<img src="<?php echo base_url() . 'uploads/posts/' . $sel_fp1img; ?>" class="img-responsive" alt="">
									<p class="rec-post-title"><?=$sel_fp1art?></p>
								</div>
								<button type="button" class="closeart" data-id="3">X</button>
							</div>
							
						<?php
						//echo $row->recommended_1 . ' - ' . $row->recommended_2 ;
						
						$sel_fp1dis = '';
						$show_fp1dis = 'display:none;';						
						$sel_fp1img = '';
						$sel_fp1art = '';
						
						if( !empty( $row->recommended_4 ) )
						{
						  	$sel_fp1dis = 'display:none;';
							$show_fp1dis = '';
							
							$tbl_articelepost = $this->GeneralModel->GetInfoRow( 'tbl_articelepost', array( 'id' => $row->recommended_4 ) );
							
							// print "<hr><pre>".$this->db->last_query();exit;
							
							$sel_fp1img = $tbl_articelepost[0]->featured_image;
							$sel_fp1art = $tbl_articelepost[0]->topic_title;
						}
						
						?>
							
							<div class="col-md-3 sel_fp" id="sel_fp4" data-id="4" style="<?=$sel_fp1dis?>">
								<div class="select-recommended min-height-post">
									<div class="add-post-box">
										<i class="fa fa-plus" aria-hidden="true"></i>
										<p class="rec-post-title">Select Article</p>
									</div>
								</div>
							</div>
							

							
							<div class="col-md-3" id="show_fp4" style="<?=$show_fp1dis?>">
								<div class="recommended-post min-height-post">
									<img src="<?php echo base_url() . 'uploads/posts/' . $sel_fp1img; ?>" class="img-responsive" alt="">
									<p class="rec-post-title"><?=$sel_fp1art?></p>
								</div>
								<button type="button" class="closeart" data-id="4">X</button>
							</div>

							
						</div>
						
					</div>
						
                </div>

					<div class="row">

						<div class="col-sm-12"> &nbsp;&nbsp;

						</div>

					</div>

					

					<div class="row">

						<div class="col-sm-12"> &nbsp;&nbsp;

						</div>

					</div>

					

					<div class="row">

						<div class="col-sm-12"> &nbsp;&nbsp;

						</div>

					</div>

			  

			  <!--

             <div class="row">

                  <div class="col-sm-4">

                    <div class="form-group">

                        <label class="" style="width:100%">&nbsp;</label>

                    	

                        <label class="form-check-label" for="exampleCheck1">

							<input type="checkbox" class="form-check-input" name="save" value="1">

						Save and Publish Later</label>

                      </div>

                  </div>

              <div class="col-sm-4">

                    <div class="form-group">

                        <label class="" style="width:100%">&nbsp;</label>

                    	

                        <label class="form-check-label" for="exampleCheck1">

							<input type="checkbox" class="form-check-input" name="notification" value="1">

						Show in Notification</label>

                      </div>

                  </div>

			<div class="col-sm-4">

                    <div class="form-group">

						<label class="" style="width:100%">&nbsp;</label>

                    	

                        <label class="form-check-label" for="exampleCheck1">

							<input type="checkbox" class="form-check-input" name="featured" value="1">

						Mark as Featured post</label>

                    </div>

                  </div>  



              </div>

			  -->

			  

			  

				<div class="row" id="schdiv" style="display: none;">

					<div class="col-sm-6">

						<div class="form-group">

							<label for="scheduleddate"> Scheduled Date </label>

							

							<input type="date" class="form-control" id="scheduleddate" placeholder="" name="scheduleddate" min="<?=date('Y-m-d')?>">

	

<!--	

<div class="input-group date" data-provide="datepicker">

    <input type="text" class="form-control">

    <div class="input-group-addon">

        <span class="glyphicon glyphicon-th"></span>

    </div>

</div>

-->

							

							

						</div>

					</div>

					

					<div class="col-sm-6">

						<div class="form-group">

							<label for="scheduledtime"> Scheduled Hour ( 24 format ) </label>

							

						  <?php

							$opt = array( "" => "Select" );

							

							for( $i  = 0; $i <= 23 ; $i++ )

								$opt[ $i ] = $i ; 

			

							echo form_dropdown( 'scheduledtime', $opt, '', 'id="scheduledtime" class="form-control examcat"' );

						  ?>

							

						</div>

					</div>

					

				</div>

                        



                          <div class="row">

                              <div class="col-md-12">

                            <div class="loadimg" style="display:none;">

							<img src="<?= base_url('assets/images/reload.gif') ?>" style="margin-left:45%;" width="50px;" height="50px;">

						   </div>

                                <input type="hidden" name="action" value="update">

                                <input type="hidden" name="id_question" id="id_question" value="">

                                <input type="hidden" name="artclid" id="artclid" value="<?= $row->id ?>">

                                <input class="btn btn-primary btn-sm pull-right " type="submit" name="step2" id="mcqadd" value="Add" >

								

								<input class="btn btn-success btn-sm pull-right" type="button" name="repost" id="repost" value="Repost" style="margin-right: 5px;">
								<input class="btn btn-success btn-sm pull-right" type="button" name="schpub" id="schpub" value="Schedule Publish" style="margin-right: 5px;">

								

                                <input class="btn btn-primary btn-sm pull-right " type="button" name="mcqup" id="mcqup" value="Update" style="display:none;" >

                              </div>

                          </div>

                      </div>

                  </div>

              </div>

            </form>
			

			</div>

			

          </div>    



                

          <!-- /.box -->

        </div>

        <!--/.col (left) -->

      </div>

      <!-- /.row -->

    </section>

    <!-- /.content -->

  </div>



<div id="infoModal" class="modal fade" role="dialog" aria-labelledby="alertModal" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal">&times;</button>

        <h4 class="modal-title"></h4>

      </div>

      <div class="modal-body"></div>

      <div class="modal-footer">

        <button type="button" class="btn btn-default cl_btn" data-dismiss="modal">Close</button>

      </div>

    </div>

  </div>

</div>



<!-- Modal -->

<!--
<div class="modal fade" id="myModal" role="dialog">

	<div class="modal-dialog">



		<1!-- Modal content--1>

		<div class="modal-content">

			<div class="modal-header">

				<button type="button" class="close" data-dismiss="modal">&times;</button>

				<h4 class="modal-title">Select Article</h4>

			</div>

			<div class="modal-body">

				

				<label for="order">Article</label>

				<select class="form-control" name="artid" id="artid" >

					<option value="">Select</option>

					<?php

					

					if( !empty( $articles ) )

					{

					foreach($articles as $article)

					{

					?>

					  <option value="<?=$article->id?>"><?=$article->topic_title?></option>

					<?php

					}

					}

					?>

					

				</select>

				

				<label for="order">Order</label>

				<select class="form-control" name="artord" id="artord" >

					<option value="">Select</option>

					<option value="1">1</option>

					<option value="2">2</option>

					<option value="3">3</option>

					<option value="4">4</option>

					

				</select>				

				

				<input type="hidden" name="recid" id="recid" value="1" />



			</div>

			<div class="modal-footer">

				<button type="button" class="btn btn-success" id="recsub">Ok</button>

				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

			</div>

		</div>



	</div>

</div>
-->

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
		
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Select Article</h4>
			</div>
			
			<div class="modal-body">
				
				<label for="order">Article</label>
				<select class="form-control" name="artid" id="artid" >
					<option value="">Select</option>
					<?php
					
					if( !empty( $articles ) )
					{
					foreach($articles as $article)
					{
					?>
					  <option value="<?=$article->id?>-***-<?=$article->featured_image?>"><?=$article->topic_title?></option>
					<?php
					}
					}
					?>
					
				</select>
				
<!--				
				<label for="order">Order</label>
				<select class="form-control" name="artord" id="artord" >
					<option value="">Select</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					
				</select>
-->				

				
				

			</div>
			
			<div class="modal-footer">
			
				<input type="hidden" name="recid" id="recid" value="1" />
				<button type="button" class="btn btn-success" id="recsub">Ok</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
			
		</div>

	</div>
</div>

