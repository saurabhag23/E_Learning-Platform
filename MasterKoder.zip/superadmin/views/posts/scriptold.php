<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/select2/dist/js/select2.full.min.js"></script>
<script>

  $(function () {
    $('#topicTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
         // "order"       : [[3, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('posts/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
						  { "data" : "topic_title", render: function(data, type, row, meta) {
                                           return data.substring(0,30); 
                                        }
                           },
						   { "data" : "category_name" },
						   
                           { "data" : "added_date"},
						   { "data" : "username"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },
                           { "data" : "action", "sortable": false}],
    });
	
	$("#myModal").on("click", "#recsub", function(){
		
		var artid = $('#artid').val();
		var artnm = $('#artid option:selected').text();
		var artord = $('#artord').val();
		
		console.log( 'artid:' + artid );
		console.log( 'artnm:' + artnm );
		console.log( 'artord:' + artord );
		
		$('#fpost' + artord).val( artid );
		$('#fpost'+artord+'_nm').text( 'Article ' + artord + ' - ' + artnm );
		
	});
	
	$('.setup-panel .stepwizard-step:nth-child(1) a').trigger('click');
	// $('.setup-panel .stepwizard-step:nth-child(1) a').hide();
	
  });
  
  function refreshTopicTable(){
    $('#topicTable').DataTable().draw();
  }
  function geteaxamsubcategory()
  {
  	
  	var catid = $('#examcat').val();
	
	   $.ajax({
		    url: "<?= admin_url('posts/getsubcategory') ?>",
		    type: "POST",
		    data: {catid : catid}, 
            success: function(data){
            $('#examsubcat').html(data);
			 
            }
		});
  }
   function getsubsubcats()
   {
  	 var subid = $('#examsubcat').val();
	
	   $.ajax({
		    url: "<?= admin_url('posts/getsubsub') ?>",
		    type: "POST",
		    data: {subid : subid}, 
            success: function(data){
            $('#subsub').html(data);
		     
            }
		});
   }
  $(".examcat").select2();
   $(".examsubcat").select2();
   $(".subsub").select2();
</script>

  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>  
  <script>
    initSample();
  </script>