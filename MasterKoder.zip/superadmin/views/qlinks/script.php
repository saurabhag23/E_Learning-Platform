<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
	  
    $('#qlinksTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('quicklinks/get_feedback') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
							{ "data": "id",
    render: function (data, type, row, meta) {
        return meta.row + meta.settings._iDisplayStart + 1;
    }},
							{ "data" : "title"},
                           { "data" : "created_on"},
                           { "data" : "numposts"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == '1'){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == '0'){
                                              return '<span class="label label-warning"> Blocked </span>';
                                          } 
                                        }},
                           { "data" : "action", "sortable": false}],
    });
	
	var opt = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];

	var optindex = $('.optrow').length;
	
	$("body").on("click", "#publish", function(){
		$('#save_pub').val('1');
		$(this).closest('form').submit();
	});	
	
	$("body").on("click", "#save", function(){
		$('#save_pub').val('0');
		$(this).closest('form').submit();
	});	
		
	$("body").on("click", "#add_opt", function(){
		
		var optdiv = '<div class="form-group">					  <label for="order">Option '+ opt[optindex] +'</label>					  <input type="text" class="form-control" placeholder="Add Option '+ opt[optindex] +'" name="opt[]"><input type="hidden" class="form-control" name="optlet[]" value="'+ opt[optindex] +'"></div> <div class="form-group">																		<div>						  <label for="order">Show Onclick Text Input </label>						  <select name="txt_input[]" class="form-control"><option value="" selected="selected">Select</option><option value="Y">Yes</option><option value="N">No</option></select>						  						</div>					</div>';
		
		$('#optdiv').append( optdiv );
		
		optindex++;
		
	});	

		
	});
	
  function refreshqlinksTable(){
    $('#qlinksTable').DataTable().draw();
  }
  
  
  function geteaxamsubcategory()
  {
  	
  	var catid = $('#parent').val();
	
	   $.ajax({
		    url: "<?= admin_url('posts/getsubcategory') ?>",
		    type: "POST",
		    data: {catid : catid}, 
            success: function(data){
            $('#subcat').html(data);
            }
		});
  }
 
   function getsubsubcats()
   {
  	 var subid = $('#subcat').val();

	   $.ajax({
		    url: "<?= admin_url('posts/getsubsub') ?>",
		    type: "POST",
		    data: {subid : subid}, 
            success: function(data){
			
            $('#subsub').html(data);
		     
            }
		});
   }
  
	
</script>