
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>	 
        View Feedback
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('tools') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('feedback') ?>">Feedback</a></li>
        <li class="active">View Feedback</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('feedback/update') ?>" method="post" id="feedup" name="feedup" >
              <div class="box-body">
                
                <div class="form-group">
                  <label for="title" style="
    font-weight: normal;
">Title: </label>
                  <b><?=$row->title?></b>
				  
				 <?php echo form_error('title'); ?>				  
                </div>

                <div class="form-group col-md-6" >
                  <div style="border: 1px solid #280071 !important;padding: 0;border-bottom: 0 !important;text-align: center;font-weight: bold;color: #280071;">CREATED ON</div>
                  <div style="border: 1px solid #280071 !important;text-align: center;padding: 15px;">
				  <?php				  	
					echo date('d M, Y', strtotime( $row->created_on ) );
				  ?>
				  </div>				  
                </div>

                <div class="form-group col-md-6">
                  <div style="border: 1px solid #280071 !important;padding: 0;border-bottom: 0 !important;text-align: center;font-weight: bold;color: #280071;">TOTAL FEEDBACK GIVEN</div>
                  <div style="border: 1px solid #280071 !important;text-align: center;padding: 15px;"><?=$row->feedback_given?></div>
				  
                </div>
				
				<div id="optdiv">
				
<?php
if( !empty( $fopt ) )
{	
?>

	<table class="table table-responsive table-bordered table-striped">

		<thead>

		<tr>

			<th>OPTION</th>

			<th>OPTION TEXT</th>
			
			<th>SCORE</th>

			<th> % </th>

		</tr>

		</thead>
		
		<tbody>

<?php
	foreach( $fopt as $key => $value )
	{	
?>	

		<tr>
			<td><?=$value->feed_optlet?></td>			
			<?php
			if( $value->txt_input == 'Y' )
				echo '<td> <a href="'. admin_url( 'feedback/viewopt/' . $row->Id . '/' . $value->feed_optlet ) . '" style="color: #280071;">'. $value->opt_name .'</a></td>';
			else
				echo '<td>'. $value->opt_name .'</td>';
			?>
			<td><?=$value->score?></td>
			
			<td> <?php if( $ftscore ) echo round( ( $value->score / $ftscore ) * 100, 1 ); else echo '0'; ?> </td>
		</tr>	
			
<?php
	}
?>
		</tbody>

	</table>
<?php	
}
?>	
					
				</div>
				
                

              </div>
              <!-- /.box-body -->

              
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
