
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>	 
        Reason for selecting <?=$foptname?>
		
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('tools') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('feedback') ?>">Feedback</a></li>
        <li class="active">View Feedback Option</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('feedback/update') ?>" method="post" id="feedup" name="feedup" >
              <div class="box-body">
                
                
				
				<div id="optdiv">
				
<?php
if( !empty( $texts ) )
{	
?>

	

<?php
	foreach( $texts as $key => $value )
	{	
?>	

		<div class="" style="background-color: lightgray;border-radius: 15px;padding: 15px;margin-bottom: 10px;" >
			<div class="row" >
                  <div class="col-md-6" style="color: #280071;font-weight: bold;"><?=$value->user_fname?> <?=$value->user_lname?></div>
				  
				  <div class="col-md-6" style="text-align: right;"><?php echo date('d F Y', strtotime( $value->datec ) ) . ' at ' . date('h:i A', strtotime( $value->datec ) ) ; ?></div>
				  
			</div>	  
			<div class="row" >
                  
                  <div class="col-md-12" style="padding: 15px;">
				  <?=$value->text?>
				  </div>				  
			</div>
        </div>
			
<?php
	}
?>
		
<?php	
}
?>	
					
				</div>
				
                

              </div>
              <!-- /.box-body -->

              
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
