<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<!--
<script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js"></script>
<script src="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/src/js/bootstrap-datetimepicker.js"></script>
-->

<script>
  $(function () {
	  
    $('#cdownTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('countdown/get_countdown') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
							{"data": "id",
    render: function (data, type, row, meta) {
        return meta.row + meta.settings._iDisplayStart + 1;
    }},
							{ "data" : "title"},
                           { "data" : "exam_date"},
                           { "data" : "clicks"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == '1'){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == '0'){
                                              return '<span class="label label-warning"> Blocked </span>';
                                          } 
                                        }},
                           { "data" : "action", "sortable": false}],
    });
	
	var opt = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];

	var optindex = $('.optrow').length;
	
	$("body").on("click", "#publish", function(){
		$('#save_pub').val('1');
		$(this).closest('form').submit();
	});	
	
	$("body").on("click", "#save", function(){
		$('#save_pub').val('0');
		$(this).closest('form').submit();
	});	
		
	$("body").on("click", "#add_opt", function(){
		
		var optdiv = '<div class="form-group">					  <label for="order">Option '+ opt[optindex] +'</label>					  <input type="text" class="form-control" placeholder="Add Option '+ opt[optindex] +'" name="opt[]"><input type="hidden" class="form-control" name="optlet[]" value="'+ opt[optindex] +'"></div> <div class="form-group">																		<div>						  <label for="order">Show Onclick Text Input </label>						  <select name="txt_input[]" class="form-control"><option value="" selected="selected">Select</option><option value="Y">Yes</option><option value="N">No</option></select>						  						</div>					</div>';
		
		$('#optdiv').append( optdiv );
		
		optindex++;
		
	});	

		/*
		$('#exam_date_div').datetimepicker({
			format: 'YYYY-MM-DD hh:mm A',
			useCurrent: false,
			minDate: moment()
		}).data('DateTimePicker').minDate(moment(new Date()));
		*/
		
	});
	
  function refreshcdownTable(){
    $('#cdownTable').DataTable().draw();
  }
  
	
</script>