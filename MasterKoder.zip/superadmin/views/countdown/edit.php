
<body class="hold-transition skin-blue sidebar-mini fixed">

<!--
<link href="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css" rel="stylesheet">
-->

<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>	 
        Edit Countdown
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('tools') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('countdown') ?>">Countdown</a></li>
        <li class="active">Edit Countdown</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content admin_feedback">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('countdown/update') ?>" method="post" id="feedadd" name="feedadd" >
              <div class="box-body">
                
                <div class="form-group">
                  <label for="title">Title</label>
                  <input type="text" class="form-control" id="title" placeholder="Title" name="title" value="<?=$row->title?>">
				  
				 <?php echo form_error('title'); ?>				  
                </div>

                <div class="form-group">
				
					<label for="exam_date">Exam Date</label>
					
					<div class='input-group date' id='exam_date_div'>
						
						<input type="text" class="form-control" id="exam_date" name="exam_date" value="<?=$row->exam_date?>" >
						
						<span class="input-group-addon">
						<span class="glyphicon glyphicon-calendar"></span>
						</span>
					</div>
				  
				 <?php echo form_error('exam_date'); ?>				  
                </div>

                <div class="form-group">
                  <label for="priority">Priority</label>
                  <input type="text" class="form-control" id="priority" placeholder="Priority" name="priority" value="<?=$row->priority?>">
				  
				 <?php echo form_error('priority'); ?>				  
                </div>

                <div class="form-group">
                  <label for="url_text">URL Text</label>
                  <input type="text" class="form-control" id="url_text" placeholder="Url text" name="url_text" value="<?=$row->url_text?>">
				   
				 <?php echo form_error('url_text'); ?>				  
                </div>
				
                <div class="form-group">
                  <label for="url_link">URL Link</label>
                  <input type="text" class="form-control" id="url_link" placeholder="Url link" name="url_link" value="<?=$row->url_link?>">
				  
				 <?php echo form_error('url_link'); ?>				  
                </div>
				
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
			  
                <input type="hidden" name="action" value="update">
				<input type="hidden" name="id" value="<?=$row->id?>">
				
                <input type="hidden" name="save_pub" id="save_pub" value="0">
				<input type="hidden" name="role" value="<?=$this->uri->segment('4')?>">
				<input type="button" id="save" name="save" value="Save" class="btn btn-primary btn-sm pull-right btn-green">
				<input type="button" id="publish" name="publish" value="Publish" class="btn btn-primary btn-sm pull-right btn-green">
				  
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
