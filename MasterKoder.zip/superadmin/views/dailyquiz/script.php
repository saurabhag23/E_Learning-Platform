<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/select2/dist/js/select2.full.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/wizard/wizard.js"></script>  

<script>
  $(function () {
    $('#examTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[4, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('dailyquiz/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [ { "data": "id_exam",
                            render: function (data, type, row, meta) {
                                return meta.row + meta.settings._iDisplayStart + 1;
                            }},
							{ "data" : "exam_name"},
							{ "data" : "scat"},
							{ "data" : "cat"},
							{ "data" : "subcat"},
							{ "data" : "added_date"},
							{ "data" : "username"},
							{ "data" : "attempt_count"},
							{ "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },                                                      
                           { "data" : "action", "sortable": false}],
    });
  });
  function refreshExamTable(){
    $('#examTable').DataTable().draw();
  }

  $(function () {
		$('#questionsTable').DataTable({
			  "processing"  : true,
			  "serverSide"  : true,
			  "order"       : [[3, 'desc']],
			  "pageLength"  : 10,
			  "ajax"        : { "url"       : "<?= admin_url('dailyquiz/get_all_questions', 1) ?>",
								"dataType"  : "json",
								"type"      : "POST",
							  },
			  "columns"     : [
								{ "data" : "id_question", render: function(data, type, row, meta) {
																																				// console.log( 'data:' + data );
																																				return '<input type="checkbox" class="mcqchk" name="singmcq[]" id="singmcq" value="'+ data +'" />';
																				
									}, 
									"sortable": false
								},	
								{ 
								"data" : "mque_ans", render: function(data, type, row, meta) {
									
									console.log( 'data:' + data );
									
									if( data != null )
									{
										var arr = data.split('-***-');
										console.log( 'arr:' + arr );
										var copt = '';
										
										if( arr[6] == '1' || arr[6] == 1 )	
											copt = arr[1];	
										else if( arr[6] == '2' || arr[6] == 2 )	
											copt = arr[2];
										else if( arr[6] == '3' || arr[6] == 3 )	
											copt = arr[3];
										else if( arr[6] == '4' || arr[6] == 4 )	
											copt = arr[4];
										else if( arr[6] == '5' || arr[6] == 5 )	
											copt = arr[5];
										
										return arr[0] + '<div class="td_content" style="display: none;">Option A:'+ arr[1] +' Option B:'+ arr[2] +'Option C:'+ arr[3] +'Option D:'+ arr[4] +'Option E:'+ arr[5] +'Correct Option:'+ copt +'<br>Explanation:'+ arr[7] +'</div><input type="hidden" name="id_question" class="id_question" value="'+ arr[8] +'" />';
									}
									else
									{
										return '';
									}
								
								}},
							   { "data" : "added_date"},
							   { "data" : "status", render: function(data, type, row, meta) {
											  if (data == 1){
												  return '<span class="label label-success"> Active </span>';
											  } 
											  else if (data == 0){
												  return '<span class="label label-warning"> Hidden </span>';
											  } 
											}
							   },
								{ "data" : "action", render: function(data, type, row, meta) {
																																//console.log( 'data:' + data );
																																return '<a href="#"><span class="glyphicon glyphicon-edit"></span></a> <a href="#"><span class="glyphicon glyphicon-trash"></span></a>';
																				
											}, 
											"sortable": false
								}
							   ],
		});
		
		$('#pictorialTable').DataTable({
			  "processing"  : true,
			  "serverSide"  : true,
			  "order"       : [[1, 'desc']],
			  "pageLength"  : 10,
			  "ajax"        : { "url"       : "<?= admin_url('dailyquiz/get_all_questions_image', 1) ?>",
								"dataType"  : "json",
								"type"      : "POST",
							  },
			  "columns"     : [
			  
								{ "data" : "id_question", render: function(data, type, row, meta) {
																																				console.log( 'data:' + data );
																																				return '';
																																				// return '<input type="checkbox" class="picchk" name="picchk[]" id="picchk" value="'+ data +'" />';
																				
									}, 
									"sortable": false
								},								
								{ "data" : "img_path", render: function(data, type, row, meta)
								{
									console.log( 'img_path data:' + data );

									if( data != null )
									{
										var arr = data.split('-***-');
										console.log( 'arr:' + arr );
										return '<img src="<?php echo base_url() ; ?>' + arr[0] + '" width="100" /><br><div class="td_content" style="display: none;"><b>Answer:</b> '+ arr[1] +'</div><input type="hidden" name="id_question" class="id_question" value="'+ arr[2] +'" />';
									
									}
									else
									{
										return '';

									}
											
								}
								},
								{ "data" : "action", render: function(data, type, row, meta) {
																					console.log( 'data:' + data );
																					return '<a href="#"><span class="glyphicon glyphicon-edit"></span></a> <a href="#"><span class="glyphicon glyphicon-trash"></span></a>';
																				
											}, "sortable": false
									}
							],
		   "fnRowCallback" : function(nRow, aData, iDisplayIndex){
					$("td:first", nRow).html(iDisplayIndex +1);
				   return nRow;
				}
		});
		
		
/*

								*/
		
		$('#textualTable').DataTable({
			  "processing"  : true,
			  "serverSide"  : true,
			  "order"       : [[1, 'desc']],
			  "pageLength"  : 10,
			  "ajax"        : { "url"       : "<?= admin_url('dailyquiz/get_all_questions_textual', 1) ?>",
								"dataType"  : "json",
								"type"      : "POST",
							  },
			  "columns"     : [
			  
							{ "data" : "id_question", render: function(data, type, row, meta) {
																																				console.log( 'data txt asdf:' + data );
																																				// return 'fdsa';
																																				return '<input type="checkbox" class="txtchk" name="txtchk[]" id="txtchk" value="'+ data +'" />';
																				
									}, 
									"sortable": false
								},
			  
								
								
							{ "data" : "question_ans", render: function(data, type, row, meta) {
							
							if( data != null )
							{
							
								var arr = data.split('-***-');
								
								console.log( 'arr:' + arr );
																						
								return arr[0] + '<br><div class="td_content" style="display: none;"><b>Answer asdf:</b> '+ arr[1] +'</div><input type="hidden" name="id_question" class="id_question" value="'+ arr[2] +'" />';
																				
							}
							else
							{
								return '';
							}
							
								}},
								{  "data" : "action", render: function(data, type, row, meta) {
																					console.log( 'data action:' + data );
																					return '<a href="#"><span class="glyphicon glyphicon-edit"></span></a> <a href="#"><span class="glyphicon glyphicon-trash"></span></a>';
																				
											}, "sortable": false
									}
							   ],
		   "fnRowCallback" : function(nRow, aData, iDisplayIndex){
					$("td:first", nRow).html(iDisplayIndex +1);
				   return nRow;
				}
		});
		
		/*
		
		
								{ "data" : "question_name"},

							   { "data" : "action", "sortable": false},

		
{ "data" : "img_path", render: function(data, type, row, meta) {
												console.log( 'data:' + data );
											    return  '<img src="<?php echo base_url() ; ?>' + data + '" width="100" />';
											}
}										
		*/
	

	
  });
  function refreshQuestionsTable(){
    $('#questionsTable').DataTable().draw();
  }
  
  function refreshpictorialTable(){
    $('#pictorialTable').DataTable().draw();
  }
  
  function refreshtextualTable(){
    $('#textualTable').DataTable().draw();
  }
  
  function geteaxamsubcategory()
  {
  	
  	var catid = $('#examcat').val();
	
	   $.ajax({
		    url: "<?= admin_url('posts/getsubcategory') ?>",
		    type: "POST",
		    data: {catid : catid}, 
            success: function(data){
            $('#subcat').html(data);
            }
		});
  }
 
   function getsubsubcats()
   {
  	 var subid = $('#subcat').val();

	   $.ajax({
		    url: "<?= admin_url('posts/getsubsub') ?>",
		    type: "POST",
		    data: {subid : subid}, 
            success: function(data){
			
            $('#subsub').html(data);
		     
            }
		});
   }
</script>

<script>

  initSample();
  
 initSample3(); 
		 
 initSample4();
 initSample5();
 initSample6();
 initSample7();
 initSample8();
  $('.select2').select2({
    tags: true,
    tokenSeparators: [',', ' ']
  });
   $(".examcat").select2();
    $(".examsubcat").select2();
	 $(".subsub").select2();
</script>
<script>
		CKEDITOR.replace( 'question_name', {
			
			
			height: 200,
			resize_dir: 'both',
			resize_minWidth: 200,
			resize_minHeight: 300,
			resize_maxWidth: 800
		} );
		
		  initSample2();
		
		
		
		 
	</script>
	
<script type="text/javascript">


$(document).ready( function() {
	
	// alert('ready');

    $('#quiztype').change(function(){
		//alert('change');
		
		var quiztype = $(this).val();
		console.log('quiztype:' + quiztype);
		
		if( quiztype == 'MCQ' )
		{
			$("#mcq_frm").show();
			$("#picq_frm,#textq_frm").hide();
			$(".mopt").show();	

		}
		else if( quiztype == 'pictorial' )
		{
			$("#picq_frm").show();
			$("#mcq_frm,#textq_frm").hide();
			$(".mopt").hide();
			$(".picopt").show();
		}
		else if( quiztype == 'textual' )
		{
			$("#textq_frm").show();
			$("#mcq_frm,#picq_frm").hide();			
			$(".mopt").hide();
			$(".textopt").show();
		}
		
    });
	
	<?php
	if( !empty( $exam_id ) )
	{
		echo "$('#quiztype').trigger('change')";
	}
	?>
	
	$("#textualTable, #pictorialTable, #questionsTable").on("click", "td", function(){
		console.log("textualTable sorting_1 click");
		$(this).find('.td_content').toggle();
	});			
	
	$("#questionsTable").on("click", ".glyphicon-edit", function(){
		console.log( 'glyphicon-edit click');
		var id_question = $(this).closest('tr').find('.id_question').val();
		console.log( 'id_question:' + id_question );
		
		$.ajax({
					url:"<?php echo admin_url('dailyquiz/get_que_det'); ?>",
					type: "POST",
					data:{id_question: id_question},
					 success: function (res) {

							console.log( 'res:' );
							console.log( res );
							var obj = JSON.parse( res );

							$('#secondstep').find('div#cke_question_name').find('iframe').contents().find( "body" ).html( obj.question_name );
							$('#secondstep').find('div#cke_option_1').find('iframe').contents().find( "body" ).html( obj.question_option_1 );
							$('#secondstep').find('div#cke_option_2').find('iframe').contents().find( "body" ).html( obj.question_option_2 );
							$('#secondstep').find('div#cke_option_3').find('iframe').contents().find( "body" ).html( obj.question_option_3 );
							$('#secondstep').find('div#cke_option_4').find('iframe').contents().find( "body" ).html( obj.question_option_4 );
							$('#secondstep').find('div#cke_option_5').find('iframe').contents().find( "body" ).html( obj.question_option_5 );
							$('#secondstep').find('div#cke_explanation').find('iframe').contents().find( "body" ).html( obj.explanation );
							
							$('#id_question').val( obj.id_question );
							$('#answer_option').val( obj.question_answer );
							$('#mcqadd').hide();
							$('#mcqup').show();
							
							
					 }
		});
		
	});	
	
	$("#secondstep").on("click", "#mcqup", function(){
	
		var id_question = $('#id_question').val();
		var cke_question_name = $('#secondstep').find('div#cke_question_name').find('iframe').contents().find( "body" ).html();
		var cke_option_1 = $('#secondstep').find('div#cke_option_1').find('iframe').contents().find( "body" ).html();
		var cke_option_2 = $('#secondstep').find('div#cke_option_2').find('iframe').contents().find( "body" ).html();
		var cke_option_3 = $('#secondstep').find('div#cke_option_3').find('iframe').contents().find( "body" ).html();
		var cke_option_4 = $('#secondstep').find('div#cke_option_4').find('iframe').contents().find( "body" ).html();
		var cke_option_5 = $('#secondstep').find('div#cke_option_5').find('iframe').contents().find( "body" ).html();
		var cke_explanation = $('#secondstep').find('div#cke_explanation').find('iframe').contents().find( "body" ).html();
		var answer_option = $('#answer_option').val();
		
		$.ajax({
					url:"<?php echo admin_url('dailyquiz/up_que_det'); ?>",
					type: "POST",
					data:{id_question: id_question, cke_question_name: cke_question_name, cke_option_1: cke_option_1, cke_option_2: cke_option_2, cke_option_3: cke_option_3, cke_option_4: cke_option_4, cke_option_5: cke_option_5, cke_explanation: cke_explanation, answer_option: answer_option },
					 success: function (res) {

							console.log( res );
												
							var msg = ( res ) ? 'Updated successfully' : 'Updation failed' ;
							
							alert( msg );
							
							// $('body').find('#infoModal').find('.modal-body').html( msg );
							// $('body').find('#infoModal').modal('show');
							$('#mcqup').hide();
							$('#mcqadd').show();
							
							var id_question = $('#id_question').val('');
							var cke_question_name = $('#secondstep').find('div#cke_question_name').find('iframe').contents().find( "body" ).html('<p><br></p>');
							var cke_option_1 = $('#secondstep').find('div#cke_option_1').find('iframe').contents().find( "body" ).html('<p><br></p>');
							var cke_option_2 = $('#secondstep').find('div#cke_option_2').find('iframe').contents().find( "body" ).html('<p><br></p>');
							var cke_option_3 = $('#secondstep').find('div#cke_option_3').find('iframe').contents().find( "body" ).html('<p><br></p>');
							var cke_option_4 = $('#secondstep').find('div#cke_option_4').find('iframe').contents().find( "body" ).html('<p><br></p>');
							var cke_option_5 = $('#secondstep').find('div#cke_option_5').find('iframe').contents().find( "body" ).html('<p><br></p>');
							var cke_explanation = $('#secondstep').find('div#cke_explanation').find('iframe').contents().find( "body" ).html('<p><br></p>');
							var answer_option = $('#answer_option').val('');
							
							refreshQuestionsTable();
					 }
		});
		
	});	
	

	
	$("#questionsTable").on("click", ".glyphicon-trash", function(){
		
		console.log( 'glyphicon-trash click');
		var id_question = $(this).closest('tr').find('.id_question').val();
		console.log( 'id_question:' + id_question );
		
		var res = confirm('Do you want to delete this record?');
		
		if( res ){
		
			$.ajax({
						url:"<?php echo admin_url('dailyquiz/del_que_det'); ?>",
						type: "POST",
						data:{ id_question: id_question },
						 success: function (res) {

								console.log( res );
													
								var msg = ( res ) ? 'Deleted successfully' : 'Deletion failed' ;
								
								alert( msg );
								
								refreshQuestionsTable();
						 }
			});
			
		}
		
	});	

	
	$("#pictorialTable").on("click", ".glyphicon-edit", function(){
		console.log( 'glyphicon-edit click');
		var id_question = $(this).closest('tr').find('.id_question').val();
		console.log( 'id_question:' + id_question );
		
		$.ajax({
					url:"<?php echo admin_url('dailyquiz/get_que_img_det'); ?>",
					type: "POST",
					data:{id_question: id_question},
					 success: function (res) {

							console.log( 'res:' );
							console.log( res );
							var obj = JSON.parse( res );

							$('#picq_frm #id_question').val( obj.id_question );
							$('#picq_frm #answer').val( obj.answer );
							$('#picq_frm #image_duration').val( obj.image_duration );
							$('#picq_frm #image_duration_slug').val( obj.image_duration_slug );
							$('#picq_frm #answer_duration').val( obj.answer_duration );
							$('#picq_frm #answer_duration_slug').val( obj.answer_duration_slug );
							
							$('#picqadd').hide();
							$('#picqup').show();
							
							
					 }
		});
		
	});	
	
	$("#pictorialTable").on("click", ".glyphicon-trash", function(){
		
		console.log( 'glyphicon-trash click');
		var id_question = $(this).closest('tr').find('.id_question').val();
		console.log( 'id_question:' + id_question );
		
		var res = confirm('Do you want to delete this record?');
		
		if( res ){
		
			$.ajax({
						url:"<?php echo admin_url('dailyquiz/del_que_img_det'); ?>",
						type: "POST",
						data:{ id_question: id_question },
						 success: function (res) {

								console.log( res );
													
								var msg = ( res ) ? 'Deleted successfully' : 'Deletion failed' ;
								
								alert( msg );
								
								refreshpictorialTable();
						 }
			});
			
		}
		
	});		
	
	$("#picq_frm").on("click", "#picqup", function(){
			
		/* posting image files through ajax */		

		var form = $('#picq_frm #secondstep')[0];

		// Create an FormData object 
		var data = new FormData(form);

		// If you want to add an extra field for the FormData
		// data.append("CustomField", "This is some extra data, testing");

		// disabled the submit button
		// $("#btnSubmit").prop("disabled", true);

		$.ajax({
			type: "POST",
			enctype: 'multipart/form-data',
			url: "<?=admin_url('dailyquiz/up_que_img_det')?>",
			data: data,
			processData: false,
			contentType: false,
			cache: false,
			timeout: 600000,
			success: function (res) {
				
				console.log( "res");
				console.log( res );
				
				var msg = ( res ) ? 'Updated successfully' : 'Updation failed' ;
				
				alert( msg );
				
				refreshpictorialTable();
				
				$('#picqup').hide();
				$('#picqadd').show();
				
				$('#picq_frm #answer, #picq_frm #image_duration, #picq_frm #image_duration_slug, #picq_frm #answer_duration, #picq_frm #answer_duration_slug').val('');
					
			},
			error: function (e) {

				// $("#result").text(e.responseText);
				console.log("ERROR : ", e);
				// $("#btnSubmit").prop("disabled", false);

			}
		});
		
	});	

	$("#textualTable").on("click", ".glyphicon-edit", function(){
		console.log( 'glyphicon-edit click');
		var id_question = $(this).closest('tr').find('.id_question').val();
		console.log( 'id_question:' + id_question );
		
		$.ajax({
					url:"<?php echo admin_url('dailyquiz/get_que_txt_det'); ?>",
					type: "POST",
					data:{id_question: id_question},
					 success: function (res) {

							console.log( 'res:' );
							console.log( res );
							var obj = JSON.parse( res );

							$('#textq_frm #question_name').val( obj.question_name );
							$('#textq_frm #answer').val( obj.answer );
							$('#textq_frm #id_question').val( obj.id_question );
							
							$('#textqadd').hide();
							$('#textqup').show();
							
							
					 }
		});
		
	});		
	
	$("#textq_frm").on("click", "#textqup", function(){
	
		var id_question = $('#textq_frm #id_question').val();
		var question_name = $('#textq_frm #question_name').val();
		var answer = $('#textq_frm #answer').val();
	
		$.ajax({
					url:"<?php echo admin_url('dailyquiz/up_que_txt_det'); ?>",
					type: "POST",
					data:{id_question: id_question, question_name: question_name, answer: answer},
					 success: function (res) {

							console.log( res );
												
							var msg = ( res ) ? 'Updated successfully' : 'Updation failed' ;
							
							alert( msg );
							
							// $('body').find('#infoModal').find('.modal-body').html( msg );
							// $('body').find('#infoModal').modal('show');
							$('#textq_frm #question_name, #textq_frm  #answer').val('');
							$('#textqup').hide();
							$('#textqadd').show();
							
							refreshtextualTable();
					 }
		});
	
	});
	
	$("#textualTable").on("click", ".glyphicon-trash", function(){
		
		console.log( 'glyphicon-trash click');
		var id_question = $(this).closest('tr').find('.id_question').val();
		console.log( 'id_question:' + id_question );
		
		var res = confirm('Do you want to delete this record?');
		
		if( res ){
		
			$.ajax({
						url:"<?php echo admin_url('dailyquiz/del_que_txt_det'); ?>",
						type: "POST",
						data:{ id_question: id_question },
						 success: function (res) {

								console.log( res );
													
								var msg = ( res ) ? 'Deleted successfully' : 'Deletion failed' ;
								
								alert( msg );
								
								refreshtextualTable();
						 }
			});
			
		}
		
	});
	
	$(".nextfrm").submit( function() {				
		console.log("form submit");				
		var total_questions = $("#total_questions").val();		
		var rowadded = $(this).prev(".box-primary").find("table tbody tr").length;		
		console.log("total_questions:" + total_questions + ", rowadded:" + rowadded);		
		if( total_questions > rowadded )		
		{			
			alert('Please add ' + ( total_questions - rowadded ) + ' more question.');			
			return false;
		}		
		else if( total_questions < rowadded )		
		{			
			alert('Please remove ' + ( rowadded - total_questions ) + ' more question.');			
			return false;		
		}	
			
	} );
	
	
	//alert('Please select article');

	$("#step-3").on("click", "#recsub", function(){
		
		var recart = $("#recart").val();
		var recid = $("#recid").val();
		var exam_id = $("#exam_id").val();
		console.log( 'recart:' + recart + ', recid:' + recid + ', exam_id:' + exam_id );
		
		if( recart == '' )
			alert('Please select article');
		
		$.ajax({
					url:"<?php echo admin_url('dailyquiz/subrec'); ?>",
					type: "POST",
					data:{recart: recart, exam_id: exam_id, recid: recid},
					 success: function (res) {

							console.log( res );
												
							$("#subcat_div").html( res );
							
					 }
		});
		
	});
	

	
	$("body").on("click", "#schpub", function(){
		
		$('#schdiv').css('display','inline-flex');
		
		var scheduleddate = $('#scheduleddate').val();
		var scheduledtime = $('#scheduledtime').val();
		
		console.log( 'scheduleddate:' + scheduleddate );
		console.log( 'scheduledtime:' + scheduledtime );
		
		if( scheduleddate == '' )
		{
			alert('Please select scheduled date.' );
			$('#scheduleddate').focus();
			return false;
		}
		else if( scheduledtime == '' )
		{
			alert('Please select scheduled Hour.' );
			$('#scheduledtime').focus();
			return false;
		}
		else
		{
			$('#step3').trigger('click');
		}
		
	});
	

	$('.setup-panel .stepwizard-step:nth-child(1) a').trigger('click');
	// $('.setup-panel .stepwizard-step:first a').hide();
	
	// $('.datepicker').datepicker();
	$('.select2-container').css('width','1086px');
	
	
	/* remove test code */
	// $('#astep3').trigger('click');
	
	/*
	if( quiztype == 'MCQ' )
	{
	
		
		$("#mcq_frm").show();
		$("#picq_frm,#textq_frm").hide();
		$(".mopt").show();	
		
	
	}
	else if( quiztype == 'pictorial' )
	{
	
	
		$("#picq_frm").show();
		$("#mcq_frm,#textq_frm").hide();
		$(".mopt").hide();
		$(".picopt").show();
	
	}
	else if( quiztype == 'textual' )
	{
	
		
		$("#textq_frm").show();
		$("#mcq_frm,#picq_frm").hide();			
		$(".mopt").hide();
		$(".textopt").show();
	
	}
	*/
	
	/* remove test code end */
	
	$("body").on("click", "#allmcq", function(){
		
		if( $(this).is(':checked') )
			$('.mcqchk').prop('checked', true);
		else
			$('.mcqchk').prop('checked', false);
		
	} );// click end
	
	$("body").on("click", "#alltxt", function(){
		
		if( $(this).is(':checked') )
			$('.txtchk').prop('checked', true);
		else
			$('.txtchk').prop('checked', false);
		
	} );// click end
	
	$("body").on("click", "#allpic", function(){
		
		if( $(this).is(':checked') )
			$('.picchk').prop('checked', true);
		else
			$('.picchk').prop('checked', false);
		
	} );// click end
	
	$("body").on("click", "#allimpmcq", function(){
		
		if( $(this).is(':checked') )
			$('.singqb').prop('checked', true);
		else
			$('.singqb').prop('checked', false);
		
	} );// click end
	
	$("body").on("click", ".expqb", function(){
		
		var mcqchk = $('.mcqchk:checked').map(function() {return this.value;}).get().join(',');
		
		console.log( 'mcqchk:' );
		console.log( mcqchk );
		
		if( mcqchk == '' )
		{
			alert('Please select questions.');
			return false;
		}
		
		var res = confirm('Do you want to export these questions.');
		
		if( res != '' )
		{
			$.ajax({
						url:"<?php echo admin_url('dailyquiz'); ?>/exportqb/",
						type: "POST",
						data:{mcqchk: mcqchk},
						 success: function (res) {

								console.log( res );													
								alert('Exported to QB');
								
						 }
			});
		}
		
	});
	
	$("body").on("click", ".impqb", function(){
		
		var quiztype = $('#quiztype').val();
		
		console.log( 'quiztype:' );
		console.log( quiztype );
		
		$.ajax({
					url:"<?php echo admin_url('dailyquiz'); ?>/getqbque/",
					type: "POST",
					data:{quiztype:quiztype},
					 success: function (res) {

							console.log( 'res:' );
							console.log( res );
							
							$('#impMcqTable tbody').html(res);
							$('#impqbModel').modal('show');
							
					 }
		});
		
	});
	
	$("body").on("click", "#impqbbtn", function(){
		
		var singqb = $('.singqb:checked').map(function() {return this.value;}).get().join(',');
		
		console.log( 'singqb:' );
		console.log( singqb );
		
		var exam_id = $('input[name=exam_id]').val();
		
		console.log( 'exam_id:' );
		console.log( exam_id );
		
		$.ajax({
					url:"<?php echo admin_url('dailyquiz'); ?>/importqb/",
					type: "POST",
					data:{singqb: singqb, exam_id: exam_id},
					 success: function (res) {

							console.log( res );
							
							alert('Imported successfully');
							$('#impqbModel').modal('hide');
							
						   refreshQuestionsTable();
						  
						   refreshpictorialTable();
						  
						   refreshtextualTable();
						   
							setTimeout(function(){
								// alert("Hello"); 
								console.log( '-----  Setting txt table ------' );
								settxttable();
								console.log( '-----  Setting pic table ------' );
								setpictable();
							}, 3000); 
						   
					 }
		});
		
	});
	
	function settxttable()
	{
		$("#textualTable tr").each(function(){
			var id_question = $(this).find('.id_question').val();
			
			console.log( 'id_question:' );
			console.log( id_question );
			
			$(this).find('td').first().html('<input type="checkbox" class="mcqchk" name="mcqchk[]" id="mcqchk" value="'+ id_question +'" />');
			
		});
	}
	
	function setpictable()
	{
		$("#pictorialTable tr").each(function(){
			var id_question = $(this).find('.id_question').val();
			
			console.log( 'id_question:' );
			console.log( id_question );
			
			$(this).find('td').first().html('<input type="checkbox" class="mcqchk" name="mcqchk[]" id="mcqchk" value="'+ id_question +'" />');
			
		});
	}
	
	setTimeout(function(){
		// alert("Hello"); 
		console.log( '-----  Setting txt table ------' );
		settxttable();
		console.log( '-----  Setting pic table ------' );
		setpictable();
	}, 3000); 
	
	$("body").on("click", "#textqadd", function(){
		setTimeout(function(){
			console.log( '-----  Setting txt table ------' );
			settxttable();
		}, 5000); 	
	});
	
	$("body").on("click", "#picqadd", function(){
		setTimeout(function(){
			console.log( '-----  Setting pic table ------' );
			setpictable();
		}, 5000); 	
	});
	
	$("body").on("click", ".sel_fp", function(){
	
		var id = $(this).data('id');
		
		console.log( 'id:' );
		console.log( id );
		
		$('#recid').val( id );
		
		$('#myModal').modal('show');
			
	});
	
	console.log( 'recsub click:' );
	
	$("#myModal").on("click", "#recsub", function(){
		
		/*
		var artid = $('#artid').val();
		var artnm = $('#artid option:selected').text();
		var artord = $('#artord').val();
		
		console.log( 'artid:' + artid );
		console.log( 'artnm:' + artnm );
		console.log( 'artord:' + artord );
		
		$('#fpost' + artord).val( artid );
		$('#fpost'+artord+'_nm').text( 'Article ' + artord + ' - ' + artnm );
		*/
		
		var recid = $('#recid').val();		
		var artid = $('#artid').val();
		var artnm = $('#artid option:selected').text();		
		
		console.log( 'recid:' + recid );
		console.log( 'artid:' + artid );
		console.log( 'artnm:' + artnm );
		
		var arr = artid.split('-***-');
		
		console.log( arr );
		
		$('#show_fp' + recid + ' p').text( artnm );
		$('#show_fp' + recid + ' img').attr( 'src', '<?=base_url()?>uploads/posts/' + arr[1] );
		$('#fpost' + recid).val( arr[0] );
		
		$('#sel_fp' + recid).hide();
		$('#show_fp' + recid).show();
		
		$('#myModal').modal('hide');		
		
	});
	
	
    $("body").on("click", "#prev_quiz", function(){
            
            var exam_id = $('input[name=exam_id]').val();
    
            console.log( 'exam_id:' );
            console.log( exam_id );
    
    	   $.ajax({
    		    url: "<?= admin_url('dailyquiz/getexamslug') ?>",
    		    type: "POST",
    		    data: {exam_id : exam_id}, 
                success: function(res){
    			
                    //window.open(res, '_blank');
                    window.open(res);
    		        
                }
    		});
    });
    
    $("body").on("click", "#back1", function(){
        $('#astep1').trigger('click');
    });
    
    $("body").on("click", "#back2", function(){
        $('#astep2').trigger('click');
    });
	
});

</script>
  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
  <script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>