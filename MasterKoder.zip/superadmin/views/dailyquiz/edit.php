<style type="text/css">
.modal-body img{
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 30%;
}
</style>
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Quiz
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('dailyquiz') ?>">Exam</a></li>
        <li class="active">Edit Exam</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content dailyquiz-box">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary dailyquiz-box-header">
            <!-- form start -->
              <div class="box-body">
                <div class="col-md-12">
                    <div class="stepwizard">
                        <div class="stepwizard-row setup-panel">
                            <div class="stepwizard-step">
                                <a href="#step-1" type="button" class="btn btn-default btn-circle ">1</a>
                                <p>Add Quiz details</p>
                            </div>
                            <div class="stepwizard-step">
                                <a href="#step-2" type="button" class="btn btn-default btn-circle ">2</a>
                                <p>Add Questions & Answers</p>
                            </div>
							<div class="stepwizard-step">
                                <a href="#step-3" type="button" class="btn btn-success btn-circle ">3</a>
                                <p>Publish</p>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
          </div>
          <div class="col-md-12">
            <form class="process-form-img-editor" action="<?=admin_url('dailyquiz/update_step_1')?>" method="post" role="form">
                <div class="row setup-content" id="step-1" style="display: none;">
                  <div class="box box-primary">
                      <div class="box-header with-border">
                          <i class="fa fa-book"></i>
                          <h3 class="box-title">Quiz Details</h3>
                      </div>
                      <div class="box-body">
					  
                        <div class="col-xs-12">
						<div class="row">
						
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label for="first_name">Quiz Type</label>
                        
						<!--
						<select class="form-control examcat" name="quiztype" id="quiztype">
							<option value="">Select Quiz Type</option>
							<option value="MCQ">Multi Choice Quiz</option>
							<option value="pictorial">Pictorial Quiz</option>
							<option value="textual">Textual Quiz</option>
							

							
                        </select>
						-->
						
<?php
	$opt = array( "" => "Select", "MCQ" => "Multi Choice Quiz", "pictorial" => "Pictorial Quiz", "textual" => "Textual Quiz" );
	
	echo form_dropdown( 'quiztype', $opt, $row->quiz_type, 'id="quiztype" class="form-control examcat"' );
?>
						
                    </div>
                  </div>				                    <div class="col-sm-12">                    <div class="form-group">							<label for="exam_name">Quiz Name</label>								<input type="text" class="form-control" id="exam_name" placeholder="Exam Name" name="exam_name" value="<?= $row->exam_name ?>">                    </div>                  </div>
						
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label for="first_name">Super Category</label>
                        
						<?php

/* echo "<hr><pre>quizcatid: ";
var_dump( $row->quizcatid ); */
						?>
						
						<select class="form-control examcat" multiple="multiple" name="examcat[]" id="examcat"  onChange="geteaxamsubcategory()">
						<option value="">Select Super Category</option>
						<?php
						$catid = explode(',',$row->quizcatid);
						foreach($examcats as $examcats)
						{
						      if(in_array($examcats->id,$catid ))
							   {
								 $sel = "selected='selected'";
							   }
							   else
							   {
								 $sel ="";
							   }
						?>
						
						
						  <option value="<?=$examcats->id?>" <?= $sel?>><?=$examcats->category_name?></option>
						<?php
						}
						?>
						
                        </select>
                      </div>
                  </div>
				  <div class="col-sm-12">
                    <div class="form-group">
                        <label for="first_name"> Category</label>
                        
						<?php
$subcatid = explode(',',$row->sub_catid);
/* echo "<hr><pre>subcatid: ";
var_dump( $subcatid ); */
						
						?>
						
						<select class="form-control examsubcat" id="subcat"  multiple="multiple" name="subcat[]" onChange="getsubsubcats()">
							<option value="">Select Category </option>

						<?php

						
						foreach($subcats as $subcats)
						{
							  

							   if(in_array($subcats->id,$subcatid ))
							   {
								 $sel = "selected='selected'";
							   }
							   else
							   {
								 $sel ="";
							   }
						?>
						  <option value="<?=$subcats->id?>" <?=$sel?>><?=$subcats->title?></option>
						<?php
						}
						?>
						
						
                        </select>
                      </div>
                  </div>
          			<div class="col-sm-12">
            						<div class="form-group">
            							 <label for="first_name">Sub Category</label>
                        
											<select class="form-control subsub" multiple="multiple" id="subsub" name="subsub[]" >
											<option value="">Select  Sub Category </option>
											<?php
											$subsubcatid = explode(',',$row->subsub_catid);
											foreach($subsub as $subsub)
											{
												 if(in_array($subsub->id,$subsubcatid ))
												 {
													 $sel = "selected='selected'";
												 }
												 else
												 {
													$sel ="";
												 }
											?>
											  <option value="<?=$subsub->id?>" <?=$sel?>><?=$subsub->title?></option>
										<?php
										 }
										?>
						                    </select>
            						</div>
          					   </div>
          		 </div>
				  
               
				         
								  
				<!--
                             <div class="row">
          						<div class="col-sm-12">
            						<div class="form-group">
            							<label for="exam_name">Quiz Name</label>
            								<input type="text" class="form-control" id="exam_name" placeholder="Exam Name" name="exam_name">
            						</div>
          					   </div>
          						</div>  								-->

                            <div class="row">
                              <div class="col-sm-12">
                              <div class="form-group">
                                <label class="control-label">Description</label>
                                <textarea id="editor" name="exam_description" class="form-control" placeholder="Exam description" rows="15"><?= base64_decode($row->exam_description) ?></textarea>
                                </div>
                              </div>
                            </div> 


          									<div class="row">
          									  

          									  <div class="col-sm-4 mopt picopt textopt">
            										<div class="form-group">
            											<label class="control-label">Total Questions</label>
            											<input type="number" class="form-control" id="total_questions" placeholder="Total Questions" name="total_questions" min="1" value="<?= $row->total_questions ?>">
          										  </div>
          									  </div>

                              <div class="col-sm-4 mopt textopt">
                                <div class="form-group">
                                  <label for="first_name">Exam Duration</label>
                                  <div class="input-group input-group-md">
								  
                                    <input type="number" class="form-control" id="total_time" placeholder="Total Time" name="total_time" min="1" value="<?php if( $row->quiz_type == 'pictorial' ) echo '1'; else echo $row->exam_duration; ?>">
									
                                    <div class="input-group-btn ">
                                      <select class="btn btn-default btn-flat form-control-1" name="duration_slug" id="duration_slug">
                                        <option value="">Select</option>
                                        <option <?= ($row->exam_duration_slug == "minutes")? "selected"   : "" ?> value="minutes">Minutes</option>
                                        <option <?= ($row->exam_duration_slug == "hours")? "selected"   : "" ?> value="hours">Hours</option>
                                      </select>
                                    </div>                        
                                  </div>
                                </div>
                              </div>

                              
                              <div class="col-sm-4 mopt picopt textopt">
                                <div class="form-group">
                                  <label for="meta_tags">Coins per Correct Question</label>
                                 <input type="number" class="form-control" name="coin" id="coin" value="<?= $row->coins ?>">
                                </div>
            									</div>
                            </div>
							<div class="row">
          									  <div class="col-sm-4 mopt">
            										<div class="form-group">
            											<label class="control-label">Marks per Question</label>
            											<input type="number" class="form-control" id="marks" name="marks" placeholder="Marks"style="max-width: 100%" value="<?= $row->marks_per_ques ?>">
          										  </div>
          									  </div>
 
          									  <div class="col-sm-4 mopt">
            										<div class="form-group">
            											<label class="control-label">Negative Marks Per Questions</label>
            											<input type="number" class="form-control" step="0.01"  id="negativemarks" value="<?= $row->negative_mark ?>" placeholder="Negative Marks" name="negativemarks" min="0">
          										  </div>
          									  </div>

                              <div class="col-sm-4 mopt">
                                <div class="form-group">
                                  <label for="first_name">Difficulty Level</label>
                                 
                                     <select class="form-control" name="diff_level" id="diff_level">
                                        <option value="">Select</option>
                                        <option value="Easy" <?= ($row->difficulty_level=="Easy")? "selected" : "" ?>>Easy</option>
										 <option value="Medium" <?= ($row->difficulty_level=="Medium")? "selected" : "" ?>>Medium</option>
                                        <option value="Difficult" <?= ($row->difficulty_level=="Difficult")? "selected" : "" ?>>Difficult</option>
                                      </select>
                               
                                </div>
                              </div>

                              
                              
                            </div>
							<div class="row">

							   <div class="col-sm-8 mopt1" style="display:none;">
            										<div class="form-group">
            											<label class="control-label">Image Url</label>
            											<input type="text" class="form-control" id="imgurl" name="imgurl" value="<?=$row->image_url?>">
          										  </div>
          									  </div>
							</div>
                            <div class="row">
          						<!--<div class="col-sm-6">
									<div class="form-group">
										<label class="" style="width:100%">&nbsp;</label>
										
										<label class="form-check-label" for="exampleCheck1">
											<input type="checkbox" class="form-check-input" name="newffedpost" value="1">
										Add Quiz to Newsfeed </label>
									</div>
								  </div>-->
								  
							<!--	  
							  <div class="col-sm-12 mopt">
								<div class="form-group">
									<label class="" style="width:100%">&nbsp;</label>
									
									<label class="form-check-label" for="exampleCheck1">
										<input type="checkbox" class="form-check-input" name="featured" value="1">
									Mark as Featured Quiz</label>
								</div>
							  </div>
							  -->
							  
          						</div>

                            <div class="row">
                              <div class="col-xs-12 ">
							
                               <div class="loadimg" style="display:none;">
							<img src="<?= base_url('assets/images/reload.gif') ?>" style="margin-left:45%;" width="50px;" height="50px;">
						   </div>
                                <input type="hidden" name="action" value="exam-step1">
                                <input type="hidden" name="exam_id" class="exam_id" value="<?=$row->id_exam?>">
                                <input class="btn btn-primary btn-sm pull-right icon" type="submit" name="step1" value="Next">
                              </div>
                            </div>
                        </div>
                      </div>
                  </div>
                </div>
            </form>
          </div>  

          <div class="setup-content" id="step-2" style="display: none;">
			<div id="mcq_frm" style="display: none;">
            <form class="process-form-img-editor" id="secondstep" action="<?= admin_url('dailyquiz/insert_step_2') ?>" method="post" role="form">    
              <div class="box box-primary ">
                <div class="box-header with-border">
                    <i class="fa fa-book"></i>
                    <h3 class="box-title">Questions & Answers</h3>
                </div>

                  <div class="box-body question-options-box">
                      <div class="col-xs-12">

                          <div class="row">
                              <div class="col-sm-12">
                                <div class="form-group quiz-question-title">
                                  <label for="first_name">Question</label>
                                  
								    <textarea class="form-control" name="question_name" id="question_name" rows="3"   placeholder="Question"></textarea>
                                  
                                    
                                      <input type="file" id="question_image" name="question_image" >
                                                    
                               
                                </div>
                              </div>
                          </div>

                          <div class="row">
                              <div class="col-sm-12">
                                <div class="form-group quiz-question-option">
                                  <label for="first_name">First option</label>
                                  
                                     <textarea name="option_1" id="option_1" class="form-control abc" placeholder="First option" /></textarea>
                                   
                                      <input type="file" id="option_1_image" name="option_1_image" >
                                                      
                                
                                </div>
                              </div>

                              <div class="col-md-12">
                                <div class="form-group quiz-question-option">
                                  <label for="first_name">Second option</label>
                       
                                     <textarea name="option_2" id="option_2" class="form-control abc" placeholder="Second option" /></textarea>
                                      <input type="file" id="option_2_image" name="option_2_image">
                                                        
                                
                                </div>
                              </div>
                          </div>

                          <div class="row">
                              <div class="col-md-12">
                                <div class="form-group quiz-question-option">
                                  <label for="first_name">Third option</label>
                                
                                    <textarea name="option_3" name="option_3" id="option_3" class="form-control" placeholder="Third option" /></textarea>
                                    <input type="file" id="option_3_image" name="option_3_image" >
                                    
                                </div>
                              </div>
                              <div class="col-md-12">
                                <div class="form-group quiz-question-option">
                                  <label for="first_name">Fourth option</label>
                                  
                                    <textarea name="option_4" id="option_4" class="form-control" placeholder="Third option" /></textarea>
                                     <input type="file" id="option_4_image" name="option_4_image" >
                                   
                                </div>
                              </div>
                          </div>
						<div class="row">
                              <div class="col-md-12">
                                <div class="form-group quiz-question-option">
                                  <label for="first_name">Fifth option</label>
                                
                                    <textarea  name="option_5" id="option_5" class="form-control" placeholder="Fifth option" /></textarea>
                                    <input type="file" id="option_4_image" name="option_4_image" >
                                    
                                </div>
                              </div>
                              
                              
                              <div class="col-md-12">
                                  <p class="choose-correct-option">Choose Correct Option</p>
                              </div>
                              <div class="col-md-12">
                                <div class="form-group">
                                  <div class="form-group">
                                  <label for="first_name">Explanation</label>
                                    <textarea rows="3" cols="50" name="explanation" id="explanation" class="form-control" placeholder="Explanation"> </textarea>                      
                                </div>
                                   
                                </div>
                              </div>
                          </div>
                          <div class="row">
                              <div class="col-md-12">
                                <div class="form-group">
                                  <label class="control-label">Correct Option is</label>
                                  <select class="form-control" name="answer_option" id="answer_option">
                                      <option value="">Select</option>
                                      <option value="1">First option</option>
                                      <option value="2">Second option</option>
                                      <option value="3">Third option</option>
                                      <option value="4">Fourth option</option>
									   <option value="5">Fifth option</option>
                                    </select>
                                </div>
                              </div>
                          </div>
                        

                          <div class="row">
                              <div class="col-md-12 text-center quiz-add-question-btn">
                            <div class="loadimg" style="display:none;">
							<img src="<?= base_url('assets/images/reload.gif') ?>" style="margin-left:45%;" width="50px;" height="50px;">
						   </div>
                                <input type="hidden" name="action" value="exam-step2">
                                <input type="hidden" name="id_question" id="id_question" value="">
                                <input type="hidden" name="exam_id" class="exam_id" value="<?=$row->id_exam?>">
                                <input class="btn btn-primary btn-sm" type="submit" name="step2" id="mcqadd" value="Add question" >
                                <input class="btn btn-primary btn-sm" type="button" name="mcqup" id="mcqup" value="Update" style="display:none;" >
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
            </form>

            <div class="box box-primary bx-shadow-none bg-transparent added-questions-box">
                <div class="box-header with-border">
                    <i class="fa fa-book"></i>
                    <h3 class="box-title">Added Questions</h3>
                </div>
                <div class="box-body">
                    <div class="col-xs-12">
                      <table id="questionsTable" class="table table-responsive table-bordered table-striped" style="width: 100%; min-width: 100%">
                        <thead>
                        <tr>
							<th> <input type="checkbox" name="allmcq" id="allmcq" value="" /> </th>
                          <th>Question</th>
                          <th>Added on</th>
                          <th>Status</th>
                          <th width="10%">Actions</th>
                        </tr>
                        </thead>
                      </table>
                    </div>
                </div>
            </div>

            <form class="process-form nextfrm" action="<?= admin_url('dailyquiz/insert_step_3') ?>" method="post" role="form">
              <div class="box box-primary bx-shadow-none bg-transparent quiz-import-export-box">
                  <div class="box-body">
                      <div class="col-xs-12">
                          <div class="row">
                              <div class="col-md-12">
                                <input type="hidden" name="action" value="exam-step3">
                                
                                <input type="hidden" name="exam_id" class="exam_id" value="<?=$row->id_exam?>">
								
                                <input class="btn btn-success btn-sm pull-right impqb bg-blue-btn" type="button" id="impqb" name="impqb" value="Import from DB" style="margin-left: 5px;float: left !important;"> 
                                <input class="btn btn-success btn-sm pull-right expqb bg-blue-btn" type="button" id="expqb" name="expqb" value="Export to DB" style="margin-left: 5px;float: left !important;"> 
								
                                <input class="btn btn-success btn-sm pull-right" type="submit" name="step3" value="Next">
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
            </form>
			
			</div>
			
			<div id="picq_frm" style="display: none;">

					<form class="process-form-image" id="secondstep" action="<?= admin_url('dailyquiz/insert_image_step_2') ?>" method="post" role="form">    
						<div class="box box-primary">
						<div class="box-header with-border">
							<i class="fa fa-book"></i>
							<h3 class="box-title">Add Questions</h3>
						</div>
						<div class="box-body">
							<div class="col-xs-12">
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											<label for="first_name">Question Image</label>
											<input type="file" id="question_image" name="question_image" >
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											<label for="answer">Answer</label>
											<textarea name="answer" id="answer" class="form-control" placeholder="Answer" /></textarea>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="first_name">Picture Duration</label>
											<div class="input-group input-group-md">
												<input type="number" class="form-control" id="image_duration" placeholder="Total Picture Time" name="image_duration" min="1">
												<div class="input-group-btn">
													<select class="btn btn-default btn-flat form-control-1" name="image_duration_slug" id="image_duration_slug">
														<option value="">Select</option>
														<option value="minutes">Minutes</option>
														<option value="hours">Hours</option>
													</select>
												</div>                        
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="first_name">Answer Duration</label>
											<div class="input-group input-group-md">
												<input type="number" class="form-control" id="answer_duration" placeholder="Total Answer Time" name="answer_duration" min="1">
												<div class="input-group-btn">
													<select class="btn btn-default btn-flat form-control-1" name="answer_duration_slug" id="answer_duration_slug">
														<option value="">Select</option>
														<option value="minutes">Minutes</option>
														<option value="hours">Hours</option>
													</select>
												</div>                        
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="loadimg" style="display:none;">
											<img src="<?= base_url('assets/images/reload.gif') ?>" style="margin-left:45%;" width="50px;" height="50px;">
										</div>
										<input type="hidden" name="action" value="exam-image-step2">
										<input type="hidden" name="exam_id" class="exam_id" value="<?=$row->id_exam?>">
										<input type="hidden" name="id_question" id="id_question" value="">
										<input class="btn btn-primary btn-sm pull-right " type="submit" name="step2" id="picqadd" value="Add" >
										<input class="btn btn-primary btn-sm pull-right " type="button" name="picqup" id="picqup" value="Update" style="display:none;" >
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>

				<div class="box box-primary bx-shadow-none bg-transparent added-questions-box">
					<div class="box-header with-border">
						<i class="fa fa-book"></i>
						<h3 class="box-title">Added Questions</h3>
					</div>
					<div class="box-body">
						<div class="col-xs-12">
						  <table id="pictorialTable" class="table table-responsive table-bordered table-striped" style="width: 100%; min-width: 100%">
							<thead>
							<tr>
							  <th> <input type="checkbox" name="allpic" id="allpic" value="" /> </th>
							  <th>Question</th>
							  <th width="10%">Actions</th>
							</tr>
							</thead>
						  </table>
						</div>
					</div>
				</div>

				<form class="process-form nextfrm" action="<?= admin_url('dailyquiz/insert_step_3') ?>" method="post" role="form">
				  <div class="box box-primary bx-shadow-none bg-transparent quiz-import-export-box">
					  <div class="box-body">
						  <div class="col-xs-12">
							  <div class="row">
								  <div class="col-md-12">
									<input type="hidden" name="action" value="exam-step3">
									
									<input type="hidden" name="exam_id" class="exam_id" value="<?=$row->id_exam?>">
									
                                <input class="btn btn-success btn-sm pull-right impqb bg-blue-btn" type="button" id="impqb" name="impqb" value="Import from DB" style="margin-left: 5px;float: left !important;"> 
                                <input class="btn btn-success btn-sm pull-right expqb bg-blue-btn" type="button" id="expqb" name="expqb" value="Export to DB" style="margin-left: 5px;float: left !important;"> 
								
									<input class="btn btn-success btn-sm pull-right" type="submit" name="step3" value="Next">
								  </div>
							  </div>
						  </div>
					  </div>
				  </div>
				</form>
			
			</div>
			
			<div id="textq_frm" style="display: none;">
			
					<form class="process-form-image" id="secondstep" action="<?= admin_url('dailyquiz/insert_textual_step_2') ?>" method="post" role="form">    
						<div class="box box-primary">
						<div class="box-header with-border">
							<i class="fa fa-book"></i>
							<h3 class="box-title">Add Questions</h3>
						</div>
						<div class="box-body">
							<div class="col-xs-12">
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											<label for="question_name">Question </label>
											<textarea name="question_name" id="question_name" class="form-control" placeholder="Question" /></textarea>
											
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											<label for="answer">Answer</label>
											<textarea name="answer" id="answer" class="form-control" placeholder="Answer" /></textarea>
										</div>
									</div>
								</div>
	<!--                            <div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="first_name">Picture Duration</label>
											<div class="input-group input-group-md">
												<input type="number" class="form-control" id="image_duration" placeholder="Total Picture Time" name="image_duration" min="1">
												<div class="input-group-btn">
													<select class="btn btn-default btn-flat form-control-1" name="image_duration_slug" id="image_duration_slug">
														<option value="">Select</option>
														<option value="minutes">Minutes</option>
														<option value="hours">Hours</option>
													</select>
												</div>                        
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="first_name">Answer Duration</label>
											<div class="input-group input-group-md">
												<input type="number" class="form-control" id="answer_duration" placeholder="Total Answer Time" name="answer_duration" min="1">
												<div class="input-group-btn">
													<select class="btn btn-default btn-flat form-control-1" name="answer_duration_slug" id="answer_duration_slug">
														<option value="">Select</option>
														<option value="minutes">Minutes</option>
														<option value="hours">Hours</option>
													</select>
												</div>                        
											</div>
										</div>
									</div>
								</div>-->
								<div class="row">
									<div class="col-md-12">
										<div class="loadimg" style="display:none;">
											<img src="<?= base_url('assets/images/reload.gif') ?>" style="margin-left:45%;" width="50px;" height="50px;">
										</div>
										<input type="hidden" name="action" value="exam-textual-step2">
										<input type="hidden" name="exam_id" class="exam_id" value="<?=$row->id_exam?>">
										<input type="hidden" name="id_question" id="id_question" value="">
										<input class="btn btn-primary btn-sm pull-right " type="submit" name="step2" id="textqadd" value="Add" >
										<input class="btn btn-primary btn-sm pull-right " type="button" name="step2" id="textqup" value="Update" style="display: none;" >
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>

				<div class="box box-primary bx-shadow-none bg-transparent added-questions-box">
					<div class="box-header with-border">
						<i class="fa fa-book"></i>
						<h3 class="box-title">Added Questions</h3>
					</div>
					<div class="box-body">
						<div class="col-xs-12">
						  <table id="textualTable" class="table table-responsive table-bordered table-striped" style="width: 100%; min-width: 100%">
							<thead>
							<tr>
							  <th> <input type="checkbox" name="alltxt" id="alltxt" value="" /> </th>
							  <th>Question</th>
							  <th width="10%">Actions</th>
							</tr>
							</thead>
						  </table>
						 
						  
						</div>
					</div>
				</div>

				<form class="process-form nextfrm" action="<?= admin_url('dailyquiz/insert_step_3') ?>" method="post" role="form">
				  <div class="box box-primary bx-shadow-none bg-transparent quiz-import-export-box">
					  <div class="box-body">
						  <div class="col-xs-12">
							  <div class="row">
								  <div class="col-md-12">
									<input type="hidden" name="action" value="exam-step3">
									
									<input type="hidden" name="exam_id" class="exam_id" value="<?=$row->id_exam?>">
									
                                <input class="btn btn-success btn-sm pull-right impqb bg-blue-btn" type="button" id="impqb" name="impqb" value="Import from DB" style="margin-left: 5px;float: left !important;"> 
                                <input class="btn btn-success btn-sm pull-right expqb bg-blue-btn" type="button" id="expqb" name="expqb" value="Export to DB" style="margin-left: 5px;float: left !important;"> 
									
									<input class="btn btn-success btn-sm pull-right" type="submit" name="step3" value="Next">
								  </div>
							  </div>
						  </div>
					  </div>
				  </div>
				</form>

			</div>
			
          </div>    


          <div class="setup-content" id="step-3" style="display: none;">
	
			<?php	
			echo form_open_multipart( admin_url('dailyquiz/insert_textual_step_final'), array('class' => 'process-form-img-editor','role' => 'form'));
			?>
		  
            <!--<form class="process-form-img-editor" action="<?= admin_url('dailyquiz/insert_textual_step_final')?>" method="post" role="form">
					<form class="process-form-img-editor" id="secondstep" action="<?= admin_url('dailyquiz/insert_textual_step_final') ?>" method="post" role="form" enctype="multipart/form-data"> -->   
						<div class="box box-primary">
						
						<div class="box-body">
							<div class="col-xs-12">
							
<!--							
								<div class="row">									
									<div class="col-sm-12">									
									<div class="form-group">								
										<label class="control-label">Featured Image</label>		
										
										<input type="file" class="btn btn-default btn-flat" id="featured_image" name="featured_image" >											
										<a href="#" class="show-img-popup" data-src="<?= base_url($row->exam_upload_path.$row->exam_featured_image) ?>" data-toggle="modal" data-target="#infoModal"><?= $row->exam_featured_image ?></a>										
										</div>									
									</div>								
								</div>
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											<label for="question_name">Mark as featured post</label>
											
											<select class="form-control examcat" name="featured" id="featured">
												<option value="1" <?php if($row->featured_quiz == "1"){echo 'selected';}?>>Yes</option>
												<option value="0" <?php if($row->featured_quiz == "0"){echo 'selected';}?>>No</option>
												
											</select>
											
										</div>
									</div>
								</div>	
-->								
					
                <div class="form-group" style="display: none;">
                  <label for="order">Add Featured Post</label> <button type="button" class="btn btn-info add-featured-post-btn" data-toggle="modal" data-target="#myModal"> <span class="glyphicon glyphicon-plus"></span> </button>

				  <br>
					<span id="fpost1_nm"></span>
					<br>
					<span id="fpost2_nm"></span>
					<br>
					<span id="fpost3_nm"></span>
					<br>
					<span id="fpost4_nm"></span>
					
					<input type="hidden" name="fpost1" id="fpost1" value="<?=$row->recommended_1?>" />
					<input type="hidden" name="fpost2" id="fpost2" value="<?=$row->recommended_2?>" />
					<input type="hidden" name="fpost3" id="fpost3" value="<?=$row->recommended_3?>" />
					<input type="hidden" name="fpost4" id="fpost4" value="<?=$row->recommended_4?>" />

                </div>
				
				
				<div class="form-group">

					<div id="admin-recommended-box">
					
						<div class="row">
						
						<?php
						//echo $row->recommended_1 . ' - ' . $row->recommended_2 ;
						
						$sel_fp1dis = '';
						$show_fp1dis = 'display:none;';						
						$sel_fp1img = '';
						$sel_fp1art = '';
						
						if( !empty( $row->recommended_1 ) )
						{
						  	$sel_fp1dis = 'display:none;';
							$show_fp1dis = '';
							
							$tbl_articelepost = $this->GeneralModel->GetInfoRow( 'tbl_articelepost', array( 'id' => $row->recommended_1 ) );
							
							// print "<hr><pre>".$this->db->last_query();exit;
							
							$sel_fp1img = $tbl_articelepost[0]->featured_image;
							$sel_fp1art = $tbl_articelepost[0]->topic_title;
						}
						
						?>
						
							<div class="col-md-3 sel_fp" id="sel_fp1" data-id="1" style="<?=$sel_fp1dis?>">
								<div class="select-recommended min-height-post">
									<div class="add-post-box">
										<i class="fa fa-plus" aria-hidden="true"></i>
										<p class="rec-post-title">Select Article</p>
									</div>
								</div>
							</div>
												
							
							<div class="col-md-3" id="show_fp1" style="<?=$show_fp1dis?>">
								<div class="recommended-post min-height-post">
									<img src="<?php echo base_url() . 'uploads/posts/' . $sel_fp1img; ?>" class="img-responsive" alt="">
									<p class="rec-post-title"><?=$sel_fp1art?></p>
								</div>
							</div>
							
						<?php
						//echo $row->recommended_1 . ' - ' . $row->recommended_2 ;
						
						$sel_fp1dis = '';
						$show_fp1dis = 'display:none;';						
						$sel_fp1img = '';
						$sel_fp1art = '';
						
						if( !empty( $row->recommended_2 ) )
						{
						  	$sel_fp1dis = 'display:none;';
							$show_fp1dis = '';
							
							$tbl_articelepost = $this->GeneralModel->GetInfoRow( 'tbl_articelepost', array( 'id' => $row->recommended_2 ) );
							
							// print "<hr><pre>".$this->db->last_query();exit;
							
							$sel_fp1img = $tbl_articelepost[0]->featured_image;
							$sel_fp1art = $tbl_articelepost[0]->topic_title;
						}
						
						?>
						
							<div class="col-md-3 sel_fp" id="sel_fp2" data-id="2" style="<?=$sel_fp1dis?>">
								<div class="select-recommended min-height-post">
									<div class="add-post-box">
										<i class="fa fa-plus" aria-hidden="true"></i>
										<p class="rec-post-title">Select Article</p>
									</div>
								</div>
							</div>
						
							
							<div class="col-md-3" id="show_fp2" style="<?=$show_fp1dis?>">
								<div class="recommended-post min-height-post">
									<img src="<?php echo base_url() . 'uploads/posts/' . $sel_fp1img; ?>" class="img-responsive" alt="">
									<p class="rec-post-title"><?=$sel_fp1art?></p>
								</div>
							</div>

						<?php
						//echo $row->recommended_1 . ' - ' . $row->recommended_2 ;
						
						$sel_fp1dis = '';
						$show_fp1dis = 'display:none;';						
						$sel_fp1img = '';
						$sel_fp1art = '';
						
						if( !empty( $row->recommended_3 ) )
						{
						  	$sel_fp1dis = 'display:none;';
							$show_fp1dis = '';
							
							$tbl_articelepost = $this->GeneralModel->GetInfoRow( 'tbl_articelepost', array( 'id' => $row->recommended_3 ) );
							
							// print "<hr><pre>".$this->db->last_query();exit;
							
							$sel_fp1img = $tbl_articelepost[0]->featured_image;
							$sel_fp1art = $tbl_articelepost[0]->topic_title;
						}
						
						?>
							
							<div class="col-md-3 sel_fp" id="sel_fp3" data-id="3" style="<?=$sel_fp1dis?>">
								<div class="select-recommended min-height-post">
									<div class="add-post-box">
										<i class="fa fa-plus" aria-hidden="true"></i>
										<p class="rec-post-title">Select Article</p>
									</div>
								</div>
							</div>
							

							
							<div class="col-md-3" id="show_fp3" style="<?=$show_fp1dis?>">
								<div class="recommended-post min-height-post">
									<img src="<?php echo base_url() . 'uploads/posts/' . $sel_fp1img; ?>" class="img-responsive" alt="">
									<p class="rec-post-title"><?=$sel_fp1art?></p>
								</div>
							</div>
							
						<?php
						//echo $row->recommended_1 . ' - ' . $row->recommended_2 ;
						
						$sel_fp1dis = '';
						$show_fp1dis = 'display:none;';						
						$sel_fp1img = '';
						$sel_fp1art = '';
						
						if( !empty( $row->recommended_4 ) )
						{
						  	$sel_fp1dis = 'display:none;';
							$show_fp1dis = '';
							
							$tbl_articelepost = $this->GeneralModel->GetInfoRow( 'tbl_articelepost', array( 'id' => $row->recommended_4 ) );
							
							// print "<hr><pre>".$this->db->last_query();exit;
							
							$sel_fp1img = $tbl_articelepost[0]->featured_image;
							$sel_fp1art = $tbl_articelepost[0]->topic_title;
						}
						
						?>
							
							<div class="col-md-3 sel_fp" id="sel_fp4" data-id="4" style="<?=$sel_fp1dis?>">
								<div class="select-recommended min-height-post">
									<div class="add-post-box">
										<i class="fa fa-plus" aria-hidden="true"></i>
										<p class="rec-post-title">Select Article</p>
									</div>
								</div>
							</div>
							

							
							<div class="col-md-3" id="show_fp4" style="<?=$show_fp1dis?>">
								<div class="recommended-post min-height-post">
									<img src="<?php echo base_url() . 'uploads/posts/' . $sel_fp1img; ?>" class="img-responsive" alt="">
									<p class="rec-post-title"><?=$sel_fp1art?></p>
								</div>
							</div>

							
						</div>
						
					</div>
						
                </div>
				
				<div class="row" id="schdiv" style="display: none;">
					<div class="col-sm-6">
						<div class="form-group">
							<label for="scheduleddate"> Scheduled Date </label>
							
							<input type="date" class="form-control" id="scheduleddate" placeholder="" name="scheduleddate" min="<?=date('Y-m-d')?>">
	
<!--	
<div class="input-group date" data-provide="datepicker">
    <input type="text" class="form-control">
    <div class="input-group-addon">
        <span class="glyphicon glyphicon-th"></span>
    </div>
</div>
-->
							
							
						</div>
					</div>
					
					<div class="col-sm-6">
						<div class="form-group">
							<label for="scheduledtime"> Scheduled Hour ( 24 format ) </label>
							
						  <?php
							$opt = array( "" => "Select" );
							
							for( $i  = 0; $i <= 23 ; $i++ )
								$opt[ $i ] = $i ; 
			
							echo form_dropdown( 'scheduledtime', $opt, '', 'id="scheduledtime" class="form-control examcat"' );
						  ?>
							
						</div>
					</div>
					
				</div>	
								
			  <div class="row">
				  <div class="col-md-12">
					<input type="hidden" name="action" value="exam-stepfinal">
					<input type="hidden" name="action_up" value="1">
					
					<input type="hidden" name="exam_id" class="exam_id" value="<?=$row->id_exam?>">

					<input class="btn btn-success btn-sm pull-right" type="submit" name="step3" id="step3" value="Publish">
					
					<input class="btn btn-success btn-sm pull-right" type="button" name="schpub" id="schpub" value="Schedule Publish" style="margin-right: 5px;">
					
				  </div>
			  </div>
						  
								
							</div>
						</div>
					</div>
				</form>
		  
          </div>                          
          
           

                
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<div id="infoModal" class="modal fade" role="dialog" aria-labelledby="alertModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default cl_btn" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Select Article</h4>
			</div>
			<div class="modal-body">
				
				<label for="order">Article</label>
				<select class="form-control" name="artid" id="artid" >
					<option value="">Select</option>
					<?php
					
					if( !empty( $articles ) )
					{
					foreach($articles as $article)
					{
					?>
					  <option value="<?=$article->id?>-***-<?=$article->featured_image?>"><?=$article->topic_title?></option>
					<?php
					}
					}
					?>
					
				</select>

<!--				
				<label for="order">Order</label>
				<select class="form-control" name="artord" id="artord" >
					<option value="">Select</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					
				</select>
-->				
				
				<input type="hidden" name="recid" id="recid" value="1" />

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" id="recsub">Ok</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>

	</div>
</div>


<!-- Modal -->
<div class="modal fade" id="impqbModel" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Import to QB</h4>
			</div>
			<div class="modal-body">
				
				<table id="impMcqTable" class="table table-responsive table-bordered table-striped" style="width: 100%; min-width: 100%">
					<thead>
						<tr>
						  <th> <input type="checkbox" name="allimpmcq" id="allimpmcq" value="" /> </th>
						  <th>Question</th>
						  <!--<th>Added on</th>
						  <th>Status</th>-->
						  
						</tr>
					</thead>
					<tbody>
					
					</tbody>
				 </table>
				
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" id="impqbbtn">Ok</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>

	</div>
</div>