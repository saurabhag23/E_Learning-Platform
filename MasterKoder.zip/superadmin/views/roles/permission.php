<style type="text/css">
.brand-nav.active {
   
    background-color: #3c8dbc!important;
}
</style>
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Update User Role
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('roles') ?>">User Role</a></li>
        <li class="active">Update User Role</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    
       
	   <?= isset($permissions)? $permissions : '' ?>
	   
   
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
