


  
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Notification
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('notifications') ?>">Notification</a></li>
        <li class="active">Add Notification</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-8">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('notifications/insert') ?>" method="post">
              <div class="box-body">
                

                <div class="form-group">
                  <label for="first_name">Notification Title</label>
                  <input type="text" class="form-control" id="title" placeholder="Notification Title" name="title">
                </div>

                <div class="form-group">
                  <label for="last_name">Notification</label>
				  
                  <textarea class="form-control" rows="5"  name="content" id="content" ></textarea>
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="insert">
                <button type="submit" class="btn btn-primary btn-sm pull-right">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

   