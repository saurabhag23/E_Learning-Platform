
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="<?= admin_url('articles') ?>">Article Management</a></li>
        <li class="active">Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-lg-12 col-xs-12 col-md-12">

            <div class="box box-solid bc-transparent box-sd">
                <div class="box-header with-border">
                  <i class="fa fa-book"></i>

                  <h3 class="box-title">Article Management</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body" style="margin-top: 20px;">
  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('dailyquiz')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3><?php echo $quizcount;?></h3>

								  <p>Quiz</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('dailyquiz')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>	
			
			  <?php if(has_permission('posts', 'dashboard_view')): ?>
					 <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('posts')?>">
                          <div class="small-box bg-aqua content-posts">
                            <div class="inner">
                              <h3><?php echo $postcount;?></h3>

                              <p>Post</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-pencil"></i>
                            </div>
                            <a href=" <?=admin_url('posts')?>" class="small-box-footer">
                                More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                      </div>
		 <?php endif; ?>	
					<?php if(has_permission('studyplan', 'dashboard_view')): ?>			
					<div class="col-lg-4 col-xs-6">
                      <a href=" <?=admin_url('examdetails')?>">
                          <div class="small-box bg-green content-exam-details">
                            <div class="inner">
                              <h3><?php echo $examcount;?></h3>

								  <p>Exam Details</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-search"></i>
                            </div>
                            <a href=" <?=admin_url('examdetails')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
					<?php endif; ?>	
		  <?php if(has_permission('syllabus', 'dashboard_view')): ?>
					<div class="col-lg-4 col-xs-6">
                      <a href=" <?=admin_url('syllabus')?>">
                          <div class="small-box bg-orange content-syllabus">
                            <div class="inner">
                              <h3><!--<?php echo $syllabuscount;?>-->0</h3>

								  <p>Syllabus</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-list-alt"></i>
                            </div>
                            <a href="<?=admin_url('syllabus')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
				<?php endif; ?>	
				<?php if(has_permission('studyplan', 'dashboard_view')): ?>		
					<div class="col-lg-4 col-xs-6">
                      <a href=" <?=admin_url('notes')?>">
                          <div class="small-box bg-green content-notes">
                            <div class="inner">
                              <h3><?php echo $notescount;?></h3>

								  <p>Notes</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-sticky-note-o"></i>
                            </div>
                            <a href=" <?=admin_url('notes')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
					<?php endif; ?>	
				  <?php if(has_permission('studyplan', 'dashboard_view')): ?>
					<div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('studyplan')?>">
                          <div class="small-box bg-blue content-study-plan">
                            <div class="inner">
                              <h3><?php echo $studycount;?></h3>

								  <p>Study Plans</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-pie-chart"></i>
                            </div>
                            <a href=" <?=admin_url('studyplan')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
				<?php endif; ?>	
					<div class="col-lg-4 col-xs-6">
                      <a href=" <?=admin_url('download')?>">
                          <div class="small-box bg-blue content-download">
                            <div class="inner">
                              <h3><?php echo $downloadcount;?></h3>

								  <p>Download</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-download"></i>
                            </div>
                            <a href=" <?=admin_url('download')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
					
					
                <!-- /.box-body -->
              </div>
          </div>





        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

