
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add new Subcategory
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('subcategory') ?>">Subcategory</a></li>
        <li class="active">Add new Subcategory</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('subcategory/insert') ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
                
                <div class="col-md-6">
                    <div class="form-group">
                      <label for="role">Quiz Category</label>
                      <select class="form-control" id="category" name="category">
                        <option value="">--Category--</option>
                        <?php if(!empty($categories)): ?>
                          <?php foreach($categories as $category): ?>
                              <option value="<?= $category->id ?>"><?= $category->category_name ?></option>
                          <?php endforeach; ?>
                        <?php endif; ?>
                      </select>
                    </div>

                    <div class="form-group">
                      <label for="first_name">Quiz Sub Category Title</label>
                      <input type="text" class="form-control" id="title" placeholder=" Sub Category " name="title">
                    </div>


                </div>

                

                


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <div class="col-md-12">
                  <input type="hidden" name="action" value="insert">
                  <button type="submit" class="btn btn-primary btn-sm pull-right">Submit</button>
                </div>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
