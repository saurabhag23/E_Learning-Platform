
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->

        <!-- new dashboard -->
		

                <div class="admin-count-box">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">Feedback Created</p>
                                <p class="admin-count-small-box-count"><?=$fccnt?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">Feedback Given</p>
                                <p class="admin-count-small-box-count"><?=$fgcnt?></p>
                            </div>
                        </div>
                    </div>
                </div>
				

        <!-- new dashboard end -->
        
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

