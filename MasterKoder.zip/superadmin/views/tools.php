
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><!--<i class="fa fa-dashboard"></i>-->Home</a></li>
        <li><a href="<?= admin_url('tools') ?>">Menu Management</a></li>
        <li class="active">Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-lg-12 col-xs-12 col-md-12">

            <div class="box box-solid bc-transparent box-sd">
                <div class="box-header with-border">
                  <i class="fa fa-book"></i>

                  <h3 class="box-title">Menu Management</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body" style="margin-top: 20px;">
  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('tools/mlevels')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3><?=$menucnt?></h3>

								  <p>Menu</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('tools/mlevels')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>	
			
			
  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('upload')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3>&nbsp;</h3>

								  <p>Upload</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('upload')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>	
			
  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('feedback')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3><?=$feedcount?></h3>

								  <p>Feedback</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('feedback')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>	
			
  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('advertizement')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3><?=$advcount?></h3>

								  <p>Advertisement</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('advertizement')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>	
			
  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('quicklinks')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3><?=$quickcount?></h3>

								  <p>Quick Links</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('quicklinks')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>	
			
  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('leaderboard')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3><?=$leadcount?></h3>

								  <p>Leaderboard</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('leaderboard')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>	
			
  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('countdown')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3><?=$countcount?></h3>

								  <p>Countdown Timer</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('countdown')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>
			
  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('seo')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3><?=$countcount?></h3>

								  <p>Seo Module</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('seo')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>

  <?php if(has_permission('dailyquiz', 'dashboard_view')): ?>

                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('google')?>">
                          <div class="small-box bg-green content-daily-quiz">
                            <div class="inner">
                              <h3>1</h3>

								  <p>Google Analytics Code</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="<?= admin_url('google')?>" class="small-box-footer">
                              More info <i class="fa fa-chevron-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
			<?php endif; ?>
					
                <!-- /.box-body -->
              </div>
          </div>

        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

