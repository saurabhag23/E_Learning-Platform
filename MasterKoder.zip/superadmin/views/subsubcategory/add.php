
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add new  Sub Category
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('subsubcategory')?>">sub Category</a></li>
        <li class="active">Add new sub Category</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form-img-editor" action="<?= admin_url('subsubcategory/insert') ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
                
                <div class="col-md-12">
                    <div class="form-group">
                     <label for="first_name">Exam Super Category</label>
                        
						<select class="form-control" id="category" name="category" onChange="getexamsubcategory()">
						<option value="">Select </option>
							<?php
							foreach($categories as $categories)
							{
							?>
								<option value="<?=$categories->id?>"><?=$categories->category_name?></option>
							<?php
							}
							?>
						
						
                        </select>
                    </div>

                    <div class="form-group">
                     <label for="first_name">Exam  Category</label>
                        
						<select class="form-control" id="examsubcat" name="examsubcat">
						<option value="">Select </option>
							<?php
							foreach($subcats as $subcats)
							{
							?>
								<option value="<?=$subcats->id?>"><?=$subcats->title?></option>
							<?php
							}
							?>
						
						
                        </select>
                    </div>
              
                 <div class="form-group ">
                     <label for="first_name">Sub Category </label>
                        
						<input  type="text" class="form-control" name="subsubcategory" id="subsubcategory" >
						
                    </div>
                </div>
				<div class="form-group col-md-12">
                        <label class="control-label">Description</label>
                        <textarea id="editor" name="content" class="form-control" placeholder="Content" rows="15"></textarea>
                </div>

                <div class="form-group col-md-12">
                        <label class="control-label">Image</label>
                       	<input  type="file" class="form-control" name="image" id="image" >
                </div>

                


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <div class="col-md-12">
                  <input type="hidden" name="action" value="insert">
                  <button type="submit" class="btn btn-primary btn-sm pull-right btn-green">Submit</button>
                </div>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
