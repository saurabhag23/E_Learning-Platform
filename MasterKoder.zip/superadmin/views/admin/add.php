
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
	  <?php
	  if($this->uri->segment('4') ==2)
	  {
	  		$title = 'Mentor';
	  }
	  else
	  {
	  		$title = 'Admin';
	  }
	  ?>
        Add new <?=$title?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('users') ?>"><?=$title?></a></li>
        <li class="active">Add new <?=$title?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('admin/insert') ?>" method="post">
              <div class="box-body">
                

                <div class="form-group">
                  <label for="first_name">First Name</label>
                  <input type="text" class="form-control" id="first_name" placeholder="First Name" name="first_name">
                </div>

                <div class="form-group">
                  <label for="last_name">Last Name</label>
                  <input type="text" class="form-control" id="last_name" placeholder="Last name" name="last_name">
                </div>

                <div class="form-group">
                  <label for="email">Email address</label>
                  <input type="email" class="form-control" id="email" placeholder="Email" name="email">
                </div>

                <div class="form-group">
                  <label for="password">Password</label>
                  <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                </div>
                
                <div class="form-group">
                  <label for="password">Re-Enter Password</label>
                  <input type="password" class="form-control" id="confirm_password" placeholder="Password" name="confirm_password">
                </div>
                
				 <div class="form-group">
                  <label for="password">Contact Number</label>
                  <input type="number" class="form-control" id="contactnum" placeholder="Contact Number" name="contactnum">
                </div>
                
                <div class="form-group">
                  <label for="exam_category">Assigned Subject</label>
                  
                  
                        <select class="form-control examcat" multiple="multiple" id="subjects" name="subjects[]" >
						
						<option value="">Select Super Category</option>
						<?php
						foreach($subsubcats as $subsubcat)
						{
						?>
						  <option value="<?=$subsubcat->id?>"><?=$subsubcat->title?></option>
						<?php
						}
						?>
						
                        </select>
                  
                </div>
                
				 <div class="form-group">
                  <label for="birthdate">Birth Date</label>
                  <input type="date" class="form-control" id="birthdate" placeholder="Contact Number" name="birthdate">
                </div>
                
				 <div class="form-group">
                  <label for="address">Address</label>
                  <textarea class="form-control" id="address" name="address"></textarea>
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="insert">
				<input type="hidden" name="role" value="1">
                <button type="submit" class="btn btn-primary btn-sm pull-right btn-green">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
