
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-lg-12 col-xs-12 col-md-12">

            <div class="box box-solid">
                <div class="box-header with-border">
                  <i class="fa fa-book"></i>

                  <h3 class="box-title">Users Management</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">


                    <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('users/allusers/1')?>">
                          <div class="small-box bg-green">
                            <div class="inner">
                              <h3><?=$userscount?></h3>

								  <p>Users</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-pencil"></i>
                            </div>
                            <a href="<?=admin_url('users/allusers/1')?>" class="small-box-footer">
                              More info <i class="fa fa-arrow-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
					 <div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('users/mentors/2')?>">
                          <div class="small-box bg-aqua">
                            <div class="inner">
                              <h3><?=$mentorcount?></h3>

                              <p>Mentors</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-book"></i>
                            </div>
                            <a href="<?=admin_url('mentors')?>" class="small-box-footer">
                                More info <i class="fa fa-arrow-circle-right"></i>
                            </a>
                          </div>
                      </a>
                  </div>
				 
					<div class="col-lg-4 col-xs-6">
                      <a href="<?=admin_url('users/admins/3')?>">
                          <div class="small-box bg-orange">
                            <div class="inner">
                              <h3><?=$admincount?></h3>

								  <p>Admins</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-list-alt"></i>
                            </div>
                            <a href="<?=admin_url('users/admins/3')?>" class="small-box-footer">
                              More info <i class="fa fa-arrow-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
					
					
                <!-- /.box-body -->
              </div>
          </div>





        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

