<!DOCTYPE html>
<html lang="en">

<head>
	<title>Educational Portal</title>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/select2/dist/css/select2.min.css">
	<link href="<?=base_url()?>lib/css/emoji.css" rel="stylesheet">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/fullpage.js"></script>
	<script src="<?=base_url()?>assets/js/system.js"></script>
	<script src="<?=base_url()?>assets/js/bootstrap3-typeahead.js"></script>
	<script src="<?=base_url()?>assets/js/jquery.emojiarea.js"></script>

	<script src="//twemoji.maxcdn.com/twemoji.min.js"></script>
	<script type="text/javascript">
		<?php
			
if($this->session->userdata('logged_user'))
{
?>



		$(document).ready(function() {
			$('.shownotif').click(function() {
				load_allnotifications();
			});

			setInterval(function() {
				load_unseen_notification();

			}, 500);
		});

		function load_unseen_notification() {
			$.ajax({
				url: '<?=base_url()?>account/newnotifications',
				method: "POST",
				success: function(data) {
					$('.notifmsg').html(data);
				}
			});
		}



		function load_allnotifications() {
			$.ajax({
				url: '<?=base_url()?>account/allnotifications',
				method: "POST",
				success: function(data) {
					$('.allnotifmsg').html(data);
				}
			});
		}

		<?php
}
?>

		function readCookie(name) {
			return (document.cookie.match('(^|; )' + name + '=([^;]*)') || 0)[2]
		}
	</script>

	<script>
		$(window).scroll(function() {
			var scroll = $(window).scrollTop();

			if (scroll >= 400) {
				$(".navbar-wrapper").addClass("fixed");
			} else {
				$(".navbar-wrapper").removeClass("fixed");
			}
		});
	</script>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/fullpage.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/style.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/style1.css">

	<style type="text/css">
		.box-new-comment img,
		.box-comments .comment img.emoji {

			width: 20px!important;
			height: 20px!important;
		}

		.hdrbtn {
			margin-left: 126px;
			margin-top: -15px;
		}

		.sticks {
			color: white!important;
			position: fixed!important;
			top: 56px;
			width: 100%;
			z-index: 9999999;
			margin-top: 20px!important;
		}

		.fa-bell-o {
			position: relative;
		}

		.notification_number {
			position: absolute;
			color: #fff;
			display: inline-block;
			background-color: #DC0000;
			font-size: 13px;
			font-weight: bold;
			top: -5px;
			height: 20px;
			width: 20px;
			border-radius: 50%;
			left: 50%;
			display: table;
		}

		.emoji {
			color: transparent;
			display: inline-block;
			font-size: 18px;
			font-style: normal;
			height: 25px;
			width: 25px;
		}

		.emoji::selection {
			background-color: highlight;
			color: transparent;
		}

		.emoji-image {
			font-size: 14px;
			line-height: 28px;
		}

		.emoji-button {
			cursor: pointer;
			margin: 5px;
		}

		.emoji-editor {
			-moz-appearance: textfield-multiline;
			-webkit-appearance: textarea;
			border: 1px solid #ccc;
			border-radius: 3px;
			box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
			box-sizing: border-box;
			cursor: text;
			font: medium -moz-fixed;
			font: -webkit-small-control;
			-webkit-font-smoothing: antialiased;
			height: 51px!important;
			overflow: auto;
			padding: 5px;
			resize: both;
			width: 100%;
		}

		.emoji-picker {
			background-color: #fff;
			border: 1px solid #ccc;
			position: absolute;
			width: 410px;
			margin-top: 0px!important;
		}

		}

		.emoji-picker a {
			cursor: pointer;
			display: inline-block;
			font-size: 20px;
			padding: 3px;
		}

		.emoji-selector {
			border-bottom: 1px solid #ccc;
			display: flex;
		}

		.emoji-selector li {
			margin: 5px;
		}

		.emoji-group {
			display: <a href="https://www.jqueryscript.net/tags.php?/grid/">grid</a>;
			grid-template-columns: repeat(6, 16.66667%);
			height: 200px;
			overflow-y: scroll;
			padding: 3px;
		}

		.rejo {
			padding: 0;
		}

		.lej.mo {
			margin-top: 4px;
		}

		.lej {
			margin-top: 5px;
			font-size: 12px !important;
		}

		.rej {
			padding: 7px 21px;
			margin: 5px 10px;
		}

		.rejor {
			margin: 25px -8px;
		}

		.navbar-wrapper.fixed {
			width: 100%;
			position: fixed;
			z-index: 99;
		}
	</style>
</head>


<body onScroll=\ "document.cookie='ypos=' + window.pageYOffset\" onLoad=\ "window.scrollTo(0,readCookie('ypos'))\">


	<div class="navbar-wrapper">
		<div class="top-bar">
			<div class="container">
				<div class="row">

					<div class="col-md-1 col-sm-2 col-xs-2">
						<div class="logo" style="margin: 2px 0px 0px;
    height: 30px;">
							<a href="<?=base_url()?>">
								<!--<i class="fa fa-graduation-cap" style="font-size: 45px;"></i> --><img src="<?=base_url()?>assets/images/white-logo.png" width="80px" /></a>
						</div>
					</div>


					<div class="col-md-7 col-sm-10 col-xs-10" style="margin-bottom: 0;">
						<form action="#" method="#" role="search" style="margin-top: -5px;">
							<div class="input-group">
								<input class="form-control" placeholder="Search for Exams, Quizzes, Notes & Mentors ...." name="srch-term" id="ed-srch-term" type="text" style="font-size: 14px;
    min-height: 30px;
    margin-top: 10px;">
								<div class="input-group-btn">
									<button type="submit" id="searchbtn" style="min-height: 34px;
    margin-top: 10px;">
    <i class="fa fa-search"></i></button>
								</div>
							</div>
						</form>

					</div>


					<div class="col-md-4" style="    height: 45px;">
						<?php
			
	 
					 
	 
	  
				if($this->session->userdata('logged_user'))
				{
					 if($this->session->userdata('logged_user')->logintype == 2)
					  {
							$image = $this->session->userdata('logged_user')->user_img;
					  }
					  else if($this->session->userdata('logged_user')->logintype == 3)
					  {
							$image = $this->session->userdata('logged_user')->user_img;
					  }
					  else
					  {
							$image = base_url().$this->session->userdata('logged_user')->user_img;
					  }
			?>
							<div class="logs">
								<span class="lej"> <a href="<?=base_url()?>account"> <img src="<?=base_url()?>assets/images/edit.png" width="18px" height="18px"/><P> Post </P></a></span>
								<span class="lej shownotif"> <a href="#"  class="dropdown-toggle "  data-toggle="dropdown"> <img src="http://www.sibinfotech.in/projects/eduportal/assets/images/notifications-bell-button.png" width="18px" height="18px" class="fa-bell-o"><P> Notification</P>
				<span class="notifmsg">
				
				</span>
								</a>

								<ul class="dropdown-menu notf">
									<span class="allnotifmsg">
                             <i class="fa fa-spinner" style="font-size:24px; margin-left:54px;"></i>
					   </span>

								</ul>
								</span>







								</span>
								<span class="lej mo"> <a  href="#" class="dropdown-toggle"  data-toggle="dropdown">
				<img class="socp" src="<?=$image?>"><P> Profile </P></a>
				 <ul class="dropdown-menu">
                            <li><a  href="<?=base_url()?>account/myprofile">My Profile</a></li>
							<li><a  href="<?=base_url()?>account/mypackage">My Packages</a></li>
							<li><a  href="<?=base_url()?>account/logout">Logout</a></li>
                     </ul></span>


							</div>
							<?php
			}
			?>
							<div class="log">
								<?php
					if(!$this->session->userdata('logged_user'))
					{
					?>
								<span class="rej cor2"><a  href="<?=base_url()?>login">Login </a></span>
								<span class="rejo">O</span><span class="rejor">R</span>

								<?php
					 }
					 ?>
							</div>

							<div class="log">
								<?php
					if(!$this->session->userdata('logged_user'))
					{
					?>
								<span class="rej cor1"><a  href="<?=base_url()?>signup">Register </a></span>

								<?php
					 }
					 ?>
							</div>

					</div>

				</div>
			</div>
		</div>


		<div class="sec-bar" >
			<div class="container">
				<div class="row">
					<div class="col-md-12" style="margin-bottom: 0;">

						<nav class="navbar navbar-main navbar-default" role="navigation" style="opacity: 1;" >
							<div class="container">

								<div class="navbar-header">
									<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
								</div>


								<div class="collapse navbar-collapse navbar-1" style="margin-top: 0px;">
									<ul class="nav navbar-nav">

										<li class="dropdown megaDropMenu">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="false">Study <i class="fa fa-angle-down ml-5"></i></a>
											<ul class="dropdown-menu row" style="width: 15vw; min-height: 314px;">
												<li class="col-sm-12 col-xs-12">
													<ul class="list-unstyled my-li-1 someli">
														<li class="styleft">Study For</li>


														<?php
					$CI =& get_instance();
					$obj = $CI->load->model('accountmodel');
					$obj->load->helper('text');
					
					
					if($this->session->userdata('logged_user'))
					{
						$menu = $obj->accountmodel->getmainmenubysubscribtion();				  
					
					}
					else
					{
						$menu = $obj->accountmodel->getmainmenu();	
					}
					
				    
				
					foreach($menu as  $menus)
					{
					?>
															<li class="dropdown-submenu my-li">
																<a href="<?=base_url()?>exam/details/<?=$menus->id?>" style="color:#333333"><?=$menus->category_name?> &nbsp;<i class="fa fa-angle-right somi"></i></a>

																<div class="my-ul-1">
																	<div class="row">
																		<div class="col-md-7">
																			<?php
									    $submenu = $obj->accountmodel->getallsubcategories($menus->id);
										$i = 1;
										if(!empty($submenu))
										{
										foreach($submenu  as $submenu)
										{
										    $submenuarray[] = $submenu->id;
									 ?>

																				<div class="col-md-3 bor4">
																					<ul>
																						<li><a href="<?=base_url()?>exam/subjects/<?=$menus->id?>/<?=$submenu->id?>" style="font-weight: 600;font-size: 16px;"><?=$submenu->title?></a></li>

																						<?php
												  
													$subsubmenu = $obj->accountmodel->getallsubsubcategories($submenu->id,$menus->id);
													if(!empty($subsubmenu))
													{
														foreach($subsubmenu as $subsubmenu)
														{
														
													?>
																							<li><a href="<?=base_url()?>exam/topic/<?=$subsubmenu->id?>/<?=$menus->id?>"><?=$subsubmenu->title?></a></li>
																							<?php
													    }
													}
													?>

																					</ul>
																				</div>


																	<?php
											/* if($i%3 ==0)
											{
												echo '<div class ="clearfix"></div>';
											} */
											
											$i++;
										}
										}
										?> 


																		</div>
																		<div class="col-md-5" style="background-color: #b5abab61;">





																			<div class="col-md-4 bor4">
																				<ul>
																					<li>Featured Post </li>




																					<?php
								if(!empty($submenuarray[0]))	
								{			
							      $featuredarticle = $obj->accountmodel->getsinglefeaturedarticle($submenuarray[0]);
								
								if(!empty($featuredarticle))
								{
								foreach($featuredarticle as $featuredarticle)
								{
								?>



																						<?php
								
								  $articlelength = strlen($featuredarticle->topic_title);
								  if($articlelength<20)
								  {
								  		$article = $featuredarticle->topic_title;
								  }
								  else
								  {
								  		
										$article = substr($featuredarticle->topic_title, 0, 20).'...'; 
								  }
								   
								?>
																							<div class="fac">
																							
																							
									<?php
							if(!empty($featuredarticle->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredarticle->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredarticle->image_url))
							{
									echo'<img src="'.$featuredarticle->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>													
													
																	<a href="<?=base_url()?>articles/details/<?=$featuredarticle->id?>">
																									<?=$article?>
																								</a> <br>
																							</div>

																							<?php
							    }
								
								}
								}	
								
								?>

																				</ul>
																			</div>
																			<div class="col-md-4 bor4">
																				<ul>
																					<li>Featured Quiz</li>


																					<li>
																						<?php
													$featuredquiz =  $obj->accountmodel->getfeaturedquiz($menus->id);
														if(!empty($featuredquiz))
														{
															foreach($featuredquiz as $featuredquiz)
															{
																	  $featuredqzlength = strlen($featuredquiz->exam_name);
																	  if($featuredqzlength<20)
																	  {
																			$qzname = $featuredquiz->exam_name;
																	  }
																	  else
																	  {
																			
																			$qzname = substr($featuredquiz->exam_name, 0, 20).'...'; 
																	  }
														?>
																							<div class="fac">
						                         <?php
												if(!empty($featuredquiz->exam_featured_image))
												{
													echo'<img src="'.base_url().$featuredquiz->exam_upload_path.$featuredquiz->exam_featured_image.'" style="height:95px;">';
												}
												elseif(!empty($featuredquiz->image_url))
												{
													echo'<img src="'.$featuredquiz->image_url.'" style="height:95px;">';
												}
												else
												{
										            echo'<img src="'.base_url().'assets/images/default_quiz.png" alt="" style="height:95px;">';
												}
												?>													
																						
							
																								<a href="<?=base_url()?>quiz/attend/<?=$featuredquiz->exam_slug?>">
																									<?=$qzname ?>
																								</a><br>
																							</div>
																							<?php
											 		}
											  }
											 ?>
																					</li>

																				</ul>

																			</div>

																			<div class="col-md-4 bor4">
																				<ul>
																					<li>Featured SSB </li>




																					<?php
								if(!empty($submenuarray[2]))
								{				
							    $featuredssb = $obj->accountmodel->getfeaturedssb($submenuarray[2]);	
								if(!empty($featuredssb))
								{
								foreach($featuredssb as $featuredssb)
								{
								?>



																						<?php
								
								  $ssblength = strlen($featuredssb->topic_title);
								  if($ssblength<20)
								  {
								  		$ssb = $featuredssb->topic_title;
								  }
								  else
								  {
								  		
										$ssb = substr($featuredssb->topic_title, 0, 20).'...'; 
								  }
								   
								?>
								<div class="fac">
							<?php
							if(!empty($featuredssb->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredssb->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredssb->image_url))
							{
									echo'<img src="'.$featuredssb->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>													
									
						          
								         <a href="<?=base_url()?>articles/details/<?=$featuredssb->id?>"><?=$ssb?></a> <br>
																
								</div>
																							<?php
							    }
								}
								
								unset($submenuarray);
								}
								?>

																				</ul>
																			</div>




																		</div>

																	</div>
																</div>

															</li>

															<?php
					}
					 ?>
													</ul>

												</li>

											</ul>
										</li>




										<li class="dropdown megaDropMenu open">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="false" aria-expanded="true">Exam Details <i class="fa fa-angle-down ml-5"></i></a>

											<ul class="dropdown-menu row" style="display: none;">
												<div class="col-lg-6">



													<?php
				   $menubylimt = $obj->accountmodel->getmainmenubylimit();
				   $i=1;
				   foreach($menubylimt as $menubylimt)
				   {
				  ?>


														<li class="col-lg-4 bor4">
															<ul class="list-unstyled">
																<li>
																	<?=$menubylimt->category_name?>
																</li>
																<?php
						 $examdeatils =  $obj->accountmodel->getallexamdetailsbylimit($menubylimt->id);
						if(!empty($examdeatils))
						{
							foreach($examdeatils as  $examdeatils)
							{
								 $exlength = strlen($examdeatils->title);
								  if($exlength<30)
								  {
								  		$exdetail = $examdeatils->title;
								  }
								  else
								  {
								  		
										$exdetail = substr($examdeatils->title, 0, 30).'...'; 
								  }
							 ?>
																	<li>
																		<a href="<?=base_url()?>exam-details/<?=$examdeatils->id?>">
																			<?=$exdetail?>
																		</a>
																	</li>

																	<?php
							}
							}
						  ?>



															</ul>
														</li>

														<?php
						}
						?>

												</div>
												<div class="col-lg-6 bg5 mgpad">


													<?php
				   $menubylimtfeatured = $obj->accountmodel->getmainmenubylimit();
				   $i = 1;
				   foreach($menubylimtfeatured as $menubylimtfeatured)
				   {
				   	if($i>3)
					{
						break;
					}
				         $featuredexamdetails = $obj->accountmodel->getfeaturedexamdetails($menubylimtfeatured->id);
				  ?>
														<?php
						  if(!empty($featuredexamdetails))
						  {
						 
						  foreach($featuredexamdetails as $index=> $featuredexamdetails)
						  {
						    
						      $articlelength = strlen($featuredexamdetails->title);
								  if($articlelength<15)
								  {
								  		$article = $featuredexamdetails->title;
								  }
								  else
								  {
								  		
										$article = substr($featuredexamdetails->title, 0, 15).'...'; 
								  }
								   
							?>



															<div class="hall linehall">
																<li class="textlevel">Featured
																	<?=$featuredexamdetails->category_name?> Post</li>
		  <?php
	  if(!empty($featuredexamdetails->featured_image))
	  {
	  		echo'<img src="'.base_url().'uploads/Exam-details/'.$featuredexamdetails->featured_image.'" style="height:95px;">';
	  }
	  elseif(!empty($featuredexamdetails->image_url))
	  {
	  		echo'<img src="'.$featuredexamdetails->image_url.'" style="height:95px;">';
	  }
	  else
	  {
	  		echo'<img src="'.base_url().'assets/images/default_examdetails.png"  style="height:95px;">';
	  }
	  ?>								
							
																<a href="<?=base_url()?>exam-details/<?=$featuredexamdetails->id?>">
																	<?=$article?>
																</a>
																<br><br>
															</div>


															<?php
							
						
							}
							}
							
					       ?>
																<?php
					$i++;
							
					}
					?>


																<?php
				   $menubylimtfeatured = $obj->accountmodel->getmainmenubylimit();
				   $i =1;
				   foreach($menubylimtfeatured as $menubylimtfeatured)
				   {
				   	if($i>3)
					{
						break;
					}
				         $featuredexamdetails = $obj->accountmodel->getfeaturedexamdetailsbysecondlimit($menubylimtfeatured->id);
				  ?>
																	<?php
						  if(!empty($featuredexamdetails))
						  {
						 
						  foreach($featuredexamdetails as  $featuredexamdetails)
						  {
						    
						      $articlelength = strlen($featuredexamdetails->title);
								  if($articlelength<15)
								  {
								  		$article = $featuredexamdetails->title;
								  }
								  else
								  {
								  		
										$article = substr($featuredexamdetails->title, 0, 15).'...'; 
								  }
								   
							?>



																		<div class="hall linehall">
																			<img src="<?=base_url()?>uploads/Exam-details/<?=$featuredexamdetails->featured_image?>" style="height:95px;">
																			<a href="<?=base_url()?>exam-details/<?=$featuredexamdetails->id?>">
																				<?=$article?>
																			</a> <br><br>
																		</div>


																		<?php
							
						
							}
							}
							
					       ?>
																			<?php
					 $i++;		
					}
					?>
												</div>
											</ul>
										</li>

										<li class="dropdown megaDropMenu">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="false">Syllabus <i class="fa fa-angle-down ml-5"></i></a>
											<ul class="dropdown-menu row">

												<div class="col-lg-6">

													<?php
				   $menubysyllabus = $obj->accountmodel->getmainmenubylimit();
				   $i = 1;
				   foreach($menubysyllabus as $menubysyllabus)
				   {
				         $syllabus = $obj->accountmodel->getallsyllabusbylimit($menubysyllabus->id);
				    ?>
														<li class="col-lg-4 bor4">
															<ul class="list-unstyled">
																<li>
																	<?=$menubysyllabus->category_name?> Syllabus</li>
																<?php
							if(!empty($syllabus))
							{
								foreach($syllabus as  $syllabus)
								{
									  $syllabuslength = strlen($syllabus->syllabus_title);
									  if($syllabuslength<30)
									  {
											$sylbs = $syllabus->syllabus_title;
									  }
									  else
									  {
											
											$sylbs = substr($syllabus->syllabus_title, 0, 30).'...'; 
									  }
								?>
																	<li>
																		<a href="<?=base_url()?>exam/syllabus/<?=$syllabus->id?>">
																			<?=$sylbs?>
																		</a>
																	</li>
																	<?php
								}
							}
								?>

															</ul>
														</li>
														<?php
					 
					}
					?>
												</div>

												<div class="col-lg-6 bg5 mgpad">



													<?php
				   $menubysyllabus = $obj->accountmodel->getmainmenubylimit();
				    $i = 1;
				   foreach($menubysyllabus as $menubyfeaturedsyllabus)
				   {
				      if($i>3)
					  {
					  	break;
					  }
				         $featuredsyllabus = $obj->accountmodel->getfeaturedsyllabus($menubyfeaturedsyllabus->id);
						 if(!empty( $featuredsyllabus))
						 {
						 foreach($featuredsyllabus as $featuredsyllabus)
						 {
						 		 $slength = strlen($featuredsyllabus->syllabus_title);
								  if($slength<15)
								  {
								  		$fsylbs = $featuredsyllabus->syllabus_title;
								  }
								  else
								  {
								  		
										$fsylbs = substr($featuredsyllabus->syllabus_title, 0, 15).'...'; 
								  }
				    ?>
														<div class="hall linehall">
															<li class="textlevel">Featured
																<?=$featuredsyllabus->category_name?> Post</li>
	  <?php
	  if(!empty($featuredsyllabus->featured_image))
	  {
	  		echo'<img src="'.base_url().'uploads/Syllabus/'.$featuredsyllabus->featured_image.'" style="height:95px;">';
	  }
	  elseif(!empty($featuredsyllabus->image_url))
	  {
	  		echo'<img src="'.$featuredsyllabus->image_url.'" style="height:95px;">';
	  }
	  else
	  {
	  		echo'<img src="'.base_url().'assets/images/"  style="height:95px;">';
	  }
	  ?>
															
															<a href="<?=base_url()?>exam/syllabus/<?=$featuredsyllabus->id?>">
																<?=$fsylbs?>
															</a><br><br>
														</div>

														<?php
						}
						}
					 $i++;
					}
					?>


															<?php
				   $menubysyllabus = $obj->accountmodel->getmainmenubylimit();
				    $i = 1;
				   foreach($menubysyllabus as $menubyfeaturedsyllabus)
				   {
				   		if($i>3)
						{
							break;
						}
						
				         $featuredsyllabus = $obj->accountmodel->getfeaturedsyllabussecondlast($menubyfeaturedsyllabus->id);
						 if(!empty( $featuredsyllabus))
						 {
						 foreach($featuredsyllabus as $featuredsyllabus)
						 {
						 		 $slength = strlen($featuredsyllabus->syllabus_title);
								  if($slength<15)
								  {
								  		$fsylbs = $featuredsyllabus->syllabus_title;
								  }
								  else
								  {
								  		
										$fsylbs = substr($featuredsyllabus->syllabus_title, 0, 15).'...'; 
								  }
				    ?>
																<div class="hall linehall">

			 <?php
	  if(!empty($featuredsyllabus->featured_image))
	  {
	  		echo'<img src="'.base_url().'uploads/Syllabus/'.$featuredsyllabus->featured_image.'" style="height:95px;">';
	  }
	  elseif(!empty($featuredsyllabus->image_url))
	  {
	  		echo'<img src="'.$featuredsyllabus->image_url.'" style="height:95px;">';
	  }
	  else
	  {
	  		echo'<img src="'.base_url().'assets/images/default_syllabus.png"  style="height:95px;">';
	  }
	  ?>														
																	<a href="<?=base_url()?>exam/syllabus/<?=$featuredsyllabus->id?>">
																		<?=$fsylbs?>
																	</a>
																	<br><br>
																</div>

																<?php
						}
						}
					$i++;
					}
					?>




												</div>
										</li>
										</ul>





										<li class="dropdown megaDropMenu">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="false">Notes<i class="fa fa-angle-down ml-5"></i></a>



											<ul class="dropdown-menu row" style="display: none;">
												<div class="col-lg-6">

													<?php
				   $menubynotes = $obj->accountmodel->getmainmenubylimit();
				   $i=1;
				   foreach($menubynotes as $menubynotes)
				   {
				       $notemenuarray[]= $menubynotes->id;
				   		 
						  
							
							    
							    $notes = $obj->accountmodel->getnotesbylimit($menubynotes->id);
				     
				    ?>
														<li class="col-lg-4 bor4">
															<ul class="list-unstyled">




																<li class="subcls">
																	<?=$menubynotes->category_name?>
																</li>


																<?php
									  if(!empty($notes))
									  {
										
											 
										  foreach($notes as  $notes)
										  {
											 $noteslength = strlen($notes->title);
											  if($noteslength<40)
											  {
													$nts = $notes->title;
											  }
											  else
											  {
													
													$nts = substr($notes->title, 0, 40).'...'; 
											  }
											 echo'<li><a href="'.base_url().'exam/notes/'.$notes->id.'">'.$nts.'</a></li>';
										   
										   }
									   }
								
							  ?>
															</ul>
														</li>

														<?php
					 
								
					 }
					
				   ?>
												</div>

												<div class="col-lg-6 bg5 mgpad">
													<ul class="list-unstyled">



														<?php
				  
				         $featurednotes = $obj->accountmodel->getfeaturednotes($notemenuarray[0]);
						 if(!empty($featurednotes))
						 {
						 foreach($featurednotes as $featurednotes)
						 {
						 		 $nlength = strlen($featurednotes->title);
								  if($nlength<50)
								  {
								  		$fnotes = $featurednotes->title;
								  }
								  else
								  {
								  		
										$fnotes = substr($featurednotes->title, 0, 50).'...'; 
								  }
				    ?>
															<div class="hall linehall">
																<li class="textlevel">Featured
																	<?=$featurednotes->category_name?> Post</li>
		<?php
	  if(!empty($featurednotes->featured_image))
	  {
	  	 echo'<img src="'.base_url().'uploads/Notes/'.$featurednotes->featured_image.'" style="height:95px;">';
	  }
	  elseif(!empty($featurednotes->image_url))
	  {
	  		 echo'<img src="'.$featurednotes->image_url.'" style="height:95px;">';
	  }
	  else
	  {
	  		echo'<img src="'.base_url().'assets/images/default_notes.png" style="height:95px;">';
	  }
	  ?>
																<a href="<?=base_url()?>exam/notes/<?=$featurednotes->id?>">
																	<?=$fnotes?>
																</a>
																<br><br>
															</div>


															<?php
						
						}
					}
					?>

															<?php
								    $featuredquiz =  $obj->accountmodel->getanyfeaturedquiz();
										if(!empty($featuredquiz))
										{
										  foreach($featuredquiz as $featuredquiz)
										  {
													  $featuredqzlength = strlen($featuredquiz->exam_name);
													  if($featuredqzlength<15)
													  {
															$qzname = $featuredquiz->exam_name;
													  }
													  else
													  {
															
															$qzname = substr($featuredquiz->exam_name, 0, 15).'...'; 
													  }
								?>
																<div class="hall linehall">
																	<li class="textlevel">Featured Quiz &nbsp; &nbsp;&nbsp</li>
				                            <?php
												if(!empty($featuredquiz->exam_featured_image))
												{
													echo'<img src="'.base_url().$featuredquiz->exam_upload_path.$featuredquiz->exam_featured_image.'" style="height:95px;">';
												}
												elseif(!empty($featuredquiz->image_url))
												{
													echo'<img src="'.$featuredquiz->image_url.'" style="height:95px;">';
												}
												else
												{
										            echo'<img src="'.base_url().'assets/images/default_quiz.png" alt="" style="height:95px;">';
												}
												?>		
																	
																	<a href="<?=base_url()?>quiz/attend/<?=$featuredquiz->exam_slug?>">
																		<?=$qzname ?>
																	</a>
																	<br><br>
																</div>

																<?php
							           }
					          }
					         ?>

																	<?php
												 
								if(!empty($notemenuarray[2]))
								{				
							    $featuredssb = $obj->accountmodel->getfeaturedssbbyfirstcat($notemenuarray[2]);	
							
								if(!empty($featuredssb))
								{
								foreach($featuredssb as $featuredssb)
								{

								?>



																		<?php
								
								  $ssblength = strlen($featuredssb->topic_title);
								  if($ssblength<20)
								  {
								  		$ssb = $featuredssb->topic_title;
								  }
								  else
								  {
								  		
										$ssb = substr($featuredssb->topic_title, 0, 20).'...'; 
								  }
								   
								?>
																			<div class="hall linehall">
																				<li class="textlevel">Featured
																					<?=$featuredssb->category_name?> Post</li>
					          <?php
							if(!empty($featuredssb->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredssb->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredssb->image_url))
							{
									echo'<img src="'.$featuredssb->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>			
																				
																				<a href="<?=base_url()?>articles/details/<?=$featuredssb->id?>">
																					<?=$ssb?>
																				</a>
																				<br><br>
																			</div>

																			<?php
							    }
								}
								
								
								}
								?>



																				<!--second row-->
																				<?php
				  
				         $featurednotes = $obj->accountmodel->getfeaturednotesbylimitone($notemenuarray[0]);
						 if(!empty($featurednotes))
						 {
						 foreach($featurednotes as $featurednotes)
						 {
						 		 $nlength = strlen($featurednotes->title);
								  if($nlength<15)
								  {
								  		$fnotes = $featurednotes->title;
								  }
								  else
								  {
								  		
										$fnotes = substr($featurednotes->title, 0, 15).'...'; 
								  }
				    ?>
																					<div class="hall linehall">
					<?php
	  if(!empty($featurednotes->featured_image))
	  {
	  	 echo'<img src="'.base_url().'uploads/Notes/'.$featurednotes->featured_image.'" style="height:95px;">';
	  }
	  elseif(!empty($featurednotes->image_url))
	  {
	  		 echo'<img src="'.$featurednotes->image_url.'" style="height:95px;">';
	  }
	  else
	  {
	  		echo'<img src="'.base_url().'assets/images/default_notes.png" style="height:95px;">';
	  }
	  ?>
																						
																						<a href="<?=base_url()?>exam/notes/<?=$featurednotes->id?>">
																							<?=$fnotes?>
																						</a>
																						<br><br>
																					</div>

																					<?php
						
						}
					}
					?>

																					<?php
								    $featuredquiz =  $obj->accountmodel->getanyfeaturedquizlimitone($notemenuarray[0]);
										if(!empty($featuredquiz))
										{
										  foreach($featuredquiz as $featuredquiz)
										  {
													  $featuredqzlength = strlen($featuredquiz->exam_name);
													  if($featuredqzlength<15)
													  {
															$qzname = $featuredquiz->exam_name;
													  }
													  else
													  {
															
															$qzname = substr($featuredquiz->exam_name, 0, 15).'...'; 
													  }
								?>
																						<div class="hall linehall">
					                            <?php
												if(!empty($featuredquiz->exam_featured_image))
												{
													echo'<img src="'.base_url().$featuredquiz->exam_upload_path.$featuredquiz->exam_featured_image.'" style="height:95px;">';
												}
												elseif(!empty($featuredquiz->image_url))
												{
													echo'<img src="'.$featuredquiz->image_url.'" style="height:95px;">';
												}
												else
												{
										            echo'<img src="'.base_url().'assets/images/default_quiz.png" alt="" style="height:95px;">';
												}
												?>	
																						
																							<a href="<?=base_url()?>quiz/attend/<?=$featuredquiz->exam_slug?>">
																								<?=$qzname ?>
																							</a>
																							<br><br>
																						</div>
																						<?php
							           }
					          }
					         ?>


																							<?php
												 
								if(!empty($notemenuarray[2]))
								{				
							    $featuredssb = $obj->accountmodel->getfeaturedssbfoenotesbylimitone($notemenuarray[2]);	
								if(!empty($featuredssb))
								{
								foreach($featuredssb as $featuredssb)
								{
								?>



																								<?php
								
								  $ssblength = strlen($featuredssb->topic_title);
								  if($ssblength<20)
								  {
								  		$ssb = $featuredssb->topic_title;
								  }
								  else
								  {
								  		
										$ssb = substr($featuredssb->topic_title, 0, 20).'...'; 
								  }
								   
								?>
																									<div class="hall linehall">
																			
					          <?php
							if(!empty($featuredssb->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredssb->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredssb->image_url))
							{
									echo'<img src="'.$featuredssb->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>		
																										
																										<a href="<?=base_url()?>articles/details/<?=$featuredssb->id?>">
																											<?=$ssb?>
																										</a>
																										<br><br>
																									</div>
																									<?php
							    }
								}
								
								
								}
								?>



												</div>
												</ul>
										</li>

										<li class="dropdown megaDropMenu">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="false">Study plan <i class="fa fa-angle-down ml-5"></i></a>
											<ul class="dropdown-menu row">
												<div class="col-lg-6">
													<?php
				   $menubystudyplan = $obj->accountmodel->getmainmenubylimit();
				 
				   foreach($menubystudyplan as $menubystudyplan)
				   {
				          $studyplan = $obj->accountmodel->getstudyplanbylimit($menubystudyplan->id);
						
				    ?>


														<li class="col-lg-4 bor4">
															<ul class="list-unstyled">
																<li>
																	<?=$menubystudyplan->category_name?>
																</li>
																<?php
					   if(!empty($studyplan))
					   {
					   foreach($studyplan as $studyplan)
					   {
					   		    $stdyplanlgnth = strlen($studyplan->title);
								  if($stdyplanlgnth<40)
								  {
								  		$stdplan = $studyplan->title;
								  }
								  else
								  {
								  		
										$stdplan = substr($studyplan->title, 0, 40).'...'; 
								  }
								  
					   ?>
																	<li>
																		<a href="<?=base_url()?>exam/studyplan/<?=$studyplan->id?>">
																			<?=$stdplan?>
																		</a>
																	</li>
																	<?php
					   }
						}
					  ?>

															</ul>



														</li>
														<?php
					
					}
					?>
												</div>
												<div class="col-lg-6 bg5 mgpad">

													<ul class="list-unstyled">

														<?php
					  
					   $menubystudyplan = $obj->accountmodel->getmainmenubylimit();
				       $i = 1;
				       foreach($menubystudyplan as $menubystudyplan)
				       {
					      if($i>3)
						  {
						  	break;
						  }
				             $studyplan = $obj->accountmodel->getstudyplanbylimitone($menubystudyplan->id);
						  if(!empty($studyplan))
						  {
                                $stdyplanlgnth = strlen($studyplan->title);
								  if($stdyplanlgnth<15)
								  {
								  		$stdplan = $studyplan->title;
								  }
								  else
								  {
								  		
										$stdplan = substr($studyplan->title, 0, 15).'...'; 
								  }
							?>


															<div class="hall linehall">
																<li class="textlevel">Featured
																	<?=$studyplan->category_name?> Post</li>
		 <?php
	  if(!empty($studyplan->featured_image))
	  {
	  	   echo'<img src="'.base_url().'uploads/Studyplan/'.$studyplan->featured_image.'" class="imgcls">';
	  }
	  elseif(!empty($studyplan->image_url))
	  {
	  		 echo'<img src="'.$studyplan->image_url.'" class="imgcls">';
	  }
	  else
	  {
	  		 echo'<img src="'.base_url().'assets/images/default_studyplan.png" class="imgcls">';
	  }
	  ?> 
																
																<a href="<?=base_url()?>exam/studyplan/<?=$studyplan->id?>">
																	<?=$stdplan?>
																</a>
																<br><br>
															</div>

															<?php     
							    }
								
							
							$i++;
								}
								
								
								?>

															<?php
					  
					   $menubystudyplan = $obj->accountmodel->getmainmenubylimit();
				       $i = 1;
				       foreach($menubystudyplan as $menubystudyplan)
				       {
					      if($i>3)
						  {
						  	break;
						  }
				             $studyplan = $obj->accountmodel->getstudyplanbylimittwo($menubystudyplan->id);
						  if(!empty($studyplan))
						  {
                                $stdyplanlgnth = strlen($studyplan->title);
								  if($stdyplanlgnth<15)
								  {
								  		$stdplan = $studyplan->title;
								  }
								  else
								  {
								  		
										$stdplan = substr($studyplan->title, 0, 15).'...'; 
								  }
							?>


																<div class="hall linehall">
																	<?=$studyplan->category_name?> Post</li>
		 <?php
	  if(!empty($studyplan->featured_image))
	  {
	  	   echo'<img src="'.base_url().'uploads/Studyplan/'.$studyplan->featured_image.'" class="imgcls">';
	  }
	  elseif(!empty($studyplan->image_url))
	  {
	  		 echo'<img src="'.$studyplan->image_url.'" class="imgcls">';
	  }
	  else
	  {
	  		 echo'<img src="'.base_url().'assets/images/default_studyplan.png" class="imgcls">';
	  }
	  ?> 
																	
																	<a href="<?=base_url()?>exam/studyplan/<?=$studyplan->id?>">
																		<?=$stdplan?>
																	</a>
																	<br><br>
																</div>

																<?php     
							    }
								
							
							$i++;
								}
								
								
								?>

													</ul>






												</div>
										</li>
										</ul>
										</li>

										<li class="dropdown megaDropMenu">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="false">SSB Preperation <i class="fa fa-angle-down ml-5"></i></a>
											<ul class="dropdown-menu row">
												<li class="col-sm-7 col-xs-12">
													<ul class="list-unstyled">
														<li>SSB Preperation</li>
														<?php
						 $ssbtest = $obj->accountmodel->getssbpreperation();
						 foreach($ssbtest as  $ssbtest)
						 {
						 ?>
															<li><a href="<?=base_url()?>exam/ssb/<?=$ssbtest->id?>"><?=$ssbtest->topic_title?></a></li>
															<?php
					   }
					   ?>
													</ul>



												</li>
												<?php
				    foreach($menu as  $menus1)
					{
							 $submenus= $obj->accountmodel->getallsubcategories($menus1->id);
										
										if(!empty($submenus))
										{
											foreach($submenus  as $submenu1)
											{
												$subssbmenuarray[] = $submenu1->id;
											}               
								       }
								   
					}
					//print_r($subssbmenuarray);
					?>


													<li class="col-sm-5 col-xs-12 bg5 mgpad">
														<!--<ul class="list-unstyled">
                         <li class="textlevel">Featured Post </li>
                     </ul--->


														<?php
							  $featuredarticle = $obj->accountmodel->getanyfeaturedarticlelimitone();	
								if(!empty($featuredarticle))
								{
								
								
								
								
								  $articlelength = strlen($featuredarticle->topic_title);
								  if($articlelength<18)
								  {
								  		$article = $featuredarticle->topic_title;
								  }
								  else
								  {
								  		
										$article = substr($featuredarticle->topic_title, 0, 18).'...'; 
								  }
								   
								?>
															<div class="hall linehall">
																<p class="textlevel">Featured Post</p>
		                 <?php
							if(!empty($featuredarticle->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredarticle->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredarticle->image_url))
							{
									echo'<img src="'.$featuredarticle->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>		
									
																
																<a href="<?=base_url()?>articles/details/<?=$featuredarticle->id?>">
																	<?=$article?>
																</a>
																<br><br>
															</div>
															<?php
								
								}
								
								?>
															<?php
								    $featuredquiz =  $obj->accountmodel->getanyfeaturedquiz();
										if(!empty($featuredquiz))
										{
										 foreach($featuredquiz as  $featuredquiz)
										 {
													  $featuredqzlength = strlen($featuredquiz->exam_name);
													  if($featuredqzlength<18)
													  {
															$qzname = $featuredquiz->exam_name;
													  }
													  else
													  {
															
															$qzname = substr($featuredquiz->exam_name, 0, 15).'...'; 
													  }
								?>
																<div class="hall linehall">

																	<p class="textlevel">Featured Quiz</p>

                                                <?php
												if(!empty($featuredquiz->exam_featured_image))
												{
													echo'<img src="'.base_url().$featuredquiz->exam_upload_path.$featuredquiz->exam_featured_image.'" style="height:95px;">';
												}
												elseif(!empty($featuredquiz->image_url))
												{
													echo'<img src="'.$featuredquiz->image_url.'" style="height:95px;">';
												}
												else
												{
										            echo'<img src="'.base_url().'assets/images/default_quiz.png" alt="" style="height:95px;">';
												}
												?>	
																	
																	<a href="<?=base_url()?>quiz/attend/<?=$featuredquiz->exam_slug?>">
																		<?=$qzname ?>
																	</a>
																	<br><br>
																</div>
																<?php
							 		}
					          }
					         ?>



																	<?php
								if(!empty($subssbmenuarray[2]))
								{				
							    $featuredssb = $obj->accountmodel->getfeaturedssblimitone($subssbmenuarray[2]);	
								if(!empty($featuredssb))
								{
								foreach($featuredssb as $featuredssb)
								{
								?>



																		<?php
								
								  $ssblength = strlen($featuredssb->topic_title);
								  if($ssblength<20)
								  {
								  		$ssb = $featuredssb->topic_title;
								  }
								  else
								  {
								  		
										$ssb = substr($featuredssb->topic_title, 0, 20).'...'; 
								  }
								   
								?>
																			<div class="hall linehall">
																				<p class="textlevel">Featured SSb </p>
			                 <?php
							if(!empty($featuredssb->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredarticle->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredssb->image_url))
							{
									echo'<img src="'.$featuredssb->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>		
							
																				<a href="<?=base_url()?>articles/details/<?=$featuredssb->id?>">
																					<?=$ssb?>
																				</a>
																				<br><br>
																			</div>
																			<?php
							    }
								}
								
								
								}
								?>

																				<!--second row-->


																				<?php
							  $featuredarticle = $obj->accountmodel->getanyfeaturedarticlelimittwo();	
								if(!empty($featuredarticle))
								{
								
								
								
								
								  $articlelength = strlen($featuredarticle->topic_title);
								  if($articlelength<18)
								  {
								  		$article = $featuredarticle->topic_title;
								  }
								  else
								  {
								  		
										$article = substr($featuredarticle->topic_title, 0, 18).'...'; 
								  }
								   
								?>
																					<div class="hall linehall">
            
																
			                 <?php
							if(!empty($featuredarticle->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredarticle->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredarticle->image_url))
							{
									echo'<img src="'.$featuredarticle->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>		
													       									
																						<a href="<?=base_url()?>articles/details/<?=$featuredarticle->id?>">
																							<?=$article?>
																						</a>
																						<br><br>
																					</div>
																					<?php
								
								}
								
								?>

																					<?php
								    $featuredquiz =  $obj->accountmodel->getanyfeaturedquizlimitone();
										if(!empty($featuredquiz))
										{
										 foreach($featuredquiz as  $featuredquiz)
										 {
													  $featuredqzlength = strlen($featuredquiz->exam_name);
													  if($featuredqzlength<18)
													  {
															$qzname = $featuredquiz->exam_name;
													  }
													  else
													  {
															
															$qzname = substr($featuredquiz->exam_name, 0, 15).'...'; 
													  }
								?>
																						<div class="hall linehall">
																						
                                           <?php
												if(!empty($featuredquiz->exam_featured_image))
												{
													echo'<img src="'.base_url().$featuredquiz->exam_upload_path.$featuredquiz->exam_featured_image.'" style="height:95px;">';
												}
												elseif(!empty($featuredquiz->image_url))
												{
													echo'<img src="'.$featuredquiz->image_url.'" style="height:95px;">';
												}
												else
												{
										            echo'<img src="'.base_url().'assets/images/default_quiz.png" alt="" style="height:95px;">';
												}
												?>	
																							
																							<a href="<?=base_url()?>quiz/attend/<?=$featuredquiz->exam_slug?>">
																								<?=$qzname ?>
																							</a>
																							<br><br>
																						</div>

																						<?php
							 		}
					          }
					         ?>



																							<?php
								if(!empty($subssbmenuarray[2]))
								{				
							    $featuredssb = $obj->accountmodel->getfeaturedssblimitonelastrow($subssbmenuarray[2]);	
								if(!empty($featuredssb))
								{
								foreach($featuredssb as $featuredssb)
								{
								?>



																								<?php
								
								  $ssblength = strlen($featuredssb->topic_title);
								  if($ssblength<20)
								  {
								  		$ssb = $featuredssb->topic_title;
								  }
								  else
								  {
								  		
										$ssb = substr($featuredssb->topic_title, 0, 20).'...'; 
								  }
								   
								?>
																									<div class="hall linehall">
								  <?php
							if(!empty($featuredssb->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredssb->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredssb->image_url))
							{
									echo'<img src="'.$featuredssb->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>		
						
																										
																										<a href="<?=base_url()?>articles/details/<?=$featuredssb->id?>">
																											<?=$ssb?>
																										</a>
																										<br><br>
																									</div>
																									<?php
							    }
								}
								
								//unset($submenuarray);
								}
								?>


													</li>
											</ul>
										</li>


										<li class="dropdown megaDropMenu">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="false">Download <i class="fa fa-angle-down ml-5"></i></a>
											<ul class="dropdown-menu row">
												<div class="col-lg-6 ">
													<?php
				   $menubydownload = $obj->accountmodel->getmainmenubylimit();
				   $i=0;
				   foreach($menubydownload as $menubydownload)
				   {
				          $download = $obj->accountmodel->getdownloadbylimit($menubydownload->id);
						
				    ?>

														<li class="col-lg-4 bor4">
															<ul class="list-unstyled">

																<li>
																	<?=$menubydownload->category_name?>
																</li>


																<?php
					   if(!empty($download))
					   {
					   foreach($download as $download)
					   {
					   		    $dwnldlgnth = strlen($download->title);
								  if($dwnldlgnth<40)
								  {
								  		$dwnld = $download->title;
								  }
								  else
								  {
								  		
										$dwnld = substr($download->title, 0, 40).'...'; 
								  }
								  
					   ?>
																	<li>
																		<a href="<?=base_url()?>exam/download/<?=$download->id?>">
																			<?=$dwnld?>
																		</a>
																	</li>
																	<?php
					   }
					   }
					  ?>

															</ul>
														</li>

														<?php
					 
					}
					?>
												</div>


												<div class="col-lg-6 bg5 mgpad">


													<div class="half">

														<?php
								    $featuredquiz =  $obj->accountmodel->getanyfeaturedquizbttwolimit();
										if(!empty($featuredquiz))
										{
										 foreach($featuredquiz as  $featuredquiz)
										 {
													  $featuredqzlength = strlen($featuredquiz->exam_name);
													  if($featuredqzlength<18)
													  {
															$qzname = $featuredquiz->exam_name;
													  }
													  else
													  {
															
															$qzname = substr($featuredquiz->exam_name, 0, 15).'...'; 
													  }
								?>
															<div class="hall linehall">

																<p class="textlevel">Featured Quiz</p>
                                              <?php
												if(!empty($featuredquiz->exam_featured_image))
												{
													echo'<img src="'.base_url().$featuredquiz->exam_upload_path.$featuredquiz->exam_featured_image.'" style="height:95px;">';
												}
												elseif(!empty($featuredquiz->image_url))
												{
													echo'<img src="'.$featuredquiz->image_url.'" style="height:95px;">';
												}
												else
												{
										            echo'<img src="'.base_url().'assets/images/default_quiz.png" alt="" style="height:95px;">';
												}
												?>	
										
																<a href="<?=base_url()?>quiz/attend/<?=$featuredquiz->exam_slug?>">
																	<?=$qzname ?>
																</a>
																<br><br>
															</div>
															<?php
							 		}
					          }
					         ?>



																<?php
								if(!empty($subssbmenuarray[2]))
								{				
							    $featuredssb = $obj->accountmodel->getfeaturedssblimitone($subssbmenuarray[2]);	
								if(!empty($featuredssb))
								{
								foreach($featuredssb as $featuredssb)
								{
								?>



																	<?php
								
								  $ssblength = strlen($featuredssb->topic_title);
								  if($ssblength<20)
								  {
								  		$ssb = $featuredssb->topic_title;
								  }
								  else
								  {
								  		
										$ssb = substr($featuredssb->topic_title, 0, 20).'...'; 
								  }
								   
								?>
																		<div class="hall linehall">
																			<p class="textlevel">Featured SSb </p>
					      <?php
							if(!empty($featuredssb->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredssb->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredssb->image_url))
							{
									echo'<img src="'.$featuredssb->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>		
																			<a href="<?=base_url()?>articles/details/<?=$featuredssb->id?>">
																				<?=$ssb?>
																			</a>
																			<br><br>
																		</div>
																		<?php
							    }
								}
								
								
								}
								?>

																			<!--second row-->


																			<?php
								    $featuredquiz =  $obj->accountmodel->getanyfeaturedquizsecondrow();
										if(!empty($featuredquiz))
										{
										 foreach($featuredquiz as  $featuredquiz)
										 {
													  $featuredqzlength = strlen($featuredquiz->exam_name);
													  if($featuredqzlength<18)
													  {
															$qzname = $featuredquiz->exam_name;
													  }
													  else
													  {
															
															$qzname = substr($featuredquiz->exam_name, 0, 15).'...'; 
													  }
								?>
																				<div class="hall linehall">
                                             <?php
												if(!empty($featuredquiz->exam_featured_image))
												{
													echo'<img src="'.base_url().$featuredquiz->exam_upload_path.$featuredquiz->exam_featured_image.'" style="height:95px;">';
												}
												elseif(!empty($featuredquiz->image_url))
												{
													echo'<img src="'.$featuredquiz->image_url.'" style="height:95px;">';
												}
												else
												{
										            echo'<img src="'.base_url().'assets/images/default_quiz.png" alt="" style="height:95px;">';
												}
												?>	
																					
																					<a href="<?=base_url()?>quiz/attend/<?=$featuredquiz->exam_slug?>">
																						<?=$qzname ?>
																					</a>
																					<br><br>
																				</div>

																				<?php
							 		}
					          }
					         ?>



																					<?php
								if(!empty($subssbmenuarray[2]))
								{				
							    $featuredssb = $obj->accountmodel->getfeaturedssblimitonelastrow($subssbmenuarray[2]);	
								if(!empty($featuredssb))
								{
								foreach($featuredssb as $featuredssb)
								{
								?>



																						<?php
								
								  $ssblength = strlen($featuredssb->topic_title);
								  if($ssblength<20)
								  {
								  		$ssb = $featuredssb->topic_title;
								  }
								  else
								  {
								  		
										$ssb = substr($featuredssb->topic_title, 0, 20).'...'; 
								  }
								   
								?>
																							<div class="hall linehall">
						 <?php
							if(!empty($featuredssb->featured_image))						   
							{
						       echo'<img src="'.base_url().'uploads/Posts/'.$featuredssb->featured_image.'" style="height:95px;">';
							  
						    }
							elseif(!empty($featuredssb->image_url))
							{
									echo'<img src="'.$featuredssb->image_url.'" style="height:95px;">';
							}
							else
							{
								echo'<img src="'.base_url().'assets/images/default_article.png" style="height:95px;">';
							}
							 ?>		
							
																								
																								<a href="<?=base_url()?>articles/details/<?=$featuredssb->id?>">
																									<?=$ssb?>
																								</a>
																								<br><br>
																							</div>
																							<?php
							    }
								}
								
								//unset($submenuarray);
								}
								?>

													</div>





												</div>
											</ul>
										</li>


										<li class="dropdown megaDropMenu">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="false">Notification <i class="fa fa-angle-down ml-5"></i></a>
											<!--<ul class="dropdown-menu row">
                    <li class="col-sm-3 col-xs-12">
                      <ul class="list-unstyled">
                        <li>Exams</li>
                        <li><a href="#">Civil Services Exams</a></li>
                        <li><a href="#">UPSC Civil Services</a></li>
                        <li><a href="#">IAS Exam</a></li>
                        <li><a href="#">UPPSC</a></li>
                        <li><a href="#">MPPSC</a></li>
                     </ul>
                    </li>
                    <li class="col-sm-3 col-xs-12">
                      <ul class="list-unstyled">
                        <li>Subjects</li>
                        <li><a href="#"> GK & Current Affairs</a></li>
                        <li><a href="#">Economic & Social Development</a></li>
                        <li><a href="#">Environmental</a></li>
                        <li><a href="#">Indian History</a></li>
                        <li><a href="#">Geography</a></li>
                        <li><a href="#">Polity & Governance</a></li>
                        <li><a href="#">Science & Technology</a></li>
                       </ul>
                    </li>
                    <li class="col-sm-3 col-xs-12">
                      <ul class="list-unstyled">
                        <li>Quick Links</li>
                        <li><a href="#">UPSC Current Affairs (Daily)</a></li>
                        <li><a href="#">UPSC Current Affairs Quiz</a></li>
                        <li><a href="#">UPSC Notification</a></li>
                        <li><a href="#">GS Writing Challenge</a></li>
                     </ul>
                    </li>
                   <li class="col-sm-3 col-xs-12">
                        <ul class="list-unstyled">
                        <li>Featured</li>
                     </ul>
                     
					 <div class="half">
					 <div class="hall">
						<img src="<?=base_url()?>assets/images/hov1.jpg">
							<a href="#">UPSC IAS Syllabus and Exam Pattern for Prelims/Mains 2018 </a>
					</div>
					
					<div class="hall">
						<img src="<?=base_url()?>assets/images/hov2.jpg">
							<a href="#">UPSC IAS Syllabus and Exam Pattern for Prelims/Mains 2018 </a>
					</div>
					
					
					</div>
						
						
						<ul class="list-unstyled">
                        <li>Notes</li>
                        <li><a href="#">UPPSC booklist and strategy</a></li>
                        <li><a href="#">How To Read Newspaper For UPSC Civil Services (IAS) Exam</a></li>
                        <li><a href="#">UPSC Civil Services 2017 Preparation Strategy for Beginners</a></li>
                     </ul>
					 
                    </li>
                  </ul>-->
										</li>




										</ul>
								</div>
							</div>
						</nav>



					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>