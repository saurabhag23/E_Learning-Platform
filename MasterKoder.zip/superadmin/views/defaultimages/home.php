<style type="text/css">
td img {
    width: 100px!important;
}
</style>
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Default Images 
      </h1>
      <ol class="breadcrumb">
        <li><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Default images</a></li>
        <li class="active">All Default images</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="default" class="table table-responsive table-bordered table-striped">
                <thead>
                <tr>
                  <th>Module</th>
				  <th>Image</th>
                  <th>Update</th>
                  <th>Action</th>
               
                </tr>
				<form method="POST" class="process-form-img" enctype="multipart/form-data" action="<?= admin_url('defaultimages/updateimages')?>">
				<tr>
                  <td>Post</td>
				  <td><img src="<?=base_url()?>assets/images/default_article.png"  style="height:100px;"></td>
                  <td><input type="file" class="form-control" name = "postimage"></td>
				  
				  <?php if(has_permission('defaultimages', 'update')): ?>		
                  <td><input type="submit" class="btn btn-success" value="Update"></td>
				  <?php endif; ?>
			    </tr>
				<tr>
                  <td>Quiz</td>
				  <td><img src="<?=base_url()?>assets/images/default_quiz.png" style="height:100px;"></td>
                  <td><input type="file" class="form-control" name = "quizimage"></td>
                  <?php if(has_permission('defaultimages', 'update')): ?>		
                  <td><input type="submit" class="btn btn-success" value="Update"></td>
				  <?php endif; ?>
			    </tr>
				<tr>
                  <td>Syllabus</td>
				  <td><img src="<?=base_url()?>assets/images/default_syllabus.png" style="height:100px;"></td>
                  <td><input type="file" class="form-control" name = "syllabusimage"></td>
                 <?php if(has_permission('defaultimages', 'update')): ?>		
                  <td><input type="submit" class="btn btn-success" value="Update"></td>
				  <?php endif; ?>
			    </tr>
				<tr>
                  <td>Notes</td>
				  <td><img src="<?=base_url()?>assets/images/default_notes.png" style="height:100px;"></td>
                  <td><input type="file" class="form-control" name = "notesimage"></td>
                  <td><input type="submit" class="btn btn-success" value="Update"></td>
			    </tr>
				<tr>
                  <td>Study Plan</td>
				  <td><img src="<?=base_url()?>assets/images/default_studyplan.png" style="height:100px;"></td>
                  <td><input type="file" class="form-control" name = "studyplanimage"></td>
                 <?php if(has_permission('defaultimages', 'update')): ?>		
                  <td><input type="submit" class="btn btn-success" value="Update"></td>
				  <?php endif; ?>
			    </tr>
				<tr>
                  <td>Exam Details</td>
				  <td><img src="<?=base_url()?>assets/images/default_examdetails.png" style="height:100px;"></td>
                  <td><input type="file" class="form-control" name = "examdetailsimage"></td>
                 <?php if(has_permission('defaultimages', 'update')): ?>		
                  <td><input type="submit" class="btn btn-success" value="Update"></td>
				  <?php endif; ?>
			    </tr>
				 </form>
                </thead>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

<div id="infoModal" class="modal fade" role="dialog" aria-labelledby="alertModal" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default cl_btn" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>