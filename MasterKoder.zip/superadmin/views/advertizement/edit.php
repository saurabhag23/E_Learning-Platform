
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Update Advertizement
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('advertizement') ?>">Advertizement</a></li>
        <li class="active">Update Advertizement</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form-img" action="<?= admin_url('advertizement/update') ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">

                <div class="form-group  col-md-12">
                  <label for="first_name">Hyperlink</label>
                  <input type="text" class="form-control" id="hyperlink" placeholder="hyperlink" name="hyperlink" value="<?=$row->hyperlink?>"> 
                </div>
				
				<div class="form-group  col-md-12">
                  <label for="first_name">Priority</label>
                  <input type="number" class="form-control" id="priority" placeholder="priority" name="priority" value="<?=$row->priority?>">
                </div>	

                <div class="form-group col-md-12">
                        <label class="control-label">Image</label>
                       	<input  type="file" class="form-control" name="image" id="image" >
						<img src="<?=base_url()?>uploads/advertizement/<?=$row->image?>" style="width:100px; height:100px;">
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="update">
				 <input type="hidden" name="id" value="<?=$row->id?>">
                <button type="submit" class="btn btn-primary btn-sm pull-right">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
