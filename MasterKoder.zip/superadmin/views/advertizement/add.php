
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add new Advertizement
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('advertizement') ?>">Advertizement</a></li>
        <li class="active">Add new Advertizement</li>
      </ol>
    </section>

<style>
.optdiv{
	display: none;
}
</style>	
	
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form-img" action="<?= admin_url('advertizement/insert') ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">

                <div class="form-group  col-md-12">
                  <label for="title">Advertizement Title</label>
                  <input type="text" class="form-control" id="title" placeholder="" name="title">
                </div>
				
                <div class="form-group  col-md-12">
                  <label for="location">Location</label>
                  
				  <?php
					$opt = array( "" => "Select", "Left Sidebar" => "Left Sidebar", "Right Sidebar" => "Right Sidebar", "Newsfeed" => "Newsfeed", "Quiz" => "Quiz", "Banner Ad" => "Banner Ad" );
					
					echo form_dropdown( 'location', $opt, '', 'id="location" class="form-control"' );
				  ?>
				  
                </div>
				
                <div class="form-group  col-md-12" id="typediv">
                  <label for="type">Type</label>
                  
				  <?php
					$opt = array( "" => "Select", "I" => "Image", "V" => "Video" );
					
					echo form_dropdown( 'type', $opt, '', 'id="type" class="form-control"' );
				  ?>
				  
                </div>
			  
                <div class="form-group optdiv col-md-12" id="imagediv">
                  <label for="image">Select Image</label>
                  <input  type="file" class="form-control" name="image" id="image" >
                </div>
				
                <div class="form-group optdiv col-md-12" id="videodiv">
                  <label for="video">Select Video</label>
                  <input  type="file" class="form-control" name="video" id="video" >
                </div>
				
                <div class="form-group optdiv col-md-12" id="googlediv">
                  <label for="google_link">Google Ad Link</label>
                  <input type="text" class="form-control" id="google_link" placeholder="" name="google_link">
                </div>
				
                <div class="form-group optdiv col-md-12" id="imageurldiv">
                  <label for="image_link">Image Url Link</label>
                  <input type="text" class="form-control" id="image_link" placeholder="" name="image_link">
                </div>
				
				<div class="form-group optdiv col-md-12" id="prioritydiv">
                  <label for="priority">Priority</label>
                  <input type="number" class="form-control" id="priority" placeholder="" name="priority">
                </div>

				<div class="form-group optdiv col-md-12" id="youtube_linkdiv">
                  <label for="youtube_link">Youtube Link</label>
                  <input type="text" class="form-control" id="youtube_link" placeholder="" name="youtube_link">
                </div>

				<div class="form-group optdiv col-md-12" id="repeatdiv">
                  <label for="repeat_every">Repeat Every</label>
                  <input type="number" class="form-control" id="repeat_every" placeholder="" name="repeat_every">
                </div>	
                
                <div class="form-group optdiv col-md-12" id="gad_codediv">
                  <label for="gad_code">Google Ad Code</label>
                  
                  <textarea id="gad_code" name="gad_code" class="form-control" ></textarea>
                </div>
				
				<div class="form-group optdiv col-md-12" id="headlinediv">
                  <label for="headline_text">Headline Text</label>
                  <input type="text" class="form-control" id="headline_text" placeholder="" name="headline_text">
                </div>	
				
				<div class="form-group optdiv col-md-12" id="buttondiv">
                  <label for="button_text">Button Text</label>
                  <input type="text" class="form-control" id="button_text" placeholder="" name="button_text">
                </div>
				
				<div class="form-group optdiv col-md-12" id="urllinkdiv">
                  <label for="url_link">Url Link</label>
                  <input type="text" class="form-control" id="url_link" placeholder="" name="url_link">
                </div>
			  
				<!--
                <div class="form-group col-md-12">
                  <label for="first_name">Hyperlink</label>
                  <input type="text" class="form-control" id="hyperlink" placeholder="" name="hyperlink">
                </div>
				-->
				
              </div>
			  
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="insert">
                <input type="hidden" name="save_pub" id="save_pub" value="0">

				<input type="button" id="save" name="save" value="Save" class="btn btn-primary btn-sm pull-right btn-green">
				<input type="button" id="publish" name="publish" value="Publish" class="btn btn-primary btn-sm pull-right btn-green">
				
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
