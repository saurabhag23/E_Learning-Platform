<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
	  
	/* 
    $('#categoryTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[3, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('advertizement/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [{ "data" : "image", render: function(data, type, row, meta) {
                                        return '<img class = "ads" src= "<?= base_url('uploads/advertizement/')?>'+data+'">';
                                        }
                           },
						   { "data" : "priority"},
                           { "data" : "added_date"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },
                           { "data" : "action", "sortable": false}],
    });
	*/
	
    $('#categoryTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[3, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('advertizement/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
							{"data": "id",
    render: function (data, type, row, meta) {
        return meta.row + meta.settings._iDisplayStart + 1;
    }},
							{ "data" : "title"},							
							{ "data" : "type", render: function(data, type, row, meta) {
								
									console.log( 'data:' );
									console.log( data );
									// return data;
								
								  if (data == 'I'){
									  return 'Image';
								  } 
								  else if (data == 'V'){
									  return 'Video';
								  } 
								  else{
									  return data;
								  }
								
								}
							},
							{ "data" : "location"},														
						   { "data" : "priority"},
                           { "data" : "added_date"},                           
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },                       
                           { "data" : "action", "sortable": false}
						   ],
    });
	
	$("body").on("change", "#type", function(){
		
		var location = $('#location').val();
		var type = $(this).val();
	
		console.log( 'location:' + location );
		console.log( 'type:' + type );
		
		if( ( location == 'Left Sidebar' || location == 'Right Sidebar' ) && type == 'I' )
		{
			$('.optdiv').hide();
			//, #googlediv
			$('#imagediv, #imageurldiv, #prioritydiv, #gad_codediv').show();
		}
		else if( ( location == 'Left Sidebar' || location == 'Right Sidebar' ) && type == 'V' )
		{
			$('.optdiv').hide();
			$('#videodiv, #prioritydiv, #youtube_linkdiv, #gad_codediv').show();
		}
		else if( ( location == 'Newsfeed' ) && type == 'I' )
		{
			$('.optdiv').hide();
			$('#imagediv, #imageurldiv, #repeatdiv, #gad_codediv').show();
		}
		else if( ( location == 'Newsfeed' ) && type == 'V' )
		{
			$('.optdiv').hide();
			$('#videodiv, #repeatdiv, #youtube_linkdiv, #gad_codediv').show();
		}

	});
	
	$("body").on("change", "#location", function(){
		
		var location = $(this).val();
		
		console.log( 'location:' + location );
		
		if( location == '' )
		    return false;
		
		if( ( location == 'Quiz' ) )
		{
			$('.optdiv').hide();
			$('#type').val('V');
			$('#typediv').hide();
			$('#videodiv').show();
			$('#youtube_linkdiv').show();
		}		
		else if( ( location == 'Banner Ad' ) )
		{
			$('.optdiv').hide();
			$('#type').val('I');
			$('#typediv').hide();
			$('#imagediv, #headlinediv, #buttondiv, #urllinkdiv').show();
		}
		else
		{
			$('#type').val('I');
			$('#typediv').show();
		}
		
		
		
	});	
	
	//$('#location').trigger('change');
	$('#type').trigger('change');
	
	$("body").on("click", "#publish", function(){
		$('#save_pub').val('1');
		$(this).closest('form').submit();
	});	
	
	$("body").on("click", "#save", function(){
		$('#save_pub').val('0');
		$(this).closest('form').submit();
	});	
	
  });
  function refreshCategoryTable(){
    $('#categoryTable').DataTable().draw();
  }
</script>
<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/ckeditor.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/ckeditor/init.js"></script>  
<script src="<?= base_url() ?>assets/admin/plugins/select2/dist/js/select2.full.min.js"></script>
<script>
    initSample();   
</script>