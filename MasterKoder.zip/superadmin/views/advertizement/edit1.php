
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Update Advertizement
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('advertizement') ?>">Advertizement</a></li>
        <li class="active">Update Advertizement</li>
      </ol>
    </section>

<style>
.optdiv{
	display: none;
}
</style>	
	
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form-img" action="<?= admin_url('advertizement/update') ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">

                <div class="form-group  col-md-12">
                  <label for="title">Advertizement Title</label>
                  <input type="text" class="form-control" id="title" placeholder="" name="title" value="<?=$row->title?>">
                </div>
				
                <div class="form-group  col-md-12">
                  <label for="location">Location</label>
                  
				  <?php
					$opt = array( "" => "Select", "Left Sidebar" => "Left Sidebar", "Right Sidebar" => "Right Sidebar", "Newsfeed" => "Newsfeed", "Quiz" => "Quiz", "Banner Ad" => "Banner Ad" );
					
					echo form_dropdown( 'location', $opt, $row->location, 'id="location" class="form-control"' );
				  ?>
				  
                </div>
				
                <div class="form-group  col-md-12" id="typediv">
                  <label for="type">Type</label>
                  
				  <?php
					$opt = array( "" => "Select", "I" => "Image", "V" => "Video" );
/*					
echo "<hr><pre>type: ";
var_dump( $row->type );
*/
					
					echo form_dropdown( 'type', $opt, $row->type, 'id="type" class="form-control"' );
				  ?>
				  
                </div>
			  
                <div class="form-group optdiv col-md-12" id="imagediv">
                  <label for="image">Select Image</label>
                  <input  type="file" class="form-control" name="image" id="image" value="<?=$row->image?>">
                </div>
				
                <div class="form-group optdiv col-md-12" id="videodiv">
                  <label for="video">Select Video</label>
                  <input  type="file" class="form-control" name="video" id="video" value="<?=$row->video?>">
                </div>
				
                <div class="form-group optdiv col-md-12" id="googlediv">
                  <label for="google_link">Google Ad Link</label>
                  <input type="text" class="form-control" id="google_link" placeholder="" name="google_link" value="<?=$row->google_link?>">
                </div>
				
                <div class="form-group optdiv col-md-12" id="imageurldiv">
                  <label for="image_link">Image Url Link</label>
                  <input type="text" class="form-control" id="image_link" placeholder="" name="image_link" value="<?=$row->image_link?>">
                </div>
				
				<div class="form-group optdiv col-md-12" id="prioritydiv">
                  <label for="priority">Priority</label>
                  <input type="number" class="form-control" id="priority" placeholder="" name="priority" value="<?=$row->priority?>">
                </div>	

				<div class="form-group optdiv col-md-12" id="repeatdiv">
                  <label for="repeat_every">Repeat Every</label>
                  <input type="number" class="form-control" id="repeat_every" placeholder="" name="repeat_every" value="<?=$row->repeat_every?>">
                </div>	
                
                <div class="form-group optdiv col-md-12" id="gad_codediv">
                  <label for="gad_code">Google Ad Code</label>
                  
                  <textarea id="gad_code" name="gad_code" class="form-control" ><?=$row->gad_code?></textarea>
                </div>
				
				<div class="form-group optdiv col-md-12" id="headlinediv">
                  <label for="headline_text">Headline Text</label>
                  <input type="text" class="form-control" id="headline_text" placeholder="" name="headline_text" value="<?=$row->headline_text?>">
                </div>	
				
				<div class="form-group optdiv col-md-12" id="buttondiv">
                  <label for="button_text">Button Text</label>
                  <input type="text" class="form-control" id="button_text" placeholder="" name="button_text" value="<?=$row->button_text?>">
                </div>
				
				<div class="form-group optdiv col-md-12" id="urllinkdiv">
                  <label for="url_link">Url Link</label>
                  <input type="text" class="form-control" id="url_link" placeholder="" name="url_link" value="<?=$row->url_link?>">
                </div>
			  
				<!--
                <div class="form-group col-md-12">
                  <label for="first_name">Hyperlink</label>
                  <input type="text" class="form-control" id="hyperlink" placeholder="" name="hyperlink">
                </div>
				-->
				
              </div>
			  
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="update">
				<input type="hidden" name="id" value="<?=$row->id?>">
				
                <input type="hidden" name="save_pub" id="save_pub" value="0">
				<input type="hidden" name="role" value="<?=$this->uri->segment('4')?>">
				<input type="button" id="save" name="save" value="Save" class="btn btn-primary btn-sm pull-right btn-green">
				<input type="button" id="publish" name="publish" value="Publish" class="btn btn-primary btn-sm pull-right btn-green">
				
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
