
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
          
        <!-- new dashboard -->
        
        <div class="col-md-9">
                <div class="admin-count-box">
                    <p class="admin-count-box-title">Users</p>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">NDA Exam</p>
                                <p class="admin-count-small-box-count"><?=$ndacount?></p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">CDS Exam</p>
                                <p class="admin-count-small-box-count"><?=$cdscount?></p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">AFCAT Exam</p>
                                <p class="admin-count-small-box-count"><?=$afcount?></p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">CDS &amp; AFCAT Exam</p>
                                <p class="admin-count-small-box-count"><?=$cdsafcount?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-count-box">
                    <p class="admin-count-box-title">Total Users</p>
                    <div class="admin-count-small-box">
                        <p class="admin-count-small-box-title">&nbsp;</p>
                        <p class="admin-count-small-box-count"><?=$tucount?></p>
                    </div>
                </div>
            </div>
            
          
        
        <!-- new dashboard end -->
          
        <br><br><br><br>
          
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">Total Users: <?=$tucount?></span>
              <span class="info-box-number">NDA Exam: <?=$ndacount?></span>
              <span class="info-box-number">CDS Exam: <?=$cdscount?></span>
              <span class="info-box-number">AFCAT Exam: <?=$afcount?></span>
              <span class="info-box-number">CDS & AFCAT Exam: <?=$cdsafcount?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">Mentor Post</span>
              <span class="info-box-number">Super-Categories: <?=$ndacount?></span>
              <span class="info-box-number">Categories: <?=$ndacount?></span>
              <span class="info-box-number">Sub-Categories: <?=$ndacount?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">User Post Ask Doubt</span>
              <span class="info-box-number">Super-Categories: <?=$usupposta?></span>
              <span class="info-box-number">Categories: <?=$usubposta?></span>
              <span class="info-box-number">Sub-Categories: <?=$usubsubposta?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">User Post Share Knowledge</span>
              <span class="info-box-number">Super-Categories: <?=$usupposta?></span>
              <span class="info-box-number">Categories: <?=$usubposta?></span>
              <span class="info-box-number">Sub-Categories: <?=$usubsubposta?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">User Post MCQ</span>
              <span class="info-box-number">Super-Categories: <?=$usupposta?></span>
              <span class="info-box-number">Categories: <?=$usubposta?></span>
              <span class="info-box-number">Sub-Categories: <?=$usubsubposta?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">MCQ Quiz</span>
              <span class="info-box-number">Super-Categories: <?=$mqsup?></span>
              <span class="info-box-number">Categories: <?=$mqsub?></span>
              <span class="info-box-number">Sub-Categories: <?=$mqsubsub?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">Pictorial Quiz</span>
              <span class="info-box-number">Super-Categories: <?=$pqsup?></span>
              <span class="info-box-number">Categories: <?=$pqsub?></span>
              <span class="info-box-number">Sub-Categories: <?=$pqsubsub?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">Textual Quiz</span>
              <span class="info-box-number">Super-Categories: <?=$tqsup?></span>
              <span class="info-box-number">Categories: <?=$tqsub?></span>
              <span class="info-box-number">Sub-Categories: <?=$tqsubsub?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">Quizzes Attempted: <?=$qatot?></span>
              <span class="info-box-number">Super-Categories: <?=$qasup?></span>
              <span class="info-box-number">Categories: <?=$qasub?></span>
              <span class="info-box-number">Sub-Categories: <?=$qasubsub?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">Questions Attempted: <?=$queatot?></span>
              <span class="info-box-number">Avg. Scores / out of: <?=$scoutof?></span>
              <span class="info-box-number">Quiz Exits: <?=$totquizexits?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">Feedback Created: <?=$totfbk?></span>
              <span class="info-box-number">Feedback Given: <?=$totfbkg?></span>
              
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">Ads Created</span>
              <span class="info-box-number">Left Sidebar: <?=$adsleft?></span>
              <span class="info-box-number">Right Sidebar: <?=$adsright?></span>
              <span class="info-box-number">Newsfeed: <?=$adsnfeed?></span>
              <span class="info-box-number">Quiz: <?=$adsquiz?></span>
              <span class="info-box-number">Banner: <?=$adsbanner?></span>
              
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

