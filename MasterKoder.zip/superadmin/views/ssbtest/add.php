
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add new Ssb Preperation
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('ssbtest') ?>">Ssb</a></li>
        <li class="active">Add new Ssb Preperation</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form-img-editor" action="<?= admin_url('ssbtest/insert') ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
			  <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label for="first_name">Exam Category</label>
                        
						<select class="form-control" id="examcat" name="examcat" onChange="geteaxamsubcategory()">
						<option value="">Select Exam Category</option>
						<?php
						foreach($examcats as $examcats)
						{
						?>
						  <option value="<?=$examcats->id?>"><?=$examcats->category_name?></option>
						<?php
						}
						?>
						
                        </select>
                      </div>
                  </div>
				  
				<?php /*?> <div class="col-sm-6">
                    <div class="form-group">
                        <label for="first_name">Exam Sub Category</label>
                        
						<select class="form-control" id="examsubcat" name="examsubcat"  onChange="getexams()">
						<option value="">Select Sub Category</option>
						
						
                        </select>
                      </div>
                  </div>
				  <?php */?>
                </div>
			  <!--<div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label for="first_name">Current Affair Type</label>
                        
						<select class="form-control" id="type" name="type">
						<option value="">Select Current Affair Types</option>
						<?php
						foreach($curtypes as $types)
						{
						?>
						  <option value="<?=$types->id?>"><?=$types->current_affair?></option>
						<?php
						}
						?>
						
                        </select>
                      </div>
                  </div>
                </div>-->
				<?php /*?><div class="row">
          						<div class="col-sm-12">
            						<div class="form-group">
            							 <label for="first_name">Select Exam</label>
                        
											<select class="form-control" id="exam" name="exam">
											<option value="">Select Exam </option>
											<?php
					
						                      foreach($exams as  $exams)
						                     {
												   if($exams->id == $row->id_mainexam)
												   {
													 $sel = "selected='selected'";
												   }
												   else
												   {
													 $sel ="";
												   }
		             	                          echo '<option value="'.$exams->id.'" '.$sel.'>'.$exams->exam_title.'</option>';
		                                     }?>
						                    </select>
            						</div>
          					   </div>
          						</div><?php */?>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label for="first_name"> Title</label>
                        <input type="text" class="form-control" id="title" placeholder="Title" name="title">
                      </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label class="control-label">Description</label>
                        <textarea id="editor" name="content" class="form-control" placeholder="Content" rows="15"></textarea>
                      </div>
                  </div>
                </div>
				<div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                        <label class="control-label">Featured Image</label>
                         <input type="file" class="form-control"  name="image" id="image">
                      </div>
                  </div>
              
                  <div class="col-sm-6">
                    <div class="form-group">
						<label class="" style="width:100%">&nbsp;</label>
                    	
                        <label class="form-check-label" for="exampleCheck1">
							<input type="checkbox" class="form-check-input" name="featured" value="1">
						Mark as Featured post</label>
                    </div>
                  </div>
				  

              </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="insert">
             
                <button type="submit" class="btn btn-primary btn-sm pull-right">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
