
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
	 
        Add Level 1
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('menu') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('mentor') ?>">Mentor</a></li>
        <li class="active">Add new mentor</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('menus/add1sub') ?>" method="post">
              <div class="box-body">
                
                <div class="form-group">
                  <label for="title">Category</label>
                  <?php
				  
					if( !empty( $tbl_categories ) )
					{
						$opt = array(''=>'Select');
						
						foreach( $tbl_categories as $key => $value )
						{
							$opt[ $value->id ] = $value->category_name;							
						}
						
						echo form_dropdown('catid', $opt, '', 'id="catid" class="form-control"');
					}
					
				  ?>
				  
				 <?php echo form_error('catid'); ?>				  
                </div>

                <div class="form-group">
                  <label for="title">Level 1 Item Title</label>
                  <input type="text" class="form-control" id="title" placeholder="Title" name="title">
				  
				 <?php echo form_error('title'); ?>				  
                </div>

                <div class="form-group">
                  <label for="url">Url Link</label>
                  <input type="text" class="form-control" id="url" placeholder="Url" name="url">
				  <?php echo form_error('url'); ?>				  
                </div>

                <div class="form-group">
                  <label for="order">Order</label>
				  <div id="l1ord">
                  <?php
				  	$opt = array( "" => "Select" );
					
/* 					for( $i  = 1; $i < 11 ; $i++ )
					{
						if( ! in_array( $i, $ordarr ) )
						$opt[ $i ] = $i ;
					} */
	
					echo form_dropdown( 'order', $opt, '', 'id="order" class="form-control"' );
				  ?>
				  </div>
					
				  <?php echo form_error('order'); ?>
                </div>
				
                <div class="form-group">
                  <label for="order">Status</label>
                  <?php
					$opt = array( "" => "Select", "1" => "Active", "0" => "Inactive" );
					
					echo form_dropdown( 'status', $opt, '', 'id="status" class="form-control"' );
				  ?>
				  <?php echo form_error('status'); ?>
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="insert">
				<input type="hidden" name="role" value="<?=$this->uri->segment('4')?>">
                <button type="submit" class="btn btn-primary btn-sm pull-right btn-green">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
