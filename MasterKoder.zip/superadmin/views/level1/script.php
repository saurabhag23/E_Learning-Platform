<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
    $('#level1Table').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('menus/get_all_level1') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
							{ "data" : "id"},
							{ "data" : "title"},
                           { "data" : "l2count"},
                           { "data" : "l3count"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Blocked </span>';
                                          } 
										  else if (data == -1){
                                              return '<span class="label label-warning"> Not approved </span>';
                                          } 
                                        }},
                           { "data" : "action", "sortable": false}],
    });
  });
  function refreshlevel1Table(){
    $('#level1Table').DataTable().draw();
  }
  
	$("body").on("change", "#catid", function(){
		console.log( 'catid click' );
		var catid = $(this).val();
		var corder = $('#corder').val();
		var ccatid = $('#ccatid').val();
		$.ajax({
					url:"<?=admin_url('menus/get_l1ord')?>",
					type: "POST",
					data:{catid: catid, corder: corder, ccatid: ccatid},
					 success: function (res) {

							console.log( res );
												
							$("#l1ord").html( res );
							
					 }
		});		

	});
	
</script>