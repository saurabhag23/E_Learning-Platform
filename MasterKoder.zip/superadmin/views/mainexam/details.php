
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('subcategory') ?>">Courses</a></li>
        <li class="active">Details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-lg-12 col-xs-12 col-md-12">

            <div class="box box-solid">
                <div class="box-header with-border">
                  <i class="fa fa-book"></i>

                  <h3 class="box-title"><?= $row->course_title ?></h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">


                    <div class="col-lg-3 col-xs-6">
                      <a href="<?=admin_url('subcategory/exam/'.$course_id, 1) ?>">
                          <div class="small-box bg-green">
                            <div class="inner">
                              <h3><?= $row->exam_count ?></h3>

								  <p>Quiz</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-pencil"></i>
                            </div>
                            <a href="<?=admin_url('subcategory/current-affairs/'.$course_id, 1) ?>" class="small-box-footer">
                              More info <i class="fa fa-arrow-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
					 <div class="col-lg-3 col-xs-6">
                      <a href="<?= admin_url('subcategory/current-affairs/'.$course_id, 1) ?>">
                          <div class="small-box bg-aqua">
                            <div class="inner">
                              <h3><?= $row->exam_count ?></h3>

                              <p>Current Affairs</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-book"></i>
                            </div>
                            <a href=" <?= admin_url('subcategory/current-affairs/'.$course_id, 1) ?>" class="small-box-footer">
                                More info <i class="fa fa-arrow-circle-right"></i>
                            </a>
                          </div>
                      </a>
                  </div>
				  <div class="col-lg-3 col-xs-6">
                      <a href="<?= admin_url('subcategory/exam/'.$course_id, 1) ?>">
                          <div class="small-box bg-red">
                            <div class="inner">
                              <h3><?= $row->exam_count ?></h3>

								  <p>Exam Details</p>
                            </div>
                            <div class="icon">
                              <i class="fa fa-pencil"></i>
                            </div>
                            <a href="<?=admin_url('subcategory/current-affairs/'.$course_id, 1) ?>" class="small-box-footer">
                              More info <i class="fa fa-arrow-circle-right"></i>
                            </a>
                          </div>
                      </a>
                    </div>
                <!-- /.box-body -->
              </div>
          </div>





        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

