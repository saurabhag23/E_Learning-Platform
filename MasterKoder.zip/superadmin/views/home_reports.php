
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->

        <!-- new dashboard -->
        

        <div class="admin-count-box">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">Posts</p>
                                <p class="admin-count-small-box-count"><?=$reppost?></p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">Comments</p>
                                <p class="admin-count-small-box-count"><?=$repcom?></p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">Question</p>
                                <p class="admin-count-small-box-count">25 / 50</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-4">
                <div class="admin-report-box">
                    <div class="admin-report-box-header">
                        <p>Posts</p>
                    </div>
                    <div class="admin-report-box-content">
                        <p class="admin-report-box-list-item">
                            <span class="admin-report-name">Spam</span>
                            <span class="admin-report-count"><?=$spampost?></span>
                        </p>
                        <p class="admin-report-box-list-item">
                            <span class="admin-report-name">Wrong Information</span>
                            <span class="admin-report-count"><?=$wipost?></span>
                        </p>
                        <p class="admin-report-box-list-item">
                            <span class="admin-report-name">Should not be on TGM</span>
                            <span class="admin-report-count"><?=$shnotpost?></span>
                        </p>
						<p class="admin-report-box-list-item">
                            <span class="admin-report-name">Sell or Promotion of their own product/Services</span>
                            <span class="admin-report-count"><?=$sellpost?></span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="admin-report-box">
                    <div class="admin-report-box-header">
                        <p>Comments</p>
                    </div>
                    <div class="admin-report-box-content">
                        <p class="admin-report-box-list-item">
                            <span class="admin-report-name">Spam</span>
                            <span class="admin-report-count"><?=$spamcom?></span>
                        </p>
                        <p class="admin-report-box-list-item">
                            <span class="admin-report-name">Wrong Information</span>
                            <span class="admin-report-count"><?=$wicom?></span>
                        </p>
                        <p class="admin-report-box-list-item">
                            <span class="admin-report-name">Should not be on TGM</span>
                            <span class="admin-report-count"><?=$shnotcom?></span>
                        </p>
						<p class="admin-report-box-list-item">
                            <span class="admin-report-name">Sell or Promotion of their own product/Services</span>
                            <span class="admin-report-count"><?=$sellcom?></span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="admin-report-box">
                    <div class="admin-report-box-header">
                        <p>Question</p>
                    </div>
                    <div class="admin-report-box-content">
                        <p class="admin-report-box-list-item">
                            <span class="admin-report-name">Wrong Question</span>
                            <span class="admin-report-count">0</span>
                        </p>
                        <p class="admin-report-box-list-item">
                            <span class="admin-report-name">Wrong Answer</span>
                            <span class="admin-report-count">0</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>

       
        

        <!-- new dashboard end -->
        
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

