
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
          
        <!-- new dashboard -->
        
        <div class="col-md-9">
                <div class="admin-count-box">
                    <p class="admin-count-box-title">Users</p>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">NDA Exam</p>
                                <p class="admin-count-small-box-count"><?=$ndacount?></p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">CDS Exam</p>
                                <p class="admin-count-small-box-count"><?=$cdscount?></p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">AFCAT Exam</p>
                                <p class="admin-count-small-box-count"><?=$afcount?></p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="admin-count-small-box">
                                <p class="admin-count-small-box-title">CDS &amp; AFCAT Exam</p>
                                <p class="admin-count-small-box-count"><?=$cdscount+$afcount?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-count-box">
                    <p class="admin-count-box-title">Total Users</p>
                    <div class="admin-count-small-box">
                        <p class="admin-count-small-box-title">&nbsp;</p>
                        <p class="admin-count-small-box-count"><?=$ndacount+$cdscount+$afcount?></p>
                    </div>
                </div>
            </div>
          
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

