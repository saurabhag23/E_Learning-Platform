
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
	 
        Edit Level 3
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('menu') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('menus') ?>">Mentor</a></li>
        <li class="active">Edit Level 3</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('level3/update') ?>" method="post">
              <div class="box-body">
                

                <div class="form-group">
                  <label for="title">Level 3 Item Title</label>
                  <input type="text" class="form-control" id="title" placeholder="Title" name="title" value="<?=$row->title?>">
				  
				 <?php echo form_error('title'); ?>				  
                </div>
				
				<div class="form-group">
                  <label for="title">Category</label>
                  <?php
				  
					if( !empty( $tbl_categories ) )
					{
						$opt = array(''=>'Select');
						
						foreach( $tbl_categories as $key => $value )
						{
							$opt[ $value->id ] = $value->category_name;							
						}
						
						echo form_dropdown('catid', $opt, $row->catid, 'id="catid" class="form-control"');
					}
					
				  ?>
				  
				 <?php echo form_error('catid'); ?>				  
                </div>
				
                <div class="form-group">
                  <label for="title">Parent Level 1</label>
				  <div id="lev1div">
                  <?php
				  
					// if( !empty( $tbl_mlevel1 ) )
					// {
						$opt = array(''=>'Select');
						
/* 						foreach( $tbl_mlevel1 as $key => $value )
						{
							$opt[ $value->id ] = $value->title;							
						} */
						
						echo form_dropdown('l1_id', $opt, $row->l1_id, 'id="l1_id" class="form-control"');
					// }
					
				  ?>
				</div>
				 <?php echo form_error('l1_id'); ?>				  
                </div>
				
				<div class="form-group">
                  <label for="title">Parent Level 2</label>
				  <div id="l2div">
                  <?php
				  
					// if( !empty( $tbl_mlevel2 ) )
					// {
						$opt = array(''=>'Select');
						
/* 						foreach( $tbl_mlevel2 as $key => $value )
						{
							$opt[ $value->id ] = $value->title;							
						} */
						
						echo form_dropdown('l2_id', $opt, $row->l2_id, 'id="l2_id" class="form-control"');
					// }
					
				  ?>
					</div>				  
				 <?php echo form_error('l2_id'); ?>				  
                </div>				

                <div class="form-group">
                  <label for="url">Url Link</label>
                  <input type="text" class="form-control" id="url" placeholder="Url" name="url" value="<?=$row->url?>">
				  <?php echo form_error('url'); ?>				  
                </div>

                <div class="form-group">
                  <label for="order">Order</label>
				  <div id="l3ord">
                  <?php
				  	$opt = array( "" => "Select" );
					
					for( $i  = 1; $i < 11 ; $i++ )
						$opt[ $i ] = $i ;
	
					echo form_dropdown( 'order', $opt, $row->order, 'id="order" class="form-control"' );
				  ?>
				  </div>
				  <?php echo form_error('order'); ?>
                </div>
				
                <div class="form-group">
                  <label for="order">Status</label>
                  <?php
					$opt = array( "" => "Select", "1" => "Active", "0" => "Inactive" );
					
					echo form_dropdown( 'status', $opt, $row->status, 'id="status" class="form-control"' );
				  ?>
				  <?php echo form_error('status'); ?>
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="<?=  $row->id ?>">
				<input type="hidden" name="cl1_id" id="cl1_id" value="<?=$row->l1_id?>">
                <input type="hidden" name="cl2_id" id="cl2_id" value="<?=$row->l2_id?>">
                <input type="hidden" name="corder" id="corder" value="<?=$row->order?>">
                <button type="submit" class="btn btn-primary btn-sm pull-right btn-green">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
 
