<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
    $('#level3Table').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('level3/get_all_level3') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
							{ "data" : "id"},
							{ "data" : "title"},
                           { "data" : "lev1tit"},
                           { "data" : "lev2tit"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Blocked </span>';
                                          } 
										  else if (data == -1){
                                              return '<span class="label label-warning"> Not approved </span>';
                                          } 
                                        }},
                           { "data" : "action", "sortable": false}],
    });

  function refreshlevel3Table(){
    $('#level3Table').DataTable().draw();
  }
  
	$("body").on("change", "#l1_id", function(){
		console.log( 'l1_id click' );
		var l1_id = $(this).val();
		var cl2_id = $('#cl2_id').val();
		$.ajax({
					url:"<?=admin_url('level3/get_l2')?>",
					type: "POST",
					data:{l1_id: l1_id, cl2_id: cl2_id},
					 success: function (res) {

							console.log( res );
												
							$("#l2div").html( res );
							$('#l2_id').trigger('change');
					 }
		});		

	});
	
	
	$("body").on("change", "#l2_id", function(){
		console.log( 'l2_id click' );
		var l2_id = $(this).val();
		var corder = $('#corder').val();
		var cl2_id = $('#cl2_id').val();
		
		$.ajax({
					url:"<?=admin_url('level3/get_l3ord')?>",
					type: "POST",
					data:{l2_id: l2_id, cl2_id: cl2_id, corder: corder},
					 success: function (res) {

							console.log( res );
												
							$("#l3ord").html( res );
							
					 }
		});		

	});
	
	$("body").on("change", "#catid", function(){
		console.log( 'catid click' );
		var catid = $(this).val();
		var l1_id = $('#cl1_id').val();

		$.ajax({
					url:"<?=admin_url('level2/get_l1')?>",
					type: "POST",
					data:{catid: catid, l1_id: l1_id},
					 success: function (res) {

							console.log( res );
												
							$("#lev1div").html( res );
							$('#l1_id').trigger('change');
					 }
		});		

	});
	
	$('#catid').trigger('change');
	
	
  
});
</script>