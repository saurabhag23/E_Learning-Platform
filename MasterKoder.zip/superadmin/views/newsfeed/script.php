<script src="<?= base_url() ?>assets/admin/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/admin/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
    $('#topicTable').DataTable({
          "processing"  : true,
          "serverSide"  : true,
          "order"       : [[3, 'desc']],
          "pageLength"  : 25,
          "ajax"        : { "url"       : "<?= admin_url('newsfeed/get_all_datas') ?>",
                            "dataType"  : "json",
                            "type"      : "POST"
                          },
          "columns"     : [
						   { "data" : "topic_title"},
                            { "data" : "exam_name"},
                           { "data" : "added_date"},
                           { "data" : "status", render: function(data, type, row, meta) {
                                          if (data == 1){
                                              return '<span class="label label-success"> Active </span>';
                                          } 
                                          else if (data == 0){
                                              return '<span class="label label-warning"> Hidden </span>';
                                          } 
                                        }
                           },
                           { "data" : "action", "sortable": false}],
    });
	
setInterval(function() {
    
	/* $("button").each(function(){
		if( $(this).attr('title') == 'Unhide' )
			$(this).hide();
	}); */
	
}, 1000);  

    $('#post_type').change( function() {
        
        var post_type = $(this).val();
        console.log( 'post_type:' + post_type );
        
        if( post_type == 'A' )
        {
            $('#artdiv').show();
            $('#quizdiv').hide();
        }
        else
        {
            $('#artdiv').hide();
            $('#quizdiv').show();
        }
    } );// click end
	
  });
  function refreshTopicTable(){
    $('#topicTable').DataTable().draw();
  }
  
</script>