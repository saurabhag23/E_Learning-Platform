
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Update new Newsfeed Post
      </h1>
      <ol class="breadcrumb">
         <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('newsfeed') ?>">Post</a></li>
        <li><a href="#">Post</a></li>
        <li class="active"> Update new Newsfeed Post</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form-img" action="<?= admin_url('newsfeed/update') ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
			  
                 <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label class="control-label">Title</label>
						<input type="text" name="title" id="title" class="form-control" value="<?= $row->title?>">
                      </div>
                  </div>
                </div> 

                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label class="control-label">Contents</label>
                        <textarea id="editor" name="content" class="form-control" placeholder="Content" rows="15">
						<?= $row->upadated_status?></textarea>
                      </div>
                  </div>
                </div>
               <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label class="control-label"> Image</label>
                         <input type="file" class="form-control" id="title" placeholder="" name="image">
                      </div>
                  </div>
              
                  
				  

              </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="<?= $row->id ?>">
               
                <button type="submit" class="btn btn-primary btn-sm pull-right">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
