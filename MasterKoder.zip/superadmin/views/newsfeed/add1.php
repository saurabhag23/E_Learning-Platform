
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Select Post
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('newsfeed') ?>">Post</a></li>
        <li><a href="#">Post</a></li>
        <li class="active">Select Post</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
			
            <form class="process-form-img" action="<?= admin_url('newsfeed/insert') ?>" method="post" enctype="multipart/form-data">
			
              <div class="box-body">
                  
                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label class="control-label">Select Post Type</label>
						
						<?php
						
						$opt = array( '' => 'Select', 'A' => 'Article', 'Q' => 'Quiz' );
						
						echo form_dropdown('post_type', $opt, set_value( 'post_type' ), 'id="post_type" class="form-control"');
						
						?>
						
                      </div>
                  </div>
                </div>
			  
			   <div class="row" id="artdiv" style="display:none;">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label class="control-label">Select Article</label>
						
						<?php
						
						$opt = array( '' => 'Select' );
						
						if( !empty( $tbl_posts ) )
						{
							
							
							foreach( $tbl_posts as $key => $value )
							{
								$opt[ $value->id ] = $value->topic_title;						
							}
							
							
						}
						
						echo form_dropdown('post', $opt, set_value( 'post' ), 'id="post" class="form-control"');
						
						?>
						
                      </div>
                  </div>
                </div>
                
			   <div class="row" id="quizdiv" style="display:none;">
                  <div class="col-sm-12">
                    <div class="form-group">
                        <label class="control-label">Select Quiz</label>
						
						<?php
						
						$opt = array( '' => 'Select' );
						
						if( !empty( $tbl_quiz ) )
						{
							foreach( $tbl_quiz as $key => $value )
							{
								$opt[ $value->id ] = $value->exam_name;
							}
						}
						
						echo form_dropdown('quiz', $opt, set_value( 'quiz' ), 'id="quiz" class="form-control"');
						
						?>
						
                      </div>
                  </div>
                </div>
			
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="insert">
             
                <button type="submit" class="btn btn-primary btn-sm pull-right">Submit</button>
              </div>
			  
            </form>
			
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
