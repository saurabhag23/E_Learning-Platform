
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->

        <!-- new dashboard -->
        
        

		<div class="admin-count-tabs">
            <ul class="nav nav-pills">
                <li class="active"><a class="tabs-link" data-toggle="pill" href="#mentors-post">Mentor’s Posts</a></li>
                <li class=""><a class="tabs-link" data-toggle="pill" href="#users-post">User’s Posts</a></li>
            </ul>

            <div class="tab-content">
                <div id="mentors-post" class="tab-pane active">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="admin-count-box">
                                <p class="admin-count-box-title">Post created</p>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">NDA Exam</p>
                                            <p class="admin-count-small-box-count"><?=$mndapost?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">CDS Exam</p>
                                            <p class="admin-count-small-box-count"><?=$mcdspost?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">AFCAT Exam</p>
                                            <p class="admin-count-small-box-count"><?=$mfcatpost?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">CDS &amp; AFCAT Exam</p>
                                            <p class="admin-count-small-box-count"><?=$mcdspost+$mfcatpost?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="admin-count-box">
                                <p class="admin-count-box-title">Total posts</p>
                                <div class="admin-count-small-box">
                                    <p class="admin-count-small-box-title">&nbsp;</p>
                                    <p class="admin-count-small-box-count"><?=$mtpost?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">NDA Exam</span>
                            <span class="exam-count"><?=$mndapost?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = 9" )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $subcat as $key => $value )
                                    	{	
                                    	    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_posts` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 2 and tbl_articelepost.id_subcategory = " . $value->id )->row()->subcatcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
                                
                                <!--
                                <div class="col-md-4" style="">
                                    <div class="exam-count-box-list right-left-border">
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">History</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Geography</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Polity</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Economics</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Science</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                </div>
                                -->
                                
                                    <?php
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="col-md-4" style="">';
                                        
                                        foreach( $subcat as $key => $value )
                                    	{
                                    	    
                                    	   $subsubcat = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $value->id )->result();
                                    
                                            if( !empty( $subsubcat ) )
                                            {	
                                                echo '<div class="exam-count-box-list right-left-border subsubmp" id="subsubmp'. $value->id .'" style="display: none;">';
                                                
                                                foreach( $subsubcat as $key => $subsubv )
                                            	{	
                                            	    
                                            	$ssqry = "SELECT count( * ) as subcatcnt FROM `tbl_posts` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 2 and tbl_articelepost.id_subsub = " . $subsubv->id ;
                                            	
                                            	//echo '---ssqry: ' . $ssqry;
                                            	    
                                            	$subsubcnt = $this->db->query( $ssqry )->row()->subcatcnt;
                                            	
                                            	/*
                                            	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                            	*/
                                            	
                                            	echo '<a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">'. $subsubv->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subsubcnt .'</span>
                                        </a>';
                                            	
                                            	}
                                            	
                                                echo '</div>';	
                                            }
                                            
                                    	}
                                    	
                                    	echo '</div><div class="col-md-4"></div>';
                                    	
                                    }
                                    
                                    ?>
                                
                                <!--
                                <div class="col-md-4">
                                    
                                </div>
                                -->
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">CDS Exam</span>
                            <span class="exam-count"><?=$mcdspost?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = 3" )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $subcat as $key => $value )
                                    	{	
                                    	    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_posts` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 2 and tbl_articelepost.id_subcategory = " . $value->id )->row()->subcatcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
                                
                                <!--
                                <div class="col-md-4" style="">
                                    <div class="exam-count-box-list right-left-border">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">History</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Geography</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Polity</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Economics</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Science</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                </div>
                                -->
                                
                                    <?php
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="col-md-4" style="">';
                                        
                                        foreach( $subcat as $key => $value )
                                    	{
                                    	    
                                    	   $subsubcat = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $value->id )->result();
                                    
                                            if( !empty( $subsubcat ) )
                                            {	
                                                echo '<div class="exam-count-box-list right-left-border subsubmp" id="subsubmp'. $value->id .'" style="display: none;">';
                                                
                                                foreach( $subsubcat as $key => $subsubv )
                                            	{	
                                            	    
                                            	$subsubcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_posts` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 2 and tbl_articelepost.id_subsub = " . $subsubv->id )->row()->subcatcnt;
                                            	
                                            	/*
                                            	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                            	*/
                                            	
                                            	echo '<a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">'. $subsubv->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subsubcnt .'</span>
                                        </a>';
                                            	
                                            	}
                                            	
                                                echo '</div>';	
                                            }
                                            
                                    	}
                                    	
                                    	echo '</div><div class="col-md-4"></div>';
                                    	
                                    }
                                    
                                    ?>
                                
                                <!--
                                <div class="col-md-4">
                                    
                                </div>
                                -->
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">AFCAT Exam</span>
                            <span class="exam-count"><?=$mfcatpost?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = 8" )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $subcat as $key => $value )
                                    	{	
                                    	    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_posts` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 2 and tbl_articelepost.id_subcategory = " . $value->id )->row()->subcatcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
                                
                                <!--
                                <div class="col-md-4" style="">
                                    <div class="exam-count-box-list right-left-border">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">History</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Geography</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Polity</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Economics</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Science</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                </div>
                                -->
                                
                                    <?php
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="col-md-4" style="">';
                                        
                                        foreach( $subcat as $key => $value )
                                    	{
                                    	    
                                    	   $subsubcat = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $value->id )->result();
                                    
                                            if( !empty( $subsubcat ) )
                                            {	
                                                echo '<div class="exam-count-box-list right-left-border subsubmp" id="subsubmp'. $value->id .'" style="display: none;">';
                                                
                                                foreach( $subsubcat as $key => $subsubv )
                                            	{	
                                            	    
                                            	$subsubcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_posts` inner join tbl_articelepost on tbl_posts.article_id = tbl_articelepost.id inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 2 and tbl_articelepost.id_subsub = " . $subsubv->id )->row()->subcatcnt;
                                            	
                                            	/*
                                            	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                            	*/
                                            	
                                            	echo '<a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">'. $subsubv->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subsubcnt .'</span>
                                        </a>';
                                            	
                                            	}
                                            	
                                                echo '</div>';	
                                            }
                                            
                                    	}
                                    	
                                    	echo '</div><div class="col-md-4"></div>';
                                    	
                                    }
                                    
                                    ?>
                                
                                <!--
                                <div class="col-md-4">
                                    
                                </div>
                                -->
                                
                            </div>
                        </div>
                    </div>

                </div>
                
                <div id="users-post" class="tab-pane">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="admin-count-box">
                                <p class="admin-count-box-title">Post created</p>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">Ask Doubt</p>
                                            <p class="admin-count-small-box-count"><?=$uaskp?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">Share Knowledge</p>
                                            <p class="admin-count-small-box-count"><?=$ushp?></p>
                                        </div>
                                    </div>                                    
                                    <div class="col-md-3">
                                        <div class="admin-count-small-box">
                                            <p class="admin-count-small-box-title">Post MCQ</p>
                                            <p class="admin-count-small-box-count"><?=$umcqp?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="admin-count-box">
                                <p class="admin-count-box-title">Total posts</p>
                                <div class="admin-count-small-box">
                                    <p class="admin-count-small-box-title">&nbsp;</p>
                                    <p class="admin-count-small-box-count"><?=$uaskp+$ushp+$umcqp?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">Ask Doubt</span>
                            <span class="exam-count"><?=$uaskp?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
							
								<div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $cat = $this->db->query( "SELECT * FROM `tbl_categories`" )->result();
                                    
                                    if( !empty( $cat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $cat as $key => $value )
                                    	{	
                                    	    
                                    	$catcnt = $this->db->query( "SELECT count( * ) as catcnt FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 1 and tbl_posts.exam_category = " . $value->id )->row()->catcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active askcat" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->category_name .'</span>
                                            <span class="exam-count-box-list-count">'. $catcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
							
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
									
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list asksub" id="asksub'.$value->id.'" style="display: none;">';
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{	
                                    	    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 1 and tbl_posts.exam_subcat = " . $subval->id )->row()->subcatcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active asksuba" id="'. $subval->id .'">
                                            <span class="exam-count-box-list-text">'. $subval->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
									
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
								
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{
                                    
											$subsub = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $subval->id )->result();
											
											if( !empty( $subsub ) )
											{	
												echo '<div class="exam-count-box-list asksubsub" id="asksubsub'. $subval->id .'" style="display: none;">';
												
												foreach( $subsub as $key => $subsubval )
												{	
													
												$sscnt = $this->db->query( "SELECT count( * ) as sscnt FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 1 and tbl_posts.exam_subsubcat = " . $subsubval->id )->row()->sscnt;
												
												/*
												echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
												*/
												
												echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $subsubval->id .'">
													<span class="exam-count-box-list-text">'. $subsubval->title .'</span>
													<span class="exam-count-box-list-count">'. $sscnt .'</span>
												</a>';
												
												}
												
												echo '</div>';
											}
									
                                    	}                                    	
                                    
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">Share Knowledge</span>
                            <span class="exam-count"><?=$ushp?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
							
								<div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $cat = $this->db->query( "SELECT * FROM `tbl_categories`" )->result();
                                    
                                    if( !empty( $cat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $cat as $key => $value )
                                    	{	
                                    	    
                                    	$catcnt = $this->db->query( "SELECT count( * ) as catcnt FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 2 and tbl_posts.exam_category = " . $value->id )->row()->catcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active shcat" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->category_name .'</span>
                                            <span class="exam-count-box-list-count">'. $catcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
							
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
									
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list shsub" id="shsub'.$value->id.'" style="display: none;">';
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{	
                                    	    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 2 and tbl_posts.exam_subcat = " . $subval->id )->row()->subcatcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active shsuba" id="'. $subval->id .'">
                                            <span class="exam-count-box-list-text">'. $subval->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
									
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
								
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{
                                    
											$subsub = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $subval->id )->result();
											
											if( !empty( $subsub ) )
											{	
												echo '<div class="exam-count-box-list shsubsub" id="shsubsub'. $subval->id .'" style="display: none;">';
												
												foreach( $subsub as $key => $subsubval )
												{	
													
												$sscnt = $this->db->query( "SELECT count( * ) as sscnt FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 2 and tbl_posts.exam_subsubcat = " . $subsubval->id )->row()->sscnt;
												
												/*
												echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
												*/
												
												echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $subsubval->id .'">
													<span class="exam-count-box-list-text">'. $subsubval->title .'</span>
													<span class="exam-count-box-list-count">'. $sscnt .'</span>
												</a>';
												
												}
												
												echo '</div>';
											}
									
                                    	}                                    	
                                    
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="exam-count-box">
                        <div class="exam-count-box-header">
                            <span class="exam-title">Post MCQ</span>
                            <span class="exam-count"><?=$umcqp?></span>
                        </div>
                        <div class="exam-count-box-content">
                            <div class="row">
							
								<div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
                                    $cat = $this->db->query( "SELECT * FROM `tbl_categories`" )->result();
                                    
                                    if( !empty( $cat ) )
                                    {	
                                        echo '<div class="exam-count-box-list">';
                                        
                                        foreach( $cat as $key => $value )
                                    	{	
                                    	    
                                    	$catcnt = $this->db->query( "SELECT count( * ) as catcnt FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 3 and tbl_posts.exam_category = " . $value->id )->row()->catcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active pmcat" id="'. $value->id .'">
                                            <span class="exam-count-box-list-text">'. $value->category_name .'</span>
                                            <span class="exam-count-box-list-count">'. $catcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
                                    
                                    ?>
                                    
                                </div>
							
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
                                    
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
									
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        echo '<div class="exam-count-box-list pmsub" id="pmsub'.$value->id.'" style="display: none;">';
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{	
                                    	    
                                    	$subcatcnt = $this->db->query( "SELECT count( * ) as subcatcnt FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 3 and tbl_posts.exam_subcat = " . $subval->id )->row()->subcatcnt;
                                    	
                                    	/*
                                    	echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
                                    	*/
                                    	
                                    	echo '<a href="javascript:void(0)" class="exam-count-box-list-item active pmsuba" id="'. $subval->id .'">
                                            <span class="exam-count-box-list-text">'. $subval->title .'</span>
                                            <span class="exam-count-box-list-count">'. $subcatcnt .'</span>
                                        </a>';
                                    	
                                    	}
                                    	
                                    	echo '</div>';
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                                <div class="col-md-4">
                                    <!--
                                    <div class="exam-count-box-list">
                                        <a href="javascript:void(0)" class="exam-count-box-list-item active">
                                            <span class="exam-count-box-list-text">Gk Exam</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Maths </span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Static GK</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">Current Affairs</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                        <a href="javascript:void(0)" class="exam-count-box-list-item">
                                            <span class="exam-count-box-list-text">SSB Interview</span>
                                            <span class="exam-count-box-list-count">653</span>
                                        </a>
                                    </div>
                                    -->
                                    <?php
									
							if( !empty( $cat ) )
							{	
								foreach( $cat as $key => $value )
								{
								
                                    $subcat = $this->db->query( "SELECT * FROM `tbl_subcategories` where id_category = " . $value->id )->result();
                                    
                                    if( !empty( $subcat ) )
                                    {	
                                        
                                        foreach( $subcat as $key => $subval )
                                    	{
                                    
											$subsub = $this->db->query( "SELECT * FROM `tbl_subsubcategory` where id_subcategory = " . $subval->id )->result();
											
											if( !empty( $subsub ) )
											{	
												echo '<div class="exam-count-box-list pmsubsub" id="pmsubsub'. $subval->id .'" style="display: none;">';
												
												foreach( $subsub as $key => $subsubval )
												{	
													
												$sscnt = $this->db->query( "SELECT count( * ) as sscnt FROM `tbl_posts` inner join `tbl_users` on `tbl_posts`.`userid` = `tbl_users`.`id` where id_role = 3 and tbl_posts.status = 3 and tbl_posts.exam_subsubcat = " . $subsubval->id )->row()->sscnt;
												
												/*
												echo "SELECT count( * ) as subcatcnt FROM `tbl_posts` where tbl_posts.exam_subcat = " . $value->id;
												*/
												
												echo '<a href="javascript:void(0)" class="exam-count-box-list-item active submp" id="'. $subsubval->id .'">
													<span class="exam-count-box-list-text">'. $subsubval->title .'</span>
													<span class="exam-count-box-list-count">'. $sscnt .'</span>
												</a>';
												
												}
												
												echo '</div>';
											}
									
                                    	}                                    	
                                    
                                    }
									
								}
								
							}
                                    
                                    ?>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		

        <!-- new dashboard end -->
          
        
        
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

