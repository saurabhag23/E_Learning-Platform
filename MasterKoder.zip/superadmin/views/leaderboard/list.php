

<body class="hold-transition skin-blue sidebar-mini fixed">

<div class="wrapper">

  <?php $this->load->view('layout/top-menu'); ?>

  <?php $this->load->view('layout/side-menu'); ?>

  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

      <h1>

        Leaderboard 
		
		<a href="<?= admin_url('') ?>leaderboard/editlinks">
			<button class="btn btn-success btn-sm btn-flat" title="Edit Link Text"><i class="fa fa-edit"></i> Edit Link Text </button>
		</a>

		<!--<?= top_image_buttons('dailyquiz'); ?><?= top_textual_buttons('dailyquiz'); ?>-->

      </h1>

      <ol class="breadcrumb">

        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>

        <li><a href="<?= admin_url('courses') ?>">Courses</a></li>

        <li class="active">All topics</li>

      </ol>

    </section>



    <!-- Main content -->

    <section class="content">

      <div class="row">

        <div class="col-xs-12">

          <div class="box">

            <div class="box-header with-border">

                <i class="fa fa-book"></i>

                <h3 class="box-title"><a href=""></a></h3>

            </div>

            <!-- /.box-header -->

            <div class="box-body">

			  <ul class="nav nav-tabs">
				<li class="active"><a data-toggle="tab" href="#menu2">Daily Rank</a></li>
				<li><a data-toggle="tab" href="#home">Weekly Rank</a></li>
				<li><a data-toggle="tab" href="#menu1">Monthly Rank</a></li>							
			  </ul>

			  <div class="tab-content">
			  
				<div id="menu2" class="tab-pane fade in active" >
				  
				  <table id="leaduTable" class="table table-responsive table-bordered table-striped">

					<thead>

					<tr>

						<th>RANK</th>

						<th>USER</th>
						
						<th>TOTAL COINS</th>

						<th>RIGHT ANSWER</th>

						<th>REFERALS</th>


					</tr>

					</thead>
					
					<tbody>
<?php					
if( !empty( $dailyusers ) )
{	

	$rank = 1;
	
	foreach( $dailyusers as $key => $value )
	{	
	
		echo '<tr>

				<td>'.$rank.'</td>

				<td>'. $value->uname .'</td>
				
				<td>'. $value->totcoins .'</td>

				<td>' . $value->totcorrect . '</td>

				<td> - </td>

			</tr>';
			
		$rank++;
		
	}
}
?>
					
					</tbody>

				  </table>
				  
				</div>
			  
				<div id="home" class="tab-pane fade">
				
				  <table id="leadwTable" class="table table-responsive table-bordered table-striped">

					<thead>

					<tr>

						<th>RANK</th>

						<th>USER</th>
						
						<th>TOTAL COINS</th>

						<th>RIGHT ANSWER</th>

						<th>REFERALS</th>


					</tr>

					</thead>
					
					<tbody>
<?php					
if( !empty( $weekusers ) )
{	

	$rank = 1;
	
	foreach( $weekusers as $key => $value )
	{	
	
		echo '<tr>

				<td>'.$rank.'</td>

				<td>'. $value->uname .'</td>
				
				<td>'. $value->totcoins .'</td>

				<td>' . $value->totcorrect . '</td>

				<td> - </td>

			</tr>';
			
		$rank++;
		
	}
}
?>
					
					</tbody>

				  </table>
				  
				</div>
				
				<div id="menu1" class="tab-pane fade">
				
				  <table id="leadmTable" class="table table-responsive table-bordered table-striped">

					<thead>

					<tr>

						<th>RANK</th>

						<th>USER</th>
						
						<th>TOTAL COINS</th>

						<th>RIGHT ANSWER</th>

						<th>REFERALS</th>


					</tr>

					</thead>
					
					<tbody>
<?php					
if( !empty( $monthusers ) )
{	

	$rank = 1;
	
	foreach( $monthusers as $key => $value )
	{	
	
		echo '<tr>

				<td>'.$rank.'</td>

				<td>'. $value->uname .'</td>
				
				<td>'. $value->totcoins .'</td>

				<td>' . $value->totcorrect . '</td>

				<td> - </td>

			</tr>';
			
		$rank++;
		
	}
}
?>
					
					</tbody>

				  </table>
				  
				</div>
				
				
				
			  </div>

            </div>

            <!-- /.box-body -->

          </div>

          <!-- /.box -->

        </div>

        <!-- /.col -->

      </div>

      <!-- /.row -->

    </section>

    <!-- /.content -->

  </div>


<div id="infoModal" class="modal fade" role="dialog" aria-labelledby="alertModal" aria-hidden="true">

  <div class="modal-dialog modal-md">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal">&times;</button>

        <h4 class="modal-title"></h4>

      </div>

      <div class="modal-body"></div>

      <div class="modal-footer">

        <button type="button" class="btn btn-default cl_btn" data-dismiss="modal">Close</button>

      </div>

    </div>

  </div>

</div>