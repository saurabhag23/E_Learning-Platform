
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>	 
        Update Leaderboard Links
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('tools') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('leaderboard') ?>">Quick Links</a></li>
        <li class="active">Update Leaderboard Links</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content admin_Quick Links">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('leaderboard/update') ?>" method="post" id="feedup" name="feedup" >
              <div class="box-body">
                
				<h3> Daily Rank </h3>
				
                <div class="form-group">
                  <label for="daily_url1_txt">Url link 1 Text</label>
                  <input type="text" class="form-control" id="daily_url1_txt" placeholder="Title" name="daily_url1_txt" value="<?=$leaderboard[0]->daily_url1_txt?>">
				  
				 <?php echo form_error('daily_url1_txt'); ?>				  
                </div>
              

                <div class="form-group">
                  <label for="daily_url1">Url link 1</label>
                  <input type="text" class="form-control" id="daily_url1" placeholder="Title" name="daily_url1" value="<?=$leaderboard[0]->daily_url1?>">
				  
				 <?php echo form_error('daily_url1'); ?>				  
                </div>
				
                <div class="form-group">
                  <label for="daily_url2_txt">Url link 2 Text</label>
                  <input type="text" class="form-control" id="daily_url2_txt" placeholder="Title" name="daily_url2_txt" value="<?=$leaderboard[0]->daily_url2_txt?>">
				  
				 <?php echo form_error('daily_url2_txt'); ?>				  
                </div>
              

                <div class="form-group">
                  <label for="daily_url2">Url link 2</label>
                  <input type="text" class="form-control" id="daily_url2" placeholder="Title" name="daily_url2" value="<?=$leaderboard[0]->daily_url2?>">
				  
				 <?php echo form_error('daily_url2'); ?>				  
                </div>
			
				<h3> Weekly Rank </h3>
				
                <div class="form-group">
                  <label for="week_url1_txt">Url link 1 Text</label>
                  <input type="text" class="form-control" id="week_url1_txt" placeholder="Title" name="week_url1_txt" value="<?=$leaderboard[0]->week_url1_txt?>">
				  
				 <?php echo form_error('week_url1_txt'); ?>				  
                </div>
              

                <div class="form-group">
                  <label for="week_url1">Url link 1</label>
                  <input type="text" class="form-control" id="week_url1" placeholder="Title" name="week_url1" value="<?=$leaderboard[0]->week_url1?>">
				  
				 <?php echo form_error('week_url1'); ?>				  
                </div>
				
                <div class="form-group">
                  <label for="week_url2_txt">Url link 2 Text</label>
                  <input type="text" class="form-control" id="week_url2_txt" placeholder="Title" name="week_url2_txt" value="<?=$leaderboard[0]->week_url2_txt?>">
				  
				 <?php echo form_error('week_url2_txt'); ?>				  
                </div>
              

                <div class="form-group">
                  <label for="week_url2">Url link 2</label>
                  <input type="text" class="form-control" id="week_url2" placeholder="Title" name="week_url2" value="<?=$leaderboard[0]->week_url2?>">
				  
				 <?php echo form_error('week_url2'); ?>				  
                </div>
				
				<h3> Monthly Rank </h3>
				
                <div class="form-group">
                  <label for="monthly_url1_txt">Url link 1 Text</label>
                  <input type="text" class="form-control" id="monthly_url1_txt" placeholder="Title" name="monthly_url1_txt" value="<?=$leaderboard[0]->monthly_url1_txt?>">
				  
				 <?php echo form_error('monthly_url1_txt'); ?>				  
                </div>
              

                <div class="form-group">
                  <label for="monthly_url1">Url link 1</label>
                  <input type="text" class="form-control" id="monthly_url1" placeholder="Title" name="monthly_url1" value="<?=$leaderboard[0]->monthly_url1?>">
				  
				 <?php echo form_error('monthly_url1'); ?>				  
                </div>
				
                <div class="form-group">
                  <label for="monthly_url2_txt">Url link 2 Text</label>
                  <input type="text" class="form-control" id="monthly_url2_txt" placeholder="Title" name="monthly_url2_txt" value="<?=$leaderboard[0]->monthly_url2_txt?>">
				  
				 <?php echo form_error('monthly_url2_txt'); ?>				  
                </div>
              

                <div class="form-group">
                  <label for="monthly_url2">Url link 2</label>
                  <input type="text" class="form-control" id="monthly_url2" placeholder="Title" name="monthly_url2" value="<?=$leaderboard[0]->monthly_url2?>">
				  
				 <?php echo form_error('monthly_url2'); ?>				  
                </div>
			
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="update">
				
				<input type="submit" id="save" name="save" value="Save" class="btn btn-primary btn-sm pull-right btn-green">
				
				
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
