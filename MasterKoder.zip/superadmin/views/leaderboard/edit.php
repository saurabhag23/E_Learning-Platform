
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>	 
        Update Quick Links
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('tools') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('quick_Links') ?>">Quick Links</a></li>
        <li class="active">Update New Quick Links</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content admin_Quick Links">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('quicklinks/update') ?>" method="post" id="feedup" name="feedup" >
              <div class="box-body">
                
                <div class="form-group">
                  <label for="title">Title</label>
                  <input type="text" class="form-control" id="title" placeholder="Title" name="title" value="<?=$row->title?>">
				  
				 <?php echo form_error('title'); ?>				  
                </div>
              

                <div class="form-group">
                  <label for="url">Super Category</label>
                  <?php
				  /*
				  	$opt = array( "" => "Select", "0" => "Parent" );
					echo form_dropdown( 'parent', $opt, '', 'id="parent" class="form-control"' );
					*/
				  ?>				  
				  
                  <?php
				  
					if( !empty( $tbl_categories ) )
					{
						$opt = array(''=>'Select');
						
						foreach( $tbl_categories as $key => $value )
						{
							$opt[ $value->id ] = $value->category_name;							
						}
						
						echo form_dropdown('parent', $opt, $row->supercat, 'id="parent" class="form-control" onChange="geteaxamsubcategory()"');
					}
					
				  ?>
				  
				 <?php echo form_error('parent'); ?>			  
                </div>
				
                <div class="form-group">
                  <label for="subcat">Category</label>
                  					
					<select class="form-control examsubcat" id="subcat" name="subcat" onChange="getsubsubcats()">
						<option value="">Select Category </option>

					<?php

					
					foreach($subcats as $subcats)
					{
						   if( $subcats->id == $row->cat )
						   {
							 $sel = "selected='selected'";
						   }
						   else
						   {
							 $sel ="";
						   }
					?>
					  <option value="<?=$subcats->id?>" <?=$sel?>><?=$subcats->title?></option>
					<?php
					}
					?>
					
					
					</select>
				  
				 <?php echo form_error('subcat'); ?>				  
                </div>

                <div class="form-group">
                  <label for="subsub">Sub Category</label>
				  
				  <?php 
				  /*
				  echo '<pre>';
				  var_dump( $row );
				  echo '<hr>' . $row->subcat;
				  */
				  ?>
				  
					<select class="form-control subsub" id="subsub" name="subsub" >
						<option value="">Select Sub Category </option>
						<?php
						
						
						
						foreach($subsub as $subsub)
						{
							 if( $subsub->id == $row->subcat )
							 {
								 $sel = "selected='selected'";
							 }
							 else
							 {
								$sel ="";
							 }
						?>
						  <option value="<?=$subsub->id?>" <?=$sel?>><?=$subsub->title?></option>
						<?php
						 }
						?>
					</select>
				  
				 <?php echo form_error('subsub'); ?>				  
                </div>
				
				<div class="form-group">
                  <label for="numposts">No. of posts to show</label>
                  <input type="number" class="form-control" id="numposts" placeholder="Select No. of posts" name="numposts" value="<?=$row->numposts?>">
				  
				 <?php echo form_error('numposts'); ?>				  
                </div>
			

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <input type="hidden" name="action" value="update">
				<input type="hidden" name="id" value="<?=$row->id?>">
				
                <input type="hidden" name="save_pub" id="save_pub" value="0">
				<input type="hidden" name="role" value="<?=$this->uri->segment('4')?>">
				<input type="button" id="save" name="save" value="Save" class="btn btn-primary btn-sm pull-right btn-green">
				<input type="button" id="publish" name="publish" value="Publish" class="btn btn-primary btn-sm pull-right btn-green">
				
				
                
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
