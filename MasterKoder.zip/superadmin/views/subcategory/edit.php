
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <?php $this->load->view('layout/top-menu'); ?>
  <?php $this->load->view('layout/side-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Update Category
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?= admin_url('') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?= admin_url('subcategory') ?>">Category</a></li>
        <li class="active">Update Category</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->
            <form class="process-form" action="<?= admin_url('subcategory/update') ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">

                <div class="col-md-12">
                 <div class="form-group">
                     <label for="first_name">Exam Super Category</label>
                        
						<select class="form-control" id="category" name="category">
						<option value="">Select Sub Category</option>
							<?php
							foreach($categories as $categories)
							{
							   if($categories->id == $row->id_category)
							   {
								 $sel = "selected='selected'";
							   }
							   else
							   {
								 $sel ="";
							   }
							?>
								<option value="<?=$categories->id ?>" <?=$sel?>><?=$categories->category_name?></option>
							<?php
							}
							?>
						
						
                        </select>
                    </div>


                  <div class="form-group">
                    <label for="first_name">Category Title</label>
                    <input type="text" class="form-control" id="title"  name="title" value="<?=$row->title ?>">
                  </div>
                 <div class="form-group ">
                        <label class="control-label">Description</label>
                        <textarea id="editor" name="content" class="form-control" placeholder="Content" rows="15"><?=base64_decode($row->description)?></textarea>
                </div>
				<div class="form-group ">
                        <label class="control-label">Image</label>
                       	<input  type="file" class="form-control" name="image" id="image" >
                </div>
                  <div class="form-group">
                      
                         <input type="checkbox"   name="allow" value="1"<?php if($row->user_postallowed ==1 ){ echo'checked="checked"'; }?>>
						 <label for="first_name"> Allow the Front  user to post in this  category</label>
                    </div>
                </div>

                

                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <div class="col-md-12">
                  <input type="hidden" name="action" value="update">
                  <input type="hidden" name="id" value="<?=  $row->id ?>">
                  <button type="submit" class="btn btn-primary btn-sm pull-right btn-green">Update</button>
                </div>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

  <div id="infoModal" class="modal fade" role="dialog" aria-labelledby="alertModal" aria-hidden="true">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Featured Image</h4>
        </div>
        <div class="modal-body"></div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default cl_btn" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>