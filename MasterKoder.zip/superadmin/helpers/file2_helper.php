<?php

function is_dir_empty($dir) {
    if (!is_readable($dir))
        return NULL;
    return (count(scandir($dir)) == 2);
}

function do_image_upload($path, $file, $options = array(), $require = 1) {
    $ci = & get_instance();
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
    $config['file_name'] = 'temp_name';
    $config['file_ext_tolower'] = TRUE;
    $config['remove_spaces'] = TRUE;
    if (!empty($options)) {
        foreach ($options as $index => $value) {
            $config[$index] = $value;
        }
    }
    $ci->upload->initialize($config);
    if ($require == 1) {
        if (!$ci->upload->do_upload($file)) {
            return array('error' => set_error($ci->upload->display_errors()));
        } else {
            $image = $ci->upload->data();
            return array('name' => $image['file_name']);
        }
    } else {
        if ($_FILES[$file]['name'] != "") {
            if (!$ci->upload->do_upload($file)) {
                return array('error' => set_error($ci->upload->display_errors()));
            } else {
                $image = $ci->upload->data();
                return array('name' => $image['file_name']);
            }
        } else {
            return array('name' => '');
        }
    }
}

function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir) || is_link($dir)) {
        return unlink($dir);
    }
    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }
        if (!deleteDirectory($dir . "/" . $item, false)) {
            chmod($dir . "/" . $item, 0777);
            if (!deleteDirectory($dir . "/" . $item, false))
                return false;
        };
    }
    return rmdir($dir);
}
