<?php
	function admin_url($url, $type = 0){
		if($type == 1){
			return base_url('superadmin/'.$url);
		}
		else{
			return site_url('superadmin/'.$url);
		}
	}

	function admin_session_name(){
		return 'superadmin_user';
	}

	function set_error($error){
		return '<label class="control-label error">'.$error.'</label>';
	}
	function has_permission($page, $mode){
		$ci = & get_instance();
		$session_name  	= admin_session_name();
	    $user 			= $ci->session->userdata($session_name);
		 $group          = $user->id_role;

		$ci->db->where("group_id", $group);
		$res = $ci->db->get('tbl_permissions');
		if($res->num_rows() > 0){
			$results = $res->result();
			if(count($results) > 0){
				foreach($results as $result){
					$module = $result->module;
					unset($result->module);
					unset($result->group_id);
					unset($result->id);
					foreach($result as $i => $r){
						$permission[$module][$i] = $r;
					}
				}
			}
		}
		
		if(isset($permission[$page][$mode])){
			if($permission[$page][$mode] == 1){
				return TRUE;
			}
		}

		return FALSE;
	}