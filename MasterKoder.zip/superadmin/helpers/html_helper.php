<?php

function generate_menus($menus, $active_page, $level = 0) {
    $CI = & get_instance();
    $CI->load->library('permissions', 'tbl_permissions');
    $CI->session_name = admin_session_name();
    $CI->user = $CI->session->userdata($CI->session_name);
    if (count($menus > 0)) {
        if ($level == 0) {
            $list = '<ul class="sidebar-menu" data-widget="tree">';
        } else {
            $list = '<ul class="treeview-menu">';
        }


        foreach ($menus as $key => $menu) {
            $class = '';
            if ($menu['has_sub'] == 1) {
                $class .= 'treeview ';
            }
            if ($active_page == $menu['page']) {
                $class .= 'active ';
            }

            if ($menu['has_sub'] == 1) {
                if (array_search($active_page, array_column($menu['submenus'], 'page')) !== FALSE) {
                    $class .= 'menu-open active';
                }
            }

            $list .= '<li class="' . $class . '">';

            if ($CI->permissions->has_permission($CI->user->id_role, strtolower($menu['page']), 'dashboard_view')) {
                if ($menu['page'] == 'roles') {
                    $page = 'Settings';
                } else {
                    $page = $menu['page'];
                }
                $list .= '<a href="' . (($menu['has_sub'] == 1) ? "javascript:;" : admin_url($menu['url'])) . '">
				                   <div class="admin-sidenav-icons ' . $menu['icon'] . '"> <i class="fa ' . $menu['icon'] . '"></i></div> <span>' . $page . '</span>';
                if ($menu['has_sub'] == 1) {
                    $list .= '<span class="pull-right-container">
								                      <i class="fa fa-angle-left pull-right"></i>
								                   </span>';
                }

                $list .= '</a>';
            }

            if ($menu['has_sub'] == 1) {
                $list .= generate_menus($menu['submenus'], $active_page, 1);
            }
            $list .= '</li>';
        }
        $list .= '</ul>';
    }
    return $list;
}

function action_buttons($id, $page, $view = 0, $edit = 0, $delete = 0, $hide = 0, $view_page = 0, $permission = 0) {
    $CI = & get_instance();
    $CI->load->library('permissions', 'tbl_permissions');
    $CI->session_name = admin_session_name();
    $CI->user = $CI->session->userdata($CI->session_name);
    $html = '';
    if ($view == 1) {
        if ($CI->permissions->has_permission($CI->user->id_role, strtolower($page), 'view')) {
            $html .= '<form class="process-form form-inline" action="' . admin_url($page . "/view") . '" method="post">
		    			<input type="hidden" name="id" value="' . $id . '">
		    			<input type="hidden" name="action" value="viewRow">
		    			<button class="btn btn-info btn-xs" title="View">
		    				<i class="fa fa-info-circle"></i>
		    			</button>
		    		  </form>';
        }
    }
	else if ($view == 2){
        if ($CI->permissions->has_permission($CI->user->id_role, strtolower($page), 'view')) {

            $html .= '	<a href="' . admin_url($page . "/view/" . $id, 1) . '">
								<button class="btn btn-primary btn-xs" title="View">
									<i class="fa fa-info-circle"></i>
								</button>
						</a>';
		
        }
	}

    if ($view_page == 1) {
        $html .= '<a href="' . admin_url($page . "/details/" . $id, 1) . '">
		                <button class="btn btn-info btn-xs" title="View">
		                    <i class="fa fa-info-circle"></i>
		                </button>
		            </a>';
    }


    if ($edit == 1) {
        if ($CI->permissions->has_permission($CI->user->id_role, strtolower($page), 'edit')) {
            $html .= '<a href="' . admin_url($page . "/edit/" . $id, 1) . '">
								<button class="btn btn-primary btn-xs" title="Edit">
									<i class="fa fa-edit"></i>
								</button>
							</a>';
        }
    }
    if ($hide == 1) {
        if ($CI->permissions->has_permission($CI->user->id_role, strtolower($page), 'status')) {
            $html .= '<form class="process-form form-inline" action="' . admin_url($page . "/hide") . '" method="post">
							<input type="hidden" name="id" value="' . $id . '">
							<input type="hidden" name="action" value="hideRow">
							<button class="btn btn-warning btn-xs" title="Hide" onclick="return confirm(\'Do you want to hide this?\')">
								<i class="fa fa-toggle-off"></i>
							</button>
						  </form>';
        }
    } else if ($hide == -1) {

        $html .= '<form class="process-form form-inline" action="' . admin_url($page . "/approve") . '" method="post">
		    			<input type="hidden" name="id" value="' . $id . '">
		    			<input type="hidden" name="action" value="approve">
		    			<button class="btn btn-warning btn-xs" title="Approve" onclick="return confirm(\'Do you want to Approve this instructor and Send the admin url?\')">
		    				<i class="fa fa-toggle-off"></i>
		    			</button>
		    		  </form>';
    } else if ($hide == -2) {
        $html .= "";
    } else {
        $html .= '<form class="process-form form-inline" action="' . admin_url($page . "/unhide") . '" method="post">
		    			<input type="hidden" name="id" value="' . $id . '">
		    			<input type="hidden" name="action" value="unhideRow">
		    			<button class="btn btn-success btn-xs" title="Unhide" onclick="return confirm(\'Do you want to active this?\')">
		    				<i class="fa fa-toggle-on"></i>
		    			</button>
		    		  </form>';
    }

    if ($delete == 1) {
        if ($CI->permissions->has_permission($CI->user->id_role, strtolower($page), 'delete')) {
            $html .= '<form class="process-form form-inline" action="' . admin_url($page . "/delete") . '" method="post">
							<input type="hidden" name="id" value="' . $id . '">
							<input type="hidden" name="action" value="deleteRow">
							<button class="btn btn-danger btn-xs" onclick="return confirm(\'Do you want to delete this?\')" title="Delete">
								<i class="fa fa-trash"></i>
							</button>
						  </form>';
        }
    }
    if ($permission == 1) {
        if ($CI->permissions->has_permission($CI->user->id_role, strtolower($page), 'permission')) {
            $html .= '<a href="' . admin_url($page . "/permissions/" . $id, 1) . '">
								<button class="btn btn-info btn-xs" title="Permission">
									<i class="fa fa-lock"></i>
								</button>
							</a>';
        }
    }

    return $html;
}

function top_buttons($page, $id = 0, $add = 1, $type = 0) {
    $CI = & get_instance();
    $CI->load->library('permissions', 'tbl_permissions');
    $html = '';
    ($id != 0) ? $id = '/' . $id : $id = '';
    if ($add == 1) {
        if ($CI->permissions->has_permission($CI->user->id_role, strtolower($page), 'add')) {
            $html .= '<a href="' . admin_url($page . "/add" . $id, $type) . '">
								<button class="btn btn-success btn-sm btn-flat" title="Edit"><i class="fa fa-plus"></i> Add New </button>
							 </a>';
        }
    }
    return $html;
}

function top_image_buttons($page, $id = 0, $add = 1, $type = 0) {
    $CI = & get_instance();
    $CI->load->library('permissions', 'tbl_permissions');
    $html = '';
    ($id != 0) ? $id = '/' . $id : $id = '';
    if ($add == 1) {
        if ($CI->permissions->has_permission($CI->user->id_role, strtolower($page), 'add')) {
            $html .= '<a href="' . admin_url($page . "/add_image" . $id, $type) . '">
								<button class="btn btn-success btn-sm btn-flat" title="Edit"><i class="fa fa-plus"></i> Add Image New </button>
							 </a>';
        }
    }
    return $html;
}
function top_textual_buttons($page, $id = 0, $add = 1, $type = 0) {
    $CI = & get_instance();
    $CI->load->library('permissions', 'tbl_permissions');
    $html = '';
    ($id != 0) ? $id = '/' . $id : $id = '';
    if ($add == 1) {
        if ($CI->permissions->has_permission($CI->user->id_role, strtolower($page), 'add')) {
            $html .= '<a href="' . admin_url($page . "/add_textual" . $id, $type) . '">
								<button class="btn btn-success btn-sm btn-flat" title="Edit"><i class="fa fa-plus"></i> Add Textual New </button>
							 </a>';
        }
    }
    return $html;
}


/*
				$this->myadmin->data['menus'][2] = array('name' 	=> 'Courses', 
													 'url'  	=> 'courses', 
													 'page' 	=> 'course', 
													 'icon'		=> 'fa-book', 
													 'has_sub' 	=> 1, 
													 'submenus' => array(array('name' 	=> 'Courses', 
													 	                       'url'  	=> 'courses', 
													 	                       'page' 	=> 'course', 
													 	                       'icon' 	=> 'fa-book', 
													 	                       'has_sub'=> 0),

																	     array('name' 	=> 'Topics', 
																	     	   'url'    => '#', 
																	     	   'page'   => 'topics', 
																	     	   'icon' 	=> 'fa-pencil', 
																	     	   'has_sub'=> 0)));
*/